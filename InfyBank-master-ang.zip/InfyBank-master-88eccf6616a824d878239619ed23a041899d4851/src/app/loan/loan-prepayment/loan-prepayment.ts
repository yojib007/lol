export class LoanPrePayment {
    'fromAccount': string;
    'prepayAmount': number;
    'paymentOption': string;
    'loanAcctNo': string;
}
