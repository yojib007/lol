export class AmmortizationSchedule {
    'loanAcctNo': string;
    'interestRate': number;
    'installmentNo': number;
    'installmentAmount': number;
    'installmentDate': string;
    'principalComponent': number;
    'interestComponent': number;
    'openingPrincipal': number;
    'closingPrincipal': number;
    'status': string;
}
