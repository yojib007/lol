import { AmmortizationSchedule } from './ammortization-schedule';

export class Ammortization {
    'ammortizationList': AmmortizationSchedule[];
    'totalNoOfInstallments': number;
}
