import { SuccessMessageService } from './../../shared/success-message.service';
import { UserInformationService } from './../../shared/user-information.service';
import { FormsModule } from '@angular/forms';
import { AmmortizationScheduleComponent } from './ammortization-schedule.component';
import { Observable } from 'rxjs/Observable';
import { LoansAccount } from './../../account-detail/account-summary/loans-account';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DownloadService } from './../../shared/download.service';
import { AmmortizationScheduleService } from './ammortization-schedule.service';
import { Ammortization } from './ammortization';
import { AccountService } from './../../shared/account.service';
import { ProfileService } from './../../shared/profile.service';

class AmmortizationScheduleServiceStub {
    getAmmortizationSchedule() {
        return Observable.of(new Ammortization());
    }
}

class AccountServiceStub {
    accountSummary() {
        return Observable.of({
            loanAccountDtoList: [{
                loanAcctNo: '123456',
                loanStatus: 'A'
            }]
        });
    }
}

class DownloadServiceStub {
    asPdf() { }
    asExcel() { }
}
describe('AmmortizationScheduleComponent', () => {
    const ammortizationScheduleServiceStub = new AmmortizationScheduleServiceStub();
    const accountServiceStub = new AccountServiceStub();
    const downloadServiceStub = new DownloadServiceStub();
    let component: AmmortizationScheduleComponent;
    let fixture: ComponentFixture<AmmortizationScheduleComponent>;
    let accountService;
    let ammortizationScheduleService;
    let downloadService;
    let loanObject1;
    let loanObject2;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule],
            declarations: [AmmortizationScheduleComponent],
            providers: [
                { provide: AmmortizationScheduleService, useValue: ammortizationScheduleServiceStub },
                { provide: AccountService, useValue: accountServiceStub },
                { provide: DownloadService, useValue: downloadServiceStub },
                UserInformationService, SuccessMessageService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AmmortizationScheduleComponent);
        component = fixture.componentInstance;
        accountService = TestBed.get(AccountService);
        ammortizationScheduleService = TestBed.get(AmmortizationScheduleService);
        downloadService = TestBed.get(DownloadService);
        fixture.detectChanges();
        loanObject1 = {

            loanAcctNo: '123456',
            loanStatus: 'A'
        };

        loanObject2 = {

            loanAcctNo: '123457',
            loanStatus: 'S'
        };
    });

    // Checking everything is created
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking call should be made to accountSummary method of AccountService
    it('should invoke accountSummary method of AccountService', () => {
        const spy = spyOn(accountService, 'accountSummary').and.returnValue(Observable.of({ loanAccountDtoList: [loanObject1] }));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('on recieving data from accountSummary method of AccountService', () => {

        let spy;

        beforeEach(() => {
            spyOn(accountService, 'accountSummary').and.returnValue(Observable.of({ loanAccountDtoList: [loanObject1] }));
            spy = spyOn(component, 'getAmmortizationSchedule');
            component.ngOnInit();
        });

        // Checking accountNumber is populated
        it('should populate the accountNumber', () => {
            expect(component.accountNumber).toBeDefined();
        });

        // Checking call made to getAmmortizationSchedule function
        it('should call getAmmortizationSchedule method', () => {
            expect(spy).toHaveBeenCalled();
        });
    });

    // Checking error is populated if no loan object with status as A is recieved from accountSummary method
    it('should populate error if no loan object with status as A is recieved from accountSummary method', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.of({ loanAccountDtoList: [loanObject2] }));
        component.error = null;
        component.ngOnInit();
        expect(component.error).toBeDefined();
    });

    // Checking error is populated if error is thrown from accountSummary method of AccountService
    it('should populate error if error is thrown from accountSummary method of AccountService', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.error).toBe('Server Error');
    });

    describe('invoking getAmmortizationSchedule method', () => {

        // Checking call should be made to getAmmortizationSchedule method of getAmmortizationScheduleService
        it('should invoke getAmmortizationSchedule method of getAmmortizationScheduleService', () => {
            const spy = spyOn(ammortizationScheduleService, 'getAmmortizationSchedule').and.returnValue(Observable.of(new Ammortization()));
            component.getAmmortizationSchedule();
            expect(spy).toHaveBeenCalled();
        });

        // Checking loanAcctNo is populated
        it('should populate the loanAcctNo on recieving data from getAmmortizationSchedule method of AmmortizationScheduleService', () => {
            spyOn(ammortizationScheduleService, 'getAmmortizationSchedule').and.returnValue(Observable.of(new Ammortization()));
            component.getAmmortizationSchedule();
            expect(component.ammortization).toBeDefined();
        });

        // Checking error is populated if error is thrown from getAmmortizationSchedule method of AmmortizationScheduleService
        it('should populate error if error is thrown from getAmmortizationSchedule method of AmmortizationScheduleService', () => {
            spyOn(ammortizationScheduleService, 'getAmmortizationSchedule').and.returnValue(Observable.throw('Server Error'));
            component.getAmmortizationSchedule();
            expect(component.error).toBe('Server Error');
        });
    });

    describe('invoking downloadDetails method', () => {

        // Checking asPdf method of DownloadService has been called
        it('should call asPdf method of DownloadService is downloadStat is pdf', () => {
            component.downloadStat = 'pdf';
            const spy = spyOn(downloadService, 'asPdf');
            component.downloadDetails();
            expect(spy).toHaveBeenCalled();
        });

        // Checking asExcel method of DownloadService has been called
        it('should call asExcel method of DownloadService is downloadStat is xls', () => {
            component.downloadStat = 'xls';
            const spy = spyOn(downloadService, 'asExcel');
            component.downloadDetails();
            expect(spy).toHaveBeenCalled();
        });
    });
});
