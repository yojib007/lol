import { SuccessMessageService } from './../../shared/success-message.service';
import { UserInformationService } from './../../shared/user-information.service';
import { DownloadService } from './../../shared/download.service';
import { Component, OnInit, Input } from '@angular/core';
import { AmmortizationScheduleService } from './ammortization-schedule.service';
import { Ammortization } from './ammortization';
import { AccountService } from './../../shared/account.service';
import { ProfileService } from './../../shared/profile.service';

@Component({
  selector: 'app-ammortization-schedule',
  templateUrl: './ammortization-schedule.component.html',
  styleUrls: ['./ammortization-schedule.component.css']
})
export class AmmortizationScheduleComponent implements OnInit {

  ammortization: Ammortization;
  downloadStat = 'pdf';
  error: string[];
  accountNumber: string;
  noLoan: string;
  @Input() loanAcctNo: string;

  constructor(private ammort: AmmortizationScheduleService, private accountService: AccountService,
    private userInformationService: UserInformationService, private downloadService: DownloadService,
    private successMessageService: SuccessMessageService) { }

  getAmmortizationSchedule() {
    this.ammort.getAmmortizationSchedule(this.loanAcctNo).subscribe(
      ammort => this.ammortization = ammort,
      error => this.error = error
    );
  }

  downloadDetails() {
    if (this.downloadStat === 'pdf') {
      this.downloadService.asPdf('#download');
    } else if (this.downloadStat === 'xls') {
      this.downloadService.asExcel('download');
    }
  }

  getLoanDetails() {
   // this.accountService.accountSummary().subscribe(
    //  data => {
    //    const loanDetail = data.loanAccounts.find(loan => loan.loanStatus === 'A');
    //    this.error = null;
    //    if (loanDetail) {
         // this.accountNumber = loanDetail.loanAcctNo;
          this.getAmmortizationSchedule();
       // } else {
        //  this.noLoan = `ERRORS.AMMORTIZSHDL.NOLOAN`;
       // }
   //   },
    //  error => this.error = error
   // );
  }
  ngOnInit() {
    this.successMessageService.view = 'loan';
    this.successMessageService.subView = 'ammSdl';
   // this.getLoanDetails();
   this.getAmmortizationSchedule();
  }
}
