import { StatusPipe } from './status.pipe';

describe('StatusPipe', () => {
  let pipe;

  beforeEach(() => {
    pipe = new StatusPipe();
  });

  // Checking everything is created
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  // Checking Approved is returned if A is passed
  it('should return Approved if A is passed', () => {
    expect(pipe.transform('A')).toBe('Approved');
  });

  // Checking Submitted is returned if S is passed
  it('should return Submitted if S is passed', () => {
    expect(pipe.transform('S')).toBe('Submitted');
  });

});
