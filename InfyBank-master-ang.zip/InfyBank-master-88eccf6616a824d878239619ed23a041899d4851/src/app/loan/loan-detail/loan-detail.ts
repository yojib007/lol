export class LoanDetail {
    'loanAcctNo': string;
    'loanAmount': number;
    'tenure': number;
    'emi': number;
    'loanStatus': string;
    'totalInterestPaid': number;
    'expectedClosureDate': string;
    'totalPrincipalAmount': number;
    'outstandingAmount': number;
    'lastPrepaymentDate': string;
}
