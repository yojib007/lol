import { UserInformationService } from './../../shared/user-information.service';
import { SuccessMessageService } from './../../shared/success-message.service';
import { Component, OnInit } from '@angular/core';
import { LoanDetail } from './loan-detail';
import { AccountSummary } from './../../account-detail/account-summary/account-summary';
import { LoanDetailService } from './loan-detail.service';
import { AccountService } from './../../shared/account.service';
import { ProfileService } from './../../shared/profile.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-loan-detail',
  templateUrl: './loan-detail.component.html',
  styleUrls: ['./loan-detail.component.css']
})
export class LoanDetailComponent implements OnInit {
  loanDetails: LoanDetail;
  error: string[];
  loanAcctNo: string;
  noLoan: string;
  constructor(private loanInfo: LoanDetailService, private userInformationService: UserInformationService,
    private accountService: AccountService, private successMessageService: SuccessMessageService,
    private route: ActivatedRoute) { }

  loanDetail() {
    this.loanInfo.loanDetail(this.loanAcctNo).subscribe(
      data => {
        this.loanDetails = data;
        this.error = null;
      },
      error => this.error = error
    );
  }

  ngOnInit() {
    this.successMessageService.view = 'loan';
    this.successMessageService.subView = 'lnDtl';
    this.loanAcctNo = this.route.snapshot.paramMap.get('loanAcctno');
    this.loanDetail();
  }
}
