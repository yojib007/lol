import { LoanDetailService } from './loan-detail.service';
import { UserDetails } from './../../register/user-details/user-details';
import { UserInformationService } from './../../shared/user-information.service';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../../shared/rest-service';
import { ProfileService } from './../../shared/profile.service';
import { UserInformation } from './../../shared/user-information';
import { TestBed, inject } from '@angular/core/testing';

class UserInformationServiceStub {
  userDetail = new UserInformation();
}

class RestServiceStub {
  get() { }
}

describe('LoanDetailService', () => {
  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoanDetailService,
        { provide: RestService, useValue: restServiceStub },
        { provide: UserInformationService, useValue: userInformationServiceStub },
      ]
    }).compileComponents();
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([LoanDetailService], (service: LoanDetailService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the loanDetail function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([LoanDetailService], (service: LoanDetailService) => {

        const spy = spyOn(restService, 'get');
        service.loanDetail('12345');
        expect(spy).toHaveBeenCalled();

      }));

    // Checking loanDetail function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([LoanDetailService], (service: LoanDetailService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.of(true));
        service.loanDetail('12345').subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking loanDetail function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([LoanDetailService], (service: LoanDetailService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.throw('Server Error'));
        service.loanDetail('12345').subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

});
