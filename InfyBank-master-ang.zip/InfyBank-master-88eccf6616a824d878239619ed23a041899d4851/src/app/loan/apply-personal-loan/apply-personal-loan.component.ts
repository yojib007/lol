import { SuccessMessageService } from './../../shared/success-message.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplyPersonalLoanService } from './apply-personal-loan.service';
import { LoanInfo } from './loan-info';
import { ApplyPersonalInfo } from './apply-personal-info';
import { AccountService } from './../../shared/account.service';
import { ValidatorsService } from './../../shared/validators.service';
import { UserInformationService } from './../../shared/user-information.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-apply-personal-loan',
  templateUrl: './apply-personal-loan.component.html',
  styleUrls: ['./apply-personal-loan.component.css']
})
export class ApplyPersonalLoanComponent implements OnInit {

  loanInfo: LoanInfo;
  loanPersonalInfo: ApplyPersonalInfo;
  accountNumbers: string[];
  loanForm: FormGroup;
  error: string[];
  errorMessage: string[];
  submit: boolean;

  constructor(private apply: ApplyPersonalLoanService, private validatorsService: ValidatorsService,
    private formBuilder: FormBuilder, private accser: AccountService, private router: Router,
    private successMessageService: SuccessMessageService) { }

  createForm() {
    this.loanForm = this.formBuilder.group({
      debitAcctNo: ['', Validators.required],
      tenure: ['', Validators.required],
      loanAmount: ['', [Validators.required, Validators.min(1)]],
      custId: [''],
      userId: ['']
    });
  }

  applyPersonalLoan() {
    this.submit = true;
    this.apply.applyPersonalLoan(this.loanForm.value).subscribe(
      data => {
        this.successMessageService.message = 'APPLYLOAN.SUCCESS';
        this.router.navigate(['/account/acctsumm']);
      },
      error => {
        this.error = error;
        this.submit = false;
      }
    );
  }

  getAccountNumbers() {
    this.accser.getAccountNumbers().subscribe(
      data => {
        this.accountNumbers = data;
        this.createForm();
      },
      error => this.errorMessage = error
    );
  }

  ngOnInit() {
    this.successMessageService.view = 'loan';
    this.successMessageService.subView = 'aplyLn';
    this.getAccountNumbers();
  }
}
