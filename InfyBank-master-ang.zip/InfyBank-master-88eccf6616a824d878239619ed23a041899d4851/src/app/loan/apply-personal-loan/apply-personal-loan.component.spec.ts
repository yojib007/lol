import { ApplyPersonalLoanComponent } from './apply-personal-loan.component';
import { ApplyPersonalLoanService } from './apply-personal-loan.service';
import { By } from '@angular/platform-browser';
import { AccountService } from './../../shared/account.service';
import { ValidatorsService } from './../../shared/validators.service';
import { SuccessMessageService } from './../../shared/success-message.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';

class AccountServiceStub {
    getAccountNumbers() {
        return Observable.of(['123456', '125678', '123678']);
    }
}

class ApplyPersonalLoanServiceStub {
    applyPersonalLoan() { }
}

class ValidatorsServiceStub {
    isFieldHasErrors() { }
}

describe('ApplyPersonalLoanComponent', () => {
    const validatorsServiceStub = new ValidatorsServiceStub();
    const accountServiceStub = new AccountServiceStub();
    const applyPersonalLoanServiceStub = new ApplyPersonalLoanServiceStub();
    let component: ApplyPersonalLoanComponent;
    let fixture: ComponentFixture<ApplyPersonalLoanComponent>;
    let router;
    let successMessageService;
    let accountService;
    let validatorsService;
    let applyLoanService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule, ReactiveFormsModule],
            declarations: [ApplyPersonalLoanComponent],
            providers: [
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                { provide: AccountService, useValue: accountServiceStub },
                { provide: ApplyPersonalLoanService, useValue: applyPersonalLoanServiceStub },
                SuccessMessageService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ApplyPersonalLoanComponent);
        component = fixture.componentInstance;
        router = TestBed.get(Router);
        successMessageService = TestBed.get(SuccessMessageService);
        applyLoanService = TestBed.get(ApplyPersonalLoanService);
        validatorsService = TestBed.get(ValidatorsService);
        accountService = TestBed.get(AccountService);
        fixture.detectChanges();
    });

    // Checking everything is created properly
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking getAccountNumbers method of accountService has been called
    it('should call getAccountNumbers method of accountService', () => {
        const spy = spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.of(['123456', '789012']));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('on recieving data from getAccountNumbers method of accountService', () => {

        let spy;
        beforeEach(() => {
            spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.of(['123456', '789012']));
            spy = spyOn(component, 'createForm');
            component.ngOnInit();
        });

        // Checking accountList has been populated
        it('should populate the accountList', () => {
            expect(component.accountNumbers).toBeDefined();
        });

        // Checking createForm method has been called
        it('should call createForm method', () => {
            expect(spy).toHaveBeenCalled();
        });

        // Should not populate errorMessage
        it('should not populate errorMessage', () => {
            expect(component.errorMessage).toBeUndefined();
        });

    });


    // Checking errorMessage is populated with message recieved from server
    it('should populate errorMessage with message returned from accountService if error is thrown', () => {
        spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.errorMessage).toMatch(`Server Error`);
    });

    describe('invoking applyPersonalLoan function', () => {

        // should call applyPersonalLoan method of applyLoanService
        it('should call applyPersonalLoan method of applyLoanService', () => {

            const spy = spyOn(applyLoanService, 'applyPersonalLoan').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.applyPersonalLoan();
            expect(spy).toHaveBeenCalled();
        });

        describe('on recieving data from applyPersonalLoan method of applyLoanService', () => {

            let spy;
            beforeEach(() => {
                spyOn(applyLoanService, 'applyPersonalLoan').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate');
                component.applyPersonalLoan();
            });

            // Populate message if data is recieved from applyPersonalLoan method of applyLoanService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/account/acctsumm']);
            });
        });

        // Populate error if error is thrown from applyPersonalLoan method of applyLoanService
        it('should populate error if error is thrown from applyPersonalLoan method of applyLoanService', () => {

            spyOn(applyLoanService, 'applyPersonalLoan').and.returnValue(Observable.throw('Server Error'));
            component.applyPersonalLoan();
            expect(component.error).toBe('Server Error');
        });
    });

    // createForm should initialize form
    it('should initialize loanForm if createForm method is invoked', () => {
        component.loanForm = null;
        component.createForm();
        expect(component.loanForm).not.toBeNull();
    });

    describe('has loanForm', () => {

        beforeEach(() => {
            component.createForm();
        });

        describe('has debitAcctNo field which is empty', () => {
            let errors = {};
            let debitAcctNo;
            beforeEach(() => {
                debitAcctNo = component.loanForm.controls['debitAcctNo'];
                debitAcctNo.setValue('');
                errors = debitAcctNo.errors || {};
                fixture.detectChanges();
            });

            // Checking debitAcctNo is invalid if it is empty
            it('should be invalid', () => {

                expect(debitAcctNo.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has debitAcctNo field which is filled', () => {
            let errors = {};
            let debitAcctNo;
            beforeEach(() => {
                debitAcctNo = component.loanForm.controls['debitAcctNo'];
                debitAcctNo.setValue('123456');
                errors = debitAcctNo.errors || {};
                fixture.detectChanges();
            });

            // Checking debitAcctNo is valid if it is filled
            it('should be valid', () => {

                expect(debitAcctNo.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has tenure field which is empty', () => {
            let errors = {};
            let tenure;
            beforeEach(() => {
                tenure = component.loanForm.controls['tenure'];
                tenure.setValue('');
                errors = tenure.errors || {};
                fixture.detectChanges();
            });

            // Checking tenure is invalid if it is empty
            it('should be invalid', () => {

                expect(tenure.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has tenure field which is filled', () => {
            let errors = {};
            let tenure;
            beforeEach(() => {
                tenure = component.loanForm.controls['tenure'];
                tenure.setValue(3);
                errors = tenure.errors || {};
                fixture.detectChanges();
            });

            // Checking tenure is valid if it is filled
            it('should be valid', () => {

                expect(tenure.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });


        describe('has loanAmount field which is empty', () => {
            let errors = {};
            let loanAmount;
            beforeEach(() => {
                loanAmount = component.loanForm.controls['loanAmount'];
                loanAmount.setValue('');
                errors = loanAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking loanAmount is invalid if it is empty
            it('should be invalid', () => {

                expect(loanAmount.valid).toBeFalsy();

            });

            // Checking required error is present if loanAmount is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has loanAmount field which is filled value less than one', () => {
            let errors = {};
            let loanAmount;
            beforeEach(() => {
                loanAmount = component.loanForm.controls['loanAmount'];
                loanAmount.setValue(-1);
                errors = loanAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking loanAmount is invalid if it is incorrect
            it('should be invalid', () => {

                expect(loanAmount.valid).toBeFalsy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required', () => {
                expect(errors['required']).toBeFalsy();

            });

            // Checking min error is present if loanAmount is invalid
            it('should contain min error', () => {
                expect(errors['min']).toBeTruthy();

            });

        });


        describe('has loanAmount field which is filled value less than one', () => {
            let errors = {};
            let loanAmount;
            beforeEach(() => {
                loanAmount = component.loanForm.controls['loanAmount'];
                loanAmount.setValue(1000);
                errors = loanAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking loanAmount is valid if it is filled
            it('should be valid', () => {

                expect(loanAmount.valid).toBeTruthy();

            });

            // Checking min error is not present if field is correct
            it('should not contain min error', () => {
                expect(errors['min']).toBeFalsy();

            });

        });

        describe('loanForm when all fields are valid', () => {

            let submitBtn;
            beforeEach(() => {
                submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
                component.loanForm.controls['debitAcctNo'].setValue('123456');
                component.loanForm.controls['tenure'].setValue(5);
                component.loanForm.controls['loanAmount'].setValue(1000);
                fixture.detectChanges();
            });

            // form should be valid if all feilds are filled properly
            it('should be valid', () => {

                expect(component.loanForm.valid).toBe(true);

            });

            // checking submit button is enabled if form is valid
            it('should has submit button enabled', () => {

                expect(submitBtn.disabled).toBe(false);

            });

            // applyPersonalLoan function should be called on clicking the submit button
            it('should call applyPersonalLoan function on clicking submit button', () => {

                const spy = spyOn(component, 'applyPersonalLoan');
                submitBtn.click();
                expect(spy).toHaveBeenCalled();
            });

        });
    });


});
