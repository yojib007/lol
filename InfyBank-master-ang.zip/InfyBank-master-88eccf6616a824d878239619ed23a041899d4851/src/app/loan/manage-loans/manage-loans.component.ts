import { Component, OnInit } from '@angular/core';
import {AccountService } from '../../shared/account.service';
import {LoansAccount} from  "./loans-account";
import { SuccessMessageService } from './../../shared/success-message.service';
import { UserInformationService} from '../../shared/user-information.service';
@Component({
  selector: 'app-manage-loans',
  templateUrl: './manage-loans.component.html',
  styleUrls: ['./manage-loans.component.css']
})
export class ManageLoansComponent implements OnInit {
  loanAccounts: LoansAccount[];
  noLoan: string;
  error: string[];
  date: string;
  constructor(private loanService: AccountService, private userInformationService: UserInformationService, private successMessageService: SuccessMessageService) { 
   
    this.loanService.getLoanDetails().subscribe(
      data => {
          this.loanAccounts = <LoansAccount[]>data;
          if(this.loanAccounts.length==0)
          this.noLoan = `ERRORS.LOANDETAIL.NOLOAN`;
         console.log(JSON.stringify(this.loanAccounts));
      },
      error => this.error = error
  );
 
  }

  ngOnInit() {
    this.date = (new Date().getMonth() + 1) + '/' + (new Date().getDate()) + '/' + new Date().getFullYear();
  
  }

  
}
