export class LoansAccount {
    'loanAcctNo': string;
    'loanAmount': number;
    'tenure': number;
    'emi': number;
    "interestRate": number;
    'loanStatus': string;
    'outstandingBalance': number;
    'totalInterestPaid': number;
   
    'expectedClosureDate': string;
    'lastPrepaymentDate': string;
    'lstUpdtTs': string;
    'totalPrincipalAmount': number;
   
}
