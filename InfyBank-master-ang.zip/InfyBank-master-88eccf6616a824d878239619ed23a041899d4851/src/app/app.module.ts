import { UserInformationService } from './shared/user-information.service';
import { AppCurrencyPipe } from './shared/app-currency.pipe';
import { AuthGuardAdminService } from './shared/auth-guard.admin.service';
import { AuthGuardUserService } from './shared/auth-guard.user.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SharedModule } from './shared/shared.module';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { RegisterModule } from './register/register.module';
import { RegisterService } from './register/register.service';
import { LoginModule } from './login/login.module';
import { WelcomeComponent } from './welcome/welcome.component';
import { AccountDetailModule } from './account-detail/account-detail.module';
import { FundTransferModule } from './fund-transfer/fund-transfer.module';
import { ProfileModule } from './profile/profile.module';
import { LoanModule } from './loan/loan.module';
import { ManagePayeeModule } from './manage-payee/manage-payee.module';
import { SuccessMessageService } from 'app/shared/success-message.service';

// AoT requires an exported function for factories
export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpModule,

    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    }),
    AppRoutingModule,
    RegisterModule,
    LoanModule,
    AccountDetailModule,
    SharedModule

  ],
  providers: [RegisterService, AuthGuardUserService, AuthGuardAdminService, UserInformationService, SuccessMessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
