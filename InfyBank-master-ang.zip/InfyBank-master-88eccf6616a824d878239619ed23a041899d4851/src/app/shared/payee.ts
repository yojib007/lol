export class Payee {

        'payeeId': number;
        'name': string;
        'nickName': string;
        'acctNo': string;
        'userId': string;
        'ifscCode': string;
        'acctType': string;
        'custId': number;
        'status': string;

}
