import { ProfileService } from './profile.service';
import { Profile } from './profile';
import { UserInformation } from './user-information';
import { UserDetails } from './../register/user-details/user-details';
import { Injectable } from '@angular/core';
import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

@Injectable()
export class UserInformationService {

    userDetail: UserInformation;
    profileDetail: Profile;

}
