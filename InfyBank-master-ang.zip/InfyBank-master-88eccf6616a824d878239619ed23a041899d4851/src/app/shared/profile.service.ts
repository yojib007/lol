import { RestService } from './rest-service';
import { UserInformationService } from './user-information.service';
import { UpdateProfile } from './update-profile';
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Profile } from './profile';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { UserInformation } from './user-information';

@Injectable()
export class ProfileService {

  url: string;
  constructor(public userInformationService: UserInformationService, private restService: RestService) { }

  getUserDetails(): Observable<Profile> {

    this.url = '/infybank_core/v1/customers/' + this.userInformationService.userDetail.custId;
    return this.restService.get(this.url);
  }

  update(profile: Profile) {

    this.url = '/infybank_core/v1/customers/' + this.userInformationService.userDetail.custId;
    const updateProfile: UpdateProfile = new UpdateProfile();
    updateProfile.address = profile.address;
    updateProfile.amountPref = profile.amountPref;
    updateProfile.city = profile.city;
    updateProfile.creditDebitLimit = profile.creditDebitLimit;
    updateProfile.datePref = profile.datePref;
    updateProfile.email = profile.email;
    updateProfile.pinCode = profile.pinCode;
    updateProfile.state = profile.state;
    updateProfile.userId = this.userInformationService.userDetail.userId;
    return this.restService.patch(this.url, updateProfile);
  }
}
