import { Injectable } from '@angular/core';
import * as jsPDF from 'jspdf';
declare var $;

@Injectable()
export class DownloadService {

  asPdf(tableId: string) {
    // console.log(tableId);
    const pdf = new jsPDF({cellWidth: 35,
      rowCount: 0,
      leftMargin: 2,
      topMargin: 12,
      topMarginTable: 55,
      headerRowHeight: 13,
      rowHeight: 9,
      orientation: 'l',
      unit: 'mm',
      format: 'a3',
      compress: true,
      fontSize: 8,
      lineHeight: 1,
      autoSize: false,
      printHeaders: true
    }, 'pt', 'a4');
    // console.log(tableId)
  const source = $(tableId)[0];
    const margins = {
        top: 80,
        bottom: 60,
        left: 40,
        width: 500
    };
    pdf.fromHTML(
    source,                                                                                           // HTML string or DOM elem ref.
    margins.left,                                                                // x coord
    margins.top, {                                                             // y coord
        'width': margins.width        // max width of content on PDF
    },

    function (dispose) {
      pdf.save('Bank_Statement.pdf');
    }, margins);
  }
  asExcel(tableId: string) {
    let table: any = tableId;
    const name: any = 'W3C Example Table';
    const uri = 'data:application/vnd.ms-excel;base64,',
      template = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" 
                  xmlns="http://www.w3.org/TR/REC-html40">
                  <head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name>
                  <x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>
                  </x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
                  <meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>
                  </head>
                  <body><table>{table}</table></body></html>`,
      base64 = function (s) {
        return window.btoa(decodeURIComponent(encodeURIComponent(s)));
      },
      format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }); };
    if (!table.nodeType) {
      table = document.getElementById(table);
    }
    const ctx = { worksheet: name || 'Worksheet', table: table.innerHTML };
    window.location.href = uri + base64(format(template, ctx));
  }

}
