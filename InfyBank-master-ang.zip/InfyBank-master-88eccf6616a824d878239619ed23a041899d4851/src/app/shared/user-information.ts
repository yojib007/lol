export class UserInformation {

    custId: number;
    userId: string;
    role: string;
}
