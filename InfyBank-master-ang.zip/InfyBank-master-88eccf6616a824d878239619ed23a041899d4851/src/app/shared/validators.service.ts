import { Component, Injectable } from '@angular/core';
import { FormGroup, FormControl, FormArray, AbstractControl } from '@angular/forms';
import { AccountService } from './account.service';


@Injectable()
export class ValidatorsService {

    accountBalance: number;
    loanAmount: number;
    error: any;

    constructor(private accountService: AccountService) { }

    findBalance(accountNo: string) {
        this.accountService.accountSummary().subscribe(
            data => {
                this.accountBalance = data.accounts
                    .find(account => account.acctNo === accountNo).balance;
                this.error = null;
            },
            error => this.error = error.message || error
        );
    }

    amountValidator = (c: FormControl) => {

        if (c && c.value) {
            if (this.accountBalance >= c.value) {
                return null;
            } else {
                return { 'balance': this.accountBalance };
            }
        }
    }

    loanAmountValidator = (c: FormControl) => {

        if (c && c.value) {

            if (this.loanAmount >= c.value) {
                return null;
            } else {
                return { 'loanBalance': this.loanAmount };
            }
        }
    }

    isFieldHasErrors(formObj, fieldName: string) {
        const field = formObj.controls[fieldName];
        if (field.errors && (field.dirty || field.touched)) {
            return true;
        }
        return false;
    }

    checkDate(c: FormControl) {
        if (c && c.value) {
            const selectedDate = new Date(c.value);
            const now = new Date();
            if (selectedDate > now) {
                return {
                    available: true
                };
            } else {

                return null;
            }
        }
    }

    checkDatePast(c: FormControl) {
        if (c && c.value) {
            const selectedDate = new Date(c.value).setHours(0, 0, 0, 0);
            const now = new Date().setHours(0, 0, 0, 0);
            if (selectedDate >= now) {
                return null;
            } else {
                return {
                    date: true
                };
            }
        }
    }

    validateScoreStart(c: FormControl) {
        const formGroup: FormGroup = c['_parent'];
        if (c && c.value && formGroup && formGroup.value.creditScoreEnd) {
            if (c.value > formGroup.value.creditScoreEnd) {
                return null;
            } else {
                return { creditScoreEnd: formGroup.value.creditScoreEnd };
            }

        }
    }

    validateScoreEnd(c: FormControl) {
        const formGroup: FormGroup = c['_parent'];
        if (formGroup) {
            const formArray: FormArray = formGroup['_parent'];
            let index: number;
            if (formGroup && formArray) {
                for (let i = 0; i < formArray.controls.length; i++) {
                    const currFormGroup: FormGroup = <FormGroup>formArray.controls[i];
                    if (currFormGroup.value === (formGroup.value)) {
                        index = i;
                    }
                }
                if (index === 0) {
                    return null;
                } else if (c.value === formArray.controls[index - 1].value.creditScoreStart + 1) {
                    return null;
                } else {
                    return { creditScoreStart: formArray.controls[index - 1].value.creditScoreStart + 1 };
                }
            }
        }
    }

    creditScore(c: AbstractControl) {

        if (c) {

            const formArrayControl = <FormArray>c.get('loanConfigDtoList');

            if (formArrayControl && formArrayControl.controls.length > 0) {

                for (let x = 0; x < formArrayControl.controls.length; x++) {
                    const formGroupControl1 = <FormGroup>formArrayControl.controls[x];

                    const creditScoreStart = formGroupControl1.get('creditScoreStart');
                    const creditScoreEnd = formGroupControl1.get('creditScoreEnd');
                    const interestRate = formGroupControl1.get('interestRate');
                    const loanApprovalInd = formGroupControl1.get('loanApprovalInd');

                    if (creditScoreEnd && creditScoreStart) {
                        if (creditScoreEnd.value <= creditScoreStart.value) {
                            creditScoreEnd.setErrors({ creditValue: creditScoreStart.value });
                        } else if (creditScoreEnd.value > 0) {
                            creditScoreEnd.setErrors(null);
                        }
                    }
                    if (interestRate) {
                        if (loanApprovalInd.value === 'Y' && !interestRate.value) {
                            interestRate.setErrors({ zero: true });
                        } else {
                            interestRate.setErrors(null);
                        }
                    }

                    if (x !== 0) {
                        const formGroupControl2 = <FormGroup>formArrayControl.controls[x - 1];
                        const creditScoreEnd2 = formGroupControl2.get('creditScoreEnd');
                        if (creditScoreStart.value !== creditScoreEnd2.value + 1) {
                            creditScoreStart.setErrors({ creditValue: creditScoreEnd2.value + 1 });
                        } else {
                            creditScoreStart.setErrors(null);
                        }
                    }
                }
            }
        }

    }

    fromAmountToAmount(c: AbstractControl) {

        const fromAmount = c.get('fromAmount');
        const toAmount = c.get('toAmount');

        if (fromAmount && toAmount) {
            if (!fromAmount.value && fromAmount.value !== 0 && !toAmount.value && toAmount.value !== 0) {
                toAmount.setErrors(null);
                fromAmount.setErrors(null);
            } else if (fromAmount.value || fromAmount.value === 0) {
                if (!toAmount.value && toAmount.value !== 0) {
                    toAmount.setErrors({ required: true });
                } else if (fromAmount.value > toAmount.value) {
                    toAmount.setErrors({ min: { value: fromAmount.value } });
                } else if (fromAmount.value === 0 && toAmount.value === 0) {
                    toAmount.setErrors({ min: { value: fromAmount.value } });
                } else {
                    toAmount.setErrors(null);
                }
            } else {
                if (!fromAmount.value && toAmount.value >= 0) {
                    fromAmount.setErrors({ required: true });
                } else {
                    fromAmount.setErrors(null);
                }
            }
        }
    }
}
