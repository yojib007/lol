import { TranslateService } from '@ngx-translate/core';
import { CustomErrorResponse } from './custom-error-response';
import { Injectable } from '@angular/core';
import { Component } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

@Injectable()
export class RestService {

    url = 'http://10.78.28.204:8080';
    constructor(private http: Http, private translate: TranslateService) { }

    get(url: string) {
        const headers = new Headers({ 'Content-Type': 'application/json', 'Accept-Language': this.translate.getBrowserLang() });
        const options = new RequestOptions({ headers: headers });
        return this.http.get(this.url + url, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }

    post(url, data) {
        const headers = new Headers({ 'Content-Type': 'application/json', 'Accept-Language': this.translate.getBrowserLang() });
        const options = new RequestOptions({ headers: headers });
        return this.http.post(this.url + url, data, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }

    delete(url: string) {
        const headers = new Headers({ 'Content-Type': 'application/json', 'Accept-Language': this.translate.getBrowserLang() });
        const options = new RequestOptions({ headers: headers });
        return this.http.delete(this.url + url, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }
    patch(url, data) {
        const headers = new Headers({ 'Content-Type': 'application/json', 'Accept-Language': this.translate.getBrowserLang() });
        const options = new RequestOptions({ headers: headers });
        return this.http.patch(this.url + url, data, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);
    }

    put(url, data) {
        const headers = new Headers({ 'Content-Type': 'application/json', 'Accept-Language': this.translate.getBrowserLang() });
        const options = new RequestOptions({ headers: headers });
        const body = JSON.stringify(data);
        return this.http.put(this.url + url, body, options)
            .map(this.extractData)
            .catch(this.handleErrorObservable);

    }

    extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        } else {
            return res['_body'] ? res.json() : true;
        }
    }

    handleErrorObservable(error: Response | any) {
        const errMsg = [];
        if (error instanceof Response) {

            if (error.status === 400 || error.status === 500 || error.status === 404) {
                const body = error.json();

                for (let i = 0; i < body.errors.length; i++) {
                    errMsg.push(body.errors[i].message);
                }
            } else {
                errMsg.push('UNKNOWNERROR');
            }

        } else {
            errMsg.push(error.message ? error.message : error.toString());
        }
        return Observable.throw(errMsg);
    }
}
