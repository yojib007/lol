export class AddPayee {

    'name': string;
    'nickName': string;
    'acctNo': number;
    'ifscCode': string;
    'acctType': string;
    'userId': string;

}
