import { Profile } from './profile';
import { PayeeService } from './payee.service';
import { UserInformationService } from './user-information.service';
import { Observable } from 'rxjs/Observable';
import { RestService } from './rest-service';
import { UserInformation } from './user-information';
import { TestBed, inject } from '@angular/core/testing';
import { ConfirmPayee } from './../manage-payee/confirm-payee/confirm-payee';
import { AddPayee } from './add-payee';
import { Payee } from './payee';

class UserInformationServiceStub {
  userDetail = new UserInformation();
  profileDetail = new Profile();
}

class RestServiceStub {
  get() { }
  put() { }
  post() { }
}

describe('PayeeService', () => {
  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PayeeService,
        { provide: RestService, useValue: restServiceStub },
        { provide: UserInformationService, useValue: userInformationServiceStub },
      ]
    }).compileComponents();
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([PayeeService], (service: PayeeService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the viewPayee function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'get');
        service.viewPayee();
        expect(spy).toHaveBeenCalled();

      }));

    // Checking viewPayee function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.of(true));
        service.viewPayee().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking viewPayee function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.throw('Server Error'));
        service.viewPayee().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

  describe('on calling the addPayee function', () => {

    let returnValue;
    let errMsg;

    // Checking post method of RestService is called
    it('should invoke post method of RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'post');
        service.addPayee(new AddPayee());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking addPayee function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
        service.addPayee(new AddPayee()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking addPayee function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
        service.addPayee(new AddPayee()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

  describe('on calling the confirmPayee function', () => {

    let returnValue;
    let errMsg;

    // Checking put method of RestService is called
    it('should invoke put method of RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'put');
        service.confirmPayee(new Payee(), new ConfirmPayee());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking confirmPayee function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.of(true));
        service.confirmPayee(new Payee(), new ConfirmPayee()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking confirmPayee function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.throw('Server Error'));
        service.confirmPayee(new Payee(), new ConfirmPayee()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

  describe('on calling the deletePayee function', () => {

    let returnValue;
    let errMsg;

    // Checking put method of RestService is called
    it('should invoke put method of RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'put');
        service.deletePayee(new Payee());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking deletePayee function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.of(true));
        service.deletePayee(new Payee()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking deletePayee function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([PayeeService], (service: PayeeService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.throw('Server Error'));
        service.deletePayee(new Payee()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });
});
