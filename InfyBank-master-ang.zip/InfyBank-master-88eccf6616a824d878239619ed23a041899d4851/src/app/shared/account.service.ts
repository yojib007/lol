import { Accountstatement } from './../account-detail/account-statement/accountstatement';
import { AccountSummary } from './../account-detail/account-summary/account-summary';
import { RestService } from './rest-service';
import { UserInformationService } from './user-information.service';
import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import { AccountTransaction } from 'app/account-detail/account-statement/account-transaction';

@Injectable()
export class AccountService {
  accounts:any[];
  accountSummaryUrl: string;
  accountNoUrl: string;
  acct_stmt_url = '/infybank_core/v1/customers/';
  constructor(private userInfo: UserInformationService, private restService: RestService) { }


  accountSummary(): Observable<AccountSummary> {
    console.log(this.userInfo.userDetail);
    console.log(this.userInfo.profileDetail);
    this.accountSummaryUrl = '/infybank_core/v1/customers/' + this.userInfo.userDetail.custId + '/account-summary';
    return this.restService.get(this.accountSummaryUrl);
  }

  getAccountNumbers(): Observable<string[]> {
    this.accountNoUrl = '/infybank_core/v1/customers/' + this.userInfo.userDetail.custId + '/accounts?onlyAcctNo=true';
    return this.restService.get(this.accountNoUrl);

  }
  getAccountStatement(accountTransaction: AccountTransaction, accountNumber): Observable<Accountstatement[]> {
    let paramUrl = this.userInfo.userDetail.custId + '/accounts/' + accountNumber + '/transactions?';
    if (accountTransaction.startDate) {
      paramUrl += 'startDate=' + accountTransaction.startDate + '&';
    }
    if (accountTransaction.endDate) {
      paramUrl += 'endDate=' + accountTransaction.endDate + '&';
    }
    if (accountTransaction.fromAmount) {
      paramUrl += 'fromAmount=' + accountTransaction.fromAmount + '&';
    }
    if (accountTransaction.toAmount) {
      paramUrl += 'toAmount=' + accountTransaction.toAmount + '&';
    }
    if (accountTransaction.txnType) {
      paramUrl += 'txnType=' + accountTransaction.txnType + '&';
    }
    if (accountTransaction.lastMonth) {
      paramUrl += 'lastMonth=' + accountTransaction.lastMonth + '&';
    }
    paramUrl = paramUrl.slice(0, -1);
    return this.restService.get(this.acct_stmt_url + paramUrl);
  }

  getLoanDetails(){
    this.accountNoUrl = '/infybank_core/v1/customers/' + this.userInfo.userDetail.custId + '/loans';
    return this.restService.get(this.accountNoUrl);
    
  }
}
