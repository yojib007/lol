import { CustomError } from './custom-error';
export class CustomErrorResponse {
    errors: CustomError[];
}
