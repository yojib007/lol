import { DownloadService } from './download.service';
import { SuccessMessageService } from './success-message.service';
import { ProfileService } from './profile.service';

import { AccountService } from './account.service';
import { PayeeService } from './payee.service';
import { UserInformationService } from './user-information.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RestService } from './rest-service';
import { ValidatorsService } from './validators.service';
import { PayeePipe } from './payee.pipe';
import { AppCurrencyPipe } from './app-currency.pipe';

@NgModule({
    imports: [FormsModule, ReactiveFormsModule],
    declarations: [
        PayeePipe,
        AppCurrencyPipe
    ],
    exports: [
        AppCurrencyPipe
    ],
    providers: [
        RestService,
        ValidatorsService,
        PayeeService,
        AccountService,
        ProfileService,
        DownloadService
    ]
})
export class SharedModule { }
