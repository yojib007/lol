import { AccountService } from './account.service';
import { AccountDetails } from './../register/account-details/account-details';
import { Observable } from 'rxjs/Rx';
import { TestBed, inject } from '@angular/core/testing';
import { ValidatorsService } from './validators.service';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';

class AccountServiceStub {
    accountSummary() { }
}

describe('ValidatorsService', () => {

    let registerForm: FormGroup;
    const accountServiceStub = new AccountServiceStub();
    const formBuilder: FormBuilder = new FormBuilder();
    let accountService;
    let accountSummary;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ValidatorsService,
                { provide: AccountService, useValue: accountServiceStub }
            ],
        }).compileComponents();

        accountService = TestBed.get(AccountService);
        accountSummary = {
            'totalAssets': 10000,
            'totalLiability': 5000,
            accountDtoList: [{
                'acctNo': '123456',
                'acctType': 'S',
                'balance': 5000,
                'salaried': 'Y'
            },
            {
                'acctNo': '123457',
                'acctType': 'S',
                'balance': 10000,
                'salaried': 'Y'
            }
            ],
            loanAccountDtoList: [{
                'loanAcctNo': '12345',
                'loanAmount': 5000,
                'loanStatus': 'A'
            }
            ]
        };
        registerForm = formBuilder.group({
            aadhar: ['', [Validators.required, Validators.pattern('[1-9][0-9]{11}')]],
            fromAccountNo: ['12345'],
            amount: [],
            date: [],
            loanRate: formBuilder.array([
                formBuilder.group({
                    creditScoreEnd: [],
                    creditScoreStart: []
                }),
                formBuilder.group({
                    creditScoreEnd: [],
                    creditScoreStrat: []
                }),
            ])
        });

    });

    // Checking whether the service is injectable
    it('can instantiate service when inject service',
        inject([ValidatorsService], (service: ValidatorsService) => {
            expect(service instanceof ValidatorsService).toBe(true);
        }));

    it('should return true on passing a form with field filled with value which fails to meets pattern validator',
        inject([ValidatorsService], (service: ValidatorsService) => {
            registerForm.controls['aadhar'].setValue('213132231');
            registerForm.controls['aadhar'].markAsDirty();
            expect(service.isFieldHasErrors(registerForm, 'aadhar')).toBe(true);
        }));

    it('should return true on passing a form with field filled with value which fails to meets required validator',
        inject([ValidatorsService], (service: ValidatorsService) => {
            registerForm.controls['aadhar'].setValue('');
            registerForm.controls['aadhar'].markAsDirty();
            expect(service.isFieldHasErrors(registerForm, 'aadhar')).toBe(true);
        }));

    it('should return false on passing a form with field filled with value which fails to meets required validator',
        inject([ValidatorsService], (service: ValidatorsService) => {
            registerForm.controls['aadhar'].setValue('123456789101');
            registerForm.controls['aadhar'].markAsDirty();
            expect(service.isFieldHasErrors(registerForm, 'aadhar')).toBe(false);
        }));

    it('should return false on passing a form with field which is untouched',
        inject([ValidatorsService], (service: ValidatorsService) => {
            expect(service.isFieldHasErrors(registerForm, 'aadhar')).toBe(false);
        }));

    describe('invoking findBalance method', () => {

        // Checking call should be made to accountSummary method of AccountService
        it('should invoke accountSummary method of AccountService',
            inject([ValidatorsService], (service: ValidatorsService) => {
                const spy = spyOn(accountService, 'accountSummary').and.returnValue(Observable.of(accountSummary));
                service.findBalance('123456');
                expect(spy).toHaveBeenCalled();
            }));

        // Checking accountBalance is populated
        it('should populate the accountSummary on recieving data from accountSummary method of AccountService',
            inject([ValidatorsService], (service: ValidatorsService) => {
                spyOn(accountService, 'accountSummary').and.returnValue(Observable.of(accountSummary));
                service.findBalance('123456');
                expect(service.accountBalance).toBe(5000);
            }));

        // Checking error is populated if error is thrown from accountSummary method of AccountService
        it('should populate error if error is thrown from accountSummary method of AccountService',
            inject([ValidatorsService], (service: ValidatorsService) => {
                spyOn(accountService, 'accountSummary').and.returnValue(Observable.throw('Server Error'));
                service.findBalance('123456');
                expect(service.error).toBe('Server Error');
            }));
    });

    describe('invoking amountValidator method', () => {

        it('should return error object if accountBalance is less than passed field value',
            inject([ValidatorsService], (service: ValidatorsService) => {
                service.accountBalance = 1000;
                const formControl: FormControl = <FormControl>registerForm.controls['amount'];
                formControl.setValue(10000);
                expect(service.amountValidator(formControl)).toEqual({ 'balance': service.accountBalance });
            }));

        it('should return null if accountBalance is greater than passed field value',
            inject([ValidatorsService], (service: ValidatorsService) => {
                service.accountBalance = 1000;
                const formControl: FormControl = <FormControl>registerForm.controls['amount'];
                formControl.setValue(50);
                expect(service.amountValidator(formControl)).toBeNull();
            }));
    });

    describe('invoking loanAmountValidator method', () => {

        it('should return error object if loanAmount is less than passed field value',
            inject([ValidatorsService], (service: ValidatorsService) => {
                service.loanAmount = 1000;
                const formControl: FormControl = <FormControl>registerForm.controls['amount'];
                formControl.setValue(10000);
                expect(service.loanAmountValidator(formControl)).toEqual({ 'loanBalance': service.loanAmount });
            }));

        it('should return null if loanAmount is greater than passed field value',
            inject([ValidatorsService], (service: ValidatorsService) => {
                service.loanAmount = 1000;
                const formControl: FormControl = <FormControl>registerForm.controls['amount'];
                formControl.setValue(50);
                expect(service.loanAmountValidator(formControl)).toBeNull();
            }));
    });

    describe('invoking checkDate method', () => {

        it('should return error object if future date is passed in field value',
            inject([ValidatorsService], (service: ValidatorsService) => {
                const formControl: FormControl = <FormControl>registerForm.controls['date'];
                formControl.setValue(new Date().setDate(new Date().getDate() + 1));
                expect(service.checkDate(formControl)).toEqual({ available: true });
            }));

        it('should return null if present or past date is passed in field value',
            inject([ValidatorsService], (service: ValidatorsService) => {
                const formControl: FormControl = <FormControl>registerForm.controls['date'];
                formControl.setValue(new Date().toLocaleDateString());
                expect(service.checkDate(formControl)).toBeNull();
            }));
    });

    describe('invoking checkDatePast method', () => {

        it('should return error object if past date is passed in field value',
            inject([ValidatorsService], (service: ValidatorsService) => {
                const formControl: FormControl = <FormControl>registerForm.controls['date'];
                formControl.setValue(new Date().setDate(new Date().getDate() - 1));
                expect(service.checkDatePast(formControl)).toEqual({ date: true });
            }));

        it('should return null if present or future date is passed in field value',
            inject([ValidatorsService], (service: ValidatorsService) => {
                const formControl: FormControl = <FormControl>registerForm.controls['date'];
                formControl.setValue(new Date().toLocaleDateString());
                expect(service.checkDatePast(formControl)).toBeNull();
            }));
    });

    describe('invoking validateScoreStart method', () => {

        let formArray: FormArray;
        let formGroup: FormGroup;
        let formControlOther: FormControl;
        let formControl: FormControl;

        beforeEach(() => {
            formArray = <FormArray>registerForm.controls['loanRate'];
            formGroup = <FormGroup>formArray.controls[0];
            formControlOther = <FormControl>formGroup.controls['creditScoreEnd'];
            formControl = <FormControl>formGroup.controls['creditScoreStart'];
        });

        it('should return error object if creditScoreStart is less than creditScoreEnd',
            inject([ValidatorsService], (service: ValidatorsService) => {

                formControlOther.setValue(200);
                formControl.setValue(100);
                expect(service.validateScoreStart(formControl)).toEqual({ creditScoreEnd: registerForm.value.loanRate[0].creditScoreEnd });
            }));

        it('should return null if if creditScoreStart is less than creditScoreEnd',
            inject([ValidatorsService], (service: ValidatorsService) => {
                formControlOther.setValue(50);
                formControl.setValue(100);
                expect(service.validateScoreStart(formControl)).toBeNull();
            }));
    });

    describe('invoking validateScoreEnd method', () => {

        let formArray: FormArray;
        let formGroup: FormGroup;
        let formGroupBefore: FormGroup;
        let formControlOther: FormControl;
        let formControl: FormControl;
        let formControlBefore: FormControl;

        beforeEach(() => {
            formArray = <FormArray>registerForm.controls['loanRate'];
            formGroupBefore = <FormGroup>formArray.controls[0];
            formGroup = <FormGroup>formArray.controls[1];
            formControlOther = <FormControl>formGroupBefore.controls['creditScoreStart'];
            formControl = <FormControl>formGroup.controls['creditScoreEnd'];
            formControlBefore = <FormControl>formGroupBefore.controls['creditScoreEnd'];
        });

        it('should return error object if creditScoreEnd is not equal to next digit of creditScoreStart of before one',
            inject([ValidatorsService], (service: ValidatorsService) => {

                formControlOther.setValue(200);
                formControl.setValue(100);
                expect(service.validateScoreEnd(formControl))
                    .toEqual({ creditScoreStart: registerForm.value.loanRate[0].creditScoreStart + 1 });
            }));

        it('should return null if if creditScoreEnd is equal to next digit of creditScoreStart of before formGroup',
            inject([ValidatorsService], (service: ValidatorsService) => {
                formControlOther.setValue(100);
                formControl.setValue(101);
                expect(service.validateScoreEnd(formControl)).toBeNull();
            }));

        it('should return null if if creditScoreEnd is first formGroup in formArray',
            inject([ValidatorsService], (service: ValidatorsService) => {
                formControlBefore.setValue(10);
                expect(service.validateScoreEnd(formControlBefore)).toBeNull();
            }));
    });
});
