import { AccountService } from './account.service';
import { UserInformationService } from './user-information.service';
import { Observable } from 'rxjs/Observable';
import { RestService } from './rest-service';
import { UserInformation } from './user-information';
import { TestBed, inject } from '@angular/core/testing';

class UserInformationServiceStub {
    userDetail = new UserInformation();
}

class RestServiceStub {
    get() { }
    post() { }
}

describe('AccountService', () => {
    const restServiceStub = new RestServiceStub();
    const userInformationServiceStub = new UserInformationServiceStub();
    let restService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [AccountService,
                { provide: RestService, useValue: restServiceStub },
                { provide: UserInformationService, useValue: userInformationServiceStub },
            ]
        }).compileComponents();
        restService = TestBed.get(RestService);
    });

    it('should be created', inject([AccountService], (service: AccountService) => {
        expect(service).toBeTruthy();
    }));

    describe('on calling the accountSummary function', () => {

        let returnValue;
        let errMsg;

        // Checking get method of RestService is called
        it('should invoke get method of RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'get');
                service.accountSummary();
                expect(spy).toHaveBeenCalled();

            }));

        // Checking accountSummary function returning the Observable of true returned from RestService
        it('should return Obervable of true which is returned from RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'get').and.returnValue(Observable.of(true));
                service.accountSummary().subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(returnValue).toBe(true);

            }));

        // Checking accountSummary function returning the Observable of error returned from RestService
        it('should return Obervable of error which is returned from RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'get').and.returnValue(Observable.throw('Server Error'));
                service.accountSummary().subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(errMsg).toBe('Server Error');

            }));
    });

    describe('on calling the getAccountNumbers function', () => {

        let returnValue;
        let errMsg;

        // Checking get method of RestService is called
        it('should invoke get method of RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'get');
                service.getAccountNumbers();
                expect(spy).toHaveBeenCalled();

            }));

        // Checking getAccountNumbers function returning the Observable of true returned from RestService
        it('should return Obervable of true which is returned from RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'get').and.returnValue(Observable.of(true));
                service.getAccountNumbers().subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(returnValue).toBe(true);

            }));

        // Checking getAccountNumbers function returning the Observable of error returned from RestService
        it('should return Obervable of error which is returned from RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'get').and.returnValue(Observable.throw('Server Error'));
                service.getAccountNumbers().subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(errMsg).toBe('Server Error');

            }));
    });

    describe('on calling the getAccountStatement function', () => {

        let returnValue;
        let errMsg;

        // Checking get method of RestService is called
        it('should invoke get method of RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'post');
                service.getAccountStatement({}, '12345');
                expect(spy).toHaveBeenCalled();

            }));

        // Checking getAccountStatement function returning the Observable of true returned from RestService
        it('should return Obervable of true which is returned from RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
                service.getAccountStatement({}, '12345').subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(returnValue).toBe(true);

            }));

        // Checking getAccountStatement function returning the Observable of error returned from RestService
        it('should return Obervable of error which is returned from RestService',
            inject([AccountService], (service: AccountService) => {

                const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
                service.getAccountStatement({}, '12345').subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(errMsg).toBe('Server Error');

            }));
    });
});
