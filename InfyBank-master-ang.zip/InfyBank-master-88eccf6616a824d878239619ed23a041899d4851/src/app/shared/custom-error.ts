export class CustomError {
    code: number;
    message: string;
}
