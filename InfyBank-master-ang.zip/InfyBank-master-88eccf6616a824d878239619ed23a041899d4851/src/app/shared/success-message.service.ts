import { Injectable } from '@angular/core';

@Injectable()
export class SuccessMessageService {

  message: string;
  view: string;
  subView: string;

}
