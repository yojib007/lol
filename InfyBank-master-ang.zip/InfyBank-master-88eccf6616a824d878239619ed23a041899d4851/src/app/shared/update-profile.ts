export class UpdateProfile {

        'email': string;
        'address': string;
        'city': string;
        'state': string;
        'pinCode': number;
        'creditDebitLimit': number;
        'amountPref': string;
        'datePref': string;
        'userId':  string;
}
