import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'appCurrency'
})
export class AppCurrencyPipe implements PipeTransform {

  transform(value: any, ...args: string[]): any {
   // if (value) {
      let returnValue = '';
      if (args[0].toLocaleLowerCase() === 'indian') {
        if (args.length <= 1 || args[1].toString() === 'true') {
          returnValue = '₹ ';
        } else {
          returnValue = 'INR ';
        }
        const amount = Math.round(value * 100) / 100;
        const stringAmount = amount.toString();
        const arrayAmount = stringAmount.split('.');
        let lastThree = arrayAmount[0].substring(arrayAmount[0].length - 3);
        const otherNumbers = arrayAmount[0].substring(0, arrayAmount[0].length - 3);
        if (otherNumbers !== '') {
          lastThree = ',' + lastThree;
        }
        const result = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;
        returnValue += result;
        if (arrayAmount[1]) {
          returnValue += '.' + arrayAmount[1];
        }
        else{
          returnValue+='.00';
        }
        return returnValue;

      } else if (args[0].toLocaleLowerCase() === 'international') {
        if (args.length <= 1 || args[1].toString() === 'true') {
          returnValue = '$ ';
        } else {
          returnValue = 'USD ';
        }
        const amount = Math.round(value * 100) / 100;
        const stringAmount = amount.toString();
        const arrayAmount = stringAmount.split('.');
        let lastThree = arrayAmount[0].substring(arrayAmount[0].length - 3);
        const otherNumbers = arrayAmount[0].substring(0, arrayAmount[0].length - 3);
        if (otherNumbers !== '') {
          lastThree = ',' + lastThree;
        }
        const result = otherNumbers.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + lastThree;
        returnValue += result;
        if (arrayAmount[1]) {
          returnValue += '.' + arrayAmount[1];
        }
        else{
          returnValue+='.00';
        }
        return returnValue;

      }
  //  }

  }
}
