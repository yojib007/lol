import { LoginService } from './login.service';
import { Login } from './Login';
import { Observable } from 'rxjs/Observable';
import { TestBed, inject } from '@angular/core/testing';
import { RestService } from '../../shared/rest-service';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

class RestServiceStub {
    post() { }
}

describe('LoginService', () => {
    const restServiceStub = new RestServiceStub();
    let login: Login;
    let restService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [LoginService,
                { provide: RestService, useValue: restServiceStub }],
        }).compileComponents();
        login = new Login();
        restService = TestBed.get(RestService);
    });

    // Checking weather the service is injectable
    it('can instantiate service when inject service',
        inject([LoginService], (service: LoginService) => {
            expect(service instanceof LoginService).toBe(true);
        }));

    describe('on calling the Login function', () => {

        let returnValue;
        let errMsg;

        // Checking Obervable contains true is returned on successful validation
        it('should invoke post method of RestService',
            inject([LoginService], (service: LoginService) => {

                const spy = spyOn(restService, 'post');
                service.checkUser(login);
                expect(spy).toHaveBeenCalled();

            }));

        it('should return Obervable of true which is returned from RestService',
            inject([LoginService], (service: LoginService) => {

                const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
                service.checkUser(login).subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(returnValue).toBe(true);

            }));

        it('should return Obervable of error which is returned from RestService',
            inject([LoginService], (service: LoginService) => {

                const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
                service.checkUser(login).subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(errMsg).toBe('Server Error');

            }));
    });

});
