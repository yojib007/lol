import { Observable } from 'rxjs/Rx';
import { UserInformation } from './../../shared/user-information';
import { RestService } from './../../shared/rest-service';
import { Injectable } from '@angular/core';
import {Login} from './Login';

@Injectable()
export class LoginService {

  url = '/infybank_core/v1/login';

  constructor(private restService: RestService) { }

  checkUser (login: Login): Observable<UserInformation> {

    return this.restService.post(this.url, login);
  }
}
