import { Profile } from './../../shared/profile';
import { UserDetails } from './../../register/user-details/user-details';
import { UserInformationService } from './../../shared/user-information.service';
import { Observable } from 'rxjs/Observable';
import { By } from '@angular/platform-browser';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { UserInformation } from './../../shared/user-information';
import { ProfileService } from './../../shared/profile.service';
import { ValidatorsService } from './../../shared/validators.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login.component';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { Login } from './Login';

class LoginServiceStub {
  checkUser() { }
};

class ValidatorsServiceStub {
  isFieldHasErrors() { }
}

class ProfileServiceStub {
  getUserDetails() { }
}

describe('LoginComponent', () => {

  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let loginService: LoginService;
  let router: Router;
  let profileService;
  let submitBtn;
  let userInformationService;
  const loginServiceStub: LoginServiceStub = new LoginServiceStub();
  const profileServiceStub = new ProfileServiceStub();
  const validatorsServiceStub = new ValidatorsServiceStub();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [ReactiveFormsModule, FormsModule, RouterTestingModule],
      providers: [
        { provide: LoginService, useValue: loginServiceStub },
        { provide: ProfileService, useValue: profileServiceStub },
        { provide: ValidatorsService, useValue: validatorsServiceStub },
        UserInformationService
      ]
    })
      .compileComponents();

  }));

  beforeEach(() => {
    loginService = TestBed.get(LoginService);
    router = TestBed.get(Router);
    userInformationService = TestBed.get(UserInformationService);
    profileService = TestBed.get(ProfileService);
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
  });

  // Checking everything is created correct or not
  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  // Checking form is invalid if it is empty
  it('should have invalid form when it is empty', () => {

    expect(component.loginForm.valid).toBeFalsy();
  });

  describe('should have userId field', () => {
    let errors = {};
    let userId;
    beforeEach(() => {
      userId = component.loginForm.controls['userId'];
      errors = userId.errors || {};
    });
    // Checking userId is invalid if it is empty
    it('which is invalid when it is empty', () => {
      expect(userId.valid).toBeFalsy();

    });

    // Checking required error is present if userId is invalid
    it('which contains required error when it is empty', () => {
      expect(errors['required']).toBeTruthy();

    });
  });

  describe('should have userId field', () => {
    let errors = {};
    let userId;
    beforeEach(() => {
      userId = component.loginForm.controls['userId'];
      userId.setValue('Kalpana');
      errors = userId.errors || {};

    });
    // Checking userId is valid if it is filled
    it('which is valid when it is filled', () => {
      expect(userId.valid).toBeTruthy();

    });

    // Checking required error is not present if userId is valid
    it('which should not contains required error when it is filled', () => {
      expect(errors['required']).toBeFalsy();

    });
  });

  describe('should have password field', () => {
    let errors = {};
    let password;
    beforeEach(() => {
      password = component.loginForm.controls['password'];
      errors = password.errors || {};
    });
    // Checking password is invalid if it is empty
    it('which is invalid when it is empty', () => {
      expect(password.valid).toBeFalsy();

    });

    // Checking required error is present if password is invalid
    it('which contains required error when it is empty', () => {
      expect(errors['required']).toBeTruthy();

    });
  });

  describe('should have password field', () => {
    let errors = {};
    let password;
    beforeEach(() => {
      password = component.loginForm.controls['password'];
      password.setValue('Kalpana');
      errors = password.errors || {};

    });
    // Checking password is valid if it is filled
    it('which is valid when it is filled', () => {
      expect(password.valid).toBeTruthy();

    });

    // Checking required error is not present if password is valid
    it('which should not contains required error when it is filled', () => {
      expect(errors['required']).toBeFalsy();

    });
  });

  describe('have loginForm when all fields are filled', () => {

    beforeEach(() => {
      component.loginForm.controls['userId'].setValue('Kalpana');
      component.loginForm.controls['password'].setValue('Kalpana');
      fixture.detectChanges();
    });

    // Checking form is valid if all fields are filled properly
    it('should have valid valid form', () => {

      expect(component.loginForm.valid).toBeTruthy();

    });

    // Checking submit button is enabled if form is valid
    it('should have submit button enabled', () => {

      expect(submitBtn.disabled).toBeFalsy();

    });

    // Checking userLogin function is called if submit button is clicked
    it('should call userLogin on clicking submit button', () => {

      const spy = spyOn(component, 'userLogin');
      submitBtn.click();
      expect(spy).toHaveBeenCalled();

    });

  });

  describe('invoking userLogin function', () => {

    beforeEach(() => {
      spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(null));
    });

    // Checking checkUser method of LoginService is called
    it('should call checkUser function of LoginService', () => {

      const spy = spyOn(loginService, 'checkUser').and.returnValue(Observable.of(true));
      component.userLogin();
      expect(spy).toHaveBeenCalled();
    });

    // Checking successfullLogin funciton is called data is returned from LoginService
    it('should call successfullLogin function if data is recieved from LoginService', () => {

      const spy = spyOn(component, 'successfullLogin');
      spyOn(loginService, 'checkUser').and.returnValue(Observable.of(true));
      component.userLogin();
      expect(spy).toHaveBeenCalled();
    });

    // Checking failureLogin funciton is called error is thrown from LoginService
    it('should call failureLogin function if error is thrown from LoginService', () => {

      const spy = spyOn(component, 'failureLogin');
      spyOn(loginService, 'checkUser').and.returnValue(Observable.throw(null));
      component.userLogin();
      expect(spy).toHaveBeenCalled();
    });

  });

  describe('invoking failureLogin function with "Invalid Login"', () => {

    beforeEach(() => {
      component.userName = 'kalpana';
      component.loginForm.value.userId = 'kalpana';
      component.failureLogin('Invalid Login');

    });

    // Checking errorFromServer is populated with error getting from server
    it('should populate errorFromServer with error message passed to the function', () => {
      expect(component.errorFromServer).toBe('Invalid Login');
    });

    it('should bring noOfAttempts to zero if different userName is entered than before', () => {
      component.userName = 'kalpana01';
      component.loginForm.value.userId = 'kalpana';
      component.noOfAttempts = 2;
      component.failureLogin('Invalid Login');
      expect(component.noOfAttempts).toBe(1);
    });

    describe('for the first time', () => {

      // Checking noOfAttempts for first time with wrong values
      it('should increase noOfAttempts by 1', () => {
        expect(component.noOfAttempts).toBe(1);

      });

      // Checking error is populated with warning message for first time
      it('should populate error with warning message for first time', () => {
        expect(component.error).toBeDefined();
      });

    });

    describe('for the second time', () => {

      beforeEach(() => {
        component.failureLogin('Invalid Login');
      });

      // Checking noOfAttempts for second time
      it('should increase noOfAttempts by 2', () => {
        expect(component.noOfAttempts).toBe(2);

      });

      // Checking error is populated with warning message for second time
      it('should populate error with warning message for second time', () => {
        expect(component.error).toBeDefined();
      });

    });

    describe('for the third time', () => {

      beforeEach(() => {
        component.failureLogin('Invalid Login');
        component.failureLogin('Invalid Login');
      });

      // Checking noOfAttempts for third time
      it('should increase noOfAttempts by 3', () => {
        expect(component.noOfAttempts).toBe(3);

      });

      // Checking error is populated with warning message for third time
      it('should populate error with warning message for third time', () => {
        expect(component.error).toContain('Sorry you have exceeded all the attempts...Come again later...');
      });

      // Submit button should be disabled if three times function is called
      it('should disable the submit button', () => {
        expect(submitBtn.disabled).toBeTruthy();
      });

    });
  });

  describe('invoking failureLogin function with different error messages except "invalid login"', () => {

    it('should not increase noOfAttempts', () => {

      component.userName = 'kalpana';
      component.loginForm.value.userId = 'kalpana';
      component.failureLogin('Server Error');
      expect(component.noOfAttempts).toBe(0);
    });

    it('should not change the value noOfAttempts', () => {

      component.userName = 'kalpana';
      component.loginForm.value.userId = 'kalpana';
      component.noOfAttempts = 2;
      component.failureLogin('Database is down');
      expect(component.noOfAttempts).toBe(2);
    });

  });

  describe('invoking successfullLogin function', () => {

    let userInformationCustomer: UserInformation;
    let userInformationAdmin: UserInformation;
    let spy;
    let routerSpy;
    let profile: Profile;
    beforeEach(() => {
      userInformationCustomer = {
        custId: 1,
        userId: 'kalpana',
        role: 'C'
      };
      userInformationAdmin = {
        custId: 1,
        userId: 'kalpana',
        role: 'A'
      };
      profile = {
        'custId': 3,
        'firstName': 'Test1',
        'lastName': 'Test1Last',
        'aadharId': '123456789123',
        'email': 'roopan.narayanan@infosys.com',
        'address': 'Xyz street, 4th cross, first main',
        'city': 'Bangalore',
        'state': 'Karnataka',
        'pinCode': 560078,
        'creditDebitLimit': 5000,
        'amountPref': 'lakhs',
        'datePref': 'mm/dd/yy'
      };
      routerSpy = spyOn(router, 'navigate').and.returnValue(null);

    });

    // userDetails property of userInformation property in ProfileService has to be populated
    it('should populated userDetails property of UserInformationService', () => {
      spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(null));
      component.successfullLogin(userInformationCustomer);
      expect(userInformationService.userDetail).toBe(userInformationCustomer);
    });

    // Checking getUserDetails of ProfileService has been called
    it('should call the getUserDetails method of ProfileService', () => {
      spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(profile));
      component.successfullLogin(userInformationCustomer);
      expect(spy).toHaveBeenCalled();
    });

    describe('recieving data from getUserDetails of ProfileService', () => {

      beforeEach(() => {
        spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(profile));
        component.successfullLogin(userInformationCustomer);
      });

      // populate profileDetails property of ProfileService
      it('should populate profileDetails property of ProfileService', () => {
        expect(userInformationService.profileDetail).toEqual(profile);
      });

      // should navigate to Admin page if role is "A"
      it('shoule navigate to Admin page if role is Admin', () => {
        component.successfullLogin(userInformationAdmin);
        expect(routerSpy).toHaveBeenCalledWith(['/admin']);
      });

      // should navigate to Acccount Summary page if role is "C"
      it('shoule navigate to Account Summary page if role is Customer', () => {
        component.successfullLogin(userInformationCustomer);
        expect(routerSpy).toHaveBeenCalledWith(['/account/acctsumm']);
      });

    });

    describe('recieving error from getUserDetails of ProfileService', () => {
      beforeEach(() => {
        spyOn(profileService, 'getUserDetails').and.returnValue(Observable.throw('Server Error'));
        component.successfullLogin(userInformationAdmin);
      });

      // should populate error with message recieved from the server
      it('should populate the error with message recieved from the server', () => {
        expect(component.error).toBe('Server Error');
      });

      // Checking router is not called
      it('should not call the router', () => {
        expect(routerSpy).not.toHaveBeenCalled();
      });

    });

  });

});
