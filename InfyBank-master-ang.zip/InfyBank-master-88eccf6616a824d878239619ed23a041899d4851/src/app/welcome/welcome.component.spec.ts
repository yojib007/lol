import { SuccessMessageService } from './../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { WelcomeComponent } from './welcome.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('WelcomeComponent', () => {
    let component: WelcomeComponent;
    let fixture: ComponentFixture<WelcomeComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [WelcomeComponent],
            providers: [SuccessMessageService]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(WelcomeComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    // Checking everything is created successfully
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // router should be called
    // it('should call router if register method is invoked', () => {
    //     const spy = spyOn(router, 'navigate').and.returnValue(null);
    //     component.register();
    //     expect(spy).toHaveBeenCalledWith(['/register']);
    // });

    // clicking register button should invoke register function
    // it('should invoke register method if register button is clicked', () => {
    //     const registerBtn = fixture.debugElement.query(By.css('#register')).nativeElement;
    //     const spy = spyOn(component, 'register');
    //     registerBtn.click();
    //     expect(spy).toHaveBeenCalled();
    // });

});
