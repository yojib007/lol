import { AccountDetailRoutingModule } from './account-detail.routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountSummaryComponent } from './account-summary/account-summary.component';
import { OpeningAccountComponent } from './opening-account/opening-account.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { OpeningAccountService } from './opening-account/opening-account.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CalculationPipe } from './account-summary/calculation.pipe';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from 'app/shared/shared.module';

@NgModule({
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule, AccountDetailRoutingModule, TranslateModule, SharedModule
  ],
  declarations: [AccountSummaryComponent, OpeningAccountComponent, AccountStatementComponent, CalculationPipe],
  providers: [OpeningAccountService]
})
export class AccountDetailModule { }
