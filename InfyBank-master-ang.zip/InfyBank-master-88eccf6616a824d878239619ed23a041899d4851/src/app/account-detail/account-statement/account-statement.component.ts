import { SuccessMessageService } from './../../shared/success-message.service';
import { UserInformationService } from './../../shared/user-information.service';
import { DownloadService } from './../../shared/download.service';
import { AccountService } from './../../shared/account.service';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ValidatorsService } from './../../shared/validators.service';
import { Accountstatement } from './accountstatement';
import { AccountTransaction } from './account-transaction';

@Component({
  selector: 'app-account-statement',
  templateUrl: './account-statement.component.html',
  styleUrls: ['./account-statement.component.css']
})
export class AccountStatementComponent implements OnInit {

  accountStatementForm: FormGroup;
  accountStatement: Accountstatement[];
  error: string[];
  errorMessage: string[];
  accountNumber: string;
  dwnldAcctStat = 'pdf';
  accounts: string[];
  submit: boolean;

  constructor(private _formbuilder: FormBuilder, private validatorsService: ValidatorsService,
    private acctStatService: AccountService, private userInformationService: UserInformationService,
    private downloadService: DownloadService, private successMessageService: SuccessMessageService) { }

  getAccountNumbers() {
    this.acctStatService.getAccountNumbers().subscribe(
      accnts => {
        this.accounts = accnts;
        this.createForm();
      },
      error => this.error = error
    );
  }

  filter(): any {
    const accountStatementDetails = {};
    accountStatementDetails['lastMonth'] = this.accountStatementForm.value.lastMonth;
    if (this.accountStatementForm.value.fromAmount || this.accountStatementForm.value.fromAmount === 0) {
      accountStatementDetails['fromAmount'] = this.accountStatementForm.value.fromAmount;
      accountStatementDetails['toAmount'] = this.accountStatementForm.value.toAmount;
    }
    if (this.accountStatementForm.value.txnType) {
      accountStatementDetails['txnType'] = this.accountStatementForm.value.txnType;
    }

    if (this.accountStatementForm.value.startDate) {
      accountStatementDetails['startDate'] = this.accountStatementForm.value.startDate;
      accountStatementDetails['endDate'] = this.accountStatementForm.value.endDate;
    }
    return accountStatementDetails;
  }

  getAccountStatement() {
    this.submit = true;
    this.acctStatService.getAccountStatement(this.filter(), this.accountStatementForm.value.accountNumber).subscribe(
      data => {
        this.accountStatement = data;
        if (this.accountStatement.length) {
          this.errorMessage = null;
        } else {
          this.errorMessage = ['ERRORS.ACCOUNTSTATEMENT.NOTRANSACTION'];
        }
        this.submit = false;
      },
      error => {
        this.errorMessage = error;
        this.submit = false;
      });
  }

  downloadDetails() {
    if (this.dwnldAcctStat === 'pdf') {
      this.downloadService.asPdf('#table1');

    } else if (this.dwnldAcctStat === 'xls') {
      this.downloadService.asExcel('table1');
    }
  }

  disableDate() {

    this.accountStatementForm.get('startDate').disable();
    this.accountStatementForm.get('endDate').disable();
    this.accountStatementForm.get('lastMonth').setValue(true);
  }

  enableDate() {

    this.accountStatementForm.get('startDate').enable();
    this.accountStatementForm.get('endDate').enable();
    this.accountStatementForm.get('lastMonth').setValue(false);
  }

  createForm() {
    this.accountStatementForm = this._formbuilder.group({
      accountNumber: ['', Validators.required],
      startDate: ['', [Validators.required, this.validatorsService.checkDate]],
      endDate: ['', [Validators.required, this.validatorsService.checkDate]],
      txnType: [''],
      fromAmount: [''],
      toAmount: [''],
      lastMonth: []
    }, {
        validator: this.validatorsService.fromAmountToAmount
      });
    this.disableDate();
  }

  ngOnInit() {
    this.successMessageService.view = 'account';
    this.successMessageService.subView = 'actStmt';
    this.getAccountNumbers();

  }
}
