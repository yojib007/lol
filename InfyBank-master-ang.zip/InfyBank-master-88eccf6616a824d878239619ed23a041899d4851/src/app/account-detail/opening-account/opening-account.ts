export class OpeningAccount {
 'acctType': string;
 'balance': number;
 'salaried': string;
 'userId':  string;
}
