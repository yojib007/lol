import { SuccessMessageService } from './../../shared/success-message.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ValidatorsService } from './../../shared/validators.service';
import { OpeningAccountService } from './opening-account.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-opening-account',
  templateUrl: './opening-account.component.html',
  styleUrls: ['./opening-account.component.css']
})
export class OpeningAccountComponent implements OnInit {

  error: string[];
  submit: boolean;
  accOpenForm: FormGroup;
  constructor(private openingAccountService: OpeningAccountService,
    private validatorsService: ValidatorsService, private successMessageService: SuccessMessageService,
    private router: Router, private formBuilder: FormBuilder) { }

  change() {
    if (this.accOpenForm.value.salaried === 'Y') {
      this.accOpenForm.value.salaried = 'N';
    } else {
      this.accOpenForm.value.salaried = 'Y';
    }
  }

  openAccount() {
    this.submit = true;
    this.openingAccountService.openAccount(this.accOpenForm.value).subscribe(
      data => {
        this.successMessageService.message = 'OPENINGACCOUNT.SUCCESSMESSAGE';
        this.router.navigate(['/account/acctsumm']);
      },
      error => {
        this.error = error;
        this.submit = false;
      });
  }

  createForm() {
    this.accOpenForm = this.formBuilder.group({
      acctType: ['S', Validators.required],
      balance: ['', [Validators.required, Validators.min(1)]],
      salaried: ['N'],
      userId: ['']
    });
  }

  ngOnInit() {
    this.successMessageService.view = 'account';
    this.successMessageService.subView = 'opnAct';
    this.createForm();
  }

}
