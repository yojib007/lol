import { AccountStatementComponent } from './account-statement/account-statement.component';
import { OpeningAccountComponent } from './opening-account/opening-account.component';
import { AccountSummaryComponent } from './account-summary/account-summary.component';

import { AuthGuardUserService } from './../shared/auth-guard.user.service';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [
        { path: 'acctsumm', component: AccountSummaryComponent },
        { path: 'acctstmt', component: AccountStatementComponent },
        { path: 'opnacct', component: OpeningAccountComponent },
    ],
    canActivate: [AuthGuardUserService]
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountDetailRoutingModule { }
