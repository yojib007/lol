import { SuccessMessageService } from './../../shared/success-message.service';
import { DownloadService } from './../../shared/download.service';
import { UserInformationService } from './../../shared/user-information.service';
import { AccountService } from './../../shared/account.service';
import { ProfileService } from './../../shared/profile.service';
import { Component, OnInit } from '@angular/core';
import { AccountSummary } from './account-summary';

@Component({

    selector: 'app-account-summary',
    templateUrl: './account-summary.component.html',
    styleUrls: ['./account-summary.component.css']
})
export class AccountSummaryComponent implements OnInit {

    userOption = 'accsum';
    accountSummary: AccountSummary;
    date: string;
    time: string;
    error: string[];
    dwnldAcctStat = 'pdf';
    constructor(private accSumService: AccountService, private userInformationService: UserInformationService,
        private downloadService: DownloadService, private successMessageService: SuccessMessageService) { }

    options(option: string) {
        this.userOption = option;
    }

    downloadDetails(name: string) {
        if (this.dwnldAcctStat === 'pdf') {
            this.downloadService.asPdf('#' + name);

        } else if (this.dwnldAcctStat === 'xls') {
            this.downloadService.asExcel(name);
        }
    }

    getAccountSummary() {
        this.accSumService.accountSummary().subscribe(
            data => {
                this.accountSummary = data;
                this.accSumService.accounts = this.accountSummary.accounts;
                console.log("Accsum:"+JSON.stringify(this.accSumService.accounts));
                if (this.accountSummary.loanAccounts && this.accountSummary.loanAccounts.length) {
                    this.accountSummary.loanAccounts = this.accountSummary.loanAccounts
                        .filter(
                        loanDetailObj => loanDetailObj.loanStatus === 'A');
                }
            },
            error => this.error = error
        );
    }

    ngOnInit() {
        this.successMessageService.view = 'account';
        this.successMessageService.subView = 'actSumm';
        this.date = (new Date().getMonth() + 1) + '/' + (new Date().getDate()) + '/' + new Date().getFullYear();
        this.getAccountSummary();
        if (this.successMessageService.message) {
            setTimeout(() => {
                this.successMessageService.message = null;
            }, 5000);
        }
    }
}
