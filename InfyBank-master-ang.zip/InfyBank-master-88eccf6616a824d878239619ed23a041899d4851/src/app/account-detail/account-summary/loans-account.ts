export class LoansAccount {
    'loanAcctNo': string;
    'loanAmount': number;
    'outstandingBalance': number;
    'tenure': number;
    'interestRate': number;
    'openingDate': string;
    'emi': number;
    'nextEmiDueDate': string;
    'loanStatus': string;
    'debitAcctNo': string;
    'remarks': string;
}
