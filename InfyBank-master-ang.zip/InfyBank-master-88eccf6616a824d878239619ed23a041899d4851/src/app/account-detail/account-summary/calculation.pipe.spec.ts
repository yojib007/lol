import { CalculationPipe } from './calculation.pipe';

describe('CalculationPipe', () => {

  let pipe;

  beforeEach(() => {
    pipe = new CalculationPipe();
  });

  // Checking everything is fine
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  // Checking sum of balance is returned if accounts is passed as arguments
  it('should return sum of balance in all accounts if args is passed as arguments', () => {
    const accountList = [{ balance: 1000 }, { balance: 2000 }];
    expect(pipe.transform(accountList, 'accounts')).toBe('3000');
  });

  // Checking sum of balance is returned if loans is passed as arguments
  it('should return sum of balance in all loan accounts if args is passed as arguments', () => {
    const accountList = [{ loanAmount: 2000 }, { loanAmount: 2000 }];
    expect(pipe.transform(accountList, 'loans')).toBe('4000');
  });
});
