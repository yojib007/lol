import { SuccessMessageService } from './../../shared/success-message.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import { AccountConfigService } from './../account-config.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountConfigComponent } from './account-config.component';

class AccountConfigServiceStub {
  getAccountConfig() {
    return Observable.of(true);
  }
}
describe('AccountConfigComponent', () => {
  let component: AccountConfigComponent;
  let fixture: ComponentFixture<AccountConfigComponent>;
  const accountConfigServiceStub = new AccountConfigServiceStub();
  let accountConfigService;
  let successMessageService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AccountConfigComponent],
      providers: [{ provide: AccountConfigService, useValue: accountConfigServiceStub }, SuccessMessageService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    accountConfigService = TestBed.get(AccountConfigService);
    successMessageService = TestBed.get(SuccessMessageService);
    fixture = TestBed.createComponent(AccountConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // Checking everything is created successfully
  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  // Checking getAccountConfig method of accountConfigService is called when the component is created
  it('should call getAccountConfig method of accountConfigService', () => {
    const spy = spyOn(accountConfigService, 'getAccountConfig').and.returnValue(Observable.of(true));
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  // Checking userDetails is populated if data is recieved from ProfileSerivce
  it('should populate userDetails if data is recieved from accountConfigService', () => {
    const spy = spyOn(accountConfigService, 'getAccountConfig').and.returnValue(Observable.of(true));
    component.ngOnInit();
    expect(component.accountConfigDetails).toBe(true);
  });

  // Checking error is populated if error is thrown from ProfileSerivce
  it('should populate userDetails if data is recieved from accountConfigService', () => {
    const spy = spyOn(accountConfigService, 'getAccountConfig').and.returnValue(Observable.throw('Server Error'));
    component.ngOnInit();
    expect(component.error).toBe('Server Error');
  });

  // Checking message property became null after 5 secs
  it('should null the message property of SuccessMessageService after 5 secs', async(() => {
    successMessageService.message = 'success';
    component.ngOnInit();
    setTimeout(() => {
      expect(successMessageService.message).toBeFalsy();
    }, 5000);
  }));
});
