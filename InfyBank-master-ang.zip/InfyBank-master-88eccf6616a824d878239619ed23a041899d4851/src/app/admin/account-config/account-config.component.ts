import { SuccessMessageService } from './../../shared/success-message.service';
import { AccountConfigService } from './../account-config.service';
import { Component, OnInit } from '@angular/core';
import { AccountConfig } from '../account-config';
import { UserInformationService } from './../../shared/user-information.service';

@Component({
  selector: 'app-account-config',
  templateUrl: './account-config.component.html',
  styleUrls: ['./account-config.component.css']
})
export class AccountConfigComponent implements OnInit {

  accountConfigDetails: AccountConfig[];
  error: string[];

  constructor(private accountConfigService: AccountConfigService, private successMessageService: SuccessMessageService, private userInformationService: UserInformationService) { }

  getAccountConfig() {
    this.accountConfigService.getAccountConfig().subscribe(
      data => { this.accountConfigDetails = data; },
      error => this.error = error.message || error
    );
  }

  ngOnInit() {
    if (this.successMessageService.message) {
      setTimeout(() => {
        this.successMessageService.message = null;
      }, 5000);
    }
    this.successMessageService.view = 'account';
    this.successMessageService.subView = '';
    this.getAccountConfig();
  }

}
