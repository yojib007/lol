import { Accountstatement } from '../account-detail/account-statement/accountstatement';


export class ViewLoanApplication {
    'custName': string;
    'loanAcctNo': string;
    'creditScore': number;
    'loanAmount': number;
    'debitAcctNo': string;
    'tenure': number;
    'isSalaryCreditedForLastNDays': boolean;
    'lastNSalaryCredits': Accountstatement[];
    'isCreditScoreEligible': boolean;
    'interestRate': number;
    'emi': number;
    'isValidEmi': boolean;
    'eligible': boolean;

}
