import { UserInformationService } from './../shared/user-information.service';
import { EditAccountConfig } from './edit-account-config';
import { Observable } from 'rxjs/Rx';
import { UserInformation } from './../shared/user-information';
import { RestService } from './../shared/rest-service';
import { ProfileService } from './../shared/profile.service';
import { TestBed, inject } from '@angular/core/testing';

import { AccountConfigService } from './account-config.service';

class UserInformationServiceStub {
  userDetail = new UserInformation();
}

class RestServiceStub {
  get() { }
  put() { }
}

describe('AccountConfigService', () => {

  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AccountConfigService,
        { provide: UserInformationService, useValue: userInformationServiceStub },
        { provide: RestService, useValue: restServiceStub }]
    });
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([AccountConfigService], (service: AccountConfigService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the getAccountConfig function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([AccountConfigService], (service: AccountConfigService) => {

        const spy = spyOn(restService, 'get');
        service.getAccountConfig();
        expect(spy).toHaveBeenCalled();

      }));

    // Checking getAccountConfig function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([AccountConfigService], (service: AccountConfigService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.of(true));
        service.getAccountConfig().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking getAccountConfig function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([AccountConfigService], (service: AccountConfigService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.throw('Server Error'));
        service.getAccountConfig().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

  describe('on calling the editAccountConfig function', () => {

    let returnValue;
    let errMsg;

    // Checking put method of RestService is called
    it('should invoke put method of RestService',
      inject([AccountConfigService], (service: AccountConfigService) => {

        const spy = spyOn(restService, 'put');
        service.editAccountConfig(new EditAccountConfig());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking editAccountConfig function returning the Observable of true which is returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([AccountConfigService], (service: AccountConfigService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.of(true));
        service.editAccountConfig(new EditAccountConfig()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking editAccountConfig function returning the Observable of error which is returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([AccountConfigService], (service: AccountConfigService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.throw('Server Error'));
        service.editAccountConfig(new EditAccountConfig()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });
});
