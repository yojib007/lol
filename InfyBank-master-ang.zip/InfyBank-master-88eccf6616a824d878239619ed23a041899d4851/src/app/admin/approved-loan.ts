export class ApprovedLoan {
    'custId': number;
    'loanAcctNo': string;
    'loanAmount': number;
    'tenure': number;
    'interestRate': number;
    'openingDate': string;
    'emi': number;
    'emiDueDate': string;
    'loanStatus': string;
    'debitAcctNo': number;
    'remarks': string; ;
    'lstUpdtTs': string;
    'lstUpdtId': string;
}
