export class LoanApproval {
    'approve': boolean;
    'interestRate': number;
    'remarks': string;
    'adminUserId': string;
}
