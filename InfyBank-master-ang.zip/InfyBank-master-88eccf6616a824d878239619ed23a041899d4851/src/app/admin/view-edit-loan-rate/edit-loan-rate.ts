import { LoanRate } from './loan-rate';
export class EditLoanRate {
    loanConfigDtoList: LoanRate[];
    lstUpdtId: string;
}
