import { UserInformationService } from './../../shared/user-information.service';
import { EditLoanRate } from './edit-loan-rate';
import { RestService } from './../../shared/rest-service';
import { ProfileService } from './../../shared/profile.service';
import { Observable } from 'rxjs/Observable';
import { LoanRate } from './loan-rate';
import { Injectable } from '@angular/core';

@Injectable()
export class ViewEditLoanRateService {
  loanUrl = '/infybank_core/v1/loanconfigs';
  constructor(private userInformationService: UserInformationService, private restService: RestService) { }

  viewLoanRate(): Observable<LoanRate[]> {
    return this.restService.get(this.loanUrl);
  }

  editLoanRate(data: EditLoanRate): Observable<boolean> {
    for (let i = 0; i < data.loanConfigDtoList.length; i++) {
      data.loanConfigDtoList[i].userId = this.userInformationService.userDetail.userId;
    }
    data.lstUpdtId = this.userInformationService.userDetail.userId;
    return this.restService.put(this.loanUrl, data);
  }

}
