export class LoanRate {
    'creditScoreStart': number;
    'creditScoreEnd': number;
    'loanApprovalInd': string;
    'interestRate': number;
    'userId': string;
}
