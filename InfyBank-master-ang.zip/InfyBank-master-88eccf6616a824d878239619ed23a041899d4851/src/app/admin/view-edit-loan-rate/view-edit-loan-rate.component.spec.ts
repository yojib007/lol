import { SuccessMessageService } from './../../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { LoanRate } from './loan-rate';
import { Observable } from 'rxjs/Rx';
import { ViewEditLoanRateService } from './view-edit-loan-rate.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule, FormArray, FormControl, FormGroup } from '@angular/forms';
import { ValidatorsService } from './../../shared/validators.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEditLoanRateComponent } from './view-edit-loan-rate.component';

class ValidatorsServiceStub {
  isFieldHasErrors() { }
  validateScoreStart() { }
  validateScoreEnd() { }
}

class ViewEditLoanRateServiceStub {
  viewLoanRate() {
    return Observable.of([new LoanRate(), new LoanRate()]);
  }
  editLoanRate() { }
}

describe('ViewEditLoanRateComponent', () => {
  let component: ViewEditLoanRateComponent;
  let fixture: ComponentFixture<ViewEditLoanRateComponent>;
  const validatorsServiceStub = new ValidatorsServiceStub();
  const viewEditLoanRateServiceStub = new ViewEditLoanRateServiceStub();
  let viewEditLoanRateService;
  let validatorsService;
  let submitBtn;
  let successMessageService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, RouterTestingModule],
      declarations: [ViewEditLoanRateComponent],
      providers: [
        { provide: ValidatorsService, useValue: validatorsServiceStub },
        { provide: ViewEditLoanRateService, useValue: viewEditLoanRateServiceStub },
        SuccessMessageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewEditLoanRateComponent);
    component = fixture.componentInstance;
    validatorsService = TestBed.get(ValidatorsService);
    successMessageService = TestBed.get(SuccessMessageService);
    viewEditLoanRateService = TestBed.get(ViewEditLoanRateService);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  // Checking viewLoanRate method of viewEditLoanRateService is called when the component is created
  it('should call viewLoanRate method of viewEditLoanRateService', () => {
    const spy = spyOn(viewEditLoanRateService, 'viewLoanRate').and.returnValue(Observable.of(true));
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  // Checking addField function adding the form Group
  it('should add formGroup object into the formArray if addField function is invoked', () => {

    component.loanRateListForm.enable();
    component.addField();
    expect(component.loanRateListForm.value.loanConfigDtoList.length).toBe(3);

  });

  // Checking removeField function adding the form Group
  it('should remove formGroup object into the formArray if removeField function is invoked', () => {
    component.removeField(1);
    expect(component.loanRateListForm.value.loanConfigDtoList.length).toBe(1);
  });

  // Checking message property became null after 5 secs
  it('should null the message property of SuccessMessageService after 5 secs', async(() => {
    successMessageService.message = 'success';
    component.ngOnInit();
    setTimeout(() => {
      expect(successMessageService.message).toBeFalsy();
    }, 5000);
  }));

  describe('recieving data from viewEditLoanRateService', () => {

    let spy;

    beforeEach(() => {
      spyOn(viewEditLoanRateService, 'viewLoanRate').and.returnValue(Observable.of([new LoanRate(), new LoanRate()]));
      spy = spyOn(component, 'createForm');
      component.ngOnInit();
    });

    // Checking userDetails is populated if data is recieved from ViewEditLoanRateService
    it('should populate userDetails', () => {

      expect(component.loanRateDetails).toBeDefined();
    });

    // should call createForm method
    it('should populate userDetails', () => {

      expect(spy).toHaveBeenCalled();
    });

  });


  // Checking error is populated if error is thrown from ViewEditLoanRateService
  it('should populate userDetails if data is recieved from viewEditLoanRateService', () => {
    const spy = spyOn(viewEditLoanRateService, 'viewLoanRate').and.returnValue(Observable.throw('Server Error'));
    component.ngOnInit();
    expect(component.errorMsg).toBe('Server Error');
  });

  // Checking form is disabled
  it('should have form which is disabled', () => {
    component.edit = true;
    expect(component.loanRateListForm.disabled).toBeTruthy();
  });

  describe('invoking submit function', () => {

    // should call editLoanRate method of viewEditLoanRateService
    it('should call editLoanRate method of viewEditLoanRateService', () => {

      const spy = spyOn(viewEditLoanRateService, 'editLoanRate').and.returnValue(Observable.of(true));
      component.submit();
      expect(spy).toHaveBeenCalledWith(component.loanRateListForm.value);
    });

    // Populate message of SuccessMessageService if data is recieved from editLoanRate method of viewEditLoanRateService
    it('should populate message of SuccessMessageService if data is recieved from editLoanRate method of viewEditLoanRateService', () => {

      spyOn(viewEditLoanRateService, 'editLoanRate').and.returnValue(Observable.of(true));
      component.submit();
      expect(successMessageService.message).toBeDefined();
    });

    // Populate error if error is thrown from editLoanRate method of viewEditLoanRateService
    it('should populate error if error is thrown from editLoanRate method of viewEditLoanRateService', () => {

      spyOn(viewEditLoanRateService, 'editLoanRate').and.returnValue(Observable.throw('Server Error'));
      component.submit();
      expect(component.error).toBe('Server Error');
    });
  });

  describe('invoking createForm function', () => {

    // Checking 2 formGroups are prsesnt if lenght of loanRateDetails is 2
    it('should push 2 formGroup object into loanRateListForm', () => {
      spyOn(viewEditLoanRateService, 'viewLoanRate').and.returnValue(Observable.of([new LoanRate(), new LoanRate()]));
      component.ngOnInit();
      expect(component.loanRateListForm.controls['loanConfigDtoList'].get('length')).toBe(2);
    });

    // Checking 3 formGroups are prsesnt if lenght of loanRateDetails is 3
    it('should push 3 formGroup object into loanRateListForm', () => {
      spyOn(viewEditLoanRateService, 'viewLoanRate').and.returnValue(Observable.of([new LoanRate(), new LoanRate(), new LoanRate()]));
      component.ngOnInit();
      expect(component.loanRateListForm.controls['loanConfigDtoList'].get('length')).toBe(3);
    });
  });

  describe('contains loanRateListForm which', () => {

    let formArrayControl;
    let formGroupControl;

    beforeEach(() => {
      spyOn(viewEditLoanRateService, 'viewLoanRate').and.returnValue(Observable.of([new LoanRate()]));
      component.ngOnInit();
      component.loanRateListForm.enable();
      formArrayControl = <FormArray>component.loanRateListForm.get('loanConfigDtoList');
      formGroupControl = <FormGroup>formArrayControl.controls[0];
    });

    describe('has creditScoreStart field which is empty', () => {
      let errors = {};
      let creditScoreStart;

      beforeEach(() => {

        creditScoreStart = formGroupControl.controls['creditScoreStart'];

        creditScoreStart.setValue('');
        errors = creditScoreStart.errors || {};
        fixture.detectChanges();
      });

      // Checking creditScoreStart is invalid if it is empty
      it('should be invalid', () => {

        expect(creditScoreStart.valid).toBeFalsy();

      });

      // Checking required error is present if creditScoreStart is not entered
      it('should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

    });

    describe('has creditScoreStart field which is filled', () => {
      let errors = {};
      let creditScoreStart;

      beforeEach(() => {

        creditScoreStart = formGroupControl.controls['creditScoreStart'];

        creditScoreStart.setValue(8);
        errors = creditScoreStart.errors || {};
        fixture.detectChanges();
      });

      // Checking creditScoreStart is valid if it is filled
      it('should be valid', () => {

        expect(creditScoreStart.valid).toBeTruthy();

      });

    });

    describe('has creditScoreStart field on recieving error object from validateScoreStart method of ValidatorService', () => {

      let errors = {};
      let creditScoreStart;

      beforeEach(() => {
        spyOn(validatorsService, 'validateScoreStart').and.returnValue({ creditScore: true });
        component.ngOnInit();
        component.loanRateListForm.enable();
        formArrayControl = <FormArray>component.loanRateListForm.get('loanConfigDtoList');
        formGroupControl = <FormGroup>formArrayControl.controls[0];
        creditScoreStart = formGroupControl.controls['creditScoreStart'];

        creditScoreStart.setValue('100');
        errors = creditScoreStart.errors || {};
        fixture.detectChanges();
      });

      // Checking creditScoreStart is invalid if it is incorrect
      it('should be invalid', () => {

        expect(creditScoreStart.valid).toBeFalsy();

      });

      // Checking creditScore error is present if amount is invalid
      it('should contain creditScore error', () => {
        expect(errors['creditScore']).toBeTruthy();

      });

    });

    describe('has creditScoreStart field on recieving null from validateScoreStart method of ValidatorService', () => {
      let errors = {};
      let creditScoreStart;

      beforeEach(() => {
        spyOn(validatorsService, 'validateScoreStart').and.returnValue(null);
        component.ngOnInit();
        component.loanRateListForm.enable();
        formArrayControl = <FormArray>component.loanRateListForm.get('loanConfigDtoList');
        formGroupControl = <FormGroup>formArrayControl.controls[0];
        creditScoreStart = formGroupControl.controls['creditScoreStart'];

        creditScoreStart.setValue('100');
        errors = creditScoreStart.errors || {};
        fixture.detectChanges();
      });

      // Checking creditScoreStart is valid if it is filled
      it('should be valid', () => {

        expect(creditScoreStart.valid).toBeTruthy();

      });

      // Checking creditScore error is not present if field is correct
      it('should not contain creditScore error', () => {
        expect(errors['creditScore']).toBeFalsy();

      });

    });

    describe('has creditScoreEnd field which is empty', () => {

      let errors = {};
      let creditScoreEnd;

      beforeEach(() => {

        creditScoreEnd = formGroupControl.controls['creditScoreEnd'];

        creditScoreEnd.setValue('');
        errors = creditScoreEnd.errors || {};
        fixture.detectChanges();
      });

      // Checking creditScoreStart is invalid if it is empty
      it('should be invalid', () => {

        expect(creditScoreEnd.valid).toBeFalsy();

      });

      // Checking required error is present if creditScoreStart is not entered
      it('should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

    });

    describe('has creditScoreEnd field which is filled', () => {

      let errors = {};
      let creditScoreEnd;

      beforeEach(() => {
        creditScoreEnd = formGroupControl.controls['creditScoreEnd'];
        creditScoreEnd.setValue(1000);
        errors = creditScoreEnd.errors || {};
        fixture.detectChanges();
      });

      // Checking creditScoreEnd is valid if it is filled
      it('should be valid', () => {

        expect(creditScoreEnd.valid).toBeTruthy();

      });

    });

    describe('has creditScoreEnd field on recieving error object from validateScoreStart method of ValidatorService', () => {

      let errors = {};
      let creditScoreEnd;

      beforeEach(() => {
        spyOn(validatorsService, 'validateScoreEnd').and.returnValue({ creditScore: true });
        component.ngOnInit();
        component.loanRateListForm.enable();
        formArrayControl = <FormArray>component.loanRateListForm.get('loanConfigDtoList');
        formGroupControl = <FormGroup>formArrayControl.controls[0];
        creditScoreEnd = formGroupControl.controls['creditScoreEnd'];

        creditScoreEnd.setValue('100');
        errors = creditScoreEnd.errors || {};
        fixture.detectChanges();
      });

      // Checking creditScoreEnd is invalid if it is incorrect
      it('should be invalid', () => {

        expect(creditScoreEnd.valid).toBeFalsy();

      });

      // Checking creditScore error is present if amount is invalid
      it('should contain creditScore error', () => {
        expect(errors['creditScore']).toBeTruthy();

      });

    });

    describe('has creditScoreEnd field on recieving null from validateScoreStart method of ValidatorService', () => {
      let errors = {};
      let creditScoreEnd;

      beforeEach(() => {
        spyOn(validatorsService, 'validateScoreEnd').and.returnValue(null);
        component.ngOnInit();
        component.loanRateListForm.enable();
        formArrayControl = <FormArray>component.loanRateListForm.get('loanConfigDtoList');
        formGroupControl = <FormGroup>formArrayControl.controls[0];
        creditScoreEnd = formGroupControl.controls['creditScoreEnd'];

        creditScoreEnd.setValue('100');
        errors = creditScoreEnd.errors || {};
        fixture.detectChanges();
      });

      // Checking creditScoreEnd is valid if it is filled
      it('should be valid', () => {

        expect(creditScoreEnd.valid).toBeTruthy();

      });

      // Checking creditScore error is not present if field is correct
      it('should not contain creditScore error', () => {
        expect(errors['creditScore']).toBeFalsy();

      });

    });
    describe('has interestRate field which is empty', () => {

      let errors = {};
      let interestRate;

      beforeEach(() => {

        interestRate = formGroupControl.controls['interestRate'];

        interestRate.setValue('');
        errors = interestRate.errors || {};
        fixture.detectChanges();
      });

      // Checking interestRate is invalid if it is empty
      it('should be invalid', () => {

        expect(interestRate.valid).toBeFalsy();

      });

      // Checking required error is present if interestRate is not entered
      it('should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

    });

    describe('has interestRate field which is filled', () => {

      let errors = {};
      let interestRate;

      beforeEach(() => {
        interestRate = formGroupControl.controls['interestRate'];
        interestRate.setValue(10);
        errors = interestRate.errors || {};
        fixture.detectChanges();
      });

      // Checking interestRate is valid if it is filled
      it('should be valid', () => {

        expect(interestRate.valid).toBeTruthy();

      });

    });

    describe('contains all fields are filled', () => {

      beforeEach(() => {
        component.loanRateListForm.enable();
        formGroupControl.controls['creditScoreEnd'].setValue(8);
        formGroupControl.controls['creditScoreStart'].setValue(8);
        formGroupControl.controls['interestRate'].setValue(8);
        component.edit = true;
        fixture.detectChanges();
        submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;

      });

      // form should be valid if all feilds are filled properly
      it('should be valid', () => {

        expect(component.loanRateListForm.valid).toBe(true);

      });

      // checking submit button is enabled if form is valid
      it('should has submit button enabled', () => {

        expect(submitBtn.disabled).toBe(false);

      });

      // invokeUserService function should be called on clicking the submit button
      it('should call submit function on clicking submit button', () => {
        const spy = spyOn(component, 'submit');
        submitBtn.click();
        expect(spy).toHaveBeenCalled();
      });

    });
  });

});
