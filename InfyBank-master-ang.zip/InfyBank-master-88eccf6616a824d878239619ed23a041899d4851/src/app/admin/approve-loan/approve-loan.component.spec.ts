import { SuccessMessageService } from './../../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { ViewLoanService } from './../view-loan.service';
import { ValidatorsService } from './../../shared/validators.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { ViewLoanApplication } from './../view-loan-app';
import { Observable } from 'rxjs/Rx';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { ApproveLoanComponent } from './approve-loan.component';

class ValidatorsServiceStub {
  isFieldHasErrors() { }
}

class ViewLoanServiceStub {
  getLoanApplication() {
    return Observable.of([new ViewLoanApplication(), new ViewLoanApplication()]);
  }
  approveLoan() { }
}

describe('ApproveLoanComponent', () => {
  const viewLoanServiceStub = new ViewLoanServiceStub();
  const validatorsServiceStub = new ValidatorsServiceStub();
  let component: ApproveLoanComponent;
  let fixture: ComponentFixture<ApproveLoanComponent>;
  let viewLoanService;
  let route;
  let loanAppl1: ViewLoanApplication;
  let loanAppl2: ViewLoanApplication;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, FormsModule, ReactiveFormsModule],
      declarations: [ApproveLoanComponent],
      providers: [
        { provide: ValidatorsService, useValue: validatorsServiceStub },
        { provide: ViewLoanService, useValue: viewLoanServiceStub },
        SuccessMessageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproveLoanComponent);
    component = fixture.componentInstance;
    viewLoanService = TestBed.get(ViewLoanService);
    route = TestBed.get(ActivatedRoute);
    fixture.detectChanges();
    loanAppl1 = {
      'custName': null,
      'loanAcctNo': '0449003103',
      'creditScore': 0,
      'loanAmount': 200000,
      'debitAcctNo': null,
      'tenure': 5,
      'isSalaryCreditedForLastThreeDays': null,
      'lastThreeSalaryCredits': null,
      'isCreditScoreEligible': null,
      'interestRate': null,
      'emi': null,
      'isValidEmi': null,
      'eligible': null
    };
    loanAppl2 = {
      'custName': null,
      'loanAcctNo': '0449003104',
      'creditScore': 0,
      'loanAmount': 10000,
      'debitAcctNo': null,
      'tenure': 3,
      'isSalaryCreditedForLastThreeDays': null,
      'lastThreeSalaryCredits': null,
      'isCreditScoreEligible': null,
      'interestRate': null,
      'emi': null,
      'isValidEmi': null,
      'eligible': null
    };
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  // Checking loanAccountNo has been populated
  it('should populate the loanAccountNo', () => {
    spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of([loanAppl1, loanAppl2]));
    spyOn(route.snapshot.paramMap, 'get').and.returnValue('0449003104');
    component.ngOnInit();
    expect(component.loanAccountNo).toBe('0449003104');
  });

  // Checking getLoanApplication method of viewLoanService is called when the component is created
  it('should call getLoanApplication method of viewLoanService', () => {
    spyOn(route.snapshot.paramMap, 'get').and.returnValue('0449003104');
    const spy = spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of([loanAppl1, loanAppl2]));
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  describe('recieving data from viewLoanService', () => {

    let spy;

    beforeEach(() => {
      spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of([loanAppl1, loanAppl2]));
      spy = spyOn(component, 'createForm');
      spyOn(route.snapshot.paramMap, 'get').and.returnValue('0449003104');
      component.ngOnInit();
    });

    // Checking userDetails is populated if data is recieved from viewLoanService
    it('should populate userDetails', () => {

      expect(component.loanApplication).toBeDefined();
    });

    // should call createForm method
    it('should populate userDetails', () => {

      expect(spy).toHaveBeenCalled();
    });

  });

  // Checking error is populated if error is thrown from viewLoanService
  it('should populate userDetails if data is recieved from viewLoanService', () => {
    spyOn(route.snapshot.paramMap, 'get').and.returnValue(6);
    const spy = spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.throw('Server Error'));
    component.ngOnInit();
    expect(component.error).toBe('Server Error');
  });

  // Checking form is created
  it('should create form if createForm method is invoked', () => {
    component.loanApplication = loanAppl1;
    component.loanApproveForm = null;
    component.createForm();
    expect(component.loanApproveForm).toBeDefined();
  });

  describe('has loanApproveForm which', () => {
    beforeEach(() => {
      spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of([loanAppl1, loanAppl2]));
      spyOn(route.snapshot.paramMap, 'get').and.returnValue('0449003104');
      spyOn(viewLoanService, 'approveLoan').and.returnValue(Observable.of(true));
      component.ngOnInit();
    });

    describe('has interestRate field which is empty', () => {
      let errors = {};
      let interestRate;
      beforeEach(() => {
        interestRate = component.loanApproveForm.controls['interestRate'];
        interestRate.setValue('');
        errors = interestRate.errors || {};
        fixture.detectChanges();
      });

      // Checking interestRate is invalid if it is empty
      it('should be invalid', () => {

        expect(interestRate.valid).toBeFalsy();

      });

      // Checking required error is present if interestRate is not entered
      it('should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

    });

    describe('has interestRate field which is filled', () => {
      let errors = {};
      let interestRate;
      beforeEach(() => {
        interestRate = component.loanApproveForm.controls['interestRate'];
        interestRate.setValue(8);
        errors = interestRate.errors || {};
        fixture.detectChanges();
      });

      // Checking interestRate is valid if it is filled
      it('should be valid', () => {

        expect(interestRate.valid).toBeTruthy();

      });

    });

    describe('has remarks field which is empty', () => {
      let errors = {};
      let remarks;
      beforeEach(() => {
        remarks = component.loanApproveForm.controls['remarks'];
        remarks.setValue('');
        errors = remarks.errors || {};
        fixture.detectChanges();
      });

      // Checking interestRate is invalid if it is empty
      it('should be invalid', () => {

        expect(remarks.valid).toBeFalsy();

      });

      // Checking required error is present if interestRate is not entered
      it('should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

    });

    describe('has remarks field which is filled', () => {
      let errors = {};
      let remarks;
      beforeEach(() => {
        remarks = component.loanApproveForm.controls['remarks'];
        remarks.setValue('Approved');
        errors = remarks.errors || {};
        fixture.detectChanges();
      });

      // Checking remarks is valid if it is filled
      it('should be valid', () => {

        expect(remarks.valid).toBeTruthy();

      });

    });
  });


  describe('loanApproveForm when all fields are valid', () => {

    beforeEach(() => {
      spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of([loanAppl1, loanAppl2]));
      spyOn(route.snapshot.paramMap, 'get').and.returnValue('0449003104');
      spyOn(viewLoanService, 'approveLoan').and.returnValue(Observable.of(true));
      component.ngOnInit();
      component.loanApproveForm.controls['interestRate'].setValue(8);
      component.loanApproveForm.controls['remarks'].setValue('Approved');
      fixture.detectChanges();
      component.loanApplication = loanAppl1;
      fixture.detectChanges();
    });

    // form should be valid if all feilds are filled properly
    it('should be valid', () => {

      expect(component.loanApproveForm.valid).toBe(true);

    });

    // checking approve button is enabled if form is valid
    it('should has approve button enabled', () => {

      const approveBtn = fixture.debugElement.query(By.css('#approve')).nativeElement;
      expect(approveBtn.disabled).toBe(false);

    });

    // checking approve button is enabled if form is valid
    it('should has approve button enabled', () => {

      const rejectBtn = fixture.debugElement.query(By.css('#reject')).nativeElement;
      expect(rejectBtn.disabled).toBe(false);

    });

    // approve function should be called on clicking the approve button
    it('should call approve function on clicking approve button', () => {

      const spy = spyOn(component, 'approve');
      const approveBtn = fixture.debugElement.query(By.css('#approve')).nativeElement;
      approveBtn.click();
      expect(spy).toHaveBeenCalledWith(true);
    });

    // approve function should be called on clicking the reject button
    it('should call approve function on clicking reject button', () => {

      const spy = spyOn(component, 'approve');
      const rejectBtn = fixture.debugElement.query(By.css('#reject')).nativeElement;
      rejectBtn.click();
      expect(spy).toHaveBeenCalledWith(false);
    });

  });

  describe('invoking approve function', () => {

    beforeEach(() => {
      spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of([loanAppl1, loanAppl2]));
      spyOn(route.snapshot.paramMap, 'get').and.returnValue('0449003104');
      spyOn(viewLoanService, 'approveLoan').and.returnValue(Observable.of(true));
      component.ngOnInit();
      fixture.detectChanges();
    });

    // should set approve as true if true is passed to function
    it('should set approve field of loanApproveForm as true if true is passed to function', () => {
      component.approve(true);
      expect(component.loanApproveForm.value.approve).toBe(true);
    });

    // should set approve as false if false is passed to function
    it('should set approve field of loanApproveForm as false if false is passed to function', () => {
      component.approve(false);
      expect(component.loanApproveForm.value.approve).toBe(false);
    });
  });

  describe('invoking submit function', () => {

    beforeEach(() => {
      spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of([loanAppl1, loanAppl2]));
      spyOn(route.snapshot.paramMap, 'get').and.returnValue('0449003104');
      component.ngOnInit();
      fixture.detectChanges();
    });


    // should call approveLoan method of viewLoanService
    it('should call approveLoan method of viewLoanService', () => {

      const spy = spyOn(viewLoanService, 'approveLoan').and.returnValue(Observable.of(true));
      component.approve(true);
      expect(spy).toHaveBeenCalled();
    });

    // Populate success if data is recieved from approveLoan method of viewLoanService
    it('should populate success if data is recieved from approveLoan method of viewLoanService', () => {

      spyOn(viewLoanService, 'approveLoan').and.returnValue(Observable.of(true));
      component.approve(true);
      expect(component.approveLoan).toBe(true);
    });

    // Populate error if error is thrown from approveLoan method of viewLoanService
    it('should populate error if error is thrown from approveLoan method of viewLoanService', () => {

      spyOn(viewLoanService, 'approveLoan').and.returnValue(Observable.throw('Server Error'));
      component.approve(true);
      expect(component.error).toBe('Server Error');
    });
  });
});
