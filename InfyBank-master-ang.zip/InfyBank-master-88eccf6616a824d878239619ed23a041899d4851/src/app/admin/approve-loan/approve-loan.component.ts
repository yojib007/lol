import { SuccessMessageService } from './../../shared/success-message.service';
import { ValidatorsService } from './../../shared/validators.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApprovedLoan } from './../approved-loan';
import { ViewLoanApplication } from './../view-loan-app';
import { ViewLoanService } from './../view-loan.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-approve-loan',
  templateUrl: './approve-loan.component.html',
  styleUrls: ['./approve-loan.component.css']
})
export class ApproveLoanComponent implements OnInit {

  loanAccountNo: string;
  loanApproveForm: FormGroup;
  loanApplication: ViewLoanApplication;
  approveLoan: ApprovedLoan;
  submit: boolean;
  error: string[];
  edit: boolean;
  constructor(private validatorsService: ValidatorsService,
    private route: ActivatedRoute,
    private router: Router,
    private viewLoanService: ViewLoanService, private formBuilder: FormBuilder, private successMessageService: SuccessMessageService) { }

  approve(status: boolean) {
    this.submit = true;
    if (status) {
      this.loanApproveForm.value.approve = true;
    } else {
      this.loanApproveForm.value.approve = false;
    }
    this.viewLoanService.approveLoan(this.loanAccountNo, this.loanApproveForm.value).subscribe(
      data => {
        this.approveLoan = data;
        this.router.navigate(['/admin/viewloanapp']);
      },
      error => {
        this.error = error;
        this.submit = false;
      }
    );
  }

  createForm() {
    this.loanApproveForm = this.formBuilder.group({
      'approve': [''],
      'interestRate': [this.loanApplication.interestRate, Validators.required],
      'remarks': ['', Validators.required],
      'adminUserId': []
    });
  }

  getLoanDetails() {
    if (this.loanAccountNo) {
      this.viewLoanService.getLoanApplicationForParticularLoan(this.loanAccountNo).subscribe(
        data => {
          this.loanApplication = data;
          this.createForm();
        },
        error => this.error = error
      );
    }
  }
  ngOnInit() {
    this.successMessageService.view = 'loan';
    this.successMessageService.subView = 'lnApp';
    this.loanAccountNo = this.route.snapshot.paramMap.get('account');
    this.getLoanDetails();
  }
}
