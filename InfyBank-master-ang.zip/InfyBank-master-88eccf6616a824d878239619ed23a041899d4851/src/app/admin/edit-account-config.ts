import { AccountConfig } from './account-config';

export class EditAccountConfig {
    accountconfig: AccountConfig[] = [];
    userId: string;
}
