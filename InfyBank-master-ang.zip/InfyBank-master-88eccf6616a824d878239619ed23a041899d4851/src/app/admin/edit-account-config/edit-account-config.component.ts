import { Router } from '@angular/router';
import { SuccessMessageService } from './../../shared/success-message.service';
import { ValidatorsService } from './../../shared/validators.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EditAccountConfig } from './../edit-account-config';
import { AccountConfig } from './../account-config';
import { AccountConfigService } from '../account-config.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-account-config',
  templateUrl: './edit-account-config.component.html',
  styleUrls: ['./edit-account-config.component.css']
})
export class EditAccountConfigComponent implements OnInit {

  accountConfigDetails: AccountConfig[];
  accountConfigFormCredit: FormGroup;
  accountConfigFormSaving: FormGroup;
  error: string[];
  errorMessage: string[];
  submitted: boolean;
  editAccountConfig: EditAccountConfig;

  constructor(
    private accountConfigService: AccountConfigService,
    private formBuilder: FormBuilder,
    private router: Router,
    private validatorsService: ValidatorsService,
    private successMessageService: SuccessMessageService) { }

  submit() {

    this.submitted = true;
    if (this.accountConfigFormSaving.dirty) {
      this.editAccountConfig.accountconfig.push(this.accountConfigFormSaving.value);
    }
    if (this.accountConfigFormCredit.dirty) {
      this.editAccountConfig.accountconfig.push(this.accountConfigFormCredit.value);
    }

    this.accountConfigService.editAccountConfig(this.editAccountConfig).subscribe(
      data => {
        this.successMessageService.message = 'EDITACCTCONFIG.SUCCESS';
        this.router.navigate(['/admin']);
      },
      error => {
        this.errorMessage = error;
        this.editAccountConfig = new EditAccountConfig();
        this.submitted = false;
      }
    );

  }

  getAccountConfig() {
    this.accountConfigService.getAccountConfig().subscribe(
      data => {
        this.accountConfigDetails = data;
        this.createForms();
      },
      error => this.error = error
    );
  }

  createForms() {
    this.accountConfigFormCredit = this.formBuilder.group({
      interestRate: ['', [Validators.required, Validators.min(0), Validators.max(100)]],
      minBalance: ['', Validators.required],
      acctType: ['C']

    });

    this.accountConfigFormSaving = this.formBuilder.group({
      interestRate: ['', [Validators.required, Validators.min(0), Validators.max(100)]],
      minBalance: ['', Validators.required],
      acctType: ['S']

    });
  }

  ngOnInit() {
    this.successMessageService.view = 'account';
    this.successMessageService.subView = '';
    this.editAccountConfig = new EditAccountConfig();
    this.getAccountConfig();
  }
}
