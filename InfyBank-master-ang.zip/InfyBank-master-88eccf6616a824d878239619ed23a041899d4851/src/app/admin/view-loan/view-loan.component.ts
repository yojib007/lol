import { SuccessMessageService } from './../../shared/success-message.service';
import { ViewLoanApplication } from './../view-loan-app';
import { ViewLoanService } from './../view-loan.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-loan',
  templateUrl: './view-loan.component.html',
  styleUrls: ['./view-loan.component.css']
})
export class ViewLoanComponent implements OnInit {

  loanApplicationList: ViewLoanApplication[];
  error: string[];
  constructor(private viewLoanService: ViewLoanService, private successMessageService: SuccessMessageService) { }

  getLoanApplication() {
    this.viewLoanService.getLoanApplication().subscribe(
      data => {
        this.loanApplicationList = data;
        if (!this.loanApplicationList.length) {
          this.error = ['ERRORS.VIEWLOAN.NOLOAN'];
        }
      },
      error => this.error = error
    );
  }

  ngOnInit() {
    this.successMessageService.view = 'loan';
    this.successMessageService.subView = 'lnApp';
    this.getLoanApplication();
  }

}
