import { SuccessMessageService } from './../../shared/success-message.service';
import { ViewLoanApplication } from './../view-loan-app';
import { Observable } from 'rxjs/Rx';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { ViewLoanService } from './../view-loan.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLoanComponent } from './view-loan.component';

class ViewLoanServiceStub {
  getLoanApplication() {
    return Observable.of([new ViewLoanApplication()]);
  }
}

describe('ViewLoanComponent', () => {
  const viewLoanServiceStub = new ViewLoanServiceStub();
  let component: ViewLoanComponent;
  let fixture: ComponentFixture<ViewLoanComponent>;
  let viewLoanService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, FormsModule],
      declarations: [ ViewLoanComponent ],
      providers: [{ provide: ViewLoanService, useValue: viewLoanServiceStub}, SuccessMessageService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLoanComponent);
    component = fixture.componentInstance;
    viewLoanService = TestBed.get(ViewLoanService);
    fixture.detectChanges();

  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  // Checking getLoanApplication method of viewLoanService is called when the component is created
  it('should call getLoanApplication method of viewLoanService', () => {
    const spy = spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of(true));
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  // Checking loanApplicationList is populated if data is recieved from ProfileSerivce
  it('should populate loanApplicationList if data is recieved from viewLoanService', () => {
    const spy = spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.of(true));
    component.ngOnInit();
    expect(component.loanApplicationList).toBe(true);
  });

  // Checking error is populated if error is thrown from ProfileSerivce
  it('should populate error with message recieved from viewLoanService if error is thrown', () => {
    const spy = spyOn(viewLoanService, 'getLoanApplication').and.returnValue(Observable.throw('Server Error'));
    component.ngOnInit();
    expect(component.error).toBe('Server Error');
  });
});
