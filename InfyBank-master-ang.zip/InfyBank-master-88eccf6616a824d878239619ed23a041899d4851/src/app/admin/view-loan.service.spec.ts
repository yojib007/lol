import { LoanApproval } from './loan-approval';
import { UserInformationService } from './../shared/user-information.service';
import { Observable } from 'rxjs/Rx';
import { UserInformation } from './../shared/user-information';
import { RestService } from './../shared/rest-service';
import { ProfileService } from './../shared/profile.service';
import { TestBed, inject } from '@angular/core/testing';

import { ViewLoanService } from './view-loan.service';

class UserInformationServiceStub {
  userDetail = new UserInformation();
}

class RestServiceStub {
  get() { }
  put() { }
}

describe('ViewLoanService', () => {

  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewLoanService,
        { provide: UserInformationService, useValue: userInformationServiceStub },
        { provide: RestService, useValue: restServiceStub }]
    });
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([ViewLoanService], (service: ViewLoanService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the getLoanApplication function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([ViewLoanService], (service: ViewLoanService) => {

        const spy = spyOn(restService, 'get');
        service.getLoanApplication();
        expect(spy).toHaveBeenCalled();

      }));

    // Checking getLoanApplication function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([ViewLoanService], (service: ViewLoanService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.of(true));
        service.getLoanApplication().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking getLoanApplication function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([ViewLoanService], (service: ViewLoanService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.throw('Server Error'));
        service.getLoanApplication().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

  describe('on calling the approveLoan function', () => {

    let returnValue;
    let errMsg;

    // Checking put method of RestService is called
    it('should invoke put method of RestService',
      inject([ViewLoanService], (service: ViewLoanService) => {

        const spy = spyOn(restService, 'put');
        service.approveLoan('address', new LoanApproval());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking approveLoan function returning the Observable of true which is returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([ViewLoanService], (service: ViewLoanService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.of(true));
        service.approveLoan('address', new LoanApproval()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking approveLoan function returning the Observable of error which is returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([ViewLoanService], (service: ViewLoanService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.throw('Server Error'));
        service.approveLoan('address', new LoanApproval()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });
});
