import { ApproveLoanComponent } from './approve-loan/approve-loan.component';
import { ViewLoanComponent } from './view-loan/view-loan.component';
import { ViewEditLoanRateComponent } from './view-edit-loan-rate/view-edit-loan-rate.component';
import { EditAccountConfigComponent } from './edit-account-config/edit-account-config.component';
import { AccountConfigComponent } from './account-config/account-config.component';
import { AuthGuardAdminService } from './../shared/auth-guard.admin.service';


import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [

        { path: '', component: AccountConfigComponent },
        { path: 'editaccountconifg', component: EditAccountConfigComponent },
        { path: 'vieweditloanrate', component: ViewEditLoanRateComponent },
        { path: 'viewloanapp', component: ViewLoanComponent },
        { path: 'approve/:account', component: ApproveLoanComponent }
    ],
    canActivate: [AuthGuardAdminService]
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
