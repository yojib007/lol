import { UserInformationService } from './../shared/user-information.service';
import { LoanApproval } from './loan-approval';
import { ApprovedLoan } from './approved-loan';
import { ViewLoanApplication } from './view-loan-app';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../shared/rest-service';
import { Injectable } from '@angular/core';

@Injectable()
export class ViewLoanService {

  getLoanAppUrl = '/infybank_core/v1/';
  constructor(private restService: RestService, private userInformationService: UserInformationService) { }

  getLoanApplication(): Observable<ViewLoanApplication[]> {
    return this.restService.get( this.getLoanAppUrl + 'loans?loanStatus=S');
  }

  getLoanApplicationForParticularLoan(loanNo: string): Observable<ViewLoanApplication> {
    return this.restService.get( this.getLoanAppUrl + 'loans/' + loanNo);
  }

  approveLoan(loanAccountNo: string, data: LoanApproval): Observable<ApprovedLoan> {
    data.adminUserId = this.userInformationService.userDetail.userId;
    return this.restService.put(this.getLoanAppUrl + 'loans/' + loanAccountNo + '/approve', data);
  }
}
