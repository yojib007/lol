import { Router } from '@angular/router';
import { SuccessMessageService } from './../../shared/success-message.service';
import { ProfileService } from './../../shared/profile.service';
import { ValidatorsService } from './../../shared/validators.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { Profile } from './../../shared/profile';

@Component({
  selector: 'app-update-email',
  templateUrl: './update-email.component.html',
  styleUrls: ['./update-email.component.css']
})
export class UpdateEmailComponent implements OnInit {
  userDetails: Profile;
  errorMessage: string[];
  submit: boolean;
  emailForm: FormGroup;
  error: string[];

  constructor(private successMessageService: SuccessMessageService, private router: Router,
    private validatorsService: ValidatorsService, private profileService: ProfileService, private formBuilder: FormBuilder) { }

  changeEmail() {
    this.submit = true;
    this.userDetails.email = this.emailForm.value.email;
    this.profileService.update(this.userDetails).subscribe(
      data => {
        this.successMessageService.message = 'UPDEMAIL.SUCCESS';
        this.router.navigate(['/profile']);
      },
      error => {
        this.error = error;
        this.submit = false;
      }
    );

  }
  getUserDetails() {
    this.profileService.getUserDetails().subscribe(
      user => {
        this.userDetails = user;
        this.createForm();
      },
      error => this.errorMessage = error
    );
  }

  createForm() {
    this.emailForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern('([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})')]]
    });
  }
  ngOnInit() {
    this.successMessageService.view = 'profile';
    this.getUserDetails();
  }

}
