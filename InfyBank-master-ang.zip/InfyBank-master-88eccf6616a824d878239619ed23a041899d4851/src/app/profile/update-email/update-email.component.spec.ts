import { SuccessMessageService } from './../../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { UpdateEmailComponent } from './update-email.component';
import { ValidatorsService } from './../../shared/validators.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfileService } from './../../shared/profile.service';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Profile } from './../../shared/profile';
import { Router } from '@angular/router';

class ProfileServiceStub {
    getUserDetails() {
        return Observable.of(new Profile());
    }
    update() { }
}

class ValidatorsServiceStub {
    isFieldHasErrors() {
    }
}

describe('UpdateEmailComponent', () => {

    let component: UpdateEmailComponent;
    let fixture: ComponentFixture<UpdateEmailComponent>;
    const profileServiceStub = new ProfileServiceStub();
    const validatorsServiceStub = new ValidatorsServiceStub();
    let profileService;
    let submitBtn;
    let router;
    let successMessageService;

    beforeEach(async () => {
        TestBed.configureTestingModule({
            declarations: [UpdateEmailComponent],
            imports: [FormsModule, ReactiveFormsModule, RouterTestingModule],
            providers: [
                { provide: ProfileService, useValue: profileServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                SuccessMessageService
            ]
        }).compileComponents();
        profileService = TestBed.get(ProfileService);
        router = TestBed.get(Router);
        successMessageService = TestBed.get(SuccessMessageService);
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(UpdateEmailComponent);
        component = fixture.componentInstance;
        profileService = TestBed.get(ProfileService);
        fixture.detectChanges();
        submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
    });

    // Checking everything is created correct or not
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking getUserDetails method of ProfileService is called when the component is created
    it('should call getUserDetails method of ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(true));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    // Checking userDetails is populated if data is recieved from ProfileSerivce
    it('should populate userDetails if data is recieved from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(true));
        component.ngOnInit();
        expect(component.userDetails).toBe(true);
    });

    // Checking errorMessage is populated if error is thrown from ProfileSerivce
    it('should populate userDetails if data is recieved from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.errorMessage).toBe('Server Error');
    });

    it('should have submit button disabled if form is invalid', () => {

        expect(submitBtn.disabled).toBeTruthy();

    });

    describe('has email field which is empty', () => {
        let errors = {};
        let email;
        beforeEach(() => {
            email = component.emailForm.controls['email'];
            email.setValue('');
            errors = email.errors || {};
            fixture.detectChanges();
        });

        // Checking email is invalid if it is empty
        it('should be invalid', () => {

            expect(email.valid).toBeFalsy();

        });

        // Checking required error is present if email is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has email field which is filled with invalid emaildId', () => {
        let errors = {};
        let email;
        beforeEach(() => {
            email = component.emailForm.controls['email'];
            email.setValue('abc400');
            errors = email.errors || {};
            fixture.detectChanges();
        });

        // Checking email is invalid if it is incorrect
        it('should be invalid', () => {

            expect(email.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking pattern error is present if email is invalid
        it('should contain pattern error', () => {
            expect(errors['pattern']).toBeTruthy();

        });

    });

    describe('has email field which is filled with valid emailId', () => {
        let errors = {};
        let email;
        beforeEach(() => {
            email = component.emailForm.controls['email'];
            email.setValue('kalpana@infosys.com');
            errors = email.errors || {};
            fixture.detectChanges();
        });

        // Checking email is valid if it is filled
        it('should be valid', () => {

            expect(email.valid).toBeTruthy();

        });

        // Checking required error is not present if field is correct
        it('should not contain pattern error', () => {
            expect(errors['pattern']).toBeFalsy();

        });

    });

    describe('emailForm when all fields are valid', () => {

        beforeEach(() => {
            component.emailForm.controls['email'].setValue('kalpana@infosys.com');
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.emailForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // invokeUserService function should be called on clicking the submit button
        it('should call changeEmail function on clicking submit button', () => {

            const spy = spyOn(component, 'changeEmail');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('invoking changeEmail function', () => {

        // should call update method of ProfileService
        it('should call update method of ProfileService', () => {

            const spy = spyOn(profileService, 'update').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate').and.returnValue(null);
            component.changeEmail();
            expect(spy).toHaveBeenCalledWith(component.userDetails);
        });

        describe('on recieving data from update method of ProfileService', () => {

            let spy;
            beforeEach(() => {
                spyOn(profileService, 'update').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate').and.returnValue(null);
                component.changeEmail();
            });

            // Populate message if data is recieved from update method of ProfileService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/profile']);
            });
        });

        // Populate error if error is thrown from update method of ProfileService
        it('should populate error if error is thrown from update method of ProfileService', () => {

            spyOn(profileService, 'update').and.returnValue(Observable.throw('Server Error'));
            component.changeEmail();
            expect(component.error).toBe('Server Error');
        });
    });
});
