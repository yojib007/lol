import { Router } from '@angular/router';
import { SuccessMessageService } from './../../shared/success-message.service';
import { ProfileService } from './../../shared/profile.service';
import { ValidatorsService } from './../../shared/validators.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { Profile } from './../../shared/profile';

@Component({
  selector: 'app-update-address',
  templateUrl: './update-address.component.html',
  styleUrls: ['./update-address.component.css']
})
export class UpdateAddressComponent implements OnInit {

  userDetails: Profile;
  errorMessage: string[];
  error: string[];
  submit: boolean;
  addressForm: FormGroup;
  constructor(private validatorsService: ValidatorsService, private profileService: ProfileService,
    private formBuilder: FormBuilder, private successMessageService: SuccessMessageService,
    private router: Router) { }

  changeAddress() {
    this.submit = true;
    this.profileService.update(this.userDetails).subscribe(
      data => {
        this.successMessageService.message = 'UPDADDRESS.SUCCESS';
        this.router.navigate(['/profile']);

      },
      error => {
        this.error = error;
        this.submit = false;
      }
    );
  }

  createForm() {
    this.addressForm = this.formBuilder.group({
      address: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
      pinCode: ['', [Validators.required, Validators.pattern('[1-9][0-9]{5}')]]
    });
  }

  getUserDetails() {
    this.profileService.getUserDetails().subscribe(
      user => {
        this.userDetails = user;
        this.createForm();
      },
      error => this.errorMessage = error
    );
  }
  ngOnInit() {
    this.successMessageService.view = 'profile';
    this.getUserDetails();
  }

}
