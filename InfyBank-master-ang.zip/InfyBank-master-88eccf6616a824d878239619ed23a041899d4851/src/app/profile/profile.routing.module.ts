import { AuthGuardUserService } from './../shared/auth-guard.user.service';
import { UpdateCreditDebitLimitComponent } from './update-credit-debit-limit/update-credit-debit-limit.component';
import { UpdateDateAmountComponent } from './update-date-amount/update-date-amount.component';
import { UpdateEmailComponent } from './update-email/update-email.component';
import { UpdateAddressComponent } from './update-address/update-address.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [
    { path: '', component: MyProfileComponent },
    { path: 'updaddress', component: UpdateAddressComponent },
    { path: 'updemail', component: UpdateEmailComponent },
    { path: 'upddateamount', component: UpdateDateAmountComponent },
    { path: 'updcreditlimit', component: UpdateCreditDebitLimitComponent }
    ],
    canActivate: [AuthGuardUserService]
  }];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileRoutingModule { }
