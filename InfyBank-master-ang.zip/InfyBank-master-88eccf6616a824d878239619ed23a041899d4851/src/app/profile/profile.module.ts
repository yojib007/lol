import { ProfileRoutingModule } from './profile.routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { UpdateAddressComponent } from './update-address/update-address.component';
import { UpdateEmailComponent } from './update-email/update-email.component';
import { UpdateDateAmountComponent } from './update-date-amount/update-date-amount.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { UpdateCreditDebitLimitComponent } from './update-credit-debit-limit/update-credit-debit-limit.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule, ReactiveFormsModule, FormsModule, ProfileRoutingModule, TranslateModule
  ],
  declarations: [
    MyProfileComponent,
    UpdateAddressComponent,
    UpdateEmailComponent,
    UpdateDateAmountComponent,
    UpdateCreditDebitLimitComponent
  ],
  providers: []
})
export class ProfileModule { }
