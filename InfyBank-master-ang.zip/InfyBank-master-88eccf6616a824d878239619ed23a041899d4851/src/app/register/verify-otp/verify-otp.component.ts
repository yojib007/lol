import { VerifyAadhar } from './../verify-aadhar/verify-aadhar';
import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { RegisterService } from '../register.service';
import { VerifyOtp } from './verify-otp';
import { VerifyOtpService } from './verify-otp.service';
import { ValidatorsService } from '../../shared/validators.service';

declare var $: any;

@Component({
    selector: 'app-verify-otp',
    templateUrl: './verify-otp.component.html',
    styleUrls: ['../register.component.css']
})
export class VerifyOtpComponent implements OnInit {


    otpObj = new VerifyOtp();
    submit: boolean;
    otpForm: FormGroup;
    otpError: string[];
    @Output() fetchOtpData: EventEmitter<VerifyOtp> = new EventEmitter<VerifyOtp>();

    /**
     *
     * @param verifyOtpService - to submit OTP data to server
     * @param formBuilder - to create a reactive form
     */
    constructor(
        private verifyOtpService: VerifyOtpService,
        private validatorsService: ValidatorsService,
        private formBuilder: FormBuilder) { }

    /**
     * Creates a OTP form instance and binds its properties with validators
     */
    ngOnInit() {
        this.otpForm = this.formBuilder.group({
            otp: [this.otpObj.otp, [Validators.required, Validators.pattern('[0-9]{6}')]],
        });
    }

    /**
     * Invokes service class methods to submit OTP data to server
     */
    invokeOtpService() {

        this.submit = true;
        this.verifyOtpService.verifyOtp(this.otpObj).subscribe(
            (data) => {
                $('.carousel').carousel('next');
            },
            error => {
                this.otpError = error;
                this.submit = false;
            }
        );
    }
}
