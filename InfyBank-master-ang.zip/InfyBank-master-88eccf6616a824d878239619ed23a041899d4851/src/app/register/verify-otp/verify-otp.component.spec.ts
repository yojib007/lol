import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Rx';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VerifyOtpComponent } from './verify-otp.component';
import { VerifyOtpService } from './verify-otp.service';
import { ValidatorsService } from '../../shared/validators.service';
declare var $;

describe('VerifyOtpComponent', () => {

    const ValidatorsServiceStub = {
        isFieldHasErrors() { }
    };
    const verifyOtpServiceStub = {
        verifyOtp(data: any) { }
    };
    let verifyOtpService: VerifyOtpService;
    let component: VerifyOtpComponent;
    let fixture: ComponentFixture<VerifyOtpComponent>;
    let submitBtn;


    beforeEach(async(() => {

        TestBed.configureTestingModule({
            declarations: [VerifyOtpComponent],
            imports: [ReactiveFormsModule, FormsModule, RouterTestingModule],
            providers: [{ provide: VerifyOtpService, useValue: verifyOtpServiceStub },
            { provide: ValidatorsService, useValue: ValidatorsServiceStub }
            ],
        })
            .compileComponents();

    }));

    beforeEach(() => {
        verifyOtpService = TestBed.get(VerifyOtpService);
        fixture = TestBed.createComponent(VerifyOtpComponent);
        component = fixture.componentInstance;
        submitBtn = fixture.debugElement.query(By.css('#submitButton')).nativeElement;
        component.ngOnInit();
        fixture.detectChanges();
    });

    // Checking everything is created correct or not
    it(' should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking submit button is disabled till form is invalid
    it('should have submit button disabled at initialization', () => {

        expect(submitBtn.disabled).toBe(true);
    });

    describe('have otp field which is empty', () => {
        let errors = {};
        let otp;
        beforeEach(() => {
            otp = component.otpForm.controls['otp'];
            otp.setValue('');
            errors = otp.errors || {};
            fixture.detectChanges();
        });

        // Checking otp is invalid if it is empty
        it('should be invalid', () => {

            expect(otp.valid).toBeFalsy();

        });

        // Checking required error is present if otp is not entered
        it('should contains required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('have otp field which is filled with values not matching the pattern [1-9][0-9]{5}', () => {
        let errors = {};
        let otp;
        beforeEach(() => {
            otp = component.otpForm.controls['otp'];
            otp.setValue(1234534);
            errors = otp.errors || {};
            fixture.detectChanges();
        });

        // Checking otp is invalid if it is incorrect
        it('should be invalid', () => {

            expect(otp.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contains required error', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking required error is present if otp is not entered
        it('should contains pattern error', () => {
            expect(errors['pattern']).toBeTruthy();

        });

    });

    describe('have otp field which is filled with values matching the pattern [1-9][0-9]{5}', () => {
        let errors = {};
        let otp;
        beforeEach(() => {
            otp = component.otpForm.controls['otp'];
            otp.setValue(123456);
            errors = otp.errors || {};
            fixture.detectChanges();
        });

        // Checking otp is valid if it is filled
        it('should be valid', () => {

            expect(otp.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contains required error', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking required error is not present if field is correct
        it('should not contains pattern error', () => {
            expect(errors['pattern']).toBeFalsy();

        });

    });

    describe('otpForm when all fields are valid', () => {

        beforeEach(() => {
            component.otpForm.controls['otp'].setValue(123456);
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.otpForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('have submit button which should be enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // invokeOtpService function should be called on clicking the submit button
        it('should call invokeOtpService function on clicking submit button', () => {

            const spy = spyOn(component, 'invokeOtpService');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('calling invokeOtpService', () => {

        // invokeotpService function of VerifyOtpService should be called by clicking the submit button
        it('should call invokeotpService function', () => {

            const spy = spyOn(verifyOtpService, 'verifyOtp').and.returnValue(Observable.of(true));
            component.invokeOtpService();
            expect(spy).toHaveBeenCalledWith(component.otpObj);
        });

    });

    describe('has invokeOtpService on getting Observable of true from verifyOtpService', () => {

        let spyOnCarousel;

        beforeEach(() => {
            spyOnCarousel = spyOn($.fn, 'carousel');
            spyOn(verifyOtpService, 'verifyOtp').and.returnValue(Observable.of(true));
            component.invokeOtpService();

        });

        // carousel should moved to next slide if Obervable of true is returned
        it('should call the carousel', () => {

            component.invokeOtpService();
            expect(spyOnCarousel).toHaveBeenCalledWith('next');

        });

        // verifyOtp function of verifyOtpService should be called by clicking the submit button
        it('should not populate otpError', () => {

            expect(component.otpError).toBeFalsy();
        });

    });

    describe('has invokeOtpService on getting Observable of error from verifyOtpService', () => {

        let spy;

        beforeEach(() => {
            spy = spyOn($.fn, 'carousel');
            spyOn(verifyOtpService, 'verifyOtp').and.returnValue(Observable.throw('Invalid Otp'));
            component.invokeOtpService();

        });

        // carousel should not be invoked
        it('should not call the carousel', () => {

            component.invokeOtpService();
            expect(spy).not.toHaveBeenCalled();

        });

        it('should populate otpError', () => {

            expect(component.otpError).toBe('Invalid Otp');
        });

    });


});
