export class VerifyOtp {
     otp: number;
     emailId: string;
}
