
export class AccountDetails {
    accountType: string;
    openingBalance: number;
    salariedAccount: string;
    panNo: string;

}
