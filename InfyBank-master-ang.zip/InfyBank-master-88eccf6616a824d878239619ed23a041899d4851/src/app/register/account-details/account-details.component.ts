import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';

import { AccountDetails } from './account-details';
import { ValidatorsService } from '../../shared/validators.service';

declare var $: any;

@Component({
    selector: 'app-account-details',
    templateUrl: './account-details.component.html',
    styleUrls: ['../register.component.css']
})
export class AccountDetailsComponent implements OnInit {

    accInfoForm: FormGroup;
    accountDetails = new AccountDetails();
    @Output() fetchAccountData: EventEmitter<AccountDetails> = new EventEmitter<AccountDetails>();

    /**
     * Constructor to inject service classes
     *
     * @param accountDetailsService - to fetch account details
     * @param formBuilder - for model driven forms
     */
    constructor(private validatorsService: ValidatorsService, private formBuilder: FormBuilder) { }


    /**
     * Creates account form instance and binds properties with respective validators
     */
    ngOnInit() {

        this.accInfoForm = this.formBuilder.group({
            acctype: ['', Validators.required],
            obal: ['', [Validators.required, Validators.pattern('[1-9][0-9]{0,}')]],
            salacctype: ['', Validators.required],
            pan: ['', [Validators.required, Validators.pattern('[A-Z]{5}[0-9]{4}[A-Z]{1}')]]
        });
    }

    /**
     * Method to submit data to AccountService class
     */
    invokeAccService() {
        this.fetchAccountData.emit(this.accountDetails);
        $('.carousel').carousel('next');
    }

    /**
     * Converts Pan Number to uppercase
     */
    uppercase() {
        if (this.accountDetails.panNo) {
            this.accountDetails.panNo = this.accountDetails.panNo.toUpperCase();
        }
    }
}
