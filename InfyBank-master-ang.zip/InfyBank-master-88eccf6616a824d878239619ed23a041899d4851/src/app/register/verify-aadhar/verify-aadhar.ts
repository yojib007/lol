export class VerifyAadhar {
    public firstName: string;
    public lastName: string;
    public aadharId: string;
    public emailId: string;

}
