import { RouterModule, Router } from '@angular/router';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VerifyAadharComponent } from './verify-aadhar.component';
import { VerifyAadharService } from './verify-aadhar.service';
import { ValidatorsService } from '../../shared/validators.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

declare var $: any;

describe('VerifyAadharComponent', () => {

  const ValidatorsServiceStub = {
    isFieldHasErrors() { }
  };
  const verifyAadharServiceStub = {
    verifyAadhar() {
    }
  };
  let verifyAadharService: VerifyAadharService;
  let component: VerifyAadharComponent;
  let fixture: ComponentFixture<VerifyAadharComponent>;
  let submitBtn;

  beforeEach(async(() => {

    TestBed.configureTestingModule({
      declarations: [VerifyAadharComponent],
      imports: [ReactiveFormsModule, FormsModule, RouterTestingModule],
      providers: [{ provide: VerifyAadharService, useValue: verifyAadharServiceStub },
      { provide: ValidatorsService, useValue: ValidatorsServiceStub },
      ],
    })
      .compileComponents();

  }));

  beforeEach(() => {
    verifyAadharService = TestBed.get(VerifyAadharService);
    fixture = TestBed.createComponent(VerifyAadharComponent);
    component = fixture.componentInstance;
    submitBtn = fixture.debugElement.query(By.css('#submitButton')).nativeElement;
    fixture.detectChanges();
  });

  // Checking everything is created correct or not
  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  // Checking submit button is disabled till form is invalid
  it('should have submit button disabled at initialization', () => {

    expect(submitBtn.disabled).toBe(true);
  });

  describe('has fName field which is empty', () => {
    let errors = {};
    let fName;
    beforeEach(() => {
      fName = component.registerForm.controls['fName'];
      fName.setValue('');
      errors = fName.errors || {};
      fixture.detectChanges();
    });

    // Checking fName is invalid if it is empty
    it('should be invalid', () => {

      expect(fName.valid).toBeFalsy();

    });

    // Checking required error is present if lName is not entered
    it('should contain required error', () => {
      expect(errors['required']).toBeTruthy();

    });

  });

  describe('has fName field which is filled', () => {
    let errors = {};
    let fName;
    beforeEach(() => {
      fName = component.registerForm.controls['fName'];
      fName.setValue('Kalpana');
      errors = fName.errors || {};
      fixture.detectChanges();
    });

    // Checking fName is valid if it is filled
    it('should be valid', () => {

      expect(fName.valid).toBeTruthy();

    });

    // Checking required error is not present if field is filled
    it('should not contain required error', () => {
      expect(errors['required']).toBeFalsy();

    });

  });

  describe('has lName field which is empty', () => {
    let errors = {};
    let lName;
    beforeEach(() => {
      lName = component.registerForm.controls['lName'];
      lName.setValue('');
      errors = lName.errors || {};
      fixture.detectChanges();
    });

    // Checking lName is invalid if it is empty
    it('should be invalid', () => {

      expect(lName.valid).toBeFalsy();

    });

    // Checking required error is present if lName is not entered
    it('should contain required error', () => {
      expect(errors['required']).toBeTruthy();

    });

  });

  describe('has lName field which is filled', () => {
    let errors = {};
    let lName;
    beforeEach(() => {
      lName = component.registerForm.controls['lName'];
      lName.setValue('Kalpana');
      errors = lName.errors || {};
      fixture.detectChanges();
    });

    // Checking lName is valid if it is filled
    it('should be valid', () => {

      expect(lName.valid).toBeTruthy();

    });

    // Checking required error is not present if field is filled
    it('should not contain required error', () => {
      expect(errors['required']).toBeFalsy();

    });

  });

  describe('has aadhar field which is empty', () => {
    let errors = {};
    let aadhar;
    beforeEach(() => {
      aadhar = component.registerForm.controls['aadhar'];
      aadhar.setValue('');
      errors = aadhar.errors || {};
      fixture.detectChanges();
    });

    // Checking aadhar is invalid if it is empty
    it('should be invalid', () => {

      expect(aadhar.valid).toBeFalsy();

    });

    // Checking required error is present if aadhar is not entered
    it('should contain required error', () => {
      expect(errors['required']).toBeTruthy();

    });

  });

  describe('has aadhar field which is filled with values not matching the pattern [1-9][0-9]{11}', () => {
    let errors = {};
    let aadhar;
    beforeEach(() => {
      aadhar = component.registerForm.controls['aadhar'];
      aadhar.setValue('1234534ABD');
      errors = aadhar.errors || {};
      fixture.detectChanges();
    });

    // Checking aadhar is invalid if it is incorrect
    it('should be invalid', () => {

      expect(aadhar.valid).toBeFalsy();

    });

    // Checking required error is not present if field is filled
    it('should not contain required error', () => {
      expect(errors['required']).toBeFalsy();

    });

    // Checking required error is present if aadhar is not entered
    it('should contain pattern error', () => {
      expect(errors['pattern']).toBeTruthy();

    });

  });

  describe('has aadhar field which is filled with values matching the pattern [1-9][0-9]{11}', () => {
    let errors = {};
    let aadhar;
    beforeEach(() => {
      aadhar = component.registerForm.controls['aadhar'];
      aadhar.setValue('123456789101');
      errors = aadhar.errors || {};
      fixture.detectChanges();
    });

    // Checking aadhar is valid if it is filled
    it('should be valid', () => {

      expect(aadhar.valid).toBeTruthy();

    });

    // Checking required error is not present if field is correct
    it('should not contain pattern error', () => {
      expect(errors['pattern']).toBeFalsy();

    });

  });

  describe('has eid field which is empty', () => {
    let errors = {};
    let eid;
    beforeEach(() => {
      eid = component.registerForm.controls['eid'];
      eid.setValue('');
      errors = eid.errors || {};
      fixture.detectChanges();
    });

    // Checking eid is invalid if it is empty
    it('should be invalid', () => {

      expect(eid.valid).toBeFalsy();

    });

    // Checking required error is present if eid is not entered
    it('should contain required error', () => {
      expect(errors['required']).toBeTruthy();

    });

  });

  describe(`has eid field which is filled with values
    not matching the pattern ([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})`, () => {
    let errors = {};
    let eid;
    beforeEach(() => {
      eid = component.registerForm.controls['eid'];
      eid.setValue('1234534ABD');
      errors = eid.errors || {};
      fixture.detectChanges();
    });

    // Checking eid is invalid if it is incorrect
    it('should be invalid', () => {

      expect(eid.valid).toBeFalsy();

    });

    // Checking required error is not present if field is filled
    it('should not contain required error', () => {
      expect(errors['required']).toBeFalsy();

    });

    // Checking required error is present if eid is not entered
    it('should contain pattern error', () => {
      expect(errors['pattern']).toBeTruthy();

    });

  });

  describe(`has eid field which is filled with values matching
    the pattern ([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})`, () => {

    let errors = {};
    let eid;
    beforeEach(() => {
      eid = component.registerForm.controls['eid'];
      eid.setValue('test@xyz.com');
      errors = eid.errors || {};
      fixture.detectChanges();
    });

    // Checking eid is valid if it is filled
    it('should be valid', () => {

      expect(eid.valid).toBeTruthy();

    });

    // Checking required error is not present if field is correct
    it('should not contain pattern error', () => {
      expect(errors['pattern']).toBeFalsy();

    });

  });

  describe('registerForm when all fields are valid', () => {

    beforeEach(() => {
      component.registerForm.controls['fName'].setValue('Kalpana');
      component.registerForm.controls['lName'].setValue('ETA');
      component.registerForm.controls['aadhar'].setValue('123465789012');
      component.registerForm.controls['eid'].setValue('kalpan@infosys.com');
      fixture.detectChanges();
    });

    // form should be valid if all feilds are filled properly
    it('should be valid', () => {

      expect(component.registerForm.valid).toBe(true);

    });

    // checking submit button is enabled if form is valid
    it('should has submit button enabled', () => {

      expect(submitBtn.disabled).toBe(false);

    });

    // invokeAadharService function should be called on clicking the submit button
    it('should call invokeAadharService function on clicking submit button', () => {

      const spy = spyOn(component, 'invokeAadharService');
      submitBtn.click();
      expect(spy).toHaveBeenCalled();
    });

  });

  describe('has invokeAadharService on getting Observable of true from verifyAadharService', () => {

    let spyOnCarousel;

    beforeEach(() => {
      spyOnCarousel = spyOn($.fn, 'carousel');
      spyOn(verifyAadharService, 'verifyAadhar').and.returnValue(Observable.of(true));
      component.invokeAadharService();

    });

    // carousel should moved to next slide if Obervable of true is returned
    it('should call the carousel', () => {

      component.invokeAadharService();
      expect(spyOnCarousel).toHaveBeenCalledWith('next');

    });

    // Checking vAadharObj is emitted if function is called
    it('should emit the event with vAadharObj object', () => {
        const spy = spyOn(component.fetchAadharData, 'emit');
        component.invokeAadharService();
        expect(spy).toHaveBeenCalledWith(component.vAadharObj);

     });

    // verifyAadhar function of verifyAadharService should be called by clicking the submit button
    it('should not populate aadharError', () => {

      expect(component.aadharError).toBeFalsy();
    });

  });

  describe('has invokeAadharService on getting Observable of error from verifyAadharService', () => {

    let spy;

    beforeEach(() => {
      spy = spyOn($.fn, 'carousel');
      spyOn(verifyAadharService, 'verifyAadhar').and.returnValue(Observable.throw('AadharId is not mapped to Customer'));
      component.invokeAadharService();

    });

    // carousel should not be invoked
    it('should not call the carousel', () => {

      component.invokeAadharService();
      expect(spy).not.toHaveBeenCalled();

    });

    // verifyAadhar function of verifyAadharService should be called by clicking the submit button
    it('should populate aadharError', () => {

      expect(component.aadharError).toBe('AadharId is not mapped to Customer');
    });

  });

});
