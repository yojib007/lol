import { Observable } from 'rxjs/Rx';
import { RegisterServerClass } from './register-server';
import { RouterModule } from '@angular/router';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';

import { RegisterComponent } from './register.component';
import { RegisterService } from './register.service';
import { VerifyAadhar } from './verify-aadhar/verify-aadhar';
import { VerifyOtp } from './verify-otp/verify-otp';
import { UserDetails } from './user-details/user-details';
import { AccountDetails } from './account-details/account-details';

class RegisterServiceStub {

    registerServerClass = new RegisterServerClass();
    register() { }
}
describe('RegisterComponent', () => {

    let component: RegisterComponent;
    let fixture: ComponentFixture<RegisterComponent>;
    const registerServiceStub = new RegisterServiceStub();
    let registerService;
    beforeEach(async(() => {

        TestBed.configureTestingModule({
            declarations: [RegisterComponent],
            imports: [ReactiveFormsModule, FormsModule, RouterModule],
            providers: [{ provide: RegisterService, useValue: registerServiceStub }],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
        registerService = TestBed.get(RegisterService);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RegisterComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    // Checking everything is created correct or not
    it(' should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking aadharData function is called if an event is dispatched from verify-aadhar component
    it('should get value from child component verify-aadhar', () => {

        spyOn(component, 'aadharData');
        const verifyAadhar = fixture.debugElement.query(By.css('app-verify-aadhar')).nativeElement;
        verifyAadhar.dispatchEvent(new Event('fetchAadharData'));
        expect(component.aadharData).toHaveBeenCalled();
    });

    // Checking userData function is called if an event is dispatched from user-details component
    it('should get value from child component user-details', () => {

        spyOn(component, 'userData');
        const userDetails = fixture.debugElement.query(By.css('app-user-details')).nativeElement;
        userDetails.dispatchEvent(new Event('fetchUserData'));
        expect(component.userData).toHaveBeenCalled();
    });

    // Checking accData function is called if an event is dispatched from account-details component
    it('should get value from child component account-details', () => {

        spyOn(component, 'accData');
        const accountDetails = fixture.debugElement.query(By.css('app-account-details')).nativeElement;
        accountDetails.dispatchEvent(new Event('fetchAccountData'));
        expect(component.accData).toHaveBeenCalled();
    });

    // Checking aadharData function
    it('should call aadharData function which inturn assign recieved obj to register.aadharObj', () => {

        const aadharObj = new VerifyAadhar();
        component.aadharData(aadharObj);
        expect(component.register.aadharObj).toBe(aadharObj);
    });

    // Checking userData function
    it('should call userData function which inturn assign recieved obj to register.userObj', () => {

        const userObj = new UserDetails();
        component.userData(userObj);
        expect(component.register.userObj).toBe(userObj);
    });

    // Checking accData function
    it('should call accData function which inturn assign recieved obj to register.accObj', () => {

        const accObj = new AccountDetails();
        component.accData(accObj);
        expect(component.register.accObj).toBe(accObj);
    });

    it('should call submit function on clicking submit button', () => {

        const spy = spyOn(component, 'submit');
        const submitBtn = fixture.debugElement.query(By.css('#submitButton')).nativeElement;
        submitBtn.click();
        expect(spy).toHaveBeenCalled();

    });

    // Checking submit function
    describe('invoking submit function', () => {

        // On calling submit function should invoke
        it('should call register method of registerService', () => {
            const spy = spyOn(registerService, 'register').and.returnValue(Observable.of(true));
            component.submit();
            expect(spy).toHaveBeenCalled();

        });

        // should populate success with data is returned from registerService
        it('should populate success if data is recived from registerService', () => {

            const spy = spyOn(registerService, 'register').and.returnValue(Observable.of(true));
            component.submit();
            expect(component.success).toBe(true);

        });

        // should populate error if error is returned from registerService
        it('should populate error if error is recived from registerService', () => {

            const spy = spyOn(registerService, 'register').and.returnValue(Observable.throw('Server Error'));
            component.submit();
            expect(component.error).toBe('Server Error');

        });
    });

});
