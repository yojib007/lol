import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { UserDetailsComponent } from './user-details.component';
import { ValidatorsService } from '../../shared/validators.service';

declare var $: any;

class ValidatorsServiceStub {
    isFieldHasErrors() {
    }
}

describe('UserDetailsComponent', () => {

    const validatorsServiceStub = new ValidatorsServiceStub();
    let component: UserDetailsComponent;
    let fixture: ComponentFixture<UserDetailsComponent>;
    let submitBtn;

    beforeEach(async(() => {

        TestBed.configureTestingModule({
            declarations: [UserDetailsComponent],
            imports: [ReactiveFormsModule, FormsModule],
            providers: [FormBuilder,
            {provide: ValidatorsService, useValue: validatorsServiceStub}]
        })
            .compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UserDetailsComponent);
        component = fixture.componentInstance;
        submitBtn = fixture.debugElement.query(By.css('#submitButton')).nativeElement;
        component.ngOnInit();
        fixture.detectChanges();
    });

    // Checking everything is created correct or not
    it(' should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking submit button is disabled till form is invalid
    it('should has submit button disabled at initialization', () => {

        expect(submitBtn.disabled).toBe(true);
    });

    describe('has address field which is empty', () => {
        let errors = {};
        let address;
        beforeEach(() => {
            address = component.userInfoForm.controls['address'];
            address.setValue('');
            errors = address.errors || {};
            fixture.detectChanges();
        });

        // Checking address is invalid if it is empty
        it('should be invalid', () => {

            expect(address.valid).toBeFalsy();

        });

        // Checking required error is present if field is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has address field which is filled', () => {
        let errors = {};
        let address;
        beforeEach(() => {
            address = component.userInfoForm.controls['address'];
            address.setValue('Infosys Limited');
            errors = address.errors || {};
            fixture.detectChanges();
        });

        // Checking address is valid if it is filled
        it('should be valid', () => {

            expect(address.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('has state field which is empty', () => {
        let errors = {};
        let state;
        beforeEach(() => {
            state = component.userInfoForm.controls['state'];
            state.setValue('');
            errors = state.errors || {};
            fixture.detectChanges();
        });

        // Checking state is invalid if it is empty
        it('should be invalid', () => {

            expect(state.valid).toBeFalsy();

        });

        // Checking required error is present if field is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has state field which is filled', () => {
        let errors = {};
        let state;
        beforeEach(() => {
            state = component.userInfoForm.controls['state'];
            state.setValue('Karnataka');
            errors = state.errors || {};
            fixture.detectChanges();
        });

        // Checking state is valid if it is filled
        it('should be valid', () => {

            expect(state.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('has city field which is empty', () => {
        let errors = {};
        let city;
        beforeEach(() => {
            city = component.userInfoForm.controls['city'];
            city.setValue('');
            errors = city.errors || {};
            fixture.detectChanges();
        });

        // Checking city is invalid if it is empty
        it('should be invalid', () => {

            expect(city.valid).toBeFalsy();

        });

        // Checking required error is present if field is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has city field which is filled', () => {
        let errors = {};
        let city;
        beforeEach(() => {
            city = component.userInfoForm.controls['city'];
            city.setValue('Bangalore');
            errors = city.errors || {};
            fixture.detectChanges();
        });

        // Checking city is valid if it is filled
        it('should be valid', () => {

            expect(city.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('has pinCode field which is empty', () => {
        let errors = {};
        let pinCode;
        beforeEach(() => {
            pinCode = component.userInfoForm.controls['pinCode'];
            pinCode.setValue('');
            errors = pinCode.errors || {};
            fixture.detectChanges();
        });

        // Checking pinCode is invalid if it is empty
        it('should be invalid', () => {

            expect(pinCode.valid).toBeFalsy();

        });

        // Checking required error is present if pinCode is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has pinCode field which is filled values not matching the pattern [1-9][0-9]{5}', () => {
        let errors = {};
        let pinCode;
        beforeEach(() => {
            pinCode = component.userInfoForm.controls['pinCode'];
            pinCode.setValue(1235642);
            errors = pinCode.errors || {};
            fixture.detectChanges();
        });

        // Checking pinCode is invalid if it is incorrect
        it('should be invalid', () => {

            expect(pinCode.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking pattern error is present if pinCode is invalid
        it('should contain pattern error', () => {
            expect(errors['pattern']).toBeTruthy();

        });

    });

    describe('has pinCode field which is filled values matching the pattern [1-9][0-9]{5}', () => {
        let errors = {};
        let pinCode;
        beforeEach(() => {
            pinCode = component.userInfoForm.controls['pinCode'];
            pinCode.setValue(123456);
            errors = pinCode.errors || {};
            fixture.detectChanges();
        });

        // Checking pinCode is valid if it is filled
        it('should be valid', () => {

            expect(pinCode.valid).toBeTruthy();

        });

        // Checking required error is not present if field is correct
        it('should not contain pattern error', () => {
            expect(errors['pattern']).toBeFalsy();

        });

    });

    describe('has dob field which is empty', () => {
        let errors = {};
        let dob;
        beforeEach(() => {
            dob = component.userInfoForm.controls['dob'];
            dob.setValue('');
            errors = dob.errors || {};
            fixture.detectChanges();
        });

        // Checking dob is invalid if it is empty
        it('should be invalid', () => {

            expect(dob.valid).toBeFalsy();

        });

        // Checking required error is present if field is empty
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has dob field which is filled', () => {
        let errors = {};
        let dob;
        beforeEach(() => {
            dob = component.userInfoForm.controls['dob'];
            dob.setValue('02/05/2017');
            errors = dob.errors || {};
            fixture.detectChanges();
        });

        // Checking dob is valid if it is filled
        it('should be valid', () => {

            expect(dob.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('userInfoForm when all fields are valid', () => {

        beforeEach(() => {
            component.userInfoForm.controls['address'].setValue('Infosys');
            component.userInfoForm.controls['state'].setValue('Bangalore');
            component.userInfoForm.controls['city'].setValue('Karnataka');
            component.userInfoForm.controls['pinCode'].setValue(123456);
            component.userInfoForm.controls['dob'].setValue(new Date('03/25/2015'));
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.userInfoForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // invokeUserService function should be called on clicking the submit button
        it('should call invokeUserService function on clicking submit button', () => {

            const spy = spyOn(component, 'invokeUserService');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('calling invokeUserService', () => {

        // Event emitter should emit an event if invokeUserService function is called by clicking the submit button
        it('should emit the event with userDetails object', () => {

            const spy = spyOn(component.fetchUserData, 'emit');
            component.invokeUserService();
            expect(spy).toHaveBeenCalledWith(component.userDetails);

        });

        // invokeUserService function of verifypinCodeService should be called by clicking the submit button
        it('should call invokeUserService function on clicking submit button', () => {

            const spy = spyOn($.fn, 'carousel'); ;
            component.invokeUserService();
            expect(spy).toHaveBeenCalledWith('next');
        });

    });


});
