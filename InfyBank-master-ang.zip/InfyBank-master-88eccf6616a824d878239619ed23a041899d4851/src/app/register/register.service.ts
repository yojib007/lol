import { RegisterServerClass } from './register-server';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { RestService } from '../shared/rest-service';

@Injectable()
export class RegisterService {
    registerUrl = '/infybank_core/v1/register';
    registerServerClass: RegisterServerClass = new RegisterServerClass();

    constructor(private restService: RestService) { }

    register(): Observable<boolean> {

        return this.restService.post(this.registerUrl, this.registerServerClass);
    };

}
