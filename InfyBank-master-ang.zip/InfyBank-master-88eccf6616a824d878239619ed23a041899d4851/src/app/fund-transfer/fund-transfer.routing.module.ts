import { FundTransferOwnAccountComponent } from './fund-transfer-own-account/fund-transfer-own-account.component';
import { FundTransferInfosysBankComponent } from './fund-transfer-infosys-bank/fund-transfer-infosys-bank.component';
import { FundTransferComponent } from './fund-transfer.component';
import { AuthGuardUserService } from './../shared/auth-guard.user.service';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [

        { path: '', component: FundTransferComponent },
        { path: 'fundtransferinfy', component: FundTransferInfosysBankComponent },
        { path: 'fundtransferinfy/:id', component: FundTransferInfosysBankComponent },
        { path: 'fundtransferown', component: FundTransferOwnAccountComponent },
    ],
    canActivate: [AuthGuardUserService]
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FundTransferRoutingModule { }
