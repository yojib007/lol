import { FundTransferOwn } from './fund-transfer-own-account/fund-transfer-own';
import { FundTransferInfosys } from './fund-transfer-infosys-bank/fund-transfer-infosys';
import { UserInformationService } from './../shared/user-information.service';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../shared/rest-service';
import { Injectable } from '@angular/core';

@Injectable()
export class FundTransferService {

  url: string;

  constructor(
    private restService: RestService,
    private userInformationService: UserInformationService) { }

  transfer(data: FundTransferOwn | FundTransferInfosys ): Observable<boolean> {
    this.url = '/infybank_core/v1/customers/' + this.userInformationService.userDetail.custId + '/fund-transfer';
    data.userId = this.userInformationService.userDetail.userId;
    return this.restService.post(this.url, data);
  }
}
