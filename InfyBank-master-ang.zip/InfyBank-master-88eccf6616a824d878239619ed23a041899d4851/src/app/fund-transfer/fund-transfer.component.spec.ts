import { FundTransferComponent } from './fund-transfer.component';
import { SuccessMessageService } from './../shared/success-message.service';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('FundTransferComponent', () => {
    let component: FundTransferComponent;
    let fixture: ComponentFixture<FundTransferComponent>;
    let successMessageService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            declarations: [FundTransferComponent],
            providers: [SuccessMessageService]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(FundTransferComponent);
        component = fixture.componentInstance;
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
    });

    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking message property became null after 5 secs
    it('should null the message property of SuccessMessageService after 5 secs', () => {
        successMessageService.message = 'success';
        component.ngOnInit();
        setTimeout(() => {
            expect(successMessageService.message).toBeNull();
        }, 5000);
    });

});
