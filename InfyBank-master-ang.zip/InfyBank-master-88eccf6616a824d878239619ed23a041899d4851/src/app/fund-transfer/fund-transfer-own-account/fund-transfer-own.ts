export class FundTransferOwn {

    'fromAccountNo': string;
    'toAccountNo': string;
    'amount': number;
    'remarks': string;
    'fundTransferDate': string;
    'userId':  string;
    'fundTransferType': string;

}
