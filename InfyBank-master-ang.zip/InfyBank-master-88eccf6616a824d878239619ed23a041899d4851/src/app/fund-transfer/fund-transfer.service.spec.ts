import { Observable } from 'rxjs/Rx';
import { FundTransferOwn } from './fund-transfer-own-account/fund-transfer-own';
import { UserInformationService } from './../shared/user-information.service';
import { RestService } from './../shared/rest-service';
import { UserInformation } from './../shared/user-information';
import { TestBed, inject } from '@angular/core/testing';

import { FundTransferService } from './fund-transfer.service';

class UserInformationServiceStub {
  userDetail = new UserInformation();
}

class RestServiceStub {
  post() { }
}

describe('FundTransferService', () => {

  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FundTransferService,
        { provide: UserInformationService, useValue: userInformationServiceStub },
        { provide: RestService, useValue: restServiceStub }]
    });
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([FundTransferService], (service: FundTransferService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the transfer function', () => {

    let returnValue;
    let errMsg;

    // Checking post method of RestService is called
    it('should invoke post method of RestService',
      inject([FundTransferService], (service: FundTransferService) => {

        const spy = spyOn(restService, 'post');
        service.transfer(new FundTransferOwn());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking transfer function returning the Observable of true which is returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([FundTransferService], (service: FundTransferService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
        service.transfer(new FundTransferOwn()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking transfer function returning the Observable of error which is returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([FundTransferService], (service: FundTransferService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
        service.transfer(new FundTransferOwn()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });
});
