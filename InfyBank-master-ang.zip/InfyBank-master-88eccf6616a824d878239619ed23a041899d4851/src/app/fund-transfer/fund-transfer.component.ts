import { SuccessMessageService } from './../shared/success-message.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  constructor(private successMessageService: SuccessMessageService) { }

  ngOnInit() {
    this.successMessageService.view = 'fund';
    this.successMessageService.subView = 'fundTrns';
    if (this.successMessageService.message) {
      setTimeout(() => {
        this.successMessageService.message = null;
      }, 5000);
    }
  }

}
