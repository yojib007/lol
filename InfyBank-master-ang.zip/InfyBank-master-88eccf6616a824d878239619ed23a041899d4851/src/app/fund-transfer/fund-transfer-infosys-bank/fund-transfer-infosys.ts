export class FundTransferInfosys {

    'fromAccountNo': string;
    'payeeId': number;
    'amount': number;
    'remarks': string;
    'fundTransferDate': string;
    'fundTransferType': string;
    'userId': string;

}
