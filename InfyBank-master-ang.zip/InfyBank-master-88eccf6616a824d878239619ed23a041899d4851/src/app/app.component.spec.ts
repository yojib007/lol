import { SuccessMessageService } from './shared/success-message.service';
import { UserDetails } from './register/user-details/user-details';
import { UserInformationService } from './shared/user-information.service';
import { TranslateService } from '@ngx-translate/core';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

class TranslateServiceStub {
    addLangs() { }
    setDefaultLang() { }
    getBrowserLang() {
        return 'en';
    }
    use() { }
}
describe('AppComponent', () => {
    let component: AppComponent;
    let fixture: ComponentFixture<AppComponent>;
    let userInformationService;
    const translateServiceStub = new TranslateServiceStub();
    let successMessageService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            declarations: [AppComponent],
            providers: [UserInformationService, SuccessMessageService,
                { provide: TranslateService, useValue: translateServiceStub }
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AppComponent);
        component = fixture.componentInstance;
        successMessageService = TestBed.get(SuccessMessageService);
        userInformationService = TestBed.get(UserInformationService);
        fixture.detectChanges();
    });

    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // ngAfterContentChecked should populate view
    it('should populate view on invoking AfterContentChecked', () => {

        successMessageService.view = 'account';
        component.ngAfterContentChecked();
        expect(component.view).toBe('account');

    });

    describe('invoking logout function', () => {

        beforeEach(() => {
            userInformationService.userDetail = true;
            userInformationService.profileDetail = true;
            component.logout();
        });

        // userDetail property becomes null
        it('should null the userDetail property of userInformationService', () => {
            expect(userInformationService.userDetail).toBeNull();
        });

        // Checking profileDetail property becomes null
        it('should null the profileDetail property of userInformationService', () => {
            expect(userInformationService.profileDetail).toBeNull();
        });

    });

});
