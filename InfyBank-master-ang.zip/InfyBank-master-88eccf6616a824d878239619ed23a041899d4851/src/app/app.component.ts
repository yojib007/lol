import { SuccessMessageService } from './shared/success-message.service';
import { ProfileService } from './shared/profile.service';
import { Observable } from 'rxjs/Observable';
import { UserInformationService } from './shared/user-information.service';

import { Component, AfterContentChecked } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
declare var $: any;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterContentChecked {

    view: string;
    subView: string;
    constructor(private translate: TranslateService, private successMessageService: SuccessMessageService,
        private userInformationService: UserInformationService) {
        translate.addLangs(['en', 'fr']);
        translate.setDefaultLang('en');

        const browserLang = translate.getBrowserLang();
        translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
    }
    logout() {
        this.userInformationService.profileDetail = null;
        this.userInformationService.userDetail = null;
    }

    ngAfterContentChecked() {
        setTimeout(() => {
            this.view = this.successMessageService.view;
            this.subView = this.successMessageService.subView;
        }, 2000);
    }

}
