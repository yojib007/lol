import { SuccessMessageService } from './../../shared/success-message.service';
import { PayeeService } from './../../shared/payee.service';
import { Payee } from './../../shared/payee';
import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-registered-payee',
  templateUrl: './registered-payee.component.html',
  styleUrls: ['./registered-payee.component.css']
})
export class RegisteredPayeeComponent implements OnInit {

  payeeList: Payee[];
  selectedPayee: Payee;
  error: string[];
  name: string;
  nickName: string;
  submitted: boolean;
  noPayee: string;
  errorMsg: string[];
  constructor(private payeeService: PayeeService, private successMessageService: SuccessMessageService) { }

  search() {
 
    if (this.name) {
      this.payeeList = this.payeeList.filter(payee => (payee.name.toLowerCase()===this.name.toLowerCase()));
    }
    if (this.nickName) {
      this.payeeList = this.payeeList.filter(payee => (payee.nickName.toLowerCase()===this.nickName.toLowerCase()));
    }
  }

  deletePayee() {
    this.submitted = true;
    this.payeeService.deletePayee(this.selectedPayee).subscribe(
      data => {
        this.successMessageService.message = `DELETEPAYEE.SUCCESS`;
        this.ngOnInit();
      },
      error => {
        this.errorMsg = error;
        this.submitted = false;
      }
    );
  }

  getPayee() {
    this.payeeService.viewPayee('C').subscribe(
      data => {
        this.payeeList = data;
        if (this.payeeList.length === 0) {
          this.noPayee = `ERRORS.VIEWPAYEE.NOPAYEE`;
        }
      },
      error => {
        this.error = error;
        this.payeeList = null;
      }
    );
  }

  ngOnInit() {
    if (this.successMessageService.message) {
      setTimeout(() => {
        this.successMessageService.message = null;
      }, 5000);
    }
    this.successMessageService.view = 'fund';
    this.successMessageService.subView = 'mngPaye';
    this.getPayee();
    this.name = null;
    this.nickName = null;
    this.submitted = false;
  }
}
