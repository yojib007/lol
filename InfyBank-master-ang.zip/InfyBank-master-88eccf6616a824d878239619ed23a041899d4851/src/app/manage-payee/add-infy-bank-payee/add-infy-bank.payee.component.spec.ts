import { SuccessMessageService } from './../../shared/success-message.service';
import { AddInfyBankPayeeComponent } from './add-infy-bank-payee.component';
import { PayeeService } from './../../shared/payee.service';
import { RouterModule, Router } from '@angular/router';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ValidatorsService } from '../../shared/validators.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

class ValidatorsServiceStub {
    isFieldHasErrors() { }
}

class PayeeServiceStub {
    addPayee() { }
};

describe('AddInfyBankPayeeComponent', () => {

    const validatorsServiceStub = new ValidatorsServiceStub();
    const payeeServiceStub = new PayeeServiceStub();
    let component: AddInfyBankPayeeComponent;
    let fixture: ComponentFixture<AddInfyBankPayeeComponent>;
    let submitBtn;
    let payeeService;
    let successMessageService;
    let router;

    beforeEach(async(() => {

        TestBed.configureTestingModule({
            declarations: [AddInfyBankPayeeComponent],
            imports: [ReactiveFormsModule, FormsModule, RouterTestingModule],
            providers: [
                { provide: PayeeService, useValue: payeeServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                SuccessMessageService
            ],
        })
            .compileComponents();

    }));

    beforeEach(() => {
        router = TestBed.get(Router);
        payeeService = TestBed.get(PayeeService);
        fixture = TestBed.createComponent(AddInfyBankPayeeComponent);
        component = fixture.componentInstance;
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
        submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;

    });

    // Checking everything is created correct or not
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking submit button is disabled till form is invalid
    it('should have submit button disabled at initialization', () => {

        expect(submitBtn.disabled).toBe(true);
    });

    describe('has accName field which is empty', () => {
        let errors = {};
        let accName;
        beforeEach(() => {
            accName = component.addInfyPayeeForm.controls['accName'];
            accName.setValue('');
            errors = accName.errors || {};
            fixture.detectChanges();
        });

        // Checking accName is invalid if it is empty
        it('should be invalid', () => {

            expect(accName.valid).toBeFalsy();

        });

        // Checking required error is present if accName is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has accName field which is filled', () => {
        let errors = {};
        let accName;
        beforeEach(() => {
            accName = component.addInfyPayeeForm.controls['accName'];
            accName.setValue('Kalpana');
            errors = accName.errors || {};
            fixture.detectChanges();
        });

        // Checking accName is valid if it is filled
        it('should be valid', () => {

            expect(accName.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('has nickName field which is empty', () => {
        let errors = {};
        let nickName;
        beforeEach(() => {
            nickName = component.addInfyPayeeForm.controls['nickName'];
            nickName.setValue('');
            errors = nickName.errors || {};
            fixture.detectChanges();
        });

        // Checking nickName is invalid if it is empty
        it('should be invalid', () => {

            expect(nickName.valid).toBeFalsy();

        });

        // Checking required error is present if nickName is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has nickName field which is filled', () => {
        let errors = {};
        let nickName;
        beforeEach(() => {
            nickName = component.addInfyPayeeForm.controls['nickName'];
            nickName.setValue('Kalpana');
            errors = nickName.errors || {};
            fixture.detectChanges();
        });

        // Checking nickName is valid if it is filled
        it('should be valid', () => {

            expect(nickName.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('has acctNumber field which is empty', () => {
        let errors = {};
        let acctNumber;
        beforeEach(() => {
            acctNumber = component.addInfyPayeeForm.controls['acctNumber'];
            acctNumber.setValue('');
            errors = acctNumber.errors || {};
            fixture.detectChanges();
        });

        // Checking acctNumber is invalid if it is empty
        it('should be invalid', () => {

            expect(acctNumber.valid).toBeFalsy();

        });

        // Checking required error is present if acctNumber is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has acctNumber field which is filled with values not matching the pattern [0-9]{10}', () => {
        let errors = {};
        let acctNumber;
        beforeEach(() => {
            acctNumber = component.addInfyPayeeForm.controls['acctNumber'];
            acctNumber.setValue('1234534ABD');
            errors = acctNumber.errors || {};
            fixture.detectChanges();
        });

        // Checking acctNumber is invalid if it is incorrect
        it('should be invalid', () => {

            expect(acctNumber.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking required error is present if acctNumber is not entered
        it('should contain pattern error', () => {
            expect(errors['pattern']).toBeTruthy();

        });

    });

    describe('has acctNumber field which is filled with values matching the pattern [0-9]{10}', () => {
        let errors = {};
        let acctNumber;
        beforeEach(() => {
            acctNumber = component.addInfyPayeeForm.controls['acctNumber'];
            acctNumber.setValue('1234567891');
            errors = acctNumber.errors || {};
            fixture.detectChanges();
        });

        // Checking acctNumber is valid if it is filled
        it('should be valid', () => {

            expect(acctNumber.valid).toBeTruthy();

        });

        // Checking required error is not present if field is correct
        it('should not contain pattern error', () => {
            expect(errors['pattern']).toBeFalsy();

        });

    });

    describe('has accType field which is empty', () => {
        let errors = {};
        let accType;
        beforeEach(() => {
            accType = component.addInfyPayeeForm.controls['accType'];
            accType.setValue('');
            errors = accType.errors || {};
            fixture.detectChanges();
        });

        // Checking accType is invalid if it is empty
        it('should be invalid', () => {

            expect(accType.valid).toBeFalsy();

        });

        // Checking required error is present if accType is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe(`has accType field which is filled`, () => {

        let errors = {};
        let accType;
        beforeEach(() => {
            accType = component.addInfyPayeeForm.controls['accType'];
            accType.setValue('S');
            errors = accType.errors || {};
            fixture.detectChanges();
        });

        // Checking accType is valid if it is filled
        it('should be valid', () => {

            expect(accType.valid).toBeTruthy();

        });

        // Checking required error is not present if field is correct
        it('should not contain pattern error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('addInfyPayeeForm when all fields are valid', () => {

        beforeEach(() => {
            component.addInfyPayeeForm.controls['accName'].setValue('Kalpana');
            component.addInfyPayeeForm.controls['nickName'].setValue('Kalpana');
            component.addInfyPayeeForm.controls['acctNumber'].setValue('1234657890');
            component.addInfyPayeeForm.controls['accType'].setValue('S');
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.addInfyPayeeForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // invokeacctNumberService function should be called on clicking the submit button
        it('should call invokeacctNumberService function on clicking submit button', () => {

            const spy = spyOn(component, 'submit');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('invoking submit function', () => {

        // should call addPayee method of payeeService
        it('should call addPayee method of payeeService', () => {

            const spy = spyOn(payeeService, 'addPayee').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.submit();
            expect(spy).toHaveBeenCalledWith(component.payee);
        });

        describe('on recieving data from update method of ProfileService', () => {

            let spy;
            beforeEach(() => {
                spyOn(payeeService, 'addPayee').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate');
                component.submit();
            });

            // Populate message if data is recieved from update method of ProfileService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/managepayee']);
            });
        });

        // Populate error if error is thrown from update method of ProfileService
        it('should populate error if error is thrown from update method of ProfileService', () => {

            spyOn(payeeService, 'addPayee').and.returnValue(Observable.throw('Server Error'));
            component.submit();
            expect(component.error).toBe('Server Error');
        });
    });
});
