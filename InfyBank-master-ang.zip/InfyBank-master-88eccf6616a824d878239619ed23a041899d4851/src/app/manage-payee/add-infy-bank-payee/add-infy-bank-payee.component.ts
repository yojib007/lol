import { SuccessMessageService } from './../../shared/success-message.service';
import { ValidatorsService } from './../../shared/validators.service';
import { PayeeService } from './../../shared/payee.service';
import { AddPayee } from './../../shared/add-payee';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-infy-bank-payee',
  templateUrl: './add-infy-bank-payee.component.html',
  styleUrls: ['./add-infy-bank-payee.component.css']
})
export class AddInfyBankPayeeComponent implements OnInit {

  payee: AddPayee;
  error: any;
  submitted: boolean;
  addInfyPayeeForm: FormGroup;
  constructor(
    private validatorsService: ValidatorsService,
    private formBuilder: FormBuilder,
    private payeeService: PayeeService,
    private router: Router,
    private successMessageService: SuccessMessageService
  ) { }

  submit() {
    this.submitted = true;
    this.payeeService.addPayee(this.payee).subscribe(
      data => {
        this.successMessageService.message = 'ADDPAYEE.SUCCESS';
        this.router.navigate(['/managepayee']);
      },
      error => {
        this.error = error;
        this.submitted = false;
      }
    );
  }

  createForm() {
    this.addInfyPayeeForm = this.formBuilder.group({
      accName: ['', Validators.required],
      nickName: ['', Validators.required],
      acctNumber: ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
      accType: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.payee = new AddPayee();
    this.successMessageService.view = 'fund';
    this.successMessageService.subView = 'mngPaye';
    this.createForm();
  }

}
