import { SuccessMessageService } from './../../shared/success-message.service';
import { ValidatorsService } from './../../shared/validators.service';
import { ConfirmPayeeComponent } from './confirm-payee.component';
import { ProfileService } from './../../shared/profile.service';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { PayeeService } from './../../shared/payee.service';
import { Payee } from './../../shared/payee';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';

class PayeeServiceStub {
    viewPayee() {
        return Observable.of([new Payee()]);
    }
    confirmPayee() { }
}

class ValidatorsServiceStub {
    isFieldHasErrors() { }
}

describe('ConfirmPayeeComponent', () => {
    const validatorsServiceStub = new ValidatorsServiceStub();
    const payeeServiceStub = new PayeeServiceStub();
    let component: ConfirmPayeeComponent;
    let fixture: ComponentFixture<ConfirmPayeeComponent>;
    let payeeService;
    let payee1: Payee;
    let payee2: Payee;
    let payee3: Payee;
    let payee4: Payee;
    let payeeList: Payee[];
    let submitBtn;
    let router;
    let successMessageService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule, ReactiveFormsModule],
            declarations: [ConfirmPayeeComponent],
            providers: [
                { provide: PayeeService, useValue: payeeServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                SuccessMessageService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        payeeService = TestBed.get(PayeeService);
        router = TestBed.get(Router);
        successMessageService = TestBed.get(SuccessMessageService);
        fixture = TestBed.createComponent(ConfirmPayeeComponent);
        component = fixture.componentInstance;
        payee1 = {
            'payeeId': 1,
            'name': 'test2',
            'nickName': 'nickTest2',
            'acctNo': '1234567862',
            'userId': 'suma',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payee2 = {
            'payeeId': 2,
            'name': 'test3',
            'nickName': 'nickTest3',
            'acctNo': '1234567863',
            'userId': 'john',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payee3 = {
            'payeeId': 4,
            'name': 'test4',
            'nickName': 'nickTest4',
            'acctNo': '1234567864',
            'userId': 'John Smith',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'S'
        };
        payee4 = {
            'payeeId': 6,
            'name': 'john smith',
            'nickName': 'nicktest',
            'acctNo': '1234567891',
            'userId': 'suma',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payeeList = [payee1, payee2, payee3, payee4];
        fixture.detectChanges();

    });

    // Checking everything is fine
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking viewPayee method of PayeeService has been called
    it('should call viewPayee method of PayeeService', () => {
        const spy = spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('recieving data from viewPayee method of PayeeService', () => {

        // Checking payeeList has been populated
        it('should populate the payeeList', () => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
            component.ngOnInit();
            expect(component.payeeList).toBeDefined();
        });

        // Checking payeeList is populated with objects whose status is "S"
        it('should populate the payeeList with object whose status is "S"', () => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of([payee1, payee2, payee3]));
            component.ngOnInit();
            expect(component.payeeList).toEqual([payee3]);
        });

    });

    describe('recieving error from viewPayee method of PayeeService', () => {
        beforeEach(() => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.throw('Server Error'));
            component.error = undefined;
            component.payeeList = undefined;
        });

        // Checking error is populated with message recieved from server
        it('should populate error if no object with status as "C" is recieved', () => {
            component.ngOnInit();
            expect(component.errorMessage).toMatch(`Server Error`);
        });

        // Checking payeeList is empty
        it('should not populate payeeList', () => {
            component.ngOnInit();
            expect(component.payeeList).toBeUndefined();
        });
    });

    it('should have submit button disabled if form is invalid', () => {

        component.selectedPayee = payee3;
        component.payeeList = payeeList;
        component.errorMessage = null;
        fixture.detectChanges();
        submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
        expect(submitBtn.disabled).toBeTruthy();

    });

    describe('has otp field which is empty', () => {
        let errors = {};
        let otp;
        beforeEach(() => {
            otp = component.payeeOtpForm.controls['otp'];
            otp.setValue('');
            errors = otp.errors || {};
            fixture.detectChanges();
        });

        // Checking otp is invalid if it is empty
        it('should be invalid', () => {

            expect(otp.valid).toBeFalsy();

        });

        // Checking required error is present if otp is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has otp field which is filled with values not matching pattern of six numeric digits', () => {
        let errors = {};
        let otp;
        beforeEach(() => {
            otp = component.payeeOtpForm.controls['otp'];
            otp.setValue('abc400');
            errors = otp.errors || {};
            fixture.detectChanges();
        });

        // Checking otp is invalid if it is incorrect
        it('should be invalid', () => {

            expect(otp.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking pattern error is present if otp is invalid
        it('should contain pattern error', () => {
            expect(errors['pattern']).toBeTruthy();

        });

    });

    describe('has otp field which is filled with valid otpId with values matching pattern of six numeric digits', () => {
        let errors = {};
        let otp;
        beforeEach(() => {
            otp = component.payeeOtpForm.controls['otp'];
            otp.setValue('111111');
            errors = otp.errors || {};
            fixture.detectChanges();
        });

        // Checking otp is valid if it is filled
        it('should be valid', () => {
            expect(otp.valid).toBeTruthy();

        });

        // Checking required error is not present if field is correct
        it('should not contain pattern error', () => {
            expect(errors['pattern']).toBeFalsy();

        });

    });

    describe('payeeOtpForm when all fields are valid', () => {

        beforeEach(() => {
            component.selectedPayee = payee3;
            component.payeeList = payeeList;
            component.errorMessage = null;
            fixture.detectChanges();
            component.payeeOtpForm.controls['otp'].setValue('111111');
            fixture.detectChanges();
            submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {
            expect(component.payeeOtpForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // submit function should be called on clicking the submit button
        it('should call submit function on clicking submit button', () => {

            const spy = spyOn(component, 'submit');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('invoking submit function', () => {

        // should call confirmPayee method of payeeService
        it('should call confirmPayee method of payeeService', () => {

            const spy = spyOn(payeeService, 'confirmPayee').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.submit();
            expect(spy).toHaveBeenCalledWith(component.selectedPayee, component.confirmPayee);

        });

        describe('on recieving data from update method of ProfileService', () => {

            let spy;
            beforeEach(() => {
                spyOn(payeeService, 'confirmPayee').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate');
                component.submit();
            });

            // Populate message if data is recieved from update method of ProfileService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/managepayee']);
            });
        });

        // Populate error if error is thrown from update method of ProfileService
        it('should populate error if error is thrown from update method of ProfileService', () => {

            spyOn(payeeService, 'confirmPayee').and.returnValue(Observable.throw('Server Error'));
            component.submit();
            expect(component.error).toBe('Server Error');
        });
    });
});
