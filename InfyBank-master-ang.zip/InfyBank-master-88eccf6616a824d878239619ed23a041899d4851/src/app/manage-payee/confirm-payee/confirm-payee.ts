export class ConfirmPayee {
    otp: string;
    emailId: string;
}
