import { SuccessMessageService } from './../../shared/success-message.service';
import { PayeeService } from './../../shared/payee.service';
import { Payee } from './../../shared/payee';

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';

@Component({
  selector: 'app-delete-payee',
  templateUrl: './delete-payee.component.html',
  styleUrls: ['./delete-payee.component.css']
})
export class DeletePayeeComponent implements OnInit {
  id: number;
  payee: Payee;
  error: string[];
  errorMessage: string[];
  submitted: any;
  constructor(private router: Router, private successMessageService: SuccessMessageService,
    private route: ActivatedRoute, private payeeService: PayeeService) { }

  submit() {
    this.submitted = true;
    this.payeeService.deletePayee(this.payee).subscribe(
      data => {
        this.successMessageService.message = `DELETEPAYEE.SUCCESS`;
        this.router.navigate(['/managepayee']);
      },
      error => {
        this.error = error.message || error;
        this.submitted = false;
      }
    );
  }

  ngOnInit() {
    this.successMessageService.view = 'fund';
    this.successMessageService.subView = 'mngPaye';
    this.payee = JSON.parse(this.route.snapshot.paramMap.get('id'));
  }

}
