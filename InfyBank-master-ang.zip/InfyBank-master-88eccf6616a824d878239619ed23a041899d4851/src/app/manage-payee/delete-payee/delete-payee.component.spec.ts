import { SuccessMessageService } from './../../shared/success-message.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import { PayeeService } from './../../shared/payee.service';
import { Payee } from './../../shared/payee';
import { DeletePayeeComponent } from './delete-payee.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';

class PayeeServiceStub {
    viewPayee() {
        return Observable.of([new Payee()]);
    }

    deletePayee() { }
}

describe('DeletePayeeComponent', () => {

    const payeeServiceStub = new PayeeServiceStub();
    let component: DeletePayeeComponent;
    let fixture: ComponentFixture<DeletePayeeComponent>;
    let route;
    let payeeService;
    let payee1: Payee;
    let payee2: Payee;
    let payee3: Payee;
    let payee4: Payee;
    let payeeList: Payee[];
    let router;
    let successMessageService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [FormsModule, RouterTestingModule],
            declarations: [DeletePayeeComponent],
            providers: [{ provide: PayeeService, useValue: payeeServiceStub }, SuccessMessageService]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DeletePayeeComponent);
        component = fixture.componentInstance;
        route = TestBed.get(ActivatedRoute);
        payeeService = TestBed.get(PayeeService);
        router = TestBed.get(Router);
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
        payee1 = {
            'payeeId': 1,
            'name': 'test2',
            'nickName': 'nickTest2',
            'acctNo': '1234567862',
            'userId': 'suma',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payee2 = {
            'payeeId': 2,
            'name': 'test3',
            'nickName': 'nickTest3',
            'acctNo': '1234567863',
            'userId': 'john',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payee3 = {
            'payeeId': 4,
            'name': 'test4',
            'nickName': 'nickTest4',
            'acctNo': '1234567864',
            'userId': 'John Smith',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'S'
        };
        payee4 = {
            'payeeId': 6,
            'name': 'john smith',
            'nickName': 'nicktest',
            'acctNo': '1234567891',
            'userId': 'suma',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payeeList = [payee1, payee2, payee3, payee4];
    });

    // Checking everything is created properly
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking viewPayee method of PayeeService has been called
    it('should call viewPayee method of PayeeService', () => {
        const spy = spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('recieving data from viewPayee method of PayeeService', () => {

        // Checking payee has been populated
        it('should populate the payee', () => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
            spyOn(route.snapshot.paramMap, 'get').and.returnValue(6);
            component.ngOnInit();
            expect(component.payee).toBeDefined();
        });

        // Checking payee is populated with object whose payeeId is passed through routing parameter
        it('should populate the payee with object whose payeeId is passed through routing parameter', () => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
            spyOn(route.snapshot.paramMap, 'get').and.returnValue(6);
            component.ngOnInit();
            expect(component.payee).toEqual(payee4);
        });

    });

    describe('recieving error from viewPayee method of PayeeService', () => {
        beforeEach(() => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.throw('Server Error'));
            component.error = undefined;
            component.payee = undefined;
        });

        // Checking errorMessage is populated with message recieved from server
        it('should populate errorMessage with message returned from PayeeService', () => {
            component.ngOnInit();
            expect(component.errorMessage).toMatch(`Server Error`);
        });

        // Checking payee is empty
        it('should not populate payee', () => {
            component.ngOnInit();
            expect(component.payee).toBeUndefined();
        });
    });

    describe('invoking submit function', () => {

        // should call deletePayee method of payeeService
        it('should call deletePayee method of payeeService', () => {

            const spy = spyOn(payeeService, 'deletePayee').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.submit();
            expect(spy).toHaveBeenCalledWith(component.payee);
        });

        describe('on recieving data from delete method of ProfileService', () => {

            let spy;
            beforeEach(() => {
                spyOn(payeeService, 'deletePayee').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate');
                component.submit();
            });

            // Populate message if data is recieved from update method of ProfileService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/managepayee']);
            });
        });

        // Populate error if error is thrown from deletePayee method of payeeService
        it('should populate error if error is thrown from deletePayee method of payeeService', () => {

            spyOn(payeeService, 'deletePayee').and.returnValue(Observable.throw('Server Error'));
            component.submit();
            expect(component.error).toBe('Server Error');
        });
    });

});
