export class Course {
  constructor(
    public courseId: number,
    public courseName: string,
    public duration: string
  ) { }
}

