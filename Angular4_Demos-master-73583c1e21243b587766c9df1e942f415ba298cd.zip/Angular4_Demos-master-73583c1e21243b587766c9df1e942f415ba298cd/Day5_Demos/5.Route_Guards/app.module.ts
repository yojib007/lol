import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { BookComponent } from './book/book.component';
import { BookService } from './book/book.service';

import { DashboardComponent } from './dashboard/dashboard.component';
import { BookDetailComponent } from './book-detail/book-detail.component';
import { AppRoutingModule } from './app-routing.module';
import { LoginComponent } from './login/login.component';
import {LoginService } from './login/login.service';
import {LoginGuardService} from './login/login-guard.service';

@NgModule({
  imports: [BrowserModule, HttpModule, FormsModule, ReactiveFormsModule, AppRoutingModule],
  declarations: [AppComponent, BookComponent, DashboardComponent, BookDetailComponent, LoginComponent],
  providers: [BookService,  LoginService, LoginGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
