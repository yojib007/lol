import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-root',
  styleUrls: ['./app.component.css'],
  templateUrl: './app.component.html'
})
export class AppComponent {

  data: Observable<number>;
  myArray: number[]=[];
  errors: boolean;
  finished: boolean;

  fetchData() {
    this.data = new Observable(observer => {
      setTimeout(() => { observer.next(11); }, 1000),
        setTimeout(() => { observer.next(22); }, 2000),
        setTimeout(() => { observer.complete(); }, 3000)
    });

    let sub = this.data.subscribe((value) => this.myArray.push(value),
      error => this.errors = true,
      () => this.finished = true);

  }
}

