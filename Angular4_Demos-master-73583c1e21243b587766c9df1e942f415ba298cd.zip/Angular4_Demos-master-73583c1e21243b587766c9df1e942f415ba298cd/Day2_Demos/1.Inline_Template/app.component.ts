import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: ` 
        <h1> Welcome </h1>
        <h2> Course Name: {{ courseName }}</h2>
    `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  courseName: string = "Angular";
}
