import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  colorName: string = 'red';
  fontWeight: string = 'bold';
  borderStyle: string = '1px solid black';
}
