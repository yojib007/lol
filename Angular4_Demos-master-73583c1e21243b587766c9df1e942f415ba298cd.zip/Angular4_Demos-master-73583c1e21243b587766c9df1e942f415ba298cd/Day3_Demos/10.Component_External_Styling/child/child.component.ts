import { Component } from '@angular/core';

@Component({
  selector: 'app-child',
  styleUrls: ['./child.component.css'],
  templateUrl: './child.component.html'
})
export class ChildComponent {
}
