import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = "product details";
  productCode: string = "PROD_P001";
  productName: string = "Laptop";
  productPrice: number = 25000;
  purchaseDate: string = "5/12/2017";
  productTax: string = "0.1";
  productRating: number = 4.53;
}
