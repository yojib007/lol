import { RouterTestingModule } from '@angular/router/testing';
import { ValidatorsService } from './../../shared/validators.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { AccountDetailsComponent } from './account-details.component';

declare var $: any;

class ValidatorsServiceStub {
    isFieldHasErrors() {
    }
}

describe('AccountDetailsComponent', () => {
    const validatorsServiceStub = new ValidatorsServiceStub();
    let component: AccountDetailsComponent;
    let fixture: ComponentFixture<AccountDetailsComponent>;
    let submitBtn;

    beforeEach(async(() => {

        TestBed.configureTestingModule({
            declarations: [AccountDetailsComponent],
            imports: [ReactiveFormsModule, FormsModule, RouterTestingModule],
            providers: [
            {provide: ValidatorsService, useValue: validatorsServiceStub}]
        })
            .compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AccountDetailsComponent);
        component = fixture.componentInstance;
        submitBtn = fixture.debugElement.query(By.css('#submitButton')).nativeElement;
        fixture.detectChanges();
    });

    // Checking everything is created correct or not
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking submit button is disabled till form is invalid
    it('should have submit button disabled at initialization', () => {

        expect(submitBtn.disabled).toBe(true);
    });

    describe('has acctype field which is empty', () => {
        let errors = {};
        let acctype;
        beforeEach(() => {
            acctype = component.accInfoForm.controls['acctype'];
            acctype.setValue('');
            errors = acctype.errors || {};
            fixture.detectChanges();
        });

        // Checking acctype is invalid if it is empty
        it('should be invalid', () => {

            expect(acctype.valid).toBeFalsy();

        });

        // Checking required error is present if lName is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has acctype field which is filled', () => {
        let errors = {};
        let acctype;
        beforeEach(() => {
            acctype = component.accInfoForm.controls['acctype'];
            acctype.setValue('S');
            errors = acctype.errors || {};
            fixture.detectChanges();
        });

        // Checking acctype is valid if it is filled
        it('should be valid', () => {

            expect(acctype.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('has obal field which is empty', () => {
        let errors = {};
        let obal;
        beforeEach(() => {
            obal = component.accInfoForm.controls['obal'];
            obal.setValue('');
            errors = obal.errors || {};
            fixture.detectChanges();
        });

        // Checking obal is invalid if it is empty
        it('should be invalid', () => {

            expect(obal.valid).toBeFalsy();

        });

        // Checking required error is present if obal is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has obal field which is filled with values containing alphabatic characters', () => {
        let errors = {};
        let obal;
        beforeEach(() => {
            obal = component.accInfoForm.controls['obal'];
            obal.setValue('1234534ABD');
            errors = obal.errors || {};
            fixture.detectChanges();
        });

        // Checking obal is invalid if it is incorrect
        it('should be invalid', () => {

            expect(obal.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking required error is present if obal is not entered
        it('should contain pattern error', () => {
            expect(errors['pattern']).toBeTruthy();

        });

    });

    describe('has obal field which is filled with only numeric values', () => {
        let errors = {};
        let obal;
        beforeEach(() => {
            obal = component.accInfoForm.controls['obal'];
            obal.setValue(12345);
            errors = obal.errors || {};
            fixture.detectChanges();
        });

        // Checking obal is valid if it is filled
        it('should be valid', () => {

            expect(obal.valid).toBeTruthy();

        });

        // Checking required error is not present if field is correct
        it('should not contain pattern error', () => {
            expect(errors['pattern']).toBeFalsy();

        });

    });

    describe('has salacctype field which is empty', () => {
        let errors = {};
        let salacctype;
        beforeEach(() => {
            salacctype = component.accInfoForm.controls['salacctype'];
            salacctype.setValue('');
            errors = salacctype.errors || {};
            fixture.detectChanges();
        });

        // Checking salacctype is invalid if it is empty
        it('should be invalid', () => {

            expect(salacctype.valid).toBeFalsy();

        });

        // Checking required error is present if lName is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has salacctype field which is filled', () => {
        let errors = {};
        let salacctype;
        beforeEach(() => {
            salacctype = component.accInfoForm.controls['salacctype'];
            salacctype.setValue('Y');
            errors = salacctype.errors || {};
            fixture.detectChanges();
        });

        // Checking salacctype is valid if it is filled
        it('should be valid', () => {

            expect(salacctype.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('has pan field which is empty', () => {
        let errors = {};
        let pan;
        beforeEach(() => {
            pan = component.accInfoForm.controls['pan'];
            pan.setValue('');
            errors = pan.errors || {};
            fixture.detectChanges();
        });

        // Checking pan is invalid if it is empty
        it('should be invalid', () => {

            expect(pan.valid).toBeFalsy();

        });

        // Checking required error is present if pan is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has pan field which is filled with values does not matching the pattern [A-Z]{5}[0-9]{4}[A-Z]{1}', () => {
        let errors = {};
        let pan;
        beforeEach(() => {
            pan = component.accInfoForm.controls['pan'];
            pan.setValue('1234534ABD');
            errors = pan.errors || {};
            fixture.detectChanges();
        });

        // Checking pan is invalid if it is incorrect
        it('should be invalid', () => {

            expect(pan.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking required error is present if pan is not entered
        it('should contain pattern error', () => {
            expect(errors['pattern']).toBeTruthy();

        });

    });

    describe('has pan field which is filled with values matching the pattern [A-Z]{5}[0-9]{4}[A-Z]{1}', () => {
        let errors = {};
        let pan;
        beforeEach(() => {
            pan = component.accInfoForm.controls['pan'];
            pan.setValue('BWQPR7350K');
            errors = pan.errors || {};
            fixture.detectChanges();
        });

        // Checking pan is valid if it is filled
        it('should be valid', () => {

            expect(pan.valid).toBeTruthy();

        });

        // Checking required error is not present if field is correct
        it('should not contain pattern error', () => {
            expect(errors['pattern']).toBeFalsy();

        });

    });

    describe('accInfoForm when all fields are valid', () => {

        beforeEach(() => {
            component.accInfoForm.controls['acctype'].setValue('C');
            component.accInfoForm.controls['obal'].setValue(1000);
            component.accInfoForm.controls['salacctype'].setValue('S');
            component.accInfoForm.controls['pan'].setValue('BWQPR7350K');
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.accInfoForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // invokeAccService function should be called on clicking the submit button
        it('should call invokeAccService function on clicking submit button', () => {

            const spy = spyOn(component, 'invokeAccService');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('calling invokeAccService', () => {

        // Event emitter should emit an event if invokeAccService function is called by clicking the submit button
        it('should emit the event with userDetails object', () => {

            const spy = spyOn(component.fetchAccountData, 'emit');
            component.invokeAccService();
            expect(spy).toHaveBeenCalledWith(component.accountDetails);

        });

        // invokeAccService function of verifypinCodeService should be called by clicking the submit button
        it('should move to next tab on clicking submit button', () => {

            const spy = spyOn($.fn, 'carousel');
            component.invokeAccService();
            expect(spy).toHaveBeenCalledWith('next');
        });

    });

    describe('uppercase function', () => {

        // Checking if uppercase function changes the string of panNo to UpperCase if called
        it('should convert entered panNo to UpperCase', () => {

            component.accountDetails.panNo = 'bwqpr7350k';
            component.uppercase();
            expect(component.accountDetails.panNo).toBe('BWQPR7350K');

        });

        // Checking if uppercase function is invoked if a keyup is made in panNo field in html page
        it('should be invoked on changing values in panNo field', () => {

            const spy = spyOn(component, 'uppercase');
            const input = fixture.debugElement.query(By.css('#pan')).nativeElement;
            input.value = 'bwqpr7350k';
            input.dispatchEvent(new Event('keyup'));
            fixture.detectChanges();
            expect(spy).toHaveBeenCalled();
        });

    });

});
