import { VerifyAadhar } from './verify-aadhar/verify-aadhar';
import { VerifyOtp } from './verify-otp/verify-otp';
import { AccountDetails } from './account-details/account-details';
import { UserDetails } from './user-details/user-details';

export class Register {
    aadharObj: VerifyAadhar;
    otpObj: VerifyOtp;
    userObj: UserDetails;
    accObj: AccountDetails;
}
