import { RegisterService } from './../register.service';
import { Observable } from 'rxjs/Rx';
import { TestBed, inject } from '@angular/core/testing';
import { VerifyOtp } from './verify-otp';
import { VerifyOtpService } from './verify-otp.service';
import { RestService } from '../../shared/rest-service';
declare var $: any;

class RestServiceStub {
    post() { }
}

class RegisterServiceStub {

    registerServerClass = {
                            emailId: 'kalpana@infosy.com'
                          };
}

describe('VerifyOtpService', () => {
    let varOtpObj;
    const restServiceStub = new RestServiceStub();
    const registerServiceStub = new RegisterServiceStub();
    let restService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [VerifyOtpService,
                { provide: RestService, useValue: restServiceStub },
                { provide: RegisterService, useValue: registerServiceStub }
            ],
        }).compileComponents();

        varOtpObj = new VerifyOtp();
        restService = TestBed.get(RestService);
    });

    // Checking weather the service is injectable
    it('can instantiate service when inject service',
        inject([VerifyOtpService], (service: VerifyOtpService) => {
            expect(service instanceof VerifyOtpService).toBe(true);
        }));

    describe('on calling the verifyOtp function', () => {
        let returnValue;
        let errMsg;


        it('should invoke post method of RestService',
            inject([VerifyOtpService], (service: VerifyOtpService) => {

                const spy = spyOn(restService, 'post');
                service.verifyOtp(varOtpObj);
                expect(spy).toHaveBeenCalled();

            }));

        it('should return Obervable of true which is returned from RestService',
            inject([VerifyOtpService], (service: VerifyOtpService) => {

                const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
                service.verifyOtp(varOtpObj).subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(returnValue).toBe(true);

            }));

        it('should return Obervable of error which is returned from RestService',
            inject([VerifyOtpService], (service: VerifyOtpService) => {

                const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
                service.verifyOtp(varOtpObj).subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(errMsg).toBe('Server Error');

            }));
    });

});
