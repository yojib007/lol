import { RegisterService } from './../register.service';
import { RestService } from './../../shared/rest-service';
import { Injectable } from '@angular/core';
import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { VerifyOtp } from './verify-otp';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
declare var $: any;

@Injectable()
export class VerifyOtpService {

    url = '/infybank/v1/confirm-otp';

    constructor( private restService: RestService, private registerService: RegisterService) { }

    /**
     * Submits data to service class
     *
     * @param otpObj - holds OTP data
     */
    verifyOtp(otpObj: VerifyOtp): Observable<boolean> {

        otpObj.emailId = this.registerService.registerServerClass.emailId;

       return this.restService.post(this.url, otpObj);
    }
}
