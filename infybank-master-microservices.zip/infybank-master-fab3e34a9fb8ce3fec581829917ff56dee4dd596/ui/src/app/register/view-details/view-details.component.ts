
import { Component, Input} from '@angular/core';

import { Register } from '../register';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html'
})
export class ViewDetailsComponent {
  /**
   * Fetches an instance of register class to render it
   */
    @Input() register: Register;

}
