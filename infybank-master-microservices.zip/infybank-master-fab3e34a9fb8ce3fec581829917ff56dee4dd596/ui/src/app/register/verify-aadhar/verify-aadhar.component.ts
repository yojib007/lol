import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { VerifyAadhar } from './verify-aadhar';
import { VerifyAadharService } from './verify-aadhar.service';
import { TranslateService } from '@ngx-translate/core';
import { ValidatorsService } from '../../shared/validators.service';
declare var $: any;

@Component({
    selector: 'app-verify-aadhar',
    templateUrl: './verify-aadhar.component.html',
    styleUrls: ['../register.component.css']
})
export class VerifyAadharComponent implements OnInit {
    vAadharObj = new VerifyAadhar();
    registerForm: FormGroup;
    submit: boolean;
    @Output() fetchAadharData: EventEmitter<VerifyAadhar> = new EventEmitter<VerifyAadhar>();
    aadharError: string[];

    /**
     *
     * @param verifyAadharService - contains methods to submit aadhar data to the server
     * @param formBuilder - Builds a reactive form
     */
    constructor(
        private verifyAadharService: VerifyAadharService,
        private validatorsService: ValidatorsService,
        private formBuilder: FormBuilder) { }

    /**
     * Creates a registration form instance and binds its properties with validators
     */
    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            fName: [this.vAadharObj.firstName, Validators.required],
            lName: [this.vAadharObj.lastName, Validators.required],
            aadhar: [this.vAadharObj.aadharId, [Validators.required, Validators.pattern('[1-9][0-9]{11}')]],
            eid: [this.vAadharObj.emailId,
                [Validators.required, Validators.pattern('([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})')]]
        });
    }

    /**
     * Invokes Aadhar Service class methods to submit the data
     */
    invokeAadharService() {
        this.submit = true;
        this.verifyAadharService.verifyAadhar(this.vAadharObj).subscribe(
            msg => {
                $('.carousel').carousel('next');
                this.fetchAadharData.emit(this.vAadharObj);
            },
            error => {
                this.aadharError = error;
                this.submit = false;
            }

        );
    }

}
