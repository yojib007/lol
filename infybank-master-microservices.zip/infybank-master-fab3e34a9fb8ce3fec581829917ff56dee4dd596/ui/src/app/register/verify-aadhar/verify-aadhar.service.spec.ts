import { Observable } from 'rxjs/Observable';
import { TestBed, inject } from '@angular/core/testing';
import { VerifyAadhar } from './verify-aadhar';
import { VerifyAadharService } from './verify-aadhar.service';
import { RestService } from '../../shared/rest-service';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

class RestServiceStub {
    post() { }
}

describe('VerifyAadharService', () => {
    const restServiceStub = new RestServiceStub();
    let varAadharObj;
    let restService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [VerifyAadharService,
                { provide: RestService, useValue: restServiceStub }],
        }).compileComponents();
        varAadharObj = new VerifyAadhar();
        restService = TestBed.get(RestService);
    });

    // Checking weather the service is injectable
    it('can instantiate service when inject service',
        inject([VerifyAadharService], (service: VerifyAadharService) => {
            expect(service instanceof VerifyAadharService).toBe(true);
        }));

    describe('on calling the verifyAadhar function', () => {

        let returnValue;
        let errMsg;

        // Checking Obervable contains true is returned on successful validation
        it('should invoke post method of RestService',
            inject([VerifyAadharService], (service: VerifyAadharService) => {

                const spy = spyOn(restService, 'post');
                service.verifyAadhar(varAadharObj);
                expect(spy).toHaveBeenCalled();

            }));

        it('should return Obervable of true which is returned from RestService',
            inject([VerifyAadharService], (service: VerifyAadharService) => {

                const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
                service.verifyAadhar(varAadharObj).subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(returnValue).toBe(true);

            }));

        it('should return Obervable of error which is returned from RestService',
            inject([VerifyAadharService], (service: VerifyAadharService) => {

                const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
                service.verifyAadhar(varAadharObj).subscribe(
                    data => returnValue = data,
                    error => errMsg = error
                );
                expect(errMsg).toBe('Server Error');

            }));
    });

});
