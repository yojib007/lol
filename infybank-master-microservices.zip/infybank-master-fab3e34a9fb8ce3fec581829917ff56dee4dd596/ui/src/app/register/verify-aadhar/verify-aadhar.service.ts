import { Injectable } from '@angular/core';
import { Component } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { VerifyAadhar } from './verify-aadhar';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { RestService } from '../../shared/rest-service';


@Injectable()
export class VerifyAadharService {

    aadharUrl = '/infybank/v1/generate-otp';
    /**
     *
     * @param http - to make server calls
     * @param restService - to invoke service class methods for data submission
     */

    constructor(private restService: RestService) { }

    /**
     * Makes service class methods invocation to submit Aadhar data
     *
     * @param vObj - holds Aadhar data
     */

    verifyAadhar(vObj: VerifyAadhar): Observable<boolean> {

        return  this.restService.post(this.aadharUrl, vObj);
    }

}
