export class RegisterServerClass {
    'firstName': string;
    'lastName': string;
    'emailId': string;
    'aadharId': string;
    'acctType': string;
    'balance': number;
    'address': string;
    'city': string;
    'state': string;
    'pincode': string;
    'salaried': string;
    'panNo': string;
    'dob': string;
}
