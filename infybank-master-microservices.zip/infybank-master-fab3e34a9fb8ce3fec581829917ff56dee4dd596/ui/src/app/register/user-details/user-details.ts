export class UserDetails {
    address: string;
    city: string;
    state: string;
    pinCode: string;
    dob: string;
}
