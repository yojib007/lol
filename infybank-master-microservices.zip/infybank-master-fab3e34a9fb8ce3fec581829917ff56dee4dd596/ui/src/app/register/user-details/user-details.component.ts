import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserDetails } from './user-details';
import { ValidatorsService } from '../../shared/validators.service';
declare var $: any;
/**
 *
 */

@Component({
    selector: 'app-user-details',
    templateUrl: './user-details.component.html',
    styleUrls: ['../register.component.css']
})
export class UserDetailsComponent implements OnInit {

    userInfoForm: FormGroup;

    userDetails = new UserDetails();

    @Output() fetchUserData: EventEmitter<UserDetails> = new EventEmitter<UserDetails>();


    /**
     * Injects required service classes
     *
     * @param userDetailsService - contains methods to submit user details to the server
     * @param formBuilder - to create model driven form
     */
    constructor(private validatorsService: ValidatorsService, private formBuilder: FormBuilder) { }


    /**
     * Creates an instance of User Details Form and binds its properties with validators
     */
    ngOnInit() {
        this.userInfoForm = this.formBuilder.group({
            address: ['', Validators.required],
            state: ['', Validators.required],
            city: ['', Validators.required],
            pinCode: ['', [Validators.required, Validators.pattern('[1-9][0-9]{5}')]],
            dob: [this.userDetails.dob, Validators.required]
        });
    }

    /**
        * Invoke service class methods to submit data
        */
    invokeUserService() {
        this.fetchUserData.emit(this.userDetails);
        $('.carousel').carousel('next');
    }
}
