import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { SharedModule } from '../shared/shared.module';
import { RegisterService } from './register.service';
import { RegisterComponent } from './register.component';
import { VerifyAadharComponent } from './verify-aadhar/verify-aadhar.component';
import { VerifyOtpComponent } from './verify-otp/verify-otp.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { VerifyAadharService } from './verify-aadhar/verify-aadhar.service';
import { VerifyOtpService } from './verify-otp/verify-otp.service';
@NgModule({
  declarations: [
    VerifyAadharComponent,
    VerifyOtpComponent,
    UserDetailsComponent,
    AccountDetailsComponent,
    RegisterComponent,
    ViewDetailsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    TranslateModule,
    HttpModule,
    RouterModule
  ],
  providers: [RegisterService, VerifyAadharService, VerifyOtpService],
  bootstrap: [RegisterComponent]
})
export class RegisterModule { }
