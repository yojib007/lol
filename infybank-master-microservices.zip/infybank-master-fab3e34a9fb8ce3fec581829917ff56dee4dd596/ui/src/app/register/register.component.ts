import { Observable } from 'rxjs/Observable';
import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

import { RegisterService } from './register.service';
import { VerifyAadhar } from './verify-aadhar/verify-aadhar';
import { VerifyOtp } from './verify-otp/verify-otp';
import { UserDetails } from './user-details/user-details';
import { AccountDetails } from './account-details/account-details';
import { Register } from './register';

@Component({
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  register = new Register();
  success: boolean;
  error: string[];
  email: Observable<string>;
  submitted: boolean;

  /**
   *
   * @param registerService - contains methods to submit data to server
   */
  constructor(private registerService: RegisterService) { }

  /**
   * Assigns Aadhar data to register object
   *
   * @param data - data for aadhar validation
   */
  aadharData(data: VerifyAadhar) {
    this.register.aadharObj = data;
    this.registerService.registerServerClass.firstName = data.firstName;
    this.registerService.registerServerClass.lastName = data.lastName;
    this.registerService.registerServerClass.aadharId = data.aadharId;
    this.registerService.registerServerClass.emailId = data.emailId;
  }


  /**
   * Assigns user data to register object
   *
   * @param data  - data for user data validation
   */


  userData(data: UserDetails) {
    this.register.userObj = data;
    this.registerService.registerServerClass.address = data.address;
    this.registerService.registerServerClass.city = data.city;
    this.registerService.registerServerClass.state = data.state;
    this.registerService.registerServerClass.pincode = data.pinCode;
    this.registerService.registerServerClass.dob = data.dob;
  }

  /**
   * Assigns account data to register object
   *
   * @param data - data for account data validation
   */
  accData(data: AccountDetails) {
    this.register.accObj = data;
    this.registerService.registerServerClass.acctType = data.accountType;
    this.registerService.registerServerClass.balance = data.openingBalance;
    this.registerService.registerServerClass.salaried = data.salariedAccount;
    this.registerService.registerServerClass.panNo = data.panNo;
  }

  submit() {
    this.submitted = true;
    this.registerService.register().subscribe(
      data => this.success = data,
      error => {
        this.error = error;
        this.submitted = false;
      }
    );
  }
}
