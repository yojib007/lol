import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../../shared/rest-service';
import { UserInformationService } from './../../shared/user-information.service';
import { Ammortization } from './../ammortization-schedule/ammortization';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';

@Injectable()
export class AmmortizationScheduleService {

  url = '';
  constructor(private userInformationService: UserInformationService, private rest: RestService) {
     this.url = '/infybank/v1/customers/' + this.userInformationService.userDetail.custId + '/loans/';
  }
  getAmmortizationSchedule(loanAccountNo: string) {
    return this.rest.get(this.url + loanAccountNo + '/ammortization-schedule');
  }

}
