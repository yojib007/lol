import { LoanRoutingModule } from './loan.routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApplyPersonalLoanComponent } from './apply-personal-loan/apply-personal-loan.component';
import { AmmortizationScheduleComponent } from './ammortization-schedule/ammortization-schedule.component';
import { LoanDetailComponent } from './loan-detail/loan-detail.component';
import { LoanPrepaymentComponent } from './loan-prepayment/loan-prepayment.component';
import { RouterModule, Routes } from '@angular/router';
import { AmmortizationScheduleService } from './ammortization-schedule/ammortization-schedule.service';
import { ApplyPersonalLoanService } from './apply-personal-loan/apply-personal-loan.service';
import { LoanDetailService } from './loan-detail/loan-detail.service';
import { LoanPrePaymentService } from './loan-prepayment/loan-pre-payment.service';
import { StatusPipe } from './loan-detail/status.pipe';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from 'app/shared/shared.module';
import { ManageLoansComponent } from './manage-loans/manage-loans.component';

@NgModule({
  imports: [
    CommonModule, RouterModule, FormsModule, ReactiveFormsModule, LoanRoutingModule, TranslateModule, SharedModule
  ],
  providers: [ApplyPersonalLoanService, AmmortizationScheduleService, LoanDetailService, LoanPrePaymentService],
  declarations: [ApplyPersonalLoanComponent, AmmortizationScheduleComponent, LoanDetailComponent, LoanPrepaymentComponent, StatusPipe, ManageLoansComponent]
})
export class LoanModule { }
