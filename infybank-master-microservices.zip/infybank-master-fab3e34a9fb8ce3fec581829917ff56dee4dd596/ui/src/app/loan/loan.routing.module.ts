import { AmmortizationScheduleComponent } from './ammortization-schedule/ammortization-schedule.component';
import { ApplyPersonalLoanComponent } from './apply-personal-loan/apply-personal-loan.component';
import { LoanDetailComponent } from './loan-detail/loan-detail.component';
import { LoanPrepaymentComponent } from './loan-prepayment/loan-prepayment.component';
import { ManageLoansComponent} from "./manage-loans/manage-loans.component";

import { AuthGuardUserService } from './../shared/auth-guard.user.service';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'loanprepay', component: LoanPrepaymentComponent },
      { path: 'loandetail/:loanAcctno', component: LoanDetailComponent },
      { path: 'applyloan', component: ApplyPersonalLoanComponent },
      { path: 'ammortization', component: AmmortizationScheduleComponent },
      {path:'manage-loans',component: ManageLoansComponent}
    ],
    canActivate: [AuthGuardUserService]
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoanRoutingModule { }
