import { Injectable } from '@angular/core';
import { RestService } from './../../shared/rest-service';
import { Observable } from 'rxjs/Observable';
import { LoanInfo } from './loan-info';
import { ApplyPersonalInfo } from './apply-personal-info';
import { UserInformationService } from './../../shared/user-information.service';

@Injectable()
export class ApplyPersonalLoanService {

  url = '/infybank/v1/customers/';
  constructor(private rest: RestService, private userInfo: UserInformationService) {
    this.url += this.userInfo.userDetail.custId + '/loans';
  }

  applyPersonalLoan(loanPersonalInfo: ApplyPersonalInfo): Observable<LoanInfo> {
    loanPersonalInfo.custId = this.userInfo.userDetail.custId;
    loanPersonalInfo.userId = this.userInfo.userDetail.userId;
    return this.rest.post(this.url, loanPersonalInfo);
  }
}
