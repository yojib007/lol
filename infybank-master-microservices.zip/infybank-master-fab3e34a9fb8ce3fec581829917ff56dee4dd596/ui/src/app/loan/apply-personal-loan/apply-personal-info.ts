export class ApplyPersonalInfo {
    'custId': number;
    'userId': string;
    'loanAmount': number;
    'tenure': number;
    'debitAcctNo': string;
}
