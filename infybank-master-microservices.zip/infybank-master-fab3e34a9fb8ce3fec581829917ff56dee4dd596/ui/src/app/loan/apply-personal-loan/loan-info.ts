export class LoanInfo {
  'custId': number;
  'loanAcctNo': string;
  'loanAmount': number;
  'tenure': number;
  'interestRate': number;
  'openingDate': string;
  'emi': number;
  'emiDueDate': string;
  'loanStatus': string;
  'debitAcctNo': string;
  'remarks': string;
  'lstUpdtTs': string;
  'lstUpdtId': string;
}
