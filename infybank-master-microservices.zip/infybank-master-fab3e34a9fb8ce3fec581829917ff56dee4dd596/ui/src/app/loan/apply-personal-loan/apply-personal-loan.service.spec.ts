import { ApplyPersonalInfo } from './apply-personal-info';
import { ApplyPersonalLoanService } from './apply-personal-loan.service';

import { UserInformationService } from './../../shared/user-information.service';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../../shared/rest-service';
import { UserInformation } from './../../shared/user-information';
import { TestBed, inject } from '@angular/core/testing';

class UserInformationServiceStub {
  userDetail = new UserInformation();
}

class RestServiceStub {
  post() { }
}

describe('ApplyPersonalLoanService', () => {
  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApplyPersonalLoanService,
        { provide: RestService, useValue: restServiceStub },
        { provide: UserInformationService, useValue: userInformationServiceStub },
      ]
    }).compileComponents();
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([ApplyPersonalLoanService], (service: ApplyPersonalLoanService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the applyPersonalLoan function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([ApplyPersonalLoanService], (service: ApplyPersonalLoanService) => {

        const spy = spyOn(restService, 'post');
        service.applyPersonalLoan(new ApplyPersonalInfo());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking applyPersonalLoan function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([ApplyPersonalLoanService], (service: ApplyPersonalLoanService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
        service.applyPersonalLoan(new ApplyPersonalInfo()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking applyPersonalLoan function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([ApplyPersonalLoanService], (service: ApplyPersonalLoanService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
        service.applyPersonalLoan(new ApplyPersonalInfo()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

});
