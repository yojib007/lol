import { By } from '@angular/platform-browser';
import { LoanPrePaymentService } from './loan-pre-payment.service';
import { SuccessMessageService } from './../../shared/success-message.service';
import { Router } from '@angular/router';
import { LoanDetail } from './../loan-detail/loan-detail';
import { LoanPrepaymentComponent } from './loan-prepayment.component';
import { ValidatorsService } from './../../shared/validators.service';
import { LoanDetailService } from './../loan-detail/loan-detail.service';
import { UserInformationService } from './../../shared/user-information.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { LoansAccount } from './../../account-detail/account-summary/loans-account';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DownloadService } from './../../shared/download.service';
import { AccountService } from './../../shared/account.service';
import { Profile } from './../../shared/profile';
import { UserInformation } from './../../shared/user-information';

class AccountServiceStub {

    accountSummary() {
        return Observable.of({
            'totalAssets': 10000,
            'totalLiability': 5000,
            accountDtoList: [{
                'acctNo': '123456',
                'acctType': 'S',
                'balance': 5000,
                'salaried': 'Y'
            }],
            loanAccountDtoList: [{
                'loanAcctNo': '12345',
                'loanprepayAmount': 5000,
                'loanStatus': 'A'
            },
            {
                'loanAcctNo': '12345',
                'loanprepayAmount': 5000,
                'loanStatus': 'S'
            }
            ]
        });
    }
}

class LoanDetailServiceStub {
    loanDetail() {
        return Observable.of(new LoanDetail());
    }
}

class ValidatorsServiceStub {
    loanprepayAmount;
    isFieldHasErrors() { }
    findBalance() { }
    amountValidator() { }
    loanAmountValidator() { }

}

class LoanPrePaymentServiceStub {
    loanPrePaymentService() { }
}

class UserInformationServiceStub {
    userDetail = new UserInformation();
    profileDetail = new Profile();
}

describe('LoanPrepaymentComponent', () => {
    const loanDetailServiceStub = new LoanDetailServiceStub();
    const accountServiceStub = new AccountServiceStub();
    const validatorsServiceStub = new ValidatorsServiceStub();
    const loanPrePaymentServiceStub = new LoanPrePaymentServiceStub();
    const userInformationServiceStub = new UserInformationServiceStub();
    let component: LoanPrepaymentComponent;
    let fixture: ComponentFixture<LoanPrepaymentComponent>;
    let accountService;
    let validatorsService;
    let loanDetailService;
    let loanPrePaymentService;
    let acctSummaryObj;
    let router;
    let successMessageService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule, ReactiveFormsModule],
            declarations: [LoanPrepaymentComponent],
            providers: [
                { provide: LoanDetailService, useValue: loanDetailServiceStub },
                { provide: AccountService, useValue: accountServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                { provide: LoanPrePaymentService, useValue: loanPrePaymentServiceStub },
                { provide: UserInformationService, useValue: userInformationServiceStub },
                SuccessMessageService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LoanPrepaymentComponent);
        component = fixture.componentInstance;
        accountService = TestBed.get(AccountService);
        loanDetailService = TestBed.get(LoanDetailService);
        validatorsService = TestBed.get(ValidatorsService);
        loanPrePaymentService = TestBed.get(LoanPrePaymentService);
        router = TestBed.get(Router);
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
        acctSummaryObj = {
            'totalAssets': 10000,
            'totalLiability': 5000,
            accountDtoList: [{
                'acctNo': '123456',
                'acctType': 'S',
                'balance': 5000,
                'salaried': 'Y'
            }],
            loanAccountDtoList: [{
                'loanAcctNo': '12345',
                'loanprepayAmount': 5000,
                'loanStatus': 'A'
            },
            {
                'loanAcctNo': '12345',
                'loanprepayAmount': 5000,
                'loanStatus': 'S'
            }
            ]
        };

    });

    // Checking everything is created
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking call should be made to accountSummary method of AccountService
    it('should invoke accountSummary method of AccountService', () => {
        const spy = spyOn(accountService, 'accountSummary').and.returnValue(Observable.of(acctSummaryObj));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('on recieving data from accountSummary method of AccountService', () => {

        let spyForm;
        let spyLoanInfo;

        beforeEach(() => {
            spyOn(accountService, 'accountSummary').and.returnValue(Observable.of(acctSummaryObj));
            spyForm = spyOn(component, 'createForm');
            spyLoanInfo = spyOn(component, 'loanInfo');
            component.ngOnInit();
        });

        // Checking accountNumber is populated
        it('should populate the accountNumber', () => {
            expect(component.accountNumbers).toBeDefined();
        });

        // Checking loanAcctNo is populated
        it('should populate the loanAcctNo', () => {
            expect(component.loanAcctNo).toBeDefined();
        });

        // Checking call made to createForm function
        it('should call createForm method', () => {
            expect(spyForm).toHaveBeenCalled();
        });

        // Checking call made to loanInfo function
        it('should call loanInfo method', () => {
            expect(spyLoanInfo).toHaveBeenCalled();
        });
    });

    // Checking errorMessage is populated if no loan object with status as A is recieved from accountSummary method
    it('should populate error if no loan object with status as A is recieved from accountSummary method', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.of({ accountDtoList: [], loanAccountDtoList: [] }));
        component.error = null;
        component.ngOnInit();
        expect(component.errorMessage).toBeDefined();
    });

    // Checking error is populated if error is thrown from accountSummary method of AccountService
    it('should populate error if error is thrown from accountSummary method of AccountService', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.errorMessage).toBe('Server Error');
    });

    describe('invoking loanInfo method', () => {

        // Checking call should be made to loanDetail method of LoanDetailService
        it('should invoke loanDetail method of LoanDetailService', () => {
            const spy = spyOn(loanDetailService, 'loanDetail').and.returnValue(Observable.of(new LoanDetail()));
            component.loanInfo();
            expect(spy).toHaveBeenCalled();
        });

        // Checking loanAcctNo is populated
        it('should populate the loanAcctNo on recieving data from loanDetail method of LoanDetailService', () => {
            spyOn(loanDetailService, 'loanDetail').and.returnValue(Observable.of(new LoanDetail()));
            component.loanInfo();
            expect(component.loanDetails).toBeDefined();
        });

        // Checking error is populated if error is thrown from loanDetail method of LoanDetailService
        it('should populate error if error is thrown from loanDetail method of LoanDetailService', () => {
            spyOn(loanDetailService, 'loanDetail').and.returnValue(Observable.throw('Server Error'));
            component.loanInfo();
            expect(component.errorMessage).toBe('Server Error');
        });
    });

    describe('invoking proceedWithPayment function', () => {

        // should call loanPrePaymentService method of loanPrePaymentService
        it('should call loanPrePaymentService method of loanPrePaymentService', () => {

            const spy = spyOn(loanPrePaymentService, 'loanPrePaymentService').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.proceedWithPayment();
            expect(spy).toHaveBeenCalled();
        });

        describe('on recieving data from loanPrePaymentService method of loanPrePaymentService', () => {

            let spy;
            beforeEach(() => {
                spyOn(loanPrePaymentService, 'loanPrePaymentService').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate');
                component.proceedWithPayment();
            });

            // Populate message if data is recieved from loanPrePaymentService method of loanPrePaymentService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/account/acctsumm']);
            });
        });

        // Populate error if error is thrown from loanPrePaymentService method of loanPrePaymentService
        it('should populate error if error is thrown from loanPrePaymentService method of loanPrePaymentService', () => {

            spyOn(loanPrePaymentService, 'loanPrePaymentService').and.returnValue(Observable.throw('Server Error'));
            component.proceedWithPayment();
            expect(component.error).toBe('Server Error');
        });
    });

    describe('invoking balance method', () => {

        let spy;

        beforeEach(() => {
            spy = spyOn(validatorsService, 'findBalance');
            component.loanDetails = new LoanDetail();
            component.loanDetails.loanAmount = 1000;
            spyOn(component.prePaymentForm.value, 'fromAccount').and.returnValue('123456');
            component.balance();
        });

        // Checking findBalance method of ValidatorService has been called
        it('should call the findBalance method of ValidatorService', () => {
            expect(spy).toHaveBeenCalled();
        });

        // Checking loanprepayAmount property of ValidatorService has been called
        it('should populate the loanprepayAmount property of ValidatorService', () => {
            expect(validatorsService.loanAmount).toBe(1000);
        });
    });

    describe('has prePaymentForm', () => {

        beforeEach(() => {
            component.createForm();
        });

        describe('has fromAccount field which is empty', () => {
            let errors = {};
            let fromAccount;
            beforeEach(() => {
                fromAccount = component.prePaymentForm.controls['fromAccount'];
                fromAccount.setValue('');
                errors = fromAccount.errors || {};
                fixture.detectChanges();
            });

            // Checking fromAccount is invalid if it is empty
            it('should be invalid', () => {

                expect(fromAccount.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has fromAccount field which is filled', () => {
            let errors = {};
            let fromAccount;
            beforeEach(() => {
                fromAccount = component.prePaymentForm.controls['fromAccount'];
                fromAccount.setValue('123456');
                errors = fromAccount.errors || {};
                fixture.detectChanges();
            });

            // Checking fromAccount is valid if it is filled
            it('should be valid', () => {

                expect(fromAccount.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has paymentOption field which is empty', () => {
            let errors = {};
            let paymentOption;
            beforeEach(() => {
                paymentOption = component.prePaymentForm.controls['paymentOption'];
                paymentOption.setValue('');
                errors = paymentOption.errors || {};
                fixture.detectChanges();
            });

            // Checking paymentOption is invalid if it is empty
            it('should be invalid', () => {

                expect(paymentOption.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has paymentOption field which is filled', () => {
            let errors = {};
            let paymentOption;
            beforeEach(() => {
                paymentOption = component.prePaymentForm.controls['paymentOption'];
                paymentOption.setValue('SE');
                errors = paymentOption.errors || {};
                fixture.detectChanges();
            });

            // Checking paymentOption is valid if it is filled
            it('should be valid', () => {

                expect(paymentOption.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has prepayAmount field which is empty', () => {
            let errors = {};
            let prepayAmount;
            beforeEach(() => {
                prepayAmount = component.prePaymentForm.controls['prepayAmount'];
                prepayAmount.setValue('');
                errors = prepayAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking prepayAmount is invalid if it is empty
            it('should be invalid', () => {

                expect(prepayAmount.valid).toBeFalsy();

            });

            // Checking required error is present if prepayAmount is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has prepayAmount field which is filled values less than one', () => {
            let errors = {};
            let prepayAmount;
            beforeEach(() => {
                prepayAmount = component.prePaymentForm.controls['prepayAmount'];
                prepayAmount.setValue(-1);
                errors = prepayAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking prepayAmount is invalid if it is incorrect
            it('should be invalid', () => {

                expect(prepayAmount.valid).toBeFalsy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required', () => {
                expect(errors['required']).toBeFalsy();

            });

            // Checking min error is present if prepayAmount is invalid
            it('should contain min error', () => {
                expect(errors['min']).toBeTruthy();

            });

        });

        describe('has prepayAmount field on recieving error object from amountValidator method of ValidatorService', () => {
            let errors = {};
            let prepayAmount;
            beforeEach(() => {
                spyOn(validatorsService, 'amountValidator').and.returnValue({ minprepayAmount: true });
                component.createForm();
                prepayAmount = component.prePaymentForm.controls['prepayAmount'];
                prepayAmount.setValue(1000);
                errors = prepayAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking prepayAmount is invalid if it is incorrect
            it('should be invalid', () => {

                expect(prepayAmount.valid).toBeFalsy();

            });

            // Checking min error is present if prepayAmount is invalid
            it('should contain minprepayAmount error', () => {
                expect(errors['minprepayAmount']).toBeTruthy();

            });

        });

        describe('has prepayAmount field on recieving null from amountValidator method of ValidatorService', () => {
            let errors = {};
            let prepayAmount;
            beforeEach(() => {
                spyOn(validatorsService, 'amountValidator').and.returnValue(null);
                component.createForm();
                prepayAmount = component.prePaymentForm.controls['prepayAmount'];
                prepayAmount.setValue(1000);
                errors = prepayAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking prepayAmount is valid if it is filled
            it('should be valid', () => {

                expect(prepayAmount.valid).toBeTruthy();

            });

            // Checking minprepayAmount error is not present if field is correct
            it('should not contain minprepayAmount error', () => {
                expect(errors['minprepayAmount']).toBeFalsy();

            });

        });

        describe('has prepayAmount field on recieving error object from loanAmountValidator method of ValidatorService', () => {
            let errors = {};
            let prepayAmount;
            beforeEach(() => {
                spyOn(validatorsService, 'loanAmountValidator').and.returnValue({ minprepayAmount: true });
                component.createForm();
                prepayAmount = component.prePaymentForm.controls['prepayAmount'];
                prepayAmount.setValue(1000);
                errors = prepayAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking prepayAmount is invalid if it is incorrect
            it('should be invalid', () => {

                expect(prepayAmount.valid).toBeFalsy();

            });

            // Checking min error is present if prepayAmount is invalid
            it('should contain minprepayAmount error', () => {
                expect(errors['minprepayAmount']).toBeTruthy();

            });

        });

        describe('has prepayAmount field on recieving null from loanAmountValidator method of ValidatorService', () => {
            let errors = {};
            let prepayAmount;
            beforeEach(() => {
                spyOn(validatorsService, 'loanAmountValidator').and.returnValue(null);
                component.createForm();
                prepayAmount = component.prePaymentForm.controls['prepayAmount'];
                prepayAmount.setValue(1000);
                errors = prepayAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking prepayAmount is valid if it is filled
            it('should be valid', () => {

                expect(prepayAmount.valid).toBeTruthy();

            });

            // Checking minprepayAmount error is not present if field is correct
            it('should not contain minprepayAmount error', () => {
                expect(errors['minprepayAmount']).toBeFalsy();

            });

        });

        describe('prePaymentForm when all fields are valid', () => {

            let submitBtn;
            beforeEach(() => {
                submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
                component.prePaymentForm.controls['fromAccount'].setValue('123456');
                component.prePaymentForm.controls['paymentOption'].setValue('SE');
                component.prePaymentForm.controls['prepayAmount'].setValue(1000);
                fixture.detectChanges();
            });

            // form should be valid if all feilds are filled properly
            it('should be valid', () => {

                expect(component.prePaymentForm.valid).toBe(true);

            });

            // checking submit button is enabled if form is valid
            it('should has submit button enabled', () => {

                expect(submitBtn.disabled).toBe(false);

            });

            // proceedWithPayment function should be called on clicking the submit button
            it('should call proceedWithPayment function on clicking submit button', () => {

                const spy = spyOn(component, 'proceedWithPayment');
                submitBtn.click();
                expect(spy).toHaveBeenCalled();
            });

        });
    });

});
