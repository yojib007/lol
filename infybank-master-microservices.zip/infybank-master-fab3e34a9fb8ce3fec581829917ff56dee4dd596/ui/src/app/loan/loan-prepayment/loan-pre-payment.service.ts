import { LoanPrePayment } from './loan-prepayment';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../../shared/rest-service';
import { UserInformationService } from './../../shared/user-information.service';

@Injectable()
export class LoanPrePaymentService {
  url = '/infybank/v1/customers/';
  constructor(private rest: RestService, private userInfo: UserInformationService) {
    this.url += this.userInfo.userDetail.custId + '/loans/';
  }
  loanPrePaymentService(loanPrePayment: LoanPrePayment) {
    return this.rest.post(this.url + loanPrePayment.loanAcctNo + '/prepay', loanPrePayment);
  }
}
