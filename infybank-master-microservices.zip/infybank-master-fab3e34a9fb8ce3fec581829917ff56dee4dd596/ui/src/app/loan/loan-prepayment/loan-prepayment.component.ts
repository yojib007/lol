import { Router } from '@angular/router';
import { SuccessMessageService } from './../../shared/success-message.service';
import { UserInformationService } from './../../shared/user-information.service';
import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { LoanPrePaymentService } from './loan-pre-payment.service';
import { LoanPrePayment } from './loan-prepayment';
import { AccountService } from './../../shared/account.service';
import { LoanDetailService } from './../loan-detail/loan-detail.service';
import { ValidatorsService } from './../../shared/validators.service';
import { LoanDetail } from './../loan-detail/loan-detail';

@Component({
  selector: 'app-loan-prepayment',
  templateUrl: './loan-prepayment.component.html',
  styleUrls: ['./loan-prepayment.component.css']
})
export class LoanPrepaymentComponent implements OnInit {

  prePaymentForm: FormGroup;
  //loanAcctNo: string;
  accountBalance: number;
  loanDetails: LoanDetail;
  loanPrePayment: LoanPrePayment;
  accountNumbers: string[] = [];
  submit: boolean;
  error: string[];
  errorMessage: string[];
  noLoan: string;

  @Input() loanAcctNo: string;
  constructor(private formBuilder: FormBuilder, private lppService: LoanPrePaymentService,
    private accountService: AccountService, private loanDetailService: LoanDetailService,
    private userInformationService: UserInformationService, private validatorsService: ValidatorsService,
    private successMessageService: SuccessMessageService, private router: Router) { }

  createForm() {
    this.prePaymentForm = this.formBuilder.group({
      fromAccount: ['', Validators.required],
      prepayAmount: ['', [Validators.required, Validators.min(1), this.validatorsService.amountValidator,
      this.validatorsService.loanAmountValidator]],
      paymentOption: ['', Validators.required],
      loanAcctNo: [this.loanAcctNo]
    });
  }

  balance() {
    this.validatorsService.findBalance(this.prePaymentForm.value.fromAccount);
    this.validatorsService.loanAmount = this.loanDetails.loanAmount;
  }

  getDetails() {
    //this.accountService.accountSummary().subscribe(
    //  data => {
    //   data.accounts.forEach((accountDetail) => {
    //    this.accountNumbers.push(accountDetail.acctNo);
    //  });
    this.accountService.getAccountNumbers().subscribe(accountNumbers => {
      for (let i = 0; i < accountNumbers.length; i++)
        this.accountNumbers.push(accountNumbers[i])
    }
    );

    //const loanDetail = data.loanAccounts.find(loan => loan.loanStatus === 'A');
    //if (loanDetail) {
    //this.loanAcctNo = loanDetail.loanAcctNo;
    this.loanInfo();
    // } else {
    //   this.noLoan = `ERRORS.LOANPREPAY.NOLOAN`;
    // }
    //  },
    // error => this.errorMessage = error
    // );
  }

  proceedWithPayment() {
    this.submit = true;
    this.lppService.loanPrePaymentService(this.prePaymentForm.value).subscribe(
      data => {
        this.successMessageService.message = 'LOANPREPAY.SUCCESS';
        this.router.navigate(['/manage-loans']);
      },
      error => {
        this.error = error;
        this.submit = false;
      }
    );
  }

  loanInfo() {
    this.loanDetailService.loanDetail(this.loanAcctNo).subscribe(
      value => {
        this.loanDetails = value;
        this.createForm();
      },
      error => this.errorMessage = error
    );
  }

  ngOnInit() {

    this.successMessageService.view = 'loan';
    this.successMessageService.subView = 'lnPrp';
    this.getDetails();
    //this.loanInfo();
  }

}
