import { LoanPrePaymentService } from './loan-pre-payment.service';
import { LoanPrePayment } from './loan-prepayment';
import { UserInformationService } from './../../shared/user-information.service';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../../shared/rest-service';
import { UserInformation } from './../../shared/user-information';
import { TestBed, inject } from '@angular/core/testing';

class UserInformationServiceStub {
  userDetail = new UserInformation();
}

class RestServiceStub {
  post() { }
}

describe('LoanPrePaymentService', () => {
  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoanPrePaymentService,
        { provide: RestService, useValue: restServiceStub },
        { provide: UserInformationService, useValue: userInformationServiceStub },
      ]
    }).compileComponents();
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([LoanPrePaymentService], (service: LoanPrePaymentService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the loanPrePaymentService function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([LoanPrePaymentService], (service: LoanPrePaymentService) => {

        const spy = spyOn(restService, 'post');
        service.loanPrePaymentService(new LoanPrePayment());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking loanPrePaymentService function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([LoanPrePaymentService], (service: LoanPrePaymentService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
        service.loanPrePaymentService(new LoanPrePayment()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking loanPrePaymentService function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([LoanPrePaymentService], (service: LoanPrePaymentService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
        service.loanPrePaymentService(new LoanPrePayment()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

});
