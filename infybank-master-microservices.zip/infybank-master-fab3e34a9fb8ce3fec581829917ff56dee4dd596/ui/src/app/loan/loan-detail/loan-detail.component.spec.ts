import { SuccessMessageService } from './../../shared/success-message.service';
import { Observable } from 'rxjs/Observable';
import { StatusPipe } from './status.pipe';
import { AccountService } from './../../shared/account.service';
import { LoansAccount } from './../../account-detail/account-summary/loans-account';
import { LoanDetailService } from './loan-detail.service';
import { LoanDetail } from './loan-detail';
import { LoanDetailComponent } from './loan-detail.component';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

class LoanDetailServiceStub {
    loanDetail() {
        return Observable.of(new LoanDetail());
    }
}

class AccountServiceStub {
    accountSummary() {
        return Observable.of({
            loanAccountDtoList: [{
                loanAcctNo: '123456',
                loanStatus: 'A'
            }]
        });
    }
}

describe('LoanDetailComponent', () => {
    const loanDetailServiceStub = new LoanDetailServiceStub();
    const accountServiceStub = new AccountServiceStub();

    let component: LoanDetailComponent;
    let fixture: ComponentFixture<LoanDetailComponent>;
    let accountService;
    let loanDetailService;
    let loanObject1;
    let loanObject2;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            declarations: [LoanDetailComponent, StatusPipe],
            providers: [
                { provide: LoanDetailService, useValue: loanDetailServiceStub },
                { provide: AccountService, useValue: accountServiceStub },
                SuccessMessageService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LoanDetailComponent);
        component = fixture.componentInstance;
        accountService = TestBed.get(AccountService);
        loanDetailService = TestBed.get(LoanDetailService);
        fixture.detectChanges();
        loanObject1 = {

            loanAcctNo: '123456',
            loanStatus: 'A'
        };

        loanObject2 = {

            loanAcctNo: '123457',
            loanStatus: 'C'
        };
    });

    // Checking everything is created
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking call should be made to accountSummary method of AccountService
    it('should invoke accountSummary method of AccountService', () => {
        const spy = spyOn(accountService, 'accountSummary').and.returnValue(Observable.of({ loanAccountDtoList: [loanObject1] }));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('on recieving data from accountSummary method of AccountService', () => {

        let spy;

        beforeEach(() => {
            spyOn(accountService, 'accountSummary').and.returnValue(Observable.of({ loanAccountDtoList: [loanObject1] }));
            spy = spyOn(component, 'loanDetail');
            component.ngOnInit();
        });

        // Checking loanAcctNo is populated
        it('should populate the loanAcctNo', () => {
            expect(component.loanAcctNo).toBeDefined();
        });

        // Checking call made to loanDetail function
        it('should call loanDetail method', () => {
            expect(spy).toHaveBeenCalled();
        });
    });

    // Checking error is populated if no loan object with status as A or S is recieved from accountSummary method
    it('should populate error if no loan object with status as A is recieved from accountSummary method', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.of({ loanAccountDtoList: [loanObject2] }));
        component.error = null;
        component.ngOnInit();
        expect(component.error).toBeDefined();
    });

    // Checking error is populated if error is thrown from accountSummary method of AccountService
    it('should populate error if error is thrown from accountSummary method of AccountService', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.error).toBe('Server Error');
    });

    describe('invoking loanDetail method', () => {

        // Checking call should be made to loanDetail method of LoanDetailService
        it('should invoke loanDetail method of LoanDetailService', () => {
            const spy = spyOn(loanDetailService, 'loanDetail').and.returnValue(Observable.of(new LoanDetail()));
            component.loanDetail();
            expect(spy).toHaveBeenCalled();
        });

        // Checking loanAcctNo is populated
        it('should populate the loanAcctNo on recieving data from loanDetail method of LoanDetailService', () => {
            spyOn(loanDetailService, 'loanDetail').and.returnValue(Observable.of(new LoanDetail()));
            component.loanDetail();
            expect(component.loanDetails).toBeDefined();
        });

        // Checking error is populated if error is thrown from loanDetail method of LoanDetailService
        it('should populate error if error is thrown from loanDetail method of LoanDetailService', () => {
            spyOn(loanDetailService, 'loanDetail').and.returnValue(Observable.throw('Server Error'));
            component.loanDetail();
            expect(component.error).toBe('Server Error');
        });
    });
});
