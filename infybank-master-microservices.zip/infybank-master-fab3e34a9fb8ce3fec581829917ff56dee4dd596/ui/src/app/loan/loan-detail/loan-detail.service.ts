import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../../shared/rest-service';
import { LoansAccount } from './../../account-detail/account-summary/loans-account';
import { UserInformationService } from './../../shared/user-information.service';

@Injectable()
export class LoanDetailService {

  url = '';
  constructor(private rest: RestService, private userInfo: UserInformationService) {
    this.url = '/infybank/v1/customers/' + this.userInfo.userDetail.custId + '/loans/';
  }
  loanDetail(accountNo: string) {
    return this.rest.get(this.url + accountNo);
  }

}
