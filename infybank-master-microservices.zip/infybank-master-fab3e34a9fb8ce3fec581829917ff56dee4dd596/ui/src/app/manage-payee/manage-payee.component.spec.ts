import { SuccessMessageService } from './../shared/success-message.service';
import { RouterTestingModule } from '@angular/router/testing';
import { ManagePayeeComponent } from './manage-payee.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('ManagePayeeComponent', () => {
    let component: ManagePayeeComponent;
    let fixture: ComponentFixture<ManagePayeeComponent>;
    let successMessageService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            declarations: [ManagePayeeComponent],
            providers: [SuccessMessageService]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ManagePayeeComponent);
        component = fixture.componentInstance;
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
    });

    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking message property became null after 5 secs
    it('should null the message property of SuccessMessageService after 5 secs', () => {
        successMessageService.message = 'success';
        component.ngOnInit();
        setTimeout(() => {
            expect(successMessageService.message).toBeNull();
        }, 5000);
    });

});
