import { RegisteredPayeeComponent } from './registered-payee/registered-payee.component';
import { DeletePayeeComponent } from './delete-payee/delete-payee.component';
import { ConfirmPayeeComponent } from './confirm-payee/confirm-payee.component';
import { AddInfyBankPayeeComponent } from './add-infy-bank-payee/add-infy-bank-payee.component';
import { ManagePayeeComponent } from './manage-payee.component';
import { AuthGuardUserService } from './../shared/auth-guard.user.service';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [

        { path: '', component: ManagePayeeComponent },
        { path: 'addinfypayee', component: AddInfyBankPayeeComponent },
        { path: 'confirmpayee', component: ConfirmPayeeComponent },
        { path: 'deletepayee/:id', component: DeletePayeeComponent },
        { path: 'registeredpayee', component: RegisteredPayeeComponent },
    ],
    canActivate: [AuthGuardUserService]
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManagePayeeRoutingModule { }
