import { ManagePayeeRoutingModule } from './manage-payee.routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManagePayeeComponent } from './manage-payee.component';
import { AddInfyBankPayeeComponent } from './add-infy-bank-payee/add-infy-bank-payee.component';
import { ConfirmPayeeComponent } from './confirm-payee/confirm-payee.component';
import { DeletePayeeComponent } from './delete-payee/delete-payee.component';
import { RegisteredPayeeComponent } from './registered-payee/registered-payee.component';
import { RouterModule, Routes } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule, RouterModule, FormsModule, ReactiveFormsModule, ManagePayeeRoutingModule, TranslateModule
  ],
  declarations: [ManagePayeeComponent, AddInfyBankPayeeComponent, ConfirmPayeeComponent, DeletePayeeComponent, RegisteredPayeeComponent],
  providers: []
})
export class ManagePayeeModule { }
