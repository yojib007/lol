import { Router } from '@angular/router';
import { SuccessMessageService } from './../../shared/success-message.service';
import { ValidatorsService } from './../../shared/validators.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { PayeeService } from './../../shared/payee.service';
import { Payee } from './../../shared/payee';
import { Component, OnInit } from '@angular/core';
import { ConfirmPayee } from './confirm-payee';

@Component({
  selector: 'app-confirm-payee',
  templateUrl: './confirm-payee.component.html',
  styleUrls: ['./confirm-payee.component.css']
})
export class ConfirmPayeeComponent implements OnInit {

  payeeList: Payee[];
  error: string[];
  errorMessage: string[];
  noPayee: string;
  submitted: boolean;
  selectedPayee: Payee;
  payeeOtpForm: FormGroup;
  confirmPayee: ConfirmPayee;
  constructor(private successMessageService: SuccessMessageService, private router: Router,
    private validatorsService: ValidatorsService, private payeeService: PayeeService, private formBuilder: FormBuilder) { }

  submit() {
    this.submitted = true;
    this.payeeService.confirmPayee(this.selectedPayee, this.confirmPayee).subscribe(
      (data) => {
        this.successMessageService.message = 'CONFIRMPAYEE.SUCCESS';
        this.router.navigate(['/managepayee']);
      },
      error => {
        this.error = error;
        this.submitted = false;
      }
    );
  }

  getPayee() {
    this.payeeService.viewPayee('S').subscribe(
      data => {
        this.payeeList = data;
        if (this.payeeList.length === 0) {
          this.noPayee = 'ERRORS.CONFIRMPAYEE.NOPAYEE';
        } else {
          this.createForm();
        }
      },
      error => this.errorMessage = error
    );
  }

  createForm() {
    this.payeeOtpForm = this.formBuilder.group({
      otp: ['', [Validators.pattern('[0-9]{6}'), Validators.required]]
    });
  }
  deletePayee() {
    this.submitted = true;
    this.payeeService.deletePayee(this.selectedPayee).subscribe(
      data => {
        this.successMessageService.message = `DELETEPAYEE.SUCCESS`;
        this.submitted = false;
        this.ngOnInit();
      },
      error => {
        this.error = error;
        this.submitted = false;
      }
    );
  }
  ngOnInit() {
    if (this.successMessageService.message) {
      setTimeout(() => {
        this.successMessageService.message = null;
      }, 5000);
    }
    this.successMessageService.view = 'fund';
    this.successMessageService.subView = 'mngPaye';
    this.confirmPayee = new ConfirmPayee();
    this.getPayee();
    this.selectedPayee = null;
  }

}
