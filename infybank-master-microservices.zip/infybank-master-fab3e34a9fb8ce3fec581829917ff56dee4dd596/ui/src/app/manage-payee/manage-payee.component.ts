import { SuccessMessageService } from './../shared/success-message.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-payee',
  templateUrl: './manage-payee.component.html',
  styleUrls: ['./manage-payee.component.css']
})
export class ManagePayeeComponent implements OnInit {

  constructor(private successMessageService: SuccessMessageService) { }

  ngOnInit() {
    this.successMessageService.view = 'fund';
    this.successMessageService.subView = 'mngPaye';
    if (this.successMessageService.message) {
      setTimeout(() => {
        this.successMessageService.message = null;
      }, 5000);
    }
  }
}
