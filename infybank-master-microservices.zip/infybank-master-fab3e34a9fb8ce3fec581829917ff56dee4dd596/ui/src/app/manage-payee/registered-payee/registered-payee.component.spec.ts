import { SuccessMessageService } from './../../shared/success-message.service';
import { ProfileService } from './../../shared/profile.service';
import { By } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { PayeeService } from './../../shared/payee.service';
import { Payee } from './../../shared/payee';
import { RegisteredPayeeComponent } from './registered-payee.component';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

class PayeeServiceStub {
    viewPayee() {
        return Observable.of([new Payee()]);
    }
}
describe('RegisteredPayeeComponent', () => {
    const payeeServiceStub = new PayeeServiceStub();
    let component: RegisteredPayeeComponent;
    let fixture: ComponentFixture<RegisteredPayeeComponent>;
    let payeeService;
    let payee1: Payee;
    let payee2: Payee;
    let payee3: Payee;
    let payee4: Payee;
    let payeeList: Payee[];

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule],
            declarations: [RegisteredPayeeComponent],
            providers: [{ provide: PayeeService, useValue: payeeServiceStub }, SuccessMessageService]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        payeeService = TestBed.get(PayeeService);
        fixture = TestBed.createComponent(RegisteredPayeeComponent);
        component = fixture.componentInstance;
        payee1 = {
            'payeeId': 1,
            'name': 'test2',
            'nickName': 'nickTest2',
            'acctNo': '1234567862',
            'userId': 'suma',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payee2 = {
            'payeeId': 2,
            'name': 'test3',
            'nickName': 'nickTest3',
            'acctNo': '1234567863',
            'userId': 'john',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payee3 = {
            'payeeId': 4,
            'name': 'test4',
            'nickName': 'nickTest4',
            'acctNo': '1234567864',
            'userId': 'John Smith',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'S'
        };
        payee4 = {
            'payeeId': 6,
            'name': 'john smith',
            'nickName': 'nicktest',
            'acctNo': '1234567891',
            'userId': 'suma',
            'ifscCode': 'sbi12345678',
            'acctType': 'S',
            'custId': 101,
            'status': 'C'
        };
        payeeList = [payee1, payee2, payee3, payee4];

    });

    // Checking everything is fine
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking viewPayee method of PayeeService has been called
    it('should call viewPayee method of PayeeService', () => {
        const spy = spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('recieving data from viewPayee method of PayeeService', () => {

        // Checking payeeList has been populated
        it('should populate the payeeList', () => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
            component.ngOnInit();
            expect(component.payeeList).toBeDefined();
        });

        // Checking payeeList is populated with objects whose status is "C"
        it('should populate the payeeList with object whose status is "C"', () => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of([payee1, payee2, payee3]));
            component.ngOnInit();
            expect(component.payeeList).toEqual([payee1, payee2]);
        });

        // Checking error is populated if no object with status "C" is recieved
        it('should populate error if no object with status as "C" is recieved', () => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of([payee3]));
            component.ngOnInit();
            expect(component.error).toMatch(`You don't have any payee list`);
        });
    });

    describe('recieving error from viewPayee method of PayeeService', () => {
        beforeEach(() => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.throw('Server Error'));
        });

        // Checking error is populated with message recieved from server
        it('should populate error if no object with status as "C" is recieved', () => {
            component.ngOnInit();
            expect(component.error).toMatch(`Server Error`);
        });

        // Checking payeeList is empty
        it('should not populate payeeList', () => {
            component.ngOnInit();
            expect(component.payeeList).toBeNull();
        });
    });

    describe('invoking search function', () => {

        beforeEach(() => {
            spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
            component.ngOnInit();
        });

        // Checking payeeList is filtered based on name if name is initialized
        it('should filter the payeeList based on name if name is intialized', () => {
            component.name = 'John';
            component.search();
            expect(component.payeeList).toEqual([payee4]);
        });

        // Checking payeeList is not filtered based on name if name is not initialized
        it('should filter the payeeList based on name if name is intialized', () => {
            component.name = '';
            component.search();
            expect(component.payeeList).toEqual([payee1, payee2, payee4]);
        });

        // Checking payeeList is filtered based on nickName if nickName is initialized
        it('should filter the payeeList based on nickName if nickName is intialized', () => {
            component.nickName = 'nicktest3';
            component.search();
            expect(component.payeeList).toEqual([payee2]);
        });

        // Checking payeeList is not filtered based on nickName if nickName is not initialized
        it('should filter the payeeList based on nickName if nickName is intialized', () => {
            component.nickName = '';
            component.search();
            expect(component.payeeList).toEqual([payee1, payee2, payee4]);
        });

        // Checking payeeList is filtered based on account if account is initialized
        it('should filter the payeeList based on account if account is intialized', () => {
            component.account = '1234567863';
            component.search();
            expect(component.payeeList).toEqual([payee2]);
        });

        // Checking payeeList is not filtered based on account if account is not initialized
        it('should filter the payeeList based on account if account is intialized', () => {
            component.account = '';
            component.search();
            expect(component.payeeList).toEqual([payee1, payee2, payee4]);
        });
    });

    // Checking search function is called
    it('should call search function if search button is clicked', () => {
        spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
        fixture.detectChanges();
        const btn = fixture.debugElement.query(By.css('#search')).nativeElement;
        const spy = spyOn(component, 'search');
        btn.click();
        expect(spy).toHaveBeenCalled();
    });

    // Checking refresh button is called
    it('should call ngOnInit function if search button is clicked', () => {
        spyOn(payeeService, 'viewPayee').and.returnValue(Observable.of(payeeList));
        fixture.detectChanges();
        const btn = fixture.debugElement.query(By.css('#refresh')).nativeElement;
        const spy = spyOn(component, 'ngOnInit');
        btn.click();
        expect(spy).toHaveBeenCalled();
    });
});
