import { SharedModule } from './../shared/shared.module';
import { FundTransferRoutingModule } from './fund-transfer.routing.module';
import { ManagePayeeRoutingModule } from './../manage-payee/manage-payee.routing.module';
import { FundTransferService } from './fund-transfer.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FundTransferOwnAccountComponent } from './fund-transfer-own-account/fund-transfer-own-account.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FundTransferComponent } from './fund-transfer.component';
import { FundTransferInfosysBankComponent } from './fund-transfer-infosys-bank/fund-transfer-infosys-bank.component';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule, ReactiveFormsModule, FormsModule, FundTransferRoutingModule, TranslateModule, SharedModule
  ],
  declarations: [FundTransferComponent, FundTransferInfosysBankComponent, FundTransferOwnAccountComponent],
  providers: [FundTransferService]
})
export class FundTransferModule { }
