import { FundTransferOwnAccountComponent } from './fund-transfer-own-account.component';
import { By } from '@angular/platform-browser';
import { AccountService } from './../../shared/account.service';
import { ValidatorsService } from './../../shared/validators.service';
import { FundTransferService } from './../fund-transfer.service';
import { SuccessMessageService } from './../../shared/success-message.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import { PayeeService } from './../../shared/payee.service';
import { Payee } from './../../shared/payee';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';

class AccountServiceStub {
    getAccountNumbers() {
        return Observable.of(['123456', '125678', '123678']);
    }
}

class FundTransferServiceStub {
    transfer() { }
}

class ValidatorsServiceStub {
    isFieldHasErrors() { }
    findBalance() { }
    amountValidator() { }
    checkDatePast() { }
}

describe('FundTransferOwnAccountComponent', () => {
    const validatorsServiceStub = new ValidatorsServiceStub();
    const accountServiceStub = new AccountServiceStub();
    const fundTransferServiceStub = new FundTransferServiceStub();
    let component: FundTransferOwnAccountComponent;
    let fixture: ComponentFixture<FundTransferOwnAccountComponent>;
    let router;
    let successMessageService;
    let accountService;
    let validatorsService;
    let fundTransferService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule, ReactiveFormsModule],
            declarations: [FundTransferOwnAccountComponent],
            providers: [
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                { provide: AccountService, useValue: accountServiceStub },
                { provide: FundTransferService, useValue: fundTransferServiceStub },
                SuccessMessageService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(FundTransferOwnAccountComponent);
        component = fixture.componentInstance;
        router = TestBed.get(Router);
        successMessageService = TestBed.get(SuccessMessageService);
        fundTransferService = TestBed.get(FundTransferService);
        validatorsService = TestBed.get(ValidatorsService);
        accountService = TestBed.get(AccountService);
        fixture.detectChanges();
    });

    // Checking everything is created properly
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking getAccountNumbers method of accountService has been called
    it('should call getAccountNumbers method of accountService', () => {
        const spy = spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.of(['123456', '789012']));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('on recieving data from getAccountNumbers method of accountService', () => {

        let spy;
        beforeEach(() => {
            spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.of(['123456', '789012']));
            spy = spyOn(component, 'createForm');
            component.ngOnInit();
        });

        // Checking accountList has been populated
        it('should populate the accountList', () => {
            expect(component.accountList).toBeDefined();
        });

        // Checking createForm method has been called
        it('should call createForm method', () => {
            expect(spy).toHaveBeenCalled();
        });

        // Should not populate errorMessage
        it('should not populate errorMessage', () => {
            expect(component.errorMessage).toBeUndefined();
        });
    });

    // Checking errorMessage is populated if only one accountNo is retrieved
    it('should populate errorMessage on recieving only one accountNo from getAccountNumbers method of accountService', () => {
        spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.of(['123456']));
        component.ngOnInit();
        expect(component.errorMessage).toBeDefined();
    });


    // Checking errorMessage is populated with message recieved from server
    it('should populate errorMessage with message returned from accountService if error is thrown', () => {
        spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.errorMessage).toMatch(`Server Error`);
    });

    // Checking balance function invoking findBalance method of validatorsService
    it('should call findBalance method of ValidatorsService if balance function is invoked', () => {
        const spy = spyOn(validatorsService, 'findBalance');
        component.balance();
        expect(spy).toHaveBeenCalled();
    });

    // Populate toAccountList on invoking select function
    it('should populate toAccountList on invoking select function', () => {
        component.accountList = ['123456', '123457', '123458'];
        component.selectedFromAccount = '123456';
        component.select();
        expect(component.toAccountList).toEqual(['123457', '123458']);
    });

    describe('invoking submit function', () => {

        // should call transfer method of fundTransferService
        it('should call transfer method of fundTransferService', () => {

            const spy = spyOn(fundTransferService, 'transfer').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.submit();
            expect(spy).toHaveBeenCalled();
        });

        describe('on recieving data from transfer method of fundTransferService', () => {

            let spy;
            beforeEach(() => {
                spyOn(fundTransferService, 'transfer').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate');
                component.submit();
            });

            // Populate message if data is recieved from transfer method of fundTransferService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/fundtransfer']);
            });
        });

        // Populate error if error is thrown from transfer method of fundTransferService
        it('should populate error if error is thrown from transfer method of fundTransferService', () => {

            spyOn(fundTransferService, 'transfer').and.returnValue(Observable.throw('Server Error'));
            component.submit();
            expect(component.error).toBe('Server Error');
        });
    });

    // createForm should initialize form
    it('should initialize fundTransferOwnForm if createForm method is invoked', () => {
        component.fundTransferOwnForm = null;
        component.createForm();
        expect(component.fundTransferOwnForm).not.toBeNull();
    });

    describe('has fundTransferOwnForm', () => {

        beforeEach(() => {
            component.createForm();
        });

        describe('has fromAccountNo field which is empty', () => {
            let errors = {};
            let fromAccountNo;
            beforeEach(() => {
                fromAccountNo = component.fundTransferOwnForm.controls['fromAccountNo'];
                fromAccountNo.setValue('');
                errors = fromAccountNo.errors || {};
                fixture.detectChanges();
            });

            // Checking fromAccountNo is invalid if it is empty
            it('should be invalid', () => {

                expect(fromAccountNo.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has fromAccountNo field which is filled', () => {
            let errors = {};
            let fromAccountNo;
            beforeEach(() => {
                fromAccountNo = component.fundTransferOwnForm.controls['fromAccountNo'];
                fromAccountNo.setValue('123456');
                errors = fromAccountNo.errors || {};
                fixture.detectChanges();
            });

            // Checking fromAccountNo is valid if it is filled
            it('should be valid', () => {

                expect(fromAccountNo.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has toAccountNo field which is empty', () => {
            let errors = {};
            let toAccountNo;
            beforeEach(() => {
                toAccountNo = component.fundTransferOwnForm.controls['toAccountNo'];
                toAccountNo.setValue('');
                errors = toAccountNo.errors || {};
                fixture.detectChanges();
            });

            // Checking toAccountNo is invalid if it is empty
            it('should be invalid', () => {

                expect(toAccountNo.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has toAccountNo field which is filled', () => {
            let errors = {};
            let toAccountNo;
            beforeEach(() => {
                toAccountNo = component.fundTransferOwnForm.controls['toAccountNo'];
                toAccountNo.setValue('123456');
                errors = toAccountNo.errors || {};
                fixture.detectChanges();
            });

            // Checking toAccountNo is valid if it is filled
            it('should be valid', () => {

                expect(toAccountNo.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has remarks field which is empty', () => {
            let errors = {};
            let remarks;
            beforeEach(() => {
                remarks = component.fundTransferOwnForm.controls['remarks'];
                remarks.setValue('');
                errors = remarks.errors || {};
                fixture.detectChanges();
            });

            // Checking remarks is invalid if it is empty
            it('should be invalid', () => {

                expect(remarks.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has remarks field which is filled', () => {
            let errors = {};
            let remarks;
            beforeEach(() => {
                remarks = component.fundTransferOwnForm.controls['remarks'];
                remarks.setValue('Approved');
                errors = remarks.errors || {};
                fixture.detectChanges();
            });

            // Checking remarks is valid if it is filled
            it('should be valid', () => {

                expect(remarks.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has amount field which is empty', () => {
            let errors = {};
            let amount;
            beforeEach(() => {
                amount = component.fundTransferOwnForm.controls['amount'];
                amount.setValue('');
                errors = amount.errors || {};
                fixture.detectChanges();
            });

            // Checking amount is invalid if it is empty
            it('should be invalid', () => {

                expect(amount.valid).toBeFalsy();

            });

            // Checking required error is present if amount is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has amount field which is filled values less than one', () => {
            let errors = {};
            let amount;
            beforeEach(() => {
                amount = component.fundTransferOwnForm.controls['amount'];
                amount.setValue(-1);
                errors = amount.errors || {};
                fixture.detectChanges();
            });

            // Checking amount is invalid if it is incorrect
            it('should be invalid', () => {

                expect(amount.valid).toBeFalsy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required', () => {
                expect(errors['required']).toBeFalsy();

            });

            // Checking min error is present if amount is invalid
            it('should contain min error', () => {
                expect(errors['min']).toBeTruthy();

            });

        });

        describe('has amount field on recieving error object from amountValidator method of ValidatorService', () => {
            let errors = {};
            let amount;
            beforeEach(() => {
                spyOn(validatorsService, 'amountValidator').and.returnValue({ minAmount: true });
                component.createForm();
                amount = component.fundTransferOwnForm.controls['amount'];
                amount.setValue(1000);
                errors = amount.errors || {};
                fixture.detectChanges();
            });

            // Checking amount is invalid if it is incorrect
            it('should be invalid', () => {

                expect(amount.valid).toBeFalsy();

            });

            // Checking min error is present if amount is invalid
            it('should contain minAmount error', () => {
                expect(errors['minAmount']).toBeTruthy();

            });

        });

        describe('has amount field on recieving null from amountValidator method of ValidatorService', () => {
            let errors = {};
            let amount;
            beforeEach(() => {
                spyOn(validatorsService, 'amountValidator').and.returnValue(null);
                component.createForm();
                amount = component.fundTransferOwnForm.controls['amount'];
                amount.setValue(1000);
                errors = amount.errors || {};
                fixture.detectChanges();
            });

            // Checking amount is valid if it is filled
            it('should be valid', () => {

                expect(amount.valid).toBeTruthy();

            });

            // Checking minAmount error is not present if field is correct
            it('should not contain minAmount error', () => {
                expect(errors['minAmount']).toBeFalsy();

            });

        });

        describe('has fundTransferDate field which is empty', () => {
            let errors = {};
            let fundTransferDate;
            beforeEach(() => {
                fundTransferDate = component.fundTransferOwnForm.controls['fundTransferDate'];
                fundTransferDate.setValue('');
                errors = fundTransferDate.errors || {};
                fixture.detectChanges();
            });

            // Checking fundTransferDate is invalid if it is empty
            it('should be invalid', () => {

                expect(fundTransferDate.valid).toBeFalsy();

            });

            // Checking required error is present if field is empty
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has fundTransferDate field on recieving error object from checkDatePast method of ValidatorService', () => {
            let errors = {};
            let fundTransferDate;
            beforeEach(() => {
                spyOn(validatorsService, 'checkDatePast').and.returnValue({ available: true });
                component.ngOnInit();
                fundTransferDate = component.fundTransferOwnForm.controls['fundTransferDate'];
                fundTransferDate.setValue('03/25/2017');
                errors = fundTransferDate.errors || {};
                fixture.detectChanges();
            });

            // Checking fundTransferDate is invalid if it is incorrect
            it('should be invalid', () => {

                expect(fundTransferDate.valid).toBeFalsy();

            });

            // Checking min error is present if fundTransferDate is invalid
            it('should contain available error', () => {
                expect(errors['available']).toBeTruthy();

            });

        });

        describe('has fundTransferDate field on recieving null from checkDatePast method of ValidatorService', () => {
            let errors = {};
            let fundTransferDate;
            beforeEach(() => {
                spyOn(validatorsService, 'checkDatePast').and.returnValue(null);
                component.ngOnInit();
                fundTransferDate = component.fundTransferOwnForm.controls['fundTransferDate'];
                fundTransferDate.setValue('03/25/2017');
                errors = fundTransferDate.errors || {};
                fixture.detectChanges();
            });

            // Checking fundTransferDate is valid if it is filled
            it('should be valid', () => {

                expect(fundTransferDate.valid).toBeTruthy();

            });

            // Checking available error is not present if field is correct
            it('should not contain available error', () => {
                expect(errors['available']).toBeFalsy();

            });

        });

        describe('fundTransferOwnForm when all fields are valid', () => {

            let submitBtn;
            beforeEach(() => {
                submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
                component.fundTransferOwnForm.controls['fromAccountNo'].setValue('123456');
                component.fundTransferOwnForm.controls['toAccountNo'].setValue('456789');
                component.fundTransferOwnForm.controls['remarks'].setValue('Trail');
                component.fundTransferOwnForm.controls['amount'].setValue(1000);
                component.fundTransferOwnForm.controls['fundTransferDate'].setValue('03/25/2015');
                fixture.detectChanges();
            });

            // form should be valid if all feilds are filled properly
            it('should be valid', () => {

                expect(component.fundTransferOwnForm.valid).toBe(true);

            });

            // checking submit button is enabled if form is valid
            it('should has submit button enabled', () => {

                expect(submitBtn.disabled).toBe(false);

            });

            // submit function should be called on clicking the submit button
            it('should call submit function on clicking submit button', () => {

                const spy = spyOn(component, 'submit');
                submitBtn.click();
                expect(spy).toHaveBeenCalled();
            });

        });
    });


});
