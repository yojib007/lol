import { UserInformationService } from './../../shared/user-information.service';
import { SuccessMessageService } from './../../shared/success-message.service';
import { Router } from '@angular/router';
import { AccountService } from './../../shared/account.service';
import { ValidatorsService } from './../../shared/validators.service';
import { FundTransferService } from './../fund-transfer.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fund-transfer-own-account',
  templateUrl: './fund-transfer-own-account.component.html',
  styleUrls: ['./fund-transfer-own-account.component.css']
})
export class FundTransferOwnAccountComponent implements OnInit {

  accountList: string[];
  toAccountList: any;
  fundTransferOwnForm: FormGroup;
  selectedFromAccount: string;
  error: string[];
  errorMessage: string[];
  submitted: boolean;
  accountBalance: number;
  date: string;

  constructor(
    private formBuilder: FormBuilder,
    private fundTransferService: FundTransferService,
    private validatorsService: ValidatorsService,
    private router: Router,
    private accountService: AccountService,
    private userInformationService: UserInformationService,
    private successMessageService: SuccessMessageService) {
  }

  select() {
    this.toAccountList = this.accountList.filter(account => account !== this.selectedFromAccount);
  }

  balance() {

    this.validatorsService.findBalance(this.fundTransferOwnForm.value.fromAccountNo);

  }
  submit() {
    this.submitted = true;
    this.fundTransferService.transfer(this.fundTransferOwnForm.value).subscribe(
      data => {
        this.successMessageService.message = 'FUNDTRANSOWN.SUCCESS';
        this.router.navigate(['/fundtransfer']);
      },
      error => {
        this.error = error;
        this.submitted = false;
      }
    );
  }

  formatDate() {
    const d = new Date();
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    return [year, month, day].join('-');
  }

  createForm() {

    this.date = this.formatDate();
    this.fundTransferOwnForm = this.formBuilder.group({
      'fromAccountNo': ['', Validators.required],
      'toAccountNo': ['', Validators.required],
      'amount': ['', [Validators.required, Validators.min(1), this.validatorsService.amountValidator]],
      'remarks': ['', Validators.required],
      'fundTransferDate': [this.date, [Validators.required, this.validatorsService.checkDatePast]],
      'userId': [],
      'fundTransferType': ['O']
    });
  }

  getAccountNumber() {
    this.accountService.getAccountNumbers().subscribe(
      data => {
        this.accountList = data;
        this.createForm();

        if (this.accountList.length === 1) {
          this.errorMessage = [`ERRORS.FUNDTRANSOWN.SINGLEACCT`];
        }
      },
      error => this.errorMessage = error
    );
  }

  ngOnInit() {

    this.successMessageService.view = 'fund';
    this.successMessageService.subView = 'fundTrns';
    this.getAccountNumber();

  }
}
