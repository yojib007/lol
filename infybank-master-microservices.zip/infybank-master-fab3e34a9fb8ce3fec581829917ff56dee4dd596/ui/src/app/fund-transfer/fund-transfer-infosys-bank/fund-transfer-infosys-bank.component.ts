import { UserInformationService } from './../../shared/user-information.service';
import { SuccessMessageService } from './../../shared/success-message.service';
import { AccountService } from './../../shared/account.service';
import { PayeeService } from './../../shared/payee.service';
import { Payee } from './../../shared/payee';
import { Component, OnInit } from '@angular/core';
import { ValidatorsService } from './../../shared/validators.service';
import { FundTransferService } from './../fund-transfer.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';

@Component({
  selector: 'app-fund-transfer-infosys-bank',
  templateUrl: './fund-transfer-infosys-bank.component.html',
  styleUrls: ['./fund-transfer-infosys-bank.component.css']
})
export class FundTransferInfosysBankComponent implements OnInit {

  accountList: string[];
  toAccountList: Payee[];
  fundTransferOthersForm: FormGroup;
  error: string[];
  submitted: boolean;
  errorMessage: string[];
  selectedPayeeId: number;
  date: string;

  constructor(private formBuilder: FormBuilder,
    private fundTransferService: FundTransferService,
    private validatorsService: ValidatorsService,
    private route: ActivatedRoute,
    private router: Router,
    private payeeService: PayeeService,
    private userInformationService: UserInformationService,
    private successMessageService: SuccessMessageService,
    private accountService: AccountService) { }

  submit() {
    this.submitted = true;
    this.fundTransferService.transfer(this.fundTransferOthersForm.value).subscribe(
      data => {
        this.successMessageService.message = 'FUNDTRANSINFY.SUCCESS';
        this.router.navigate(['/fundtransfer']);
      },
      error => {
        this.error = error;
        this.submitted = false;
      }
    );
  }

  formatDate() {
    const d = new Date();
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    return [year, month, day].join('-');
  }

  balance() {
    this.validatorsService.findBalance(this.fundTransferOthersForm.value.fromAccountNo);
  }

  createForm() {
    this.date = this.formatDate();
    this.fundTransferOthersForm = this.formBuilder.group({
      'fromAccountNo': ['', Validators.required],
      'amount': ['', [Validators.required, Validators.min(1), this.validatorsService.amountValidator]],
      'remarks': ['', Validators.required],
      'fundTransferDate': [this.date, [Validators.required, this.validatorsService.checkDatePast]],
      'userId': [],
      'payeeId': [this.selectedPayeeId],
      'fundTransferType': ['S']
    });

  }

  getAccountNumbers() {
    this.accountService.getAccountNumbers().subscribe(
      data => {
        this.accountList = data;
        this.createForm();
      },
      error => this.errorMessage = error
    );
  }

  getPayeeList() {
    this.payeeService.viewPayee('C').subscribe(
      data => {
        this.toAccountList = data.filter(payee => payee.status === 'C');
        if (this.toAccountList.length === 0) {
          this.errorMessage = ['ERRORS.FUNDTRANSINFY.NOPAYEE'];
        } else {
          this.getAccountNumbers();
        }
      },
      error => this.errorMessage = error.message || error
    );
  }

  ngOnInit() {

    this.successMessageService.view = 'fund';
    this.successMessageService.subView = 'fundTrns';

    if (+this.route.snapshot.paramMap.get('id')) {
      this.selectedPayeeId = +this.route.snapshot.paramMap.get('id');
    }
    this.getPayeeList();
  }

}
