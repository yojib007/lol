import { FundTransferOwnAccountComponent } from './fund-transfer/fund-transfer-own-account/fund-transfer-own-account.component';
import { UpdateCreditDebitLimitComponent } from './profile/update-credit-debit-limit/update-credit-debit-limit.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { WelcomeComponent } from './welcome/welcome.component';

const appRoutes: Routes = [
  { path: 'welcome', component: WelcomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', loadChildren: 'app/login/login.module#LoginModule' },
  { path: 'account', loadChildren: 'app/account-detail/account-detail.module#AccountDetailModule'},
  { path: 'profile', loadChildren: 'app/profile/profile.module#ProfileModule' },
  { path: 'fundtransfer', loadChildren: 'app/fund-transfer/fund-transfer.module#FundTransferModule' },
  { path: 'managepayee', loadChildren: 'app/manage-payee/manage-payee.module#ManagePayeeModule' },
  { path: 'admin', loadChildren: 'app/admin/admin.module#AdminModule' },
  { path: 'loan', loadChildren: 'app/loan/loan.module#LoanModule' },
  { path: '', redirectTo: '/welcome', pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
