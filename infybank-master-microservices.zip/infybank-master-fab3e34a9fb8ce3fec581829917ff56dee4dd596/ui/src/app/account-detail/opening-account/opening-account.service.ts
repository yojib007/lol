import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { RestService } from './../../shared/rest-service';
import {Observable} from 'rxjs/Observable';
import {OpeningAccount} from './opening-account';
import { UserInformationService } from './../../shared/user-information.service';

@Injectable()
export class OpeningAccountService {

  url = '';
  constructor(private restService: RestService, private userInformationService: UserInformationService) { }

  openAccount(accDetails: OpeningAccount): Observable<boolean> {

    this.url = '/infybank/v1/customers/' + this.userInformationService.userDetail.custId + '/accounts/';
    accDetails.userId = this.userInformationService.userDetail.userId;
    return(this.restService.post(this.url, accDetails));
  }
}
