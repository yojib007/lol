import { OpeningAccountService } from './opening-account.service';
import { OpeningAccountComponent } from './opening-account.component';
import { SuccessMessageService } from './../../shared/success-message.service';
import { RouterModule, Router } from '@angular/router';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ValidatorsService } from '../../shared/validators.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

class ValidatorsServiceStub {
    isFieldHasErrors() { }
}

class OpeningAccountServiceStub {
    openAccount() { }
};

describe('OpeningAccountComponent', () => {

    const validatorsServiceStub = new ValidatorsServiceStub();
    const openingAccountServiceStub = new OpeningAccountServiceStub();
    let component: OpeningAccountComponent;
    let fixture: ComponentFixture<OpeningAccountComponent>;
    let submitBtn;
    let openingAccountService;
    let successMessageService;
    let router;

    beforeEach(async(() => {

        TestBed.configureTestingModule({
            declarations: [OpeningAccountComponent],
            imports: [ReactiveFormsModule, FormsModule, RouterTestingModule],
            providers: [
                { provide: OpeningAccountService, useValue: openingAccountServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                SuccessMessageService
            ],
        })
            .compileComponents();

    }));

    beforeEach(() => {
        router = TestBed.get(Router);
        openingAccountService = TestBed.get(OpeningAccountService);
        fixture = TestBed.createComponent(OpeningAccountComponent);
        component = fixture.componentInstance;
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
        submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;

    });

    // Checking everything is created correct or not
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking submit button is disabled till form is invalid
    it('should have submit button disabled at initialization', () => {

        expect(submitBtn.disabled).toBe(true);
    });


    describe('invoking change method', () => {

        // Checking should change the value from N to Y for salaried field
        it('should change the value of salaried field in accOpenForm from N to Y', () => {
            component.accOpenForm.value.salaried = 'N';
            component.change();
            expect(component.accOpenForm.value.salaried).toBe('Y');
        });

        // Checking should change the value from Y to N for salaried field
        it('should change the value of salaried field in accOpenForm from Y to N', () => {
            component.accOpenForm.value.salaried = 'Y';
            component.change();
            expect(component.accOpenForm.value.salaried).toBe('N');
        });
    });


    describe('has acctType field which is empty', () => {
        let errors = {};
        let acctType;
        beforeEach(() => {
            acctType = component.accOpenForm.controls['acctType'];
            acctType.setValue('');
            errors = acctType.errors || {};
            fixture.detectChanges();
        });

        // Checking acctType is invalid if it is empty
        it('should be invalid', () => {

            expect(acctType.valid).toBeFalsy();

        });

        // Checking required error is present if acctType is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has acctType field which is filled', () => {
        let errors = {};
        let acctType;
        beforeEach(() => {
            acctType = component.accOpenForm.controls['acctType'];
            acctType.setValue('Y');
            errors = acctType.errors || {};
            fixture.detectChanges();
        });

        // Checking acctType is valid if it is filled
        it('should be valid', () => {

            expect(acctType.valid).toBeTruthy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

    });

    describe('has balance field which is empty', () => {
        let errors = {};
        let balance;
        beforeEach(() => {
            balance = component.accOpenForm.controls['balance'];
            balance.setValue('');
            errors = balance.errors || {};
            fixture.detectChanges();
        });

        // Checking balance is invalid if it is empty
        it('should be invalid', () => {

            expect(balance.valid).toBeFalsy();

        });

        // Checking required error is present if balance is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has balance field which is filled with values less than one', () => {
        let errors = {};
        let balance;
        beforeEach(() => {
            balance = component.accOpenForm.controls['balance'];
            balance.setValue(0);
            errors = balance.errors || {};
            fixture.detectChanges();
        });

        // Checking balance is invalid if it is incorrect
        it('should be invalid', () => {

            expect(balance.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required error', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking min error is present if balance is less than zero
        it('should contain min error', () => {
            expect(errors['min']).toBeTruthy();

        });

    });

    describe('has balance field which is filled with value greater than zero', () => {
        let errors = {};
        let balance;
        beforeEach(() => {
            balance = component.accOpenForm.controls['balance'];
            balance.setValue(1000);
            errors = balance.errors || {};
            fixture.detectChanges();
        });

        // Checking balance is valid if it is filled
        it('should be valid', () => {

            expect(balance.valid).toBeTruthy();

        });

        // Checking required min is not present if field is correct
        it('should not contain min error', () => {
            expect(errors['min']).toBeFalsy();

        });

    });

    describe('accOpenForm when all fields are valid', () => {

        beforeEach(() => {
            component.accOpenForm.controls['acctType'].setValue('Y');
            component.accOpenForm.controls['balance'].setValue(100);
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.accOpenForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // invoke openAccount function should be called on clicking the submit button
        it('should call invoke openAccount function on clicking submit button', () => {

            const spy = spyOn(component, 'openAccount');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('invoking openAccount function', () => {

        // should call openAccount method of OpeningAccountService
        it('should call openAccount method of OpeningAccountService', () => {

            const spy = spyOn(openingAccountService, 'openAccount').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.openAccount();
            expect(spy).toHaveBeenCalled();
        });

        describe('on recieving data from openAccount method of OpeningAccountService', () => {

            let spy;
            beforeEach(() => {
                spyOn(openingAccountService, 'openAccount').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate');
                component.openAccount();
            });

            // Populate message if data is recieved from openAccount method of OpeningAccountService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/account/acctsumm']);
            });
        });

        // Populate error if error is thrown from openAccount method of OpeningAccountService
        it('should populate error if error is thrown from openAccount method of OpeningAccountService', () => {

            spyOn(openingAccountService, 'openAccount').and.returnValue(Observable.throw('Server Error'));
            component.openAccount();
            expect(component.error).toBe('Server Error');
        });
    });


});
