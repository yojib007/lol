import { OpeningAccountService } from './opening-account.service';
import { UserInformationService } from './../../shared/user-information.service';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../../shared/rest-service';
import { UserInformation } from './../../shared/user-information';
import { TestBed, inject } from '@angular/core/testing';
import {OpeningAccount} from './opening-account';

class UserInformationServiceStub {
  userDetail = new UserInformation();
}

class RestServiceStub {
  post() { }
}

describe('OpeningAccountService', () => {
  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OpeningAccountService,
        { provide: RestService, useValue: restServiceStub },
        { provide: UserInformationService, useValue: userInformationServiceStub },
      ]
    }).compileComponents();
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([OpeningAccountService], (service: OpeningAccountService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the openAccount function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([OpeningAccountService], (service: OpeningAccountService) => {

        const spy = spyOn(restService, 'post');
        service.openAccount(new OpeningAccount());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking openAccount function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([OpeningAccountService], (service: OpeningAccountService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.of(true));
        service.openAccount(new OpeningAccount()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking openAccount function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([OpeningAccountService], (service: OpeningAccountService) => {

        const spy = spyOn(restService, 'post').and.returnValue(Observable.throw('Server Error'));
        service.openAccount(new OpeningAccount()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

});
