import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'calculation'
})
export class CalculationPipe implements PipeTransform {

  transform(value: any[], args?: any): any {
    let sum = 0;
    if (args === 'accounts') {
      for (let i = 0; i < value.length; i++) {
        sum += value[i].balance;
      }
      return sum.toString();
    } else if (args === 'loans') {
      for (let i = 0; i < value.length; i++) {
        sum += value[i].loanAmount;
      }
      return sum.toString();
    }
  }

}
