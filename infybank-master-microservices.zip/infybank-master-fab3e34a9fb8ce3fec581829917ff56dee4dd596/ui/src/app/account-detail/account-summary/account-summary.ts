import { Account } from './account';
import { LoansAccount } from './loans-account';

export class AccountSummary {
    'totalAssets': number;
    'totalLiability': number;
    accounts: Account[];
    loanAccounts: LoansAccount[];
}
