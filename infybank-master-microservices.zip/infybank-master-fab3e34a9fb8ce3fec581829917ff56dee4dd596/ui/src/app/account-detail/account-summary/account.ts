export class Account {
    'acctNo': string;
    'acctType': string;
    'balance': number;
    'salaried': string;
}
