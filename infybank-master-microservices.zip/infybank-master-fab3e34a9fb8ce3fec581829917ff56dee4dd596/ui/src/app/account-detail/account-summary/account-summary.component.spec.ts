import { SuccessMessageService } from './../../shared/success-message.service';
import { CalculationPipe } from './calculation.pipe';
import { AccountSummaryComponent } from './account-summary.component';
import { UserInformationService } from './../../shared/user-information.service';
import { UserInformation } from './../../shared/user-information';
import { Profile } from './../../shared/profile';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { LoansAccount } from './../../account-detail/account-summary/loans-account';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DownloadService } from './../../shared/download.service';
import { AccountService } from './../../shared/account.service';
import { AccountSummary } from './account-summary';

class AccountServiceStub {
    accountSummary() {
        return Observable.of({
            'totalAssets': 10000,
            'totalLiability': 5000,
            accountDtoList: [{
                'acctNo': '123456',
                'acctType': 'S',
                'balance': 5000,
                'salaried': 'Y'
            }],
            loanAccountDtoList: [{
                'loanAcctNo': '12345',
                'loanAmount': 5000,
                'loanStatus': 'A'
            },
            {
                'loanAcctNo': '12345',
                'loanAmount': 5000,
                'loanStatus': 'S'
            }
            ]
        });
    }
}

class DownloadServiceStub {
    asPdf() { }
    asExcel() { }
}

class UserInformationServiceStub {
    userDetail = new UserInformation();
    profileDetail = new Profile();
}

describe('AccountSummaryComponent', () => {
    const accountServiceStub = new AccountServiceStub();
    const downloadServiceStub = new DownloadServiceStub();
    const userInformationServiceStub = new UserInformationServiceStub();
    let component: AccountSummaryComponent;
    let fixture: ComponentFixture<AccountSummaryComponent>;
    let accountService;
    let downloadService;
    let accountSummary;
    let successMessageService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule],
            declarations: [AccountSummaryComponent, CalculationPipe],
            providers: [
                { provide: AccountService, useValue: accountServiceStub },
                { provide: DownloadService, useValue: downloadServiceStub },
                { provide: UserInformationService, useValue: userInformationServiceStub },
                SuccessMessageService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AccountSummaryComponent);
        component = fixture.componentInstance;
        accountService = TestBed.get(AccountService);
        downloadService = TestBed.get(DownloadService);
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
        accountSummary = {
            'totalAssets': 10000,
            'totalLiability': 5000,
            accountDtoList: [{
                'acctNo': '123456',
                'acctType': 'S',
                'balance': 5000,
                'salaried': 'Y'
            }],
            loanAccountDtoList: [{
                'loanAcctNo': '12345',
                'loanAmount': 5000,
                'loanStatus': 'A'
            },
            {
                'loanAcctNo': '12345',
                'loanAmount': 5000,
                'loanStatus': 'S'
            }
            ]
        };
    });

    // Checking everything is created
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking message property became null after 5 secs
    it('should null the message property of SuccessMessageService after 5 secs', async(() => {
        successMessageService.message = 'success';
        component.ngOnInit();
        setTimeout(() => {
            expect(successMessageService.message).toBeFalsy();
        }, 5000);
    }));

    // Checking call should be made to accountSummary method of AccountService
    it('should invoke accountSummary method of AccountService', () => {
        const spy = spyOn(accountService, 'accountSummary').and.returnValue(Observable.of(accountSummary));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    // Checking accountSummary is populated
    it('should populate the accountSummary on recieving data from accountSummary method of AccountService', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.of(accountSummary));
        component.ngOnInit();
        expect(component.accountSummary).toBeDefined();
    });

    // Checking accountSummary is populated with loan object whose status is A from the recieved from accountSummary method
    it('should populate accountSummary with loan object whose status is A from the recieved from accountSummary method', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.of(accountSummary));
        component.ngOnInit();
        expect(component.accountSummary.loanAccountDtoList[0]).toEqual({
            'loanAcctNo': '12345',
            'loanAmount': 5000,
            'loanStatus': 'A'
        });
    });

    // Checking error is populated if error is thrown from accountSummary method of AccountService
    it('should populate error if error is thrown from accountSummary method of AccountService', () => {
        spyOn(accountService, 'accountSummary').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.error).toBe('Server Error');
    });

    // Checking for options method populating userOpiton with passed value
    it('should populate userOption with passed value on invoking options method', () => {
        component.options('Account');
        expect(component.userOption).toBe('Account');
    });

    describe('invoking downloadDetails method', () => {

        // Checking asPdf method of DownloadService has been called
        it('should call asPdf method of DownloadService is downloadStat is pdf', () => {
            component.dwnldAcctStat = 'pdf';
            const spy = spyOn(downloadService, 'asPdf');
            component.downloadDetails('table1');
            expect(spy).toHaveBeenCalled();
        });

        // Checking asExcel method of DownloadService has been called
        it('should call asExcel method of DownloadService is downloadStat is xls', () => {
            component.dwnldAcctStat = 'xls';
            const spy = spyOn(downloadService, 'asExcel');
            component.downloadDetails('table1');
            expect(spy).toHaveBeenCalled();
        });
    });

});
