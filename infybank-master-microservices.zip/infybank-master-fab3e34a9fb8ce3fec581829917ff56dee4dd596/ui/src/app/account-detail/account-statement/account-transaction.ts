export class AccountTransaction {
    'lastMonth': string;
    'startDate': string;
    'endDate': string;
    'txnType': string;
    'fromAmount': number;
    'toAmount': number;
}
