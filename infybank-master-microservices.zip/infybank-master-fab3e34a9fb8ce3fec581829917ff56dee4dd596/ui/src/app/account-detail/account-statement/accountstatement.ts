export class Accountstatement {
        'txnType': string;
        'txnDate': string;
        'remarks': string;
        'txnAmount': number;
        'txnCategory': string;
        'openingBal': number;
        'closingBal': number;
}
