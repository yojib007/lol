import { SuccessMessageService } from './../../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { ValidatorsService } from './../../shared/validators.service';
import { Accountstatement } from './accountstatement';
import { AccountStatementComponent } from './account-statement.component';
import { UserInformationService } from './../../shared/user-information.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { LoansAccount } from './../../account-detail/account-summary/loans-account';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DownloadService } from './../../shared/download.service';
import { AccountService } from './../../shared/account.service';
import { ProfileService } from './../../shared/profile.service';

class AccountServiceStub {
    getAccountNumbers() {
        return Observable.of(['1232456', '123457', '123458']);
    }
    getAccountStatement() { }
}

class DownloadServiceStub {
    asPdf() { }
    asExcel() { }
}

class ValidatorsServiceStub {
    isFieldHasErrors() { }
    checkDate() { }
    toAmountNotNull() { }
    fromAmountNotNull() { }
}

describe('AccountStatementComponent', () => {
    const accountServiceStub = new AccountServiceStub();
    const downloadServiceStub = new DownloadServiceStub();
    const validatorsServiceStub = new ValidatorsServiceStub();
    let component: AccountStatementComponent;
    let fixture: ComponentFixture<AccountStatementComponent>;
    let accountService;
    let downloadService;
    let validatorsService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule, ReactiveFormsModule],
            declarations: [AccountStatementComponent],
            providers: [
                { provide: AccountService, useValue: accountServiceStub },
                { provide: DownloadService, useValue: downloadServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                UserInformationService, SuccessMessageService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AccountStatementComponent);
        component = fixture.componentInstance;
        accountService = TestBed.get(AccountService);
        downloadService = TestBed.get(DownloadService);
        validatorsService = TestBed.get(ValidatorsService);
        fixture.detectChanges();
    });

    // Checking everything is created
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking call should be made to getAccountNumbers method of AccountService
    it('should invoke getAccountNumbers method of AccountService', () => {
        const spy = spyOn(component, 'getAccountNumbers').and.returnValue(Observable.of(['123456']));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    // Checking disable date function is invoked automatically
    it('should invoke disableDate function', () => {
        const spy = spyOn(component, 'disableDate');
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('invoking disableDate function', () => {

        beforeEach(() => {
            component.disableDate();
        });

        // Checking startDate field is disabled
        it('should disable the startDate field in form', () => {
            expect(component.accountStatementForm.controls.startDate.disabled).toBe(true);
        });

        // Checking endDate field is disabled
        it('should disable the endDate field in form', () => {
            expect(component.accountStatementForm.controls.endDate.disabled).toBe(true);
        });

        // Checking lastMonth field value is true
        it('should assign true to lastMonth field in form', () => {
            expect(component.accountStatementForm.value.lastMonth).toBe(true);
        });
    });

    describe('invoking enableDate function', () => {

        beforeEach(() => {
            component.enableDate();
        });

        // Checking startDate field is enabled
        it('should enable the startDate field in form', () => {
            expect(component.accountStatementForm.controls.startDate.enabled).toBe(true);
        });

        // Checking endDate field is enabled
        it('should enable the endDate field in form', () => {
            expect(component.accountStatementForm.controls.endDate.enabled).toBe(true);
        });

        // Checking lastMonth field value is false
        it('should assign false to lastMonth field in form', () => {
            expect(component.accountStatementForm.value.lastMonth).toBe(false);
        });
    });

    describe('invoking getAccountNumbers method', () => {

        // Checking call should be made to getAccountNumbers method of AccountService
        it('should invoke getAccountNumbers method of AccountService', () => {
            const spy = spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.of(['123456']));
            component.getAccountNumbers();
            expect(spy).toHaveBeenCalled();
        });

        // Checking accounts is populated
        it('should populate the accounts on recieving data from getAccountNumbers method of AccountService', () => {
            spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.of(['123456']));
            component.getAccountNumbers();
            expect(component.accounts).toBeDefined();
        });

        // Checking error is populated if error is thrown from getAccountNumbers method of AccountService
        it('should populate error if error is thrown from getAccountNumbers method of AccountService', () => {
            spyOn(accountService, 'getAccountNumbers').and.returnValue(Observable.throw('Server Error'));
            component.getAccountNumbers();
            expect(component.error).toBe('Server Error');
        });
    });

    describe('invoking getAccountStatement method', () => {

        // Checking call should be made to getAccountStatement method of AccountService
        it('should invoke getAccountStatement method of AccountService', () => {
            const spy = spyOn(accountService, 'getAccountStatement').and.returnValue(Observable.of([new Accountstatement()]));
            component.getAccountStatement();
            expect(spy).toHaveBeenCalled();
        });

        // Checking accountStatement is populated
        it('should populate the accounts on recieving data from getAccountStatement method of accountService', () => {
            spyOn(accountService, 'getAccountStatement').and.returnValue(Observable.of([new Accountstatement()]));
            component.getAccountStatement();
            expect(component.accountStatement).toBeDefined();
        });

        // Checking error is populated if error is thrown from getAccountStatement method of accountService
        it('should populate error if error is thrown from getAccountStatement method of accountService', () => {
            spyOn(accountService, 'getAccountStatement').and.returnValue(Observable.throw('Server Error'));
            component.getAccountStatement();
            expect(component.errorMessage).toBe('Server Error');
        });
    });

    describe('invoking downloadDetails method', () => {

        // Checking asPdf method of DownloadService has been called
        it('should call asPdf method of DownloadService is dwnldAcctStat is pdf', () => {
            component.dwnldAcctStat = 'pdf';
            const spy = spyOn(downloadService, 'asPdf');
            component.downloadDetails();
            expect(spy).toHaveBeenCalled();
        });

        // Checking asExcel method of DownloadService has been called
        it('should call asExcel method of DownloadService is dwnldAcctStat is xls', () => {
            component.dwnldAcctStat = 'xls';
            const spy = spyOn(downloadService, 'asExcel');
            component.downloadDetails();
            expect(spy).toHaveBeenCalled();
        });
    });

    describe('has accountStatementForm which', () => {

        describe('has accountNumber field which is empty', () => {
            let errors = {};
            let accountNumber;
            beforeEach(() => {
                accountNumber = component.accountStatementForm.controls['accountNumber'];
                accountNumber.setValue('');
                errors = accountNumber.errors || {};
                fixture.detectChanges();
            });

            // Checking accountNumber is invalid if it is empty
            it('should be invalid', () => {

                expect(accountNumber.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has accountNumber field which is filled', () => {
            let errors = {};
            let accountNumber;
            beforeEach(() => {
                accountNumber = component.accountStatementForm.controls['accountNumber'];
                accountNumber.setValue('123456');
                errors = accountNumber.errors || {};
                fixture.detectChanges();
            });

            // Checking accountNumber is valid if it is filled
            it('should be valid', () => {

                expect(accountNumber.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has startDate field which is empty', () => {
            let errors = {};
            let startDate;
            beforeEach(() => {
                component.enableDate();
                startDate = component.accountStatementForm.controls['startDate'];
                startDate.setValue('');
                errors = startDate.errors || {};
                fixture.detectChanges();
            });

            // Checking startDate is invalid if it is empty
            it('should be invalid', () => {

                expect(startDate.valid).toBeFalsy();

            });

            // Checking required error is present if startDate is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has startDate field on recieving error object from checkDate method of ValidatorService', () => {
            let errors = {};
            let startDate;
            beforeEach(() => {
                spyOn(validatorsService, 'checkDate').and.returnValue({ available: true });
                component.ngOnInit();
                component.enableDate();
                startDate = component.accountStatementForm.controls['startDate'];
                startDate.setValue('03/25/2017');
                errors = startDate.errors || {};
                fixture.detectChanges();
            });

            // Checking startDate is invalid if it is incorrect
            it('should be invalid', () => {

                expect(startDate.valid).toBeFalsy();

            });

            // Checking min error is present if startDate is invalid
            it('should contain available error', () => {
                expect(errors['available']).toBeTruthy();

            });

        });

        describe('has startDate field on recieving null from checkDate method of ValidatorService', () => {
            let errors = {};
            let startDate;
            beforeEach(() => {
                spyOn(validatorsService, 'checkDate').and.returnValue(null);
                component.ngOnInit();
                component.enableDate();
                startDate = component.accountStatementForm.controls['startDate'];
                startDate.setValue('03/25/2017');
                errors = startDate.errors || {};
                fixture.detectChanges();
            });

            // Checking startDate is valid if it is filled
            it('should be valid', () => {

                expect(startDate.valid).toBeTruthy();

            });

            // Checking available error is not present if field is correct
            it('should not contain available error', () => {
                expect(errors['available']).toBeFalsy();

            });

        });

        describe('has endDate field which is empty', () => {
            let errors = {};
            let endDate;
            beforeEach(() => {
                component.enableDate();
                endDate = component.accountStatementForm.controls['endDate'];
                endDate.setValue('');
                errors = endDate.errors || {};
                fixture.detectChanges();
            });

            // Checking endDate is invalid if it is empty
            it('should be invalid', () => {

                expect(endDate.valid).toBeFalsy();

            });

            // Checking required error is present if endDate is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has endDate field on recieving error object from checkDate method of ValidatorService', () => {
            let errors = {};
            let endDate;
            beforeEach(() => {
                spyOn(validatorsService, 'checkDate').and.returnValue({ available: true });
                component.ngOnInit();
                component.enableDate();
                endDate = component.accountStatementForm.controls['endDate'];
                endDate.setValue('03/25/2017');
                errors = endDate.errors || {};
                fixture.detectChanges();
            });

            // Checking endDate is invalid if it is incorrect
            it('should be invalid', () => {

                expect(endDate.valid).toBeFalsy();

            });

            // Checking min error is present if endDate is invalid
            it('should contain available error', () => {
                expect(errors['available']).toBeTruthy();

            });

        });

        describe('has endDate field on recieving null from checkDate method of ValidatorService', () => {
            let errors = {};
            let endDate;
            beforeEach(() => {
                spyOn(validatorsService, 'checkDate').and.returnValue(null);
                component.ngOnInit();
                component.enableDate();
                endDate = component.accountStatementForm.controls['endDate'];
                endDate.setValue('03/25/2017');
                errors = endDate.errors || {};
                fixture.detectChanges();
            });

            // Checking endDate is valid if it is filled
            it('should be valid', () => {

                expect(endDate.valid).toBeTruthy();

            });

            // Checking available error is not present if field is correct
            it('should not contain available error', () => {
                expect(errors['available']).toBeFalsy();

            });

        });

        describe('has toAmount field on recieving error object from toAmountNotNull method of ValidatorService', () => {
            let errors = {};
            let toAmount;
            beforeEach(() => {
                spyOn(validatorsService, 'toAmountNotNull').and.returnValue({ available: true });
                component.ngOnInit();
                toAmount = component.accountStatementForm.controls['toAmount'];
                toAmount.setValue(1000);
                errors = toAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking toAmount is invalid if it is incorrect
            it('should be invalid', () => {

                expect(toAmount.valid).toBeFalsy();

            });

            // Checking min error is present if toAmount is invalid
            it('should contain available error', () => {
                expect(errors['available']).toBeTruthy();

            });

        });

        describe('has toAmount field on recieving null from toAmountNotNull method of ValidatorService', () => {
            let errors = {};
            let toAmount;
            beforeEach(() => {
                spyOn(validatorsService, 'toAmountNotNull').and.returnValue(null);
                component.ngOnInit();
                toAmount = component.accountStatementForm.controls['toAmount'];
                toAmount.setValue(1000);
                errors = toAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking toAmount is valid if it is filled
            it('should be valid', () => {

                expect(toAmount.valid).toBeTruthy();

            });

            // Checking available error is not present if field is correct
            it('should not contain available error', () => {
                expect(errors['available']).toBeFalsy();

            });

        });

        describe('has fromAmount field on recieving error object from fromAmountNotNull method of ValidatorService', () => {
            let errors = {};
            let fromAmount;
            beforeEach(() => {
                spyOn(validatorsService, 'fromAmountNotNull').and.returnValue({ available: true });
                component.ngOnInit();
                fromAmount = component.accountStatementForm.controls['fromAmount'];
                fromAmount.setValue(1000);
                errors = fromAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking fromAmount is invalid if it is incorrect
            it('should be invalid', () => {

                expect(fromAmount.valid).toBeFalsy();

            });

            // Checking min error is present if fromAmount is invalid
            it('should contain available error', () => {
                expect(errors['available']).toBeTruthy();

            });

        });

        describe('has fromAmount field on recieving null from fromAmountNotNull method of ValidatorService', () => {
            let errors = {};
            let fromAmount;
            beforeEach(() => {
                spyOn(validatorsService, 'fromAmountNotNull').and.returnValue(null);
                component.ngOnInit();
                fromAmount = component.accountStatementForm.controls['fromAmount'];
                fromAmount.setValue(1000);
                errors = fromAmount.errors || {};
                fixture.detectChanges();
            });

            // Checking fromAmount is valid if it is filled
            it('should be valid', () => {

                expect(fromAmount.valid).toBeTruthy();

            });

            // Checking available error is not present if field is correct
            it('should not contain available error', () => {
                expect(errors['available']).toBeFalsy();

            });

        });


        describe('accountStatementForm when all fields are valid', () => {

            let submitBtn;
            beforeEach(() => {
                submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
                component.accountStatementForm.controls['accountNumber'].setValue('123456');
                component.accountStatementForm.controls['txnType'].setValue('All');
                component.accountStatementForm.controls['startDate'].setValue('03/23/2017');
                component.accountStatementForm.controls['endDate'].setValue('03/23/2017');
                component.accountStatementForm.controls['fromAmount'].setValue('1000');
                component.accountStatementForm.controls['toAmount'].setValue('10000');
                fixture.detectChanges();
            });

            // form should be valid if all feilds are filled properly
            it('should be valid', () => {

                expect(component.accountStatementForm.valid).toBe(true);

            });

            // checking submit button is enabled if form is valid
            it('should has submit button enabled', () => {

                expect(submitBtn.disabled).toBe(false);

            });

            // getAccountStatement function should be called on clicking the submit button
            it('should call getAccountStatement function on clicking submit button', () => {

                const spy = spyOn(component, 'getAccountStatement');
                submitBtn.click();
                expect(spy).toHaveBeenCalled();
            });

        });
    });
});
