import { Router } from '@angular/router';
import { SuccessMessageService } from './../../shared/success-message.service';
import { ProfileService } from './../../shared/profile.service';
import { ValidatorsService } from './../../shared/validators.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { Profile } from './../../shared/profile';

@Component({
  selector: 'app-update-date-amount',
  templateUrl: './update-date-amount.component.html',
  styleUrls: ['./update-date-amount.component.css']
})
export class UpdateDateAmountComponent implements OnInit {

  userDetails: Profile;
  error: string[];
  submit: boolean;
  errorMessage: string[];
  formatForm: FormGroup;
  constructor(private successMessageService: SuccessMessageService,
    private validatorsService: ValidatorsService,
    private profileService: ProfileService,
    private router: Router,
    private formBuilder: FormBuilder) { }

  ChangeDateAmountFormat() {
    this.submit = true;
    this.userDetails.datePref = this.formatForm.value.dateFmt;
    this.userDetails.amountPref = this.formatForm.value.amtFmt;
    this.profileService.update(this.userDetails).subscribe(
      data => {
        this.successMessageService.message = 'UPDDATEAMT.SUCCESS';
        this.router.navigate(['/profile']);
      },
      error => {
        this.error = error;
        this.submit = false;
      });
  }

  createForm() {
    this.formatForm = this.formBuilder.group({
      dateFmt: ['', Validators.required],
      amtFmt: ['', Validators.required]
    });
  }

  getUserDetails() {
    this.profileService.getUserDetails().subscribe(
      user => {
        this.userDetails = user;
        this.createForm();
      },
      error => this.errorMessage = error
    );
  }

  ngOnInit() {

    this.successMessageService.view = 'profile';
    this.getUserDetails();
  }

}
