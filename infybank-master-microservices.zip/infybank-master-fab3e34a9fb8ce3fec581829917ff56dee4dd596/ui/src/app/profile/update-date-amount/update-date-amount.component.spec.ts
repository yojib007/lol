import { SuccessMessageService } from './../../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { UpdateDateAmountComponent } from './update-date-amount.component';
import { ValidatorsService } from './../../shared/validators.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfileService } from './../../shared/profile.service';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Profile } from './../../shared/profile';
import { Router } from '@angular/router';

class ProfileServiceStub {
    getUserDetails() {
        return Observable.of(new Profile());
    }
    update() { }
}

class ValidatorsServiceStub {
    isFieldHasErrors() {
    }
}

describe('UpdateDateAmountComponent', () => {

    let component: UpdateDateAmountComponent;
    let fixture: ComponentFixture<UpdateDateAmountComponent>;
    const profileServiceStub = new ProfileServiceStub();
    const validatorsServiceStub = new ValidatorsServiceStub();
    let profileService;
    let submitBtn;
    let router;
    let successMessageService;

    beforeEach(async () => {
        TestBed.configureTestingModule({
            declarations: [UpdateDateAmountComponent],
            imports: [FormsModule, ReactiveFormsModule, RouterTestingModule],
            providers: [
                { provide: ProfileService, useValue: profileServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                SuccessMessageService
            ]
        }).compileComponents();
        profileService = TestBed.get(ProfileService);
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(UpdateDateAmountComponent);
        component = fixture.componentInstance;
        profileService = TestBed.get(ProfileService);
        router = TestBed.get(Router);
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
        submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
    });

    // Checking everything is created correct or not
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking getUserDetails method of ProfileService is called when the component is created
    it('should call getUserDetails method of ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(true));
        spyOn(router, 'navigate');
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    // Checking userDetails is populated if data is recieved from ProfileSerivce
    it('should populate userDetails if data is recieved from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(true));
        component.ngOnInit();
        expect(component.userDetails).toBe(true);
    });

    // Checking errorMessage is populated if error is thrown from ProfileSerivce
    it('should populate userDetails if data is recieved from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.errorMessage).toBe('Server Error');
    });

    it('should have submit button disabled if form is invalid', () => {

        expect(submitBtn.disabled).toBeTruthy();

    });

    describe('has dateFmt field which is empty', () => {
        let errors = {};
        let dateFmt;
        beforeEach(() => {
            dateFmt = component.formatForm.controls['dateFmt'];
            dateFmt.setValue('');
            errors = dateFmt.errors || {};
            fixture.detectChanges();
        });

        // Checking dateFmt is invalid if it is empty
        it('should be invalid', () => {

            expect(dateFmt.valid).toBeFalsy();

        });

        // Checking required error is present if dateFmt is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has dateFmt field which is filled', () => {
        let errors = {};
        let dateFmt;
        beforeEach(() => {
            dateFmt = component.formatForm.controls['dateFmt'];
            dateFmt.setValue('MM,dd,yyyy');
            errors = dateFmt.errors || {};
            fixture.detectChanges();
        });

        // Checking dateFmt is valid if it is filled
        it('should be valid', () => {

            expect(dateFmt.valid).toBeTruthy();

        });

    });

    describe('has amtFmt field which is empty', () => {
        let errors = {};
        let amtFmt;
        beforeEach(() => {
            amtFmt = component.formatForm.controls['amtFmt'];
            amtFmt.setValue('');
            errors = amtFmt.errors || {};
            fixture.detectChanges();
        });

        // Checking dateFmt is invalid if it is empty
        it('should be invalid', () => {

            expect(amtFmt.valid).toBeFalsy();

        });

        // Checking required error is present if dateFmt is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has amtFmt field which is filled', () => {
        let errors = {};
        let amtFmt;
        beforeEach(() => {
            amtFmt = component.formatForm.controls['amtFmt'];
            amtFmt.setValue('million');
            errors = amtFmt.errors || {};
            fixture.detectChanges();
        });

        // Checking amtFmt is valid if it is filled
        it('should be valid', () => {

            expect(amtFmt.valid).toBeTruthy();

        });

    });

    describe('formatForm when all fields are valid', () => {

        beforeEach(() => {
            component.formatForm.controls['dateFmt'].setValue('MM,dd,yyyy');
            component.formatForm.controls['amtFmt'].setValue('million');
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.formatForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // invokeUserService function should be called on clicking the submit button
        it('should call ChangeDateAmountFormat function on clicking submit button', () => {

            const spy = spyOn(component, 'ChangeDateAmountFormat');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('invoking ChangeDateAmountFormat function', () => {

        // should call update method of ProfileService
        it('should call update method of ProfileService', () => {

            const spy = spyOn(profileService, 'update').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate').and.returnValue(null);
            component.ChangeDateAmountFormat();
            expect(spy).toHaveBeenCalledWith(component.userDetails);
        });

        describe('on recieving data from update method of ProfileService', () => {

            let spy;
            beforeEach(() => {
                spyOn(profileService, 'update').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate').and.returnValue(null);
                component.ChangeDateAmountFormat();
            });

            // Populate message if data is recieved from update method of ProfileService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/profile']);
            });
        });

        // Populate error if error is thrown from update method of ProfileService
        it('should populate error if error is thrown from update method of ProfileService', () => {

            spyOn(profileService, 'update').and.returnValue(Observable.throw('Server Error'));
            component.ChangeDateAmountFormat();
            expect(component.error).toBe('Server Error');
        });
    });
});
