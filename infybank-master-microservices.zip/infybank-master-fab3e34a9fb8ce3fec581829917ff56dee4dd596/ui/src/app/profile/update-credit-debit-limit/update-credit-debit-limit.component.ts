import { Router } from '@angular/router';
import { SuccessMessageService } from './../../shared/success-message.service';
import { ProfileService } from './../../shared/profile.service';
import { ValidatorsService } from './../../shared/validators.service';
import { Profile } from './../../shared/profile';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-credit-debit-limit',
  templateUrl: './update-credit-debit-limit.component.html',
  styleUrls: ['./update-credit-debit-limit.component.css']
})
export class UpdateCreditDebitLimitComponent implements OnInit {

  userDetails: Profile;
  errorMessage: string[];
  error: string[];
  submit: boolean;
  newCreditDebitLimit: number;
  valid = false;
  creditDebitLimitForm: FormGroup;
  constructor(private validatorsService: ValidatorsService, private profileService: ProfileService,
    private formBuilder: FormBuilder, private successMessageService: SuccessMessageService,
    private router: Router) { }

  changeCreditDebitLimit() {
    this.submit = true;
    this.userDetails.creditDebitLimit = this.newCreditDebitLimit;
    this.profileService.update(this.userDetails).subscribe(
      data => {
        this.successMessageService.message = 'UPDCRDBLIMIT.SUCCESS';
        this.router.navigate(['/profile']);
      },
      error => {
        this.error = error;
        this.submit = false;
      }
    );
  }

  getUserDetails() {
    this.profileService.getUserDetails().subscribe(
      user => {
        this.userDetails = user;
        this.createForm();
      },
      error => this.errorMessage = error
    );
  }

  createForm() {
    this.creditDebitLimitForm = this.formBuilder.group({
      creditDebitLimit: ['', [Validators.required, Validators.pattern('[1-9][0-9]*')]]
    });
  }

  ngOnInit() {
    this.successMessageService.view = 'profile';
    this.getUserDetails();
  }

}
