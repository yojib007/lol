import { SuccessMessageService } from './../../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { UpdateCreditDebitLimitComponent } from './update-credit-debit-limit.component';
import { ValidatorsService } from './../../shared/validators.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfileService } from './../../shared/profile.service';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Profile } from './../../shared/profile';
import { Router } from '@angular/router';

class ProfileServiceStub {
    getUserDetails() {
        return Observable.of(new Profile());
    }
    update() { }
}

class ValidatorsServiceStub {
    isFieldHasErrors() {
    }
}

describe('UpdateCreditDebitLimitComponent', () => {

    let component: UpdateCreditDebitLimitComponent;
    let fixture: ComponentFixture<UpdateCreditDebitLimitComponent>;
    const profileServiceStub = new ProfileServiceStub();
    const validatorsServiceStub = new ValidatorsServiceStub();
    let profileService;
    let submitBtn;
    let router;
    let successMessageService;

    beforeEach(async () => {
        TestBed.configureTestingModule({
            declarations: [UpdateCreditDebitLimitComponent],
            imports: [FormsModule, ReactiveFormsModule, RouterTestingModule],
            providers: [
                { provide: ProfileService, useValue: profileServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                SuccessMessageService
            ]
        }).compileComponents();
        profileService = TestBed.get(ProfileService);
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(UpdateCreditDebitLimitComponent);
        component = fixture.componentInstance;
        profileService = TestBed.get(ProfileService);
        router = TestBed.get(Router);
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
        submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
    });

    // Checking everything is created correct or not
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking getUserDetails method of ProfileService is called when the component is created
    it('should call getUserDetails method of ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(true));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    // Checking userDetails is populated if data is recieved from ProfileSerivce
    it('should populate userDetails if data is recieved from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(true));
        component.ngOnInit();
        expect(component.userDetails).toBe(true);
    });

    // Checking errorMessage is populated if error is thrown from ProfileSerivce
    it('should populate userDetails if data is recieved from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.errorMessage).toBe('Server Error');
    });

    it('should have submit button disabled if form is invalid', () => {

        expect(submitBtn.disabled).toBeTruthy();

    });

    describe('has creditDebitLimit field which is empty', () => {
        let errors = {};
        let creditDebitLimit;
        beforeEach(() => {
            creditDebitLimit = component.creditDebitLimitForm.controls['creditDebitLimit'];
            creditDebitLimit.setValue('');
            errors = creditDebitLimit.errors || {};
            fixture.detectChanges();
        });

        // Checking creditDebitLimit is invalid if it is empty
        it('should be invalid', () => {

            expect(creditDebitLimit.valid).toBeFalsy();

        });

        // Checking required error is present if creditDebitLimit is not entered
        it('should contain required error', () => {
            expect(errors['required']).toBeTruthy();

        });

    });

    describe('has creditDebitLimit field which is filled non numerical', () => {
        let errors = {};
        let creditDebitLimit;
        beforeEach(() => {
            creditDebitLimit = component.creditDebitLimitForm.controls['creditDebitLimit'];
            creditDebitLimit.setValue('abc400');
            errors = creditDebitLimit.errors || {};
            fixture.detectChanges();
        });

        // Checking creditDebitLimit is invalid if it is incorrect
        it('should be invalid', () => {

            expect(creditDebitLimit.valid).toBeFalsy();

        });

        // Checking required error is not present if field is filled
        it('should not contain required', () => {
            expect(errors['required']).toBeFalsy();

        });

        // Checking pattern error is present if creditDebitLimit is invalid
        it('should contain pattern error', () => {
            expect(errors['pattern']).toBeTruthy();

        });

    });

    describe('has creditDebitLimit field which is filled with numerical values', () => {
        let errors = {};
        let creditDebitLimit;
        beforeEach(() => {
            creditDebitLimit = component.creditDebitLimitForm.controls['creditDebitLimit'];
            creditDebitLimit.setValue(123456);
            errors = creditDebitLimit.errors || {};
            fixture.detectChanges();
        });

        // Checking creditDebitLimit is valid if it is filled
        it('should be valid', () => {

            expect(creditDebitLimit.valid).toBeTruthy();

        });

        // Checking required error is not present if field is correct
        it('should not contain pattern error', () => {
            expect(errors['pattern']).toBeFalsy();

        });

    });

    describe('creditDebitLimitForm when all fields are valid', () => {

        beforeEach(() => {
            component.creditDebitLimitForm.controls['creditDebitLimit'].setValue(1000);
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.creditDebitLimitForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // invokeUserService function should be called on clicking the submit button
        it('should call changeCreditDebitLimit function on clicking submit button', () => {

            const spy = spyOn(component, 'changeCreditDebitLimit');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('invoking changeCreditDebitLimit function', () => {

        // should call update method of ProfileService
        it('should call update method of ProfileService', () => {

            const spy = spyOn(profileService, 'update').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.changeCreditDebitLimit();
            expect(spy).toHaveBeenCalledWith(component.userDetails);
        });

        describe('on recieving data from update method of ProfileService', () => {

            let spy;
            beforeEach(() => {
                spyOn(profileService, 'update').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate').and.returnValue(null);
                component.changeCreditDebitLimit();
            });

            // Populate message if data is recieved from update method of ProfileService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/profile']);
            });
        });

        // Populate error if error is thrown from update method of ProfileService
        it('should populate error if error is thrown from update method of ProfileService', () => {

            spyOn(profileService, 'update').and.returnValue(Observable.throw('Server Error'));
            component.changeCreditDebitLimit();
            expect(component.error).toBe('Server Error');
        });
    });
});
