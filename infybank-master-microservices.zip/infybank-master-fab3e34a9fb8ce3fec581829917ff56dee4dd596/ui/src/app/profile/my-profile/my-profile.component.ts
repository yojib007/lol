import { UserInformationService } from './../../shared/user-information.service';
import { SuccessMessageService } from './../../shared/success-message.service';
import { ProfileService } from './../../shared/profile.service';
import { Profile } from './../../shared/profile';

import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  userDetails: Profile;
  errorMessage: string[];

  constructor(private profileService: ProfileService, private userInformationService: UserInformationService,
    private successMessageService: SuccessMessageService) { }

  getUserDetails() {
    this.profileService.getUserDetails().subscribe(
      user => {
        this.userDetails = user;
        this.userInformationService.profileDetail = user;
      },
      error => this.errorMessage = error
    );
  }
  ngOnInit() {
    this.successMessageService.view = 'profile';
    this.successMessageService.subView = '';
    this.getUserDetails();
    if (this.successMessageService.message) {
      setTimeout(() => {
        this.successMessageService.message = null;
      }, 5000);
    }

  }

}
