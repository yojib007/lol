import { UserInformationService } from './../../shared/user-information.service';
import { SuccessMessageService } from './../../shared/success-message.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProfileService } from './../../shared/profile.service';
import { Profile } from './../../shared/profile';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MyProfileComponent } from './my-profile.component';

class ProfileServiceStub {
    getUserDetails() {
        return Observable.of(new Profile());
    }
}

describe('MyProfileComponent', () => {

    let component: MyProfileComponent;
    let fixture: ComponentFixture<MyProfileComponent>;
    const profileServiceStub = new ProfileServiceStub();
    let profileService;
    let successMessageService;

    beforeEach(async () => {
        TestBed.configureTestingModule({
            declarations: [MyProfileComponent],
            imports: [FormsModule, RouterModule, RouterTestingModule],
            providers: [{ provide: ProfileService, useValue: profileServiceStub },
                SuccessMessageService, UserInformationService
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(MyProfileComponent);
        component = fixture.componentInstance;
        profileService = TestBed.get(ProfileService);
        successMessageService = TestBed.get(SuccessMessageService);
        fixture.detectChanges();
    });

    // Checking everything is created correct or not
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking getUserDetails method of ProfileService is called when the component is created
    it('should call getUserDetails method of ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(true));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    // Checking userDetails is populated if data is recieved from ProfileSerivce
    it('should populate userDetails if data is recieved from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(true));
        component.ngOnInit();
        expect(component.userDetails).toBe(true);
    });

    // Checking errorMessage is populated if error is thrown from ProfileSerivce
    it('should populate errorMessage if error is thrown from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.errorMessage).toBe('Server Error');
    });

    // Checking message property became null after 5 secs
    it('should null the message property of SuccessMessageService after 5 secs', () => {
        successMessageService.message = 'success';
        component.ngOnInit();
        setTimeout(() => {
            expect(successMessageService.message).toBeNull();
        }, 5000);
    });
});
