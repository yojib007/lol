import { SuccessMessageService } from './../../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { ValidatorsService } from './../../shared/validators.service';
import { UpdateAddressComponent } from './update-address.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfileService } from './../../shared/profile.service';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Profile } from './../../shared/profile';
import { Router } from '@angular/router';

class ProfileServiceStub {
    getUserDetails() {
        return Observable.of(new Profile());
    }
    update() { }
}

class ValidatorsServiceStub {
    isFieldHasErrors() {
    }
}

describe('UpdateAddressComponent', () => {

    let component: UpdateAddressComponent;
    let fixture: ComponentFixture<UpdateAddressComponent>;
    const profileServiceStub = new ProfileServiceStub();
    const validatorsServiceStub = new ValidatorsServiceStub();
    let profileService;
    let submitBtn;
    let successMessageService;
    let router;
    let profile;

    beforeEach(async () => {
        TestBed.configureTestingModule({
            declarations: [UpdateAddressComponent],
            imports: [FormsModule, ReactiveFormsModule, RouterTestingModule],
            providers: [
                { provide: ProfileService, useValue: profileServiceStub },
                { provide: ValidatorsService, useValue: validatorsServiceStub },
                SuccessMessageService
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(UpdateAddressComponent);
        component = fixture.componentInstance;
        profileService = TestBed.get(ProfileService);
        successMessageService = TestBed.get(SuccessMessageService);
        router = TestBed.get(Router);
        fixture.detectChanges();
        submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
        profile = {
            'custId': 1,
            'firstName': 'Kalpana',
            'lastName': 'Kalpana',
            'aadharId': '123456789012',
            'email': 'Kalpana@infosys.com',
            'address': 'Infosys',
            'city': 'Bangalore',
            'state': 'Karnataka',
            'pinCode': 560100,
            'creditDebitLimit': 1000,
            'amountPref': 'lakh',
            'datePref': 'dd/MM/yy',
        };
    });

    // Checking everything is created correct or not
    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    // Checking getUserDetails method of ProfileService is called when the component is created
    it('should call getUserDetails method of ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(new Profile()));
        component.ngOnInit();
        expect(spy).toHaveBeenCalled();
    });

    describe('on recieving data from ProfileService', () => {
        let spy;
        beforeEach(() => {
            spyOn(profileService, 'getUserDetails').and.returnValue(Observable.of(profile));
            spy = spyOn(component, 'createForm');
            component.ngOnInit();
        });

        // Checking userDetails is populated if data is recieved from ProfileSerivce
        it('should populate userDetails if data is recieved from ProfileService', () => {

            expect(component.userDetails).toBeDefined();
        });

        // Should create form
        it('should call createForm function', () => {
            expect(spy).toHaveBeenCalled();
        });
    });

    // Form should be created
    it('should create form if createForm function is invoked', () => {
        component.addressForm = undefined;
        component.createForm();
        expect(component.addressForm).toBeDefined();
    });

    // Checking errorMessage is populated if error is thrown from ProfileSerivce
    it('should populate userDetails if data is recieved from ProfileService', () => {
        const spy = spyOn(profileService, 'getUserDetails').and.returnValue(Observable.throw('Server Error'));
        component.ngOnInit();
        expect(component.errorMessage).toBe('Server Error');
    });

    // Checking submit button is disabled till form is invalid
    it('should has submit button disabled at initialization', () => {

        expect(submitBtn.disabled).toBe(true);
    });

    describe('have addressForm which', () => {
        beforeEach(() => {
            component.userDetails = profile;
            component.createForm();
            fixture.detectChanges();
        });
        describe('has address field which is empty', () => {
            let errors = {};
            let address;
            beforeEach(() => {
                address = component.addressForm.controls['address'];
                address.setValue('');
                errors = address.errors || {};
                fixture.detectChanges();
            });

            // Checking address is invalid if it is empty
            it('should be invalid', () => {

                expect(address.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has address field which is filled', () => {
            let errors = {};
            let address;
            beforeEach(() => {
                address = component.addressForm.controls['address'];
                address.setValue('Infosys Limited');
                errors = address.errors || {};
                fixture.detectChanges();
            });

            // Checking address is valid if it is filled
            it('should be valid', () => {

                expect(address.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has state field which is empty', () => {
            let errors = {};
            let state;
            beforeEach(() => {
                state = component.addressForm.controls['state'];
                state.setValue('');
                errors = state.errors || {};
                fixture.detectChanges();
            });

            // Checking state is invalid if it is empty
            it('should be invalid', () => {

                expect(state.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has state field which is filled', () => {
            let errors = {};
            let state;
            beforeEach(() => {
                state = component.addressForm.controls['state'];
                state.setValue('Karnataka');
                errors = state.errors || {};
                fixture.detectChanges();
            });

            // Checking state is valid if it is filled
            it('should be valid', () => {

                expect(state.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has city field which is empty', () => {
            let errors = {};
            let city;
            beforeEach(() => {
                city = component.addressForm.controls['city'];
                city.setValue('');
                errors = city.errors || {};
                fixture.detectChanges();
            });

            // Checking city is invalid if it is empty
            it('should be invalid', () => {

                expect(city.valid).toBeFalsy();

            });

            // Checking required error is present if field is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has city field which is filled', () => {
            let errors = {};
            let city;
            beforeEach(() => {
                city = component.addressForm.controls['city'];
                city.setValue('Bangalore');
                errors = city.errors || {};
                fixture.detectChanges();
            });

            // Checking city is valid if it is filled
            it('should be valid', () => {

                expect(city.valid).toBeTruthy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required error', () => {
                expect(errors['required']).toBeFalsy();

            });

        });

        describe('has pinCode field which is empty', () => {
            let errors = {};
            let pinCode;
            beforeEach(() => {
                pinCode = component.addressForm.controls['pinCode'];
                pinCode.setValue('');
                errors = pinCode.errors || {};
                fixture.detectChanges();
            });

            // Checking pinCode is invalid if it is empty
            it('should be invalid', () => {

                expect(pinCode.valid).toBeFalsy();

            });

            // Checking required error is present if pinCode is not entered
            it('should contain required error', () => {
                expect(errors['required']).toBeTruthy();

            });

        });

        describe('has pinCode field which is filled values not matching the pattern [1-9][0-9]{5}', () => {
            let errors = {};
            let pinCode;
            beforeEach(() => {
                pinCode = component.addressForm.controls['pinCode'];
                pinCode.setValue(1235642);
                errors = pinCode.errors || {};
                fixture.detectChanges();
            });

            // Checking pinCode is invalid if it is incorrect
            it('should be invalid', () => {

                expect(pinCode.valid).toBeFalsy();

            });

            // Checking required error is not present if field is filled
            it('should not contain required', () => {
                expect(errors['required']).toBeFalsy();

            });

            // Checking pattern error is present if pinCode is invalid
            it('should contain pattern error', () => {
                expect(errors['pattern']).toBeTruthy();

            });

        });

        describe('has pinCode field which is filled values matching the pattern [1-9][0-9]{5}', () => {
            let errors = {};
            let pinCode;
            beforeEach(() => {
                pinCode = component.addressForm.controls['pinCode'];
                pinCode.setValue(123456);
                errors = pinCode.errors || {};
                fixture.detectChanges();
            });

            // Checking pinCode is valid if it is filled
            it('should be valid', () => {

                expect(pinCode.valid).toBeTruthy();

            });

            // Checking required error is not present if field is correct
            it('should not contain pattern error', () => {
                expect(errors['pattern']).toBeFalsy();

            });

        });

    });



    describe('addressForm when all fields are valid', () => {

        beforeEach(() => {
            component.addressForm.controls['address'].setValue('Infosys');
            component.addressForm.controls['state'].setValue('Bangalore');
            component.addressForm.controls['city'].setValue('Karnataka');
            component.addressForm.controls['pinCode'].setValue(123456);
            fixture.detectChanges();
        });

        // form should be valid if all feilds are filled properly
        it('should be valid', () => {

            expect(component.addressForm.valid).toBe(true);

        });

        // checking submit button is enabled if form is valid
        it('should has submit button enabled', () => {

            expect(submitBtn.disabled).toBe(false);

        });

        // changeAddress function should be called on clicking the submit button
        it('should call changeAddress function on clicking submit button', () => {

            const spy = spyOn(component, 'changeAddress');
            submitBtn.click();
            expect(spy).toHaveBeenCalled();
        });

    });

    describe('invoking changeAddress function', () => {

        // should call update method of ProfileService
        it('should call update method of ProfileService', () => {

            const spy = spyOn(profileService, 'update').and.returnValue(Observable.of(true));
            spyOn(router, 'navigate');
            component.changeAddress();
            expect(spy).toHaveBeenCalledWith(component.userDetails);
        });

        describe('on recieving data from update method of ProfileService', () => {

            let spy;
            beforeEach(() => {
                spyOn(profileService, 'update').and.returnValue(Observable.of(true));
                spy = spyOn(router, 'navigate');
                component.changeAddress();
            });

            // Populate message if data is recieved from update method of ProfileService
            it('should populate message property of SuccessMessageService', () => {

                expect(successMessageService.message).toBeDefined();
            });

            // Call the router
            it('should call the router', () => {

                expect(spy).toHaveBeenCalledWith(['/profile']);
            });
        });

        // Populate error if error is thrown from update method of ProfileService
        it('should populate error if error is thrown from update method of ProfileService', () => {

            spyOn(profileService, 'update').and.returnValue(Observable.throw('Server Error'));
            component.changeAddress();
            expect(component.error).toBe('Server Error');
        });
    });
});
