import { ViewLoanService } from './view-loan.service';

import { ViewEditLoanRateService } from './view-edit-loan-rate/view-edit-loan-rate.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AccountConfigService } from './account-config.service';
import { AdminRoutingModule } from './admin.routing.module';
import { AccountConfigComponent } from './account-config/account-config.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditAccountConfigComponent } from './edit-account-config/edit-account-config.component';
import { ViewEditLoanRateComponent } from './view-edit-loan-rate/view-edit-loan-rate.component';
import { ViewLoanComponent } from './view-loan/view-loan.component';
import { ApproveLoanComponent } from './approve-loan/approve-loan.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule, AdminRoutingModule, ReactiveFormsModule, FormsModule, TranslateModule
  ],
  declarations: [AccountConfigComponent, EditAccountConfigComponent, ViewEditLoanRateComponent, ViewLoanComponent, ApproveLoanComponent],
  providers: [AccountConfigService, ViewEditLoanRateService, ViewLoanService]
})
export class AdminModule { }
