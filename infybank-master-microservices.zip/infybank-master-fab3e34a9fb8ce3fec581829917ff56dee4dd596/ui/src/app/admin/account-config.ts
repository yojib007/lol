export class AccountConfig {
    'acctType': string;
    'interestRate': number;
    'minBalance': number;
}
