import { SuccessMessageService } from './../../shared/success-message.service';
import { By } from '@angular/platform-browser';
import { ValidatorsService } from './../../shared/validators.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditAccountConfigComponent } from './edit-account-config.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import { AccountConfigService } from './../account-config.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AccountConfig } from './../account-config';
import { Router } from '@angular/router';

class AccountConfigServiceStub {
  getAccountConfig() {
    return Observable.of([new AccountConfig(), new AccountConfig()]);
  }
  editAccountConfig() { }
}

class ValidatorsServiceStub {
  isFieldHasErrors() { }
}

describe('EditAccountConfigComponent', () => {
  let component: EditAccountConfigComponent;
  let fixture: ComponentFixture<EditAccountConfigComponent>;
  const accountConfigServiceStub = new AccountConfigServiceStub();
  const validatorsServiceStub = new ValidatorsServiceStub();
  let accountConfigService;
  let submitBtn;
  let router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, FormsModule, ReactiveFormsModule],
      declarations: [EditAccountConfigComponent],
      providers: [
        { provide: AccountConfigService, useValue: accountConfigServiceStub },
        { provide: ValidatorsService, useValue: validatorsServiceStub },
        SuccessMessageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    accountConfigService = TestBed.get(AccountConfigService);
    router = TestBed.get(Router);
    fixture = TestBed.createComponent(EditAccountConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    submitBtn = fixture.debugElement.query(By.css('#submit')).nativeElement;
  });

  // Checking everything is created successfully
  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  // Checking getAccountConfig method of accountConfigService is called when the component is created
  it('should call getAccountConfig method of accountConfigService', () => {
    const spy = spyOn(accountConfigService, 'getAccountConfig').and.returnValue(Observable.of(true));
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  // Checking userDetails is populated if data is recieved from ProfileSerivce
  it('should populate userDetails if data is recieved from accountConfigService', () => {
    const spy = spyOn(accountConfigService, 'getAccountConfig').and.returnValue(Observable.of(true));
    component.ngOnInit();
    expect(component.accountConfigDetails).toBe(true);
  });

  // Checking error is populated if error is thrown from ProfileSerivce
  it('should populate userDetails if data is recieved from accountConfigService', () => {
    const spy = spyOn(accountConfigService, 'getAccountConfig').and.returnValue(Observable.throw('Server Error'));
    component.ngOnInit();
    expect(component.error).toBe('Server Error');
  });

  describe('has interest field which is empty', () => {
    let errors = {};
    let interest;
    beforeEach(() => {
      interest = component.accountConfigFormCredit.controls['interest'];
      interest.setValue('');
      errors = interest.errors || {};
      fixture.detectChanges();
    });

    // Checking interest is invalid if it is empty
    it('should be invalid', () => {

      expect(interest.valid).toBeFalsy();

    });

    // Checking required error is present if interest is not entered
    it('should contain required error', () => {
      expect(errors['required']).toBeTruthy();

    });

  });

  describe('has interest field which is filled', () => {
    let errors = {};
    let interest;
    beforeEach(() => {
      interest = component.accountConfigFormCredit.controls['interest'];
      interest.setValue(8);
      errors = interest.errors || {};
      fixture.detectChanges();
    });

    // Checking interest is valid if it is filled
    it('should be valid', () => {

      expect(interest.valid).toBeTruthy();

    });

  });

  describe('has minBalance field which is empty', () => {
    let errors = {};
    let minBalance;
    beforeEach(() => {
      minBalance = component.accountConfigFormCredit.controls['minBalance'];
      minBalance.setValue('');
      errors = minBalance.errors || {};
      fixture.detectChanges();
    });

    // Checking interest is invalid if it is empty
    it('should be invalid', () => {

      expect(minBalance.valid).toBeFalsy();

    });

    // Checking required error is present if interest is not entered
    it('should contain required error', () => {
      expect(errors['required']).toBeTruthy();

    });

  });

  describe('has minBalance field which is filled', () => {
    let errors = {};
    let minBalance;
    beforeEach(() => {
      minBalance = component.accountConfigFormCredit.controls['minBalance'];
      minBalance.setValue(1000);
      errors = minBalance.errors || {};
      fixture.detectChanges();
    });

    // Checking minBalance is valid if it is filled
    it('should be valid', () => {

      expect(minBalance.valid).toBeTruthy();

    });

  });

  describe('accountConfigFormCredit when all fields are valid', () => {

    beforeEach(() => {
      component.accountConfigFormCredit.controls['interest'].setValue(8);
      component.accountConfigFormCredit.controls['minBalance'].setValue(1000);
      fixture.detectChanges();
    });

    // form should be valid if all feilds are filled properly
    it('should be valid', () => {

      expect(component.accountConfigFormCredit.valid).toBe(true);

    });

    // checking submit button is enabled if form is valid
    it('should has submit button enabled', () => {

      expect(submitBtn.disabled).toBe(false);

    });

    // submit function should be called on clicking the submit button
    it('should call submit function on clicking submit button', () => {

      const spy = spyOn(component, 'submit');
      submitBtn.click();
      expect(spy).toHaveBeenCalled();
    });

  });

  describe('has interest field which is empty', () => {
    let errors = {};
    let interest;
    beforeEach(() => {
      interest = component.accountConfigFormSaving.controls['interest'];
      interest.setValue('');
      errors = interest.errors || {};
      fixture.detectChanges();
    });

    // Checking interest is invalid if it is empty
    it('should be invalid', () => {

      expect(interest.valid).toBeFalsy();

    });

    // Checking required error is present if interest is not entered
    it('should contain required error', () => {
      expect(errors['required']).toBeTruthy();

    });

  });

  describe('has interest field which is filled', () => {
    let errors = {};
    let interest;
    beforeEach(() => {
      interest = component.accountConfigFormSaving.controls['interest'];
      interest.setValue(8);
      errors = interest.errors || {};
      fixture.detectChanges();
    });

    // Checking interest is valid if it is filled
    it('should be valid', () => {

      expect(interest.valid).toBeTruthy();

    });

  });

  describe('has minBalance field which is empty', () => {
    let errors = {};
    let minBalance;
    beforeEach(() => {
      minBalance = component.accountConfigFormSaving.controls['minBalance'];
      minBalance.setValue('');
      errors = minBalance.errors || {};
      fixture.detectChanges();
    });

    // Checking interest is invalid if it is empty
    it('should be invalid', () => {

      expect(minBalance.valid).toBeFalsy();

    });

    // Checking required error is present if interest is not entered
    it('should contain required error', () => {
      expect(errors['required']).toBeTruthy();

    });

  });

  describe('has minBalance field which is filled', () => {
    let errors = {};
    let minBalance;
    beforeEach(() => {
      minBalance = component.accountConfigFormSaving.controls['minBalance'];
      minBalance.setValue(1000);
      errors = minBalance.errors || {};
      fixture.detectChanges();
    });

    // Checking minBalance is valid if it is filled
    it('should be valid', () => {

      expect(minBalance.valid).toBeTruthy();

    });

  });

  describe('accountConfigFormSaving when all fields are valid', () => {

    beforeEach(() => {
      component.accountConfigFormSaving.controls['interest'].setValue(8);
      component.accountConfigFormSaving.controls['minBalance'].setValue(1000);
      fixture.detectChanges();
    });

    // form should be valid if all feilds are filled properly
    it('should be valid', () => {

      expect(component.accountConfigFormSaving.valid).toBe(true);

    });

    // checking submit button is enabled if form is valid
    it('should has submit button enabled', () => {

      expect(submitBtn.disabled).toBe(false);

    });

    // invokeUserService function should be called on clicking the submit button
    it('should call submit function on clicking submit button', () => {

      const spy = spyOn(component, 'submit');
      submitBtn.click();
      expect(spy).toHaveBeenCalled();
    });

  });

  describe('invoking submit function', () => {

    // should call editAccountConfig method of AccountConfigServiceStub
    it('should call editAccountConfig method of AccountConfigServiceStub', () => {

      const spy = spyOn(accountConfigServiceStub, 'editAccountConfig').and.returnValue(Observable.of(true));
      spyOn(router, 'navigate').and.returnValue(null);
      component.submit();
      expect(spy).toHaveBeenCalledWith(component.editAccountConfig);
    });

    // Populate success if data is recieved from editAccountConfig method of AccountConfigServiceStub
    it('should call the router if data is recieved from editAccountConfig method of AccountConfigServiceStub', () => {

      spyOn(accountConfigServiceStub, 'editAccountConfig').and.returnValue(Observable.of(true));
      const spyRouter = spyOn(router, 'navigate').and.returnValue(null);
      component.submit();
      expect(spyRouter).toHaveBeenCalled();
    });

    // Populate error if error is thrown from editAccountConfig method of AccountConfigServiceStub
    it('should populate error if error is thrown from editAccountConfig method of AccountConfigServiceStub', () => {

      spyOn(accountConfigServiceStub, 'editAccountConfig').and.returnValue(Observable.throw('Server Error'));
      component.submit();
      expect(component.errorMessage).toBe('Server Error');
    });
  });
});
