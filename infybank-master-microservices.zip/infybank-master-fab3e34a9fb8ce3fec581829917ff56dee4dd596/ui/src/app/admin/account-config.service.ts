import { UserInformationService } from './../shared/user-information.service';
import { EditAccountConfig } from './edit-account-config';
import { AccountConfig } from './account-config';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../shared/rest-service';
import { Injectable } from '@angular/core';

@Injectable()
export class AccountConfigService {

  accountConfigUrl = '/infybank/v1/acctconfigs/';
  constructor(private restService: RestService, private userInformationService: UserInformationService) { }

  getAccountConfig(): Observable<AccountConfig[]> {
    return this.restService.get(this.accountConfigUrl);
  }

  editAccountConfig(data: EditAccountConfig): Observable<boolean> {
    data.userId = this.userInformationService.userDetail.userId;
    return this.restService.put(this.accountConfigUrl, data);
  }

}
