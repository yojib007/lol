import { UserDetails } from './../../register/user-details/user-details';
import { UserInformationService } from './../../shared/user-information.service';
import { EditLoanRate } from './edit-loan-rate';
import { Observable } from 'rxjs/Observable';
import { RestService } from './../../shared/rest-service';
import { ProfileService } from './../../shared/profile.service';
import { UserInformation } from './../../shared/user-information';
import { TestBed, inject } from '@angular/core/testing';

import { ViewEditLoanRateService } from './view-edit-loan-rate.service';

class UserInformationServiceStub {
  userDetail = new UserInformation();
}
class RestServiceStub {
  get() { }
  put() { }
}
describe('ViewEditLoanRateService', () => {
  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;
  let editLoanRate;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewEditLoanRateService,
        { provide: RestService, useValue: restServiceStub },
        { provide: UserInformationService, useValue: userInformationServiceStub },
      ]
    }).compileComponents();
    restService = TestBed.get(RestService);
    editLoanRate = {
      'loanConfigDtoList': [{
        'creditScoreStart': 300,
        'creditScoreEnd': 400,
        'loanApprovalInd': 'Y',
        'interestRate': 5,
        'userId': 'testtest'
      }],
      'lstUpdtId': 'testtest'
    };
  });

  it('should be created', inject([ViewEditLoanRateService], (service: ViewEditLoanRateService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the viewLoanRate function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([ViewEditLoanRateService], (service: ViewEditLoanRateService) => {

        const spy = spyOn(restService, 'get');
        service.viewLoanRate();
        expect(spy).toHaveBeenCalled();

      }));

    // Checking viewLoanRate function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([ViewEditLoanRateService], (service: ViewEditLoanRateService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.of(true));
        service.viewLoanRate().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking viewLoanRate function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([ViewEditLoanRateService], (service: ViewEditLoanRateService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.throw('Server Error'));
        service.viewLoanRate().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

  describe('on calling the editLoanRate function', () => {

    let returnValue;
    let errMsg;

    // Checking put method of RestService is called
    it('should invoke put method of RestService',
      inject([ViewEditLoanRateService], (service: ViewEditLoanRateService) => {

        const spy = spyOn(restService, 'put');
        service.editLoanRate(editLoanRate);
        expect(spy).toHaveBeenCalled();

      }));

    // Checking editLoanRate function returning the Observable of true which is returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([ViewEditLoanRateService], (service: ViewEditLoanRateService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.of(true));
        service.editLoanRate(editLoanRate).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking viewLoanRate function returning the Observable of error which is returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([ViewEditLoanRateService], (service: ViewEditLoanRateService) => {

        const spy = spyOn(restService, 'put').and.returnValue(Observable.throw('Server Error'));
        service.editLoanRate(editLoanRate).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });
});
