import { SuccessMessageService } from './../../shared/success-message.service';
import { ValidatorsService } from './../../shared/validators.service';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { LoanRate } from './loan-rate';
import { ViewEditLoanRateService } from './view-edit-loan-rate.service';
import { Component, OnInit } from '@angular/core';
import { OnChanges, DoCheck } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-view-edit-loan-rate',
  templateUrl: './view-edit-loan-rate.component.html',
  styleUrls: ['./view-edit-loan-rate.component.css']
})
export class ViewEditLoanRateComponent implements OnInit {

  edit: boolean;
  loanRateDetails: LoanRate[];
  invalid: boolean;
  error: string[];
  errorMsg: string[];
  submitted: boolean;
  loanRateListForm: FormGroup;
  constructor(private validatorsService: ValidatorsService,
    private viewEditLoanRateService: ViewEditLoanRateService,
    private successMessageService: SuccessMessageService,
    private formBuilder: FormBuilder) { }
  submit() {
    this.submitted = true;
    this.viewEditLoanRateService.editLoanRate(this.loanRateListForm.value).subscribe(
      data => {
        this.successMessageService.message = 'LOANRATE.SUCCESS';
        this.ngOnInit();
        this.error = null;
      },
      error => {
        this.error = error;
        this.submitted = false;
      }
    );
  }

  createFields() {
    for (let i = 0; i < this.loanRateDetails.length; i++) {
      const control = <FormArray>this.loanRateListForm.controls['loanConfigDtoList'];
      control.push(
        this.formBuilder.group({
          'creditScoreStart': [this.loanRateDetails[i].creditScoreStart, [Validators.required]],
          'creditScoreEnd': [this.loanRateDetails[i].creditScoreEnd, [Validators.required]],
          'loanApprovalInd': [this.loanRateDetails[i].loanApprovalInd],
          'interestRate': [this.loanRateDetails[i].interestRate, [Validators.required]],
          'userId': []
        })
      );
    };
  }

  createForm() {
    this.loanRateListForm = this.formBuilder.group({
      loanConfigDtoList: this.formBuilder.array([]),
      lstUpdtId: []
    }, {
        validator: this.validatorsService.creditScore
      });
    this.createFields();
  }

  addField(index: number) {
    const control = <FormArray>this.loanRateListForm.controls['loanConfigDtoList'];
    control.insert(index + 1,
      this.formBuilder.group({
        'creditScoreStart': ['', [Validators.required]],
        'creditScoreEnd': ['', [Validators.required]],
        'loanApprovalInd': ['N'],
        'interestRate': [0, [Validators.required]],
        'userId': []
      })
    );
  }

  change(index: number) {
    const formArrayControl = <FormArray>this.loanRateListForm.get('loanConfigDtoList');
    const formGroupControl = <FormGroup>formArrayControl.controls[index];
    const loanApprovalInd = formGroupControl.controls['loanApprovalInd'];
    loanApprovalInd.setValue(loanApprovalInd.value === 'Y' ? 'N' : 'Y');
  }

  removeField(index: number) {
    const control = <FormArray>this.loanRateListForm.controls['loanConfigDtoList'];
    control.removeAt(index);
  }

  viewLoanRate() {
    this.viewEditLoanRateService.viewLoanRate()
      .subscribe(
      data => {
        this.loanRateDetails = data;
        this.createForm();
        this.loanRateListForm.disable();
      },
      error => this.errorMsg = error
      );
  }

  ngOnInit() {
    this.successMessageService.view = 'loan';
    this.successMessageService.subView = 'lnRte';
    this.edit = false;
    if (this.successMessageService.message) {
      setTimeout(() => {
        this.successMessageService.message = null;
      }, 5000);
    }
    this.viewLoanRate();
    this.submitted = false;
    this.error = null;
    this.errorMsg = null;
  }
}
