import { UserInformationService } from './user-information.service';
import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Router } from '@angular/router';

@Injectable()
export class AuthGuardUserService implements CanActivate {

  constructor(private router: Router, private userInformationService: UserInformationService) {
   }

  canActivate() {
    if (this.userInformationService.userDetail && this.userInformationService.userDetail.role === 'C') {
      return true;

    } else {
        this.router.navigate(['/login']);
        return false;
    }
  }
}
