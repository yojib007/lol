import { CustomErrorResponse } from './custom-error-response';
import { RestService } from './rest-service';
import { async, inject, TestBed } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpModule, Http, XHRBackend, Response, ResponseOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/toPromise';

describe('RestService', () => {

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [
                RestService,
                { provide: XHRBackend, useClass: MockBackend }
            ]
        })
            .compileComponents();
    }));

    it('can instantiate service when inject service',
        inject([RestService], (service: RestService) => {
            expect(service instanceof RestService).toBe(true);
        }));



    it('can instantiate service with "new"', inject([Http], (http: Http) => {
        expect(http).not.toBeNull('http should be provided');
        const service = new RestService(http);
        expect(service instanceof RestService).toBe(true, 'new service should be ok');
    }));


    it('can provide the mockBackend as XHRBackend',
        inject([XHRBackend], (backend: MockBackend) => {
            expect(backend).not.toBeNull('backend should be provided');
        }));

    describe('invoking get function', () => {

        describe('on returning data by mocking the backend connection', () => {

            let returnValue;
            let errMsg;
            const fakeBooleanResponse = true;
            const fakeArrayResponse = [{ id: 1, name: 'Kalpana' }, { id: 2, name: 'Kavana' }];
            let booleanResponse: Response;
            let arrayResponse: Response;
            let arrayOptions: ResponseOptions;
            let booleanOptions: ResponseOptions;

            beforeEach(() => {
                booleanOptions = new ResponseOptions({ status: 200, body: JSON.stringify(fakeBooleanResponse) });
                booleanResponse = new Response(booleanOptions);
                arrayOptions = new ResponseOptions({ status: 200, body: JSON.stringify(fakeArrayResponse) });
                arrayResponse = new Response(arrayOptions);
            });

            it('should returns true if true is send from mockBackend',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(booleanResponse));
                    service.get('/infyBank').subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toBe(true);
                })));

            it('should returns array of Object if array is send from mockBackend',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(arrayResponse));
                    service.get('/infyBank').subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toEqual([{ id: 1, name: 'Kalpana' }, { id: 2, name: 'Kavana' }]);
                })));

            it('should not populate errMsg',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(booleanResponse));
                    service.get('/infyBank').subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(errMsg).toBeUndefined();
                })));
        });

        describe('on throwing error by mocking the backend connection', () => {
            let response: Response;
            let options: ResponseOptions;
            let returnValue;
            let errMsg;

            beforeEach(() => {
                options = new ResponseOptions({ status: 404 });
                response = new Response(options);
            });

            it('should catch the error',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(response));
                    service.get('/infyBank').subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(errMsg).toBeDefined();
                })));

            it('should not populate returnValue',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(response));
                    service.get('/infyBank').subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toBeUndefined();
                })));
        });

    });

    describe('invoking post function', () => {

        describe('on returning data by mocking the backend connection', () => {

            let returnValue;
            let errMsg;
            const fakeBooleanResponse = true;
            const fakeArrayResponse = [{ id: 1, name: 'Kalpana' }, { id: 2, name: 'Kavana' }];
            let booleanResponse: Response;
            let arrayResponse: Response;
            let arrayOptions: ResponseOptions;
            let booleanOptions: ResponseOptions;

            beforeEach(() => {
                booleanOptions = new ResponseOptions({ status: 200, body: JSON.stringify(fakeBooleanResponse) });
                booleanResponse = new Response(booleanOptions);
                arrayOptions = new ResponseOptions({ status: 200, body: JSON.stringify(fakeArrayResponse) });
                arrayResponse = new Response(arrayOptions);
            });

            it('should returns true if true is send from mockBackend',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(booleanResponse));
                    service.post('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toBe(true);
                })));

            it('should returns array of Object if array is send from mockBackend',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(arrayResponse));
                    service.post('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toEqual([{ id: 1, name: 'Kalpana' }, { id: 2, name: 'Kavana' }]);
                })));

            it('should not populate errMsg',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(booleanResponse));
                    service.post('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(errMsg).toBeUndefined();
                })));
        });

        describe('on throwing error by mocking the backend connection', () => {
            let response: Response;
            let options: ResponseOptions;
            let returnValue;
            let errMsg;

            beforeEach(() => {
                options = new ResponseOptions({ status: 404 });
                response = new Response(options);
            });

            it('should catch the error',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(response));
                    service.post('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(errMsg).toBeDefined();
                })));

            it('should not populate returnValue',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(response));
                    service.post('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toBeUndefined();
                })));
        });

    });

    describe('invoking patch function', () => {

        describe('on returning data by mocking the backend connection', () => {

            let returnValue;
            let errMsg;
            const fakeBooleanResponse = true;
            const fakeArrayResponse = [{ id: 1, name: 'Kalpana' }, { id: 2, name: 'Kavana' }];
            let booleanResponse: Response;
            let arrayResponse: Response;
            let arrayOptions: ResponseOptions;
            let booleanOptions: ResponseOptions;

            beforeEach(() => {
                booleanOptions = new ResponseOptions({ status: 200, body: JSON.stringify(fakeBooleanResponse) });
                booleanResponse = new Response(booleanOptions);
                arrayOptions = new ResponseOptions({ status: 200, body: JSON.stringify(fakeArrayResponse) });
                arrayResponse = new Response(arrayOptions);
            });

            it('should returns true if true is send from mockBackend',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(booleanResponse));
                    service.patch('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toBe(true);
                })));

            it('should returns array of Object if array is send from mockBackend',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(arrayResponse));
                    service.patch('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toEqual([{ id: 1, name: 'Kalpana' }, { id: 2, name: 'Kavana' }]);
                })));

            it('should not populate errMsg',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(booleanResponse));
                    service.patch('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(errMsg).toBeUndefined();
                })));
        });

        describe('on throwing error by mocking the backend connection', () => {
            let response: Response;
            let options: ResponseOptions;
            let returnValue;
            let errMsg;

            beforeEach(() => {
                options = new ResponseOptions({ status: 404 });
                response = new Response(options);
            });

            it('should catch the error',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(response));
                    service.patch('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(errMsg).toBeDefined();
                })));

            it('should not populate returnValue',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(response));
                    service.patch('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toBeUndefined();
                })));
        });

    });

    describe('invoking put function', () => {

        describe('on returning data by mocking the backend connection', () => {

            let returnValue;
            let errMsg;
            const fakeBooleanResponse = true;
            const fakeArrayResponse = [{ id: 1, name: 'Kalpana' }, { id: 2, name: 'Kavana' }];
            let booleanResponse: Response;
            let arrayResponse: Response;
            let arrayOptions: ResponseOptions;
            let booleanOptions: ResponseOptions;

            beforeEach(() => {
                booleanOptions = new ResponseOptions({ status: 200, body: JSON.stringify(fakeBooleanResponse) });
                booleanResponse = new Response(booleanOptions);
                arrayOptions = new ResponseOptions({ status: 200, body: JSON.stringify(fakeArrayResponse) });
                arrayResponse = new Response(arrayOptions);
            });

            it('should returns true if true is send from mockBackend',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(booleanResponse));
                    service.put('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toBe(true);
                })));

            it('should returns array of Object if array is send from mockBackend',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(arrayResponse));
                    service.put('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toEqual([{ id: 1, name: 'Kalpana' }, { id: 2, name: 'Kavana' }]);
                })));

            it('should not populate errMsg',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(booleanResponse));
                    service.put('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(errMsg).toBeUndefined();
                })));
        });

        describe('on throwing error by mocking the backend connection', () => {
            let response: Response;
            let options: ResponseOptions;
            let returnValue;
            let errMsg;

            beforeEach(() => {
                options = new ResponseOptions({ status: 404 });
                response = new Response(options);
            });

            it('should catch the error',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(response));
                    service.put('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(errMsg).toBeDefined();
                })));

            it('should not populate returnValue',
                async(inject([XHRBackend, RestService], (backend: MockBackend, service: RestService) => {
                    backend.connections.subscribe((c: MockConnection) => c.mockRespond(response));
                    service.put('/infyBank', { id: 1, name: 'kalpana' }).subscribe(
                        data => returnValue = data,
                        error => errMsg = error
                    );
                    expect(returnValue).toBeUndefined();
                })));
        });

    });

    describe('invoking extract method', () => {

        let successOptions: ResponseOptions;
        let errorOptions: ResponseOptions;
        let successResponse: Response;
        let errorResponse: Response;
        const jsonObject = JSON.stringify({ id: 1, name: 'Kalpana' });

        beforeEach(() => {
            successOptions = new ResponseOptions({ status: 200, body: jsonObject });
            successResponse = new Response(successOptions);
            errorOptions = new ResponseOptions({ status: 400, body: jsonObject });
            errorResponse = new Response(errorOptions);
        });

        it('should convert JSON object to Javascript object if status is success',
            inject([RestService], (service: RestService) => {
                expect(service.extractData(successResponse)).toEqual({ id: 1, name: 'Kalpana' });

            }));

        it('should throw error if status is fail',
            inject([RestService], (service: RestService) => {
                expect(() => { service.extractData(errorResponse); }).toThrow();

            }));
    });

    describe('invoking handleErrorObservable method', () => {

        let serverErrorOptionsFor400: ResponseOptions;
        let serverErrorOptionsFor500: ResponseOptions;
        let nonServerErrorOptions: ResponseOptions;
        let serverErrorResponseFor400: Response;
        let serverErrorResponseFor500: Response;
        let nonServerErrorResponse: Response;
        const serverErrorObj = new CustomErrorResponse();
        let errorObj;
        let errorString;
        let errorMsg;
        let returnValue;


        beforeEach(() => {
            serverErrorObj.errors = [
                { code: 400, message: 'Unable to process the request' },
                { code: 400, message: 'Timeout Error' }
            ];
            errorObj = { status: 404, message: 'Unknown Error' };
            errorString = 'Server Error';
            serverErrorOptionsFor400 = new ResponseOptions({ status: 400, body: JSON.stringify(serverErrorObj) });
            serverErrorResponseFor400 = new Response(serverErrorOptionsFor400);
            serverErrorOptionsFor500 = new ResponseOptions({ status: 500, body: JSON.stringify(serverErrorObj) });
            serverErrorResponseFor500 = new Response(serverErrorOptionsFor500);
            nonServerErrorOptions = new ResponseOptions({ status: 404 });
            nonServerErrorResponse = new Response(nonServerErrorOptions);
        });

        it('should convert all messages in array of errors to a single string if status code is 400',
            inject([RestService], (service: RestService) => {
                service.handleErrorObservable(serverErrorResponseFor400).subscribe(
                    data => returnValue = data,
                    error => errorMsg = error
                );
                expect(errorMsg).toBe('Unable to process the request. Timeout Error. ');

            }));

        it('should convert all messages in array of errors to a single string if status code is 500',
            inject([RestService], (service: RestService) => {
                service.handleErrorObservable(serverErrorResponseFor500).subscribe(
                    data => returnValue = data,
                    error => errorMsg = error
                );
                expect(errorMsg).toBe('Unable to process the request. Timeout Error. ');

            }));

        it('should throw Observable error with common message  if status code is not equal to 400 or 500',
            inject([RestService], (service: RestService) => {
                service.handleErrorObservable(nonServerErrorResponse).subscribe(
                    data => returnValue = data,
                    error => errorMsg = error
                );
                expect(errorMsg).toBeDefined();

            }));

        it('should throw Observable error with message recieved from error object if error is not a response object',
            inject([RestService], (service: RestService) => {
                service.handleErrorObservable(errorObj).subscribe(
                    data => returnValue = data,
                    error => errorMsg = error
                );
                expect(errorMsg).toBe('Unknown Error');

            }));

        it('should throw Observable error with message recieved from error string if error is not a response object but a string',
            inject([RestService], (service: RestService) => {
                service.handleErrorObservable(errorString).subscribe(
                    data => returnValue = data,
                    error => errorMsg = error
                );
                expect(errorMsg).toBe('Server Error');

            }));
    });


});
