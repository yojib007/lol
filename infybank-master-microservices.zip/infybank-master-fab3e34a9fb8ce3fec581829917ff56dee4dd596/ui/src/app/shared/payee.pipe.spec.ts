import { PayeePipe } from './payee.pipe';

describe('PayeePipe', () => {

  let pipe;
  let arrObj;
  beforeEach(() => {
    pipe = new PayeePipe();
    arrObj = [{ id: 1, status: 'C' }, { id: 2, status: 'S' }, { id: 3, status: 'C' }];
  });

  // Checking everything is correct
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  // Checking transform method filters array with only objects whose status is C if arguments is passed as 'confirmed'
  it('shlould filter the array with object whose status is C if argument is passed as confirmed', () => {
    expect(pipe.transform(arrObj, 'confirmed')).toEqual([{ id: 1, status: 'C' }, { id: 3, status: 'C' }]);
  });

  // Checking transform method filters array with only objects whose status is S if arguments is passed as 'submitted'
  it('shlould filter the array with object whose status is C if argument is passed as submitted', () => {

    expect(pipe.transform(arrObj, 'submitted')).toEqual([{ id: 2, status: 'S' }]);
  });
});
