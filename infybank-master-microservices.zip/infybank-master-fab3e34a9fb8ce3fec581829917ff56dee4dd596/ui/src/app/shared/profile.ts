export class Profile {
    'cust': number;
    'firstName': string;
    'lastName': string;
    'aadharId': string;
    'email': string;
    'address': string;
    'city': string;
    'state': string;
    'pinCode': number;
    'creditDebitLimit': number;
    'amountPref': string;
    'datePref': string;
}
