import { TestBed, inject } from '@angular/core/testing';

import { DownloadService } from './download.service';

describe('DownloadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DownloadService]
    });
  });

  it('should be created', inject([DownloadService], (service: DownloadService) => {
    expect(service).toBeTruthy();
  }));

  // asPdf method should work properly
  it('should not throw error if asPdf method is invoked', inject([DownloadService], (service: DownloadService) => {

    expect(() => { service.asPdf('table'); }).not.toThrow();
  }));

  // asExcel method should work properly
  it('should not throw error if asExcel method is invoked', inject([DownloadService], (service: DownloadService) => {

    spyOn(document, 'getElementById').and.returnValue({innerHTML: 'Hello'});
    expect(() => { service.asExcel('table'); }).not.toThrow();
  }));

});
