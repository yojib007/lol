import { UserInformationService } from './user-information.service';
import { ProfileService } from './profile.service';
import { ConfirmPayee } from './../manage-payee/confirm-payee/confirm-payee';
import { Observable } from 'rxjs/Rx';
import { AddPayee } from './add-payee';
import { Payee } from './payee';
import { RestService } from './../shared/rest-service';
import { Injectable } from '@angular/core';

@Injectable()
export class PayeeService {

  payeeUrl: string;
  deletePayeeUrl: string;

  constructor(private restService: RestService, private userInformationService: UserInformationService) { }

  viewPayee(status: string): Observable<Payee[]> {
    this.payeeUrl = '/infybank/v1/customers/' + this.userInformationService.userDetail.custId + '/payees?status=' + status;
    return this.restService.get(this.payeeUrl);
  }

  addPayee(payee: AddPayee): Observable<boolean> {
    this.payeeUrl = '/infybank/v1/customers/' + this.userInformationService.userDetail.custId + '/payees';
    payee.userId = this.userInformationService.userDetail.userId;
    return this.restService.post(this.payeeUrl, payee);
  }

  deletePayee(payee: Payee): Observable<boolean> {
    this.deletePayeeUrl = '/infybank/v1/customers/' + this.userInformationService.userDetail.custId + '/payees/' + payee.payeeId;
    return this.restService.delete(this.deletePayeeUrl);
  }
  confirmPayee(payee: Payee, otp: ConfirmPayee): Observable<boolean> {
    this.payeeUrl = '/infybank/v1/customers/' + this.userInformationService.userDetail.custId + '/payees/' + payee.payeeId + '/confirm';
    otp.emailId = this.userInformationService.profileDetail.email;
    return this.restService.put(this.payeeUrl, otp);
  }
}
