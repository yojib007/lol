import { UserInformationService } from './user-information.service';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthGuardAdminService } from './auth-guard.admin.service';
import { TestBed, inject } from '@angular/core/testing';
import { Router } from '@angular/router';
import { UserInformation } from './user-information';

class UserInformationServiceStub {
    userDetail: UserInformation;
}

describe('AuthGuardAdminService', () => {

    const userInformationServiceStub = new UserInformationServiceStub();
    let router;
    let userInformationService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            providers: [AuthGuardAdminService,
                { provide: UserInformationService, useValue: userInformationServiceStub }
            ]
        });
        router = TestBed.get(Router);
        userInformationService = TestBed.get(UserInformationService);
    });

    it('should be created', inject([AuthGuardAdminService], (service: AuthGuardAdminService) => {
        expect(service).toBeTruthy();
    }));

    describe('on calling the canActivate function', () => {

        let spyRouter;
        beforeEach(() => {
            spyRouter = spyOn(router, 'navigate');
        });

        // should return true in userRole is A in userDetail
        it('should return true in userRole is A in userDetail',
            inject([AuthGuardAdminService], (service: AuthGuardAdminService) => {
                userInformationService.userDetail = { role: 'A'};
                expect(service.canActivate()).toBe(true);

            }));

        // Checking navigate to login page if userRole is not A in userDetail
        it('should navigate to login page if userRole is not A in userDetail',
            inject([AuthGuardAdminService], (service: AuthGuardAdminService) => {

                userInformationService.userDetail = { role: 'C'};
                service.canActivate();
                expect(spyRouter).toHaveBeenCalledWith(['/login']);

            }));
    });

});
