import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'payee'
})
export class PayeePipe implements PipeTransform {

  transform(value: any, args: string): any {
    if (args === 'confirmed') {
      return value.filter(obj => obj.status === 'C');

    } else if (args === 'submitted') {

      return value.filter(obj => obj.status === 'S');
    }
  }

}
