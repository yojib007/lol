import { ProfileService } from './profile.service';
import { Profile } from './profile';
import { UserInformationService } from './user-information.service';
import { Observable } from 'rxjs/Observable';
import { RestService } from './rest-service';
import { UserInformation } from './user-information';
import { TestBed, inject } from '@angular/core/testing';

class UserInformationServiceStub {
  userDetail = new UserInformation();
  profileDetail = new Profile();
}

class RestServiceStub {
  get() { }
  patch() { }
}

describe('ProfileService', () => {
  const restServiceStub = new RestServiceStub();
  const userInformationServiceStub = new UserInformationServiceStub();
  let restService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProfileService,
        { provide: RestService, useValue: restServiceStub },
        { provide: UserInformationService, useValue: userInformationServiceStub },
      ]
    }).compileComponents();
    restService = TestBed.get(RestService);
  });

  it('should be created', inject([ProfileService], (service: ProfileService) => {
    expect(service).toBeTruthy();
  }));

  describe('on calling the getUserDetails function', () => {

    let returnValue;
    let errMsg;

    // Checking get method of RestService is called
    it('should invoke get method of RestService',
      inject([ProfileService], (service: ProfileService) => {

        const spy = spyOn(restService, 'get');
        service.getUserDetails();
        expect(spy).toHaveBeenCalled();

      }));

    // Checking getUserDetails function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([ProfileService], (service: ProfileService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.of(true));
        service.getUserDetails().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking getUserDetails function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([ProfileService], (service: ProfileService) => {

        const spy = spyOn(restService, 'get').and.returnValue(Observable.throw('Server Error'));
        service.getUserDetails().subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });

  describe('on calling the update function', () => {

    let returnValue;
    let errMsg;

    // Checking patch method of RestService is called
    it('should invoke patch method of RestService',
      inject([ProfileService], (service: ProfileService) => {

        const spy = spyOn(restService, 'patch');
        service.update(new Profile());
        expect(spy).toHaveBeenCalled();

      }));

    // Checking update function returning the Observable of true returned from RestService
    it('should return Obervable of true which is returned from RestService',
      inject([ProfileService], (service: ProfileService) => {

        const spy = spyOn(restService, 'patch').and.returnValue(Observable.of(true));
        service.update(new Profile()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(returnValue).toBe(true);

      }));

    // Checking update function returning the Observable of error returned from RestService
    it('should return Obervable of error which is returned from RestService',
      inject([ProfileService], (service: ProfileService) => {

        const spy = spyOn(restService, 'patch').and.returnValue(Observable.throw('Server Error'));
        service.update(new Profile()).subscribe(
          data => returnValue = data,
          error => errMsg = error
        );
        expect(errMsg).toBe('Server Error');

      }));
  });
});
