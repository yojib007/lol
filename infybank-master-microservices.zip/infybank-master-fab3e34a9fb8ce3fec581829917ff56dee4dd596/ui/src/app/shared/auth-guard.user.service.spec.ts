import { AuthGuardUserService } from './auth-guard.user.service';
import { UserInformationService } from './user-information.service';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject } from '@angular/core/testing';
import { Router } from '@angular/router';
import { UserInformation } from './user-information';

class UserInformationServiceStub {
    userDetail: UserInformation;
}

describe('AuthGuardUserService', () => {

    const userInformationServiceStub = new UserInformationServiceStub();
    let router;
    let userInformationService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            providers: [AuthGuardUserService,
                { provide: UserInformationService, useValue: userInformationServiceStub }
            ]
        });
        router = TestBed.get(Router);
        userInformationService = TestBed.get(UserInformationService);
    });

    it('should be created', inject([AuthGuardUserService], (service: AuthGuardUserService) => {
        expect(service).toBeTruthy();
    }));

    describe('on calling the canActivate function', () => {

        let spyRouter;
        beforeEach(() => {
            spyRouter = spyOn(router, 'navigate');
        });

        // should return true in userRole is C in userDetail
        it('should return true in userRole is C in userDetail',
            inject([AuthGuardUserService], (service: AuthGuardUserService) => {
                userInformationService.userDetail = { role: 'C'};
                expect(service.canActivate()).toBe(true);

            }));

        // Checking navigate to login page if userRole is not C in userDetail
        it('should navigate to login page if userRole is not C in userDetail',
            inject([AuthGuardUserService], (service: AuthGuardUserService) => {
                userInformationService.userDetail = null;
                service.canActivate();
                expect(spyRouter).toHaveBeenCalledWith(['/login']);

            }));
    });

});
