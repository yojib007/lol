export class Login {
        public userId: string;
        public password: string;
}
