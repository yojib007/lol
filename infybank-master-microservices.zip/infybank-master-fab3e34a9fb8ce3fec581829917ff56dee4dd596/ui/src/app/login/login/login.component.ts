import { ProfileService } from './../../shared/profile.service';
import { ValidatorsService } from './../../shared/validators.service';
import { UserInformationService } from './../../shared/user-information.service';
import { UserInformation } from './../../shared/user-information';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { LoginService } from './login.service';
import { Login } from './login';
import { Router } from '@angular/router';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    error: string;
    errorFromServer: string[];
    loginForm: FormGroup;
    userName: string;
    noOfAttempts = 0;
    submit: boolean;
    constructor(
        private validatorsService: ValidatorsService,
        private loginService: LoginService,
        private formBuilder: FormBuilder,
        private router: Router,
        private profileService: ProfileService,
        private userInformationService: UserInformationService
    ) { }

    userLogin() {
        this.submit = true;
        this.loginService.checkUser(this.loginForm.value)
            .subscribe(
            data => this.successfullLogin(data),
            error => {
                this.submit = false;
                this.failureLogin(error);
            }
            );
    }

    successfullLogin(data: UserInformation) {
        console.log(data);
        this.userInformationService.userDetail = data;
        this.error = null;
        this.profileService.getUserDetails().subscribe(
            (info) => {
                this.userInformationService.profileDetail = info;
                if (data.role === 'C') {
                    this.router.navigate(['/account/acctsumm']);
                } else if (data.role === 'A') {
                    this.router.navigate(['/admin']);
                }
            },
            error => this.error = error
        );
    }

    failureLogin(error: any) {
        this.errorFromServer = error;
        if (this.noOfAttempts > 0) {
            if (this.userName !== this.loginForm.value.userId) {
                this.noOfAttempts = 0;
                this.userName = this.loginForm.value.userId;
            }
        }
        if (this.errorFromServer[0].toLowerCase().indexOf('customer.login.invalid') >= 0) {
            this.noOfAttempts += 1;
            if (this.noOfAttempts === 1) {
                this.error = 'ERRORS.LOGIN.FIRSTATTMPT';
            } else if (this.noOfAttempts === 2) {
                this.error = 'ERRORS.LOGIN.SECONDATTMPT';
            } else if (this.noOfAttempts > 2) {
                this.error = 'ERRORS.LOGIN.LASTATTMPT';
            }
        }
    }
    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            userId: ['', Validators.required],
            password: ['', Validators.required]
        });
    }

}
