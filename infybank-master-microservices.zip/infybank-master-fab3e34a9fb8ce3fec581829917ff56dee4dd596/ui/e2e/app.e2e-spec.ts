import { InfyBankPage } from './app.po';

describe('infy-bank App', () => {
  let page: InfyBankPage;

  beforeEach(() => {
    page = new InfyBankPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
