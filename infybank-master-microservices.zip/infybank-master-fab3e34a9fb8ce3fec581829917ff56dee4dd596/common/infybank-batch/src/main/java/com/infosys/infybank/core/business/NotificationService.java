package com.infosys.infybank.core.business;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infosys.infybank.core.to.CreditTO;
import com.infosys.infybank.core.to.Email;
 
/**
 * The Class NotificationService.
 */
@Service
public class NotificationService {
	private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

	private static final String MESSAGE_LINE = "Dear Customer,\n\t Your account {0} is";

	private static final String EMAIL_WS_URL = "emailwebservice.url";

	private static final String RETURN_VALUE_FROM_EMAIL_WS = "return value from emailwebservice {}";
	@Autowired
	private Environment environment;

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * Email notification for OTP.
	 *
	 * @param emailId
	 *            the email id
	 * @param randomPin
	 *            the otp
	 * @return true, if successful
	 */
	public boolean emailNotificationForSalary(CreditTO obj) {
		Email email = new Email();
		email.setToEmailId(obj.getEmailId());

		email.setSubject("Notification for Salary Credit");
		String message = java.text.MessageFormat.format(
				MESSAGE_LINE
						+ "credited with  salary of {1}.Your new balance is:{2}.\n\nRegards\nCustomer Care, InfyBank",
				obj.getAcctNo(), obj.getSalary(), obj.getNewBalance());

		email.setEmailMessage(message);

		String url = environment.getProperty(EMAIL_WS_URL);

		try {
			String sentNotifcation = restTemplate.postForObject(url, email, String.class);
			logger.info(RETURN_VALUE_FROM_EMAIL_WS, sentNotifcation);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return true;

	}

	/**
	 * Email notification for user profile.
	 *
	 * @param emailId
	 *            the email id
	 * @param login
	 *            the login
	 * @return true, if successful
	 */
	public boolean emailNotificationForInterest(CreditTO dto) {

		Email email = new Email();
		email.setToEmailId(dto.getEmailId());
		email.setSubject("Notification for Interest Credit");
		BigDecimal amount = dto.getNewBalance().subtract(dto.getBalance());
		String message = java.text.MessageFormat.format(
				MESSAGE_LINE
						+ " credited with interest of {1} . Your new balance is:{2}.\n\nRegards\nCustomer Care, InfyBank ",
				dto.getAcctNo(), amount, dto.getNewBalance());

		email.setEmailMessage(message);

		String url = environment.getProperty(EMAIL_WS_URL);

		try {
			String sentNotifcation = restTemplate.postForObject(url, email, String.class);
			logger.info(RETURN_VALUE_FROM_EMAIL_WS, sentNotifcation);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return true;
	}

	public boolean emailNotificationForFundTransfer(CreditTO obj) {
		Email email = new Email();

		email.setToEmailId(obj.getEmailId());
		email.setSubject("Notification for Fund Transfer");
		BigDecimal amount = obj.getNewBalance().subtract(obj.getBalance());
		String txnType;
		if (obj.getTxnType() == 'C') {
			txnType = "credited";
		} else if (obj.getTxnType() == 'D') {
			txnType = "debited";
		} else {
			txnType = "";
			logger.error("Invalid TxnType");
		}

		String message = java.text.MessageFormat.format(
				MESSAGE_LINE + txnType
						+ " with an amount of {1} . Your new balance is : {2}.\n\nRegards\nCustomer Care, InfyBank ",
				obj.getAcctNo(), amount.abs(), obj.getNewBalance());

		email.setEmailMessage(message);

		String url = environment.getProperty(EMAIL_WS_URL);

		try {
			String sentNotifcation = restTemplate.postForObject(url, email, String.class);
			logger.info(RETURN_VALUE_FROM_EMAIL_WS, sentNotifcation);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return true;
	}

	public boolean emailNotificationForPayInstallment(String emailId, CreditTO obj) {
		Email email = new Email();

		email.setToEmailId(emailId);
		email.setSubject("Notification for Pay Installment");
		BigDecimal amount = obj.getNewBalance().subtract(obj.getBalance());
		String message = java.text.MessageFormat.format(
				MESSAGE_LINE
						+ " debited with an amount of {1} . Your new balance is:{2}.\n\nRegards\nCustomer Care, InfyBank ",
				obj.getAcctNo(), amount.abs(), obj.getNewBalance());

		email.setEmailMessage(message);

		String url = environment.getProperty(EMAIL_WS_URL);

		try {
			String sentNotifcation = restTemplate.postForObject(url, email, String.class);
			logger.info(RETURN_VALUE_FROM_EMAIL_WS, sentNotifcation);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return true;
	}

}
