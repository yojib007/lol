package com.infosys.infybank.core.to;

import java.math.BigDecimal;
import java.util.Date;
 
public class CreditTO {

	private int custId;
	private String userId;
	private char acctType;
	private BigDecimal interestRate;
	private BigDecimal balance;
	private String acctNo;
	private BigDecimal newBalance;
	private BigDecimal salary;
	private Date creditDate;
	private String toAccount;
	private String refId;
	private BigDecimal amount;
	private String remarks;
	private char txnType;
	private String batchType;
	private BigDecimal emi;
	private BigDecimal minBal;
	private String emailId;
	private String toEmailId;
	private int toCustId;
	private BigDecimal toBalance;
	private Date emiDueDate;

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public BigDecimal getMinBal() {
		return minBal;
	}

	public void setMinBal(BigDecimal minBal) {
		this.minBal = minBal;
	}

	public BigDecimal getEmi() {
		return emi;
	}

	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getToAccount() {
		return toAccount;
	}

	public void setToAccount(String toAccount) {
		this.toAccount = toAccount;
	}

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	public java.util.Date getCreditDate() {
		return creditDate;
	}

	public void setCreditDate(java.util.Date creditDate) {
		this.creditDate = creditDate;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public BigDecimal getNewBalance() {
		return newBalance;
	}

	public void setNewBalance(BigDecimal newBalance) {
		this.newBalance = newBalance;
	}

	public char getAcctType() {
		return acctType;
	}

	public void setAcctType(char acctType) {
		this.acctType = acctType;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public String getAcctNo() {
		return acctNo;
	}

	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public char getTxnType() {
		return txnType;
	}

	public void setTxnType(char txnType) {
		this.txnType = txnType;
	}

	public String getToEmailId() {
		return toEmailId;
	}

	public void setToEmailId(String toEmailId) {
		this.toEmailId = toEmailId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getToCustId() {
		return toCustId;
	}

	public void setToCustId(int toCustId) {
		this.toCustId = toCustId;
	}

	public BigDecimal getToBalance() {
		return toBalance;
	}

	public void setToBalance(BigDecimal toBalance) {
		this.toBalance = toBalance;
	}

	public Date getEmiDueDate() {
		return emiDueDate;
	}

	public void setEmiDueDate(Date emiDueDate) {
		this.emiDueDate = emiDueDate;
	}

	@Override
	public String toString() {
		return "CreditTO [custId=" + custId + ", userId=" + userId + ", acctType=" + acctType + ", interestRate="
				+ interestRate + ", balance=" + balance + ", acctNo=" + acctNo + ", newBalance=" + newBalance
				+ ", salary=" + salary + ", creditDate=" + creditDate + ", toAccount=" + toAccount + ", refId=" + refId
				+ ", amount=" + amount + ", remarks=" + remarks + ", txnType=" + txnType + ", batchType=" + batchType
				+ ", emi=" + emi + ", minBal=" + minBal + ", emailId=" + emailId + ", toEmailId=" + toEmailId
				+ ", toCustId=" + toCustId + ", toBalance=" + toBalance + ", emiDueDate=" + emiDueDate + "]";
	}

}
