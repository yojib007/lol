package com.infosys.infybank.core.persistence;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.business.NotificationService;
import com.infosys.infybank.core.to.CreditTO;
 
@Repository
public class CreditRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	FundTransferDAO ftdao;

	@Autowired
	NotificationService notificationService;

	public void creditAmountAndNotify(CreditTO creditTO) {

		String updateQuery1 = "Update bank_account set BALANCE=" + creditTO.getNewBalance() + ",lst_updt_ts=now(),"
				+ "lst_updt_id='admin' where ACCT_NO='" + creditTO.getAcctNo() + "'";

		String updateQuery2 = "Update bank_account set BALANCE=" + creditTO.getNewBalance() + ",lst_updt_ts=now(),"
				+ "lst_updt_id='admin' where ACCT_NO='" + creditTO.getAcctNo() + "'";

		String updateQuery = "N".equals(creditTO.getBatchType()) ? updateQuery2 : updateQuery1;

		int rowsUpdated = jdbcTemplate.update(updateQuery);
		logger.debug("Updated query {} and rows updated is {}", updateQuery, rowsUpdated);

		String creditTypes = "SIFN";
		if (creditTypes.indexOf(creditTO.getBatchType()) < 0) {
			logger.error("Invalid Credit Type");
		}

		String remarks = "";
		switch (creditTO.getBatchType().charAt(0)) {
		case 'F':
			remarks = "Scheduled Fund Transfer";
			break;
		case 'N':
			remarks = "Pay Installment";
			break;
		}

		BigDecimal amount = creditTO.getNewBalance().subtract(creditTO.getBalance()).abs();

		String insertQuery1 = "Insert into account_transaction"
				+ " (acct_no,closing_bal,cust_id,lst_updt_id,opening_bal, remarks,txn_amount,txn_typ,txn_date,txn_category, ref_Id) "
				+ "values('" + creditTO.getAcctNo() + "'," + creditTO.getNewBalance() + "," + creditTO.getCustId()
				+ ",'admin'," + creditTO.getBalance() + ",'" + remarks + "'," + amount + ",'" + creditTO.getTxnType()
				+ "','" + new java.sql.Date(creditTO.getCreditDate().getTime()) + "','" + creditTO.getBatchType()
				+ "','" + creditTO.getRefId() + "')";

		String insertQuery2 = "Insert into account_transaction"
				+ " (acct_no,closing_bal,cust_id,lst_updt_id,opening_bal,"
				+ "remarks,txn_amount,txn_typ,txn_date,txn_category) " + "values('" + creditTO.getAcctNo() + "',"
				+ creditTO.getNewBalance() + "," + creditTO.getCustId() + ",'admin'," + creditTO.getBalance() + ",'"
				+ remarks + "'," + amount + ",'" + creditTO.getTxnType() + "','"
				+ new java.sql.Date(creditTO.getCreditDate().getTime()) + "','" + creditTO.getBatchType() + "')";

		String insertQuery = "N".equals(creditTO.getBatchType()) ? insertQuery2 : insertQuery1;

		int rowsInserted = jdbcTemplate.update(insertQuery);
		logger.debug("Inserted query {} and rows updated is {}", insertQuery, rowsInserted);

		logger.debug("{}  Bank account {} Updated successfully", rowsUpdated, creditTO.getAcctNo());
		logger.debug("{} Transaction completed ", rowsInserted);

		String emailQuery1 = "SELECT c.email_Id FROM bank_account b, customer c where b.cust_id=c.cust_id and b.acct_no='"
				+ creditTO.getAcctNo() + "'";

		String emailQuery2 = "SELECT c.email_Id FROM bank_account b, customer c where b.cust_id=c.cust_id and b.acct_no='"
				+ creditTO.getAcctNo() + "'";

		String emailQuery = "N".equals(creditTO.getBatchType()) ? emailQuery2 : emailQuery1;

		SqlRowSet emailSet = jdbcTemplate.queryForRowSet(emailQuery);

		String emailId = null;

		while (emailSet.next()) {
			emailId = emailSet.getString(1);
		}
		creditTO.setAcctNo(creditTO.getAcctNo());
		creditTO.setSalary(creditTO.getSalary());

		if ("N".equals(creditTO.getBatchType()))
			notificationService.emailNotificationForPayInstallment(emailId, creditTO);

	}

}
