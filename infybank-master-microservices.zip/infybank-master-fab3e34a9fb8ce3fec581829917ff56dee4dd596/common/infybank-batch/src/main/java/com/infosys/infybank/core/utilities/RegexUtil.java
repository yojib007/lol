package com.infosys.infybank.core.utilities;

import java.io.FileReader;

import java.io.IOException;
import java.io.LineNumberReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infosys.infybank.core.to.CreditTO;

public class RegexUtil {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<CreditTO> readSalaryFile() {
		List<CreditTO> creditList = new ArrayList<CreditTO>();
		FileReader fileNumberReader = null;
		LineNumberReader lineNumberReader = null;
		String fileName = "D:\\BankingApp_Monolithic\\input\\Salary.txt";
		String str;
		RegexUtil util = new RegexUtil();

		try {
			fileNumberReader = new FileReader(fileName);
			lineNumberReader = new LineNumberReader(fileNumberReader);

			while ((str = lineNumberReader.readLine()) != null) {
				if (isHeader(str)) {
					util.detectHeader(str);
				} else if (isTrailer(str)) {
					logger.info("Trailer Detected");
				} else {
					CreditTO newSalaryTO = new CreditTO();
					newSalaryTO = util.processData(str, newSalaryTO);
					creditList.add(newSalaryTO);
					creditList = (newSalaryTO != null) ? creditList : new ArrayList<CreditTO>();
				}

			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (fileNumberReader != null)
					fileNumberReader.close();
				if (lineNumberReader != null)
					lineNumberReader.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}

		return creditList;
	}

	public boolean isHeader(String str) {
		Pattern pattern = Pattern.compile("^(?i)(Header)");
		Matcher matcher = pattern.matcher(str);
		return matcher.find();
	}

	public boolean isTrailer(String str) {
		Pattern pattern = Pattern.compile("^(?i)(Trailer)");
		Matcher matcher = pattern.matcher(str);
		return matcher.find();

	}

	public void detectHeader(String string) {
		Pattern pattern = Pattern.compile("(^Header)\\|(salary_.*)\\|(.*)");
		Matcher matcher = pattern.matcher(string);
		String transmissionDate;

		if (matcher.find()) {
			transmissionDate = matcher.group(3);
			logger.info(transmissionDate);
		}

	}

	public CreditTO processData(String str, CreditTO salaryTO) {
		String accountNumberValidation = "^(\\d{10})(.*)";
		String validSalaryCredit = "^(\\d{10})\\|([1-9]\\d*(\\.\\d+)?)(.*)";

		if (str.matches(accountNumberValidation)) {
			if (str.matches(validSalaryCredit)) {
				patternCheck(str, salaryTO);
			} else {
				logger.info("Salary Credit value is invalid : {}", str);
				return null;
			}
		} else {
			logger.info("Invalid account number for String :: {} ", str);
		}

		return salaryTO;
	}

	private void patternCheck(String str, CreditTO salaryTO) {
		try {
			String regexStringAllIntegerAndDecimal = "^(\\d{10})\\|([1-9]\\d*(\\.\\d+)?)\\|(.*)";
			Pattern pattern = Pattern.compile(regexStringAllIntegerAndDecimal);
			Matcher matcher = pattern.matcher(str);
			if (matcher.find()) {
				salaryTO.setAcctNo(matcher.group(1));
				salaryTO.setSalary(new BigDecimal(matcher.group(2)));
				salaryTO.setCreditDate(new SimpleDateFormat("dd-MM-yyyy").parse(matcher.group(4)));
			} else {
				logger.error("Data in file not according to the format specified");
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

}