package com.infosys.infybank.core.persistence;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.to.AmortizationDTO;
import com.infosys.infybank.core.to.CreditTO;
import com.infosys.infybank.core.to.LoanAccountDTO;
 
@Repository
public class LoanDAO {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	JdbcTemplate jdbcTemplate;

	/**
	 * Fetches all loans for which EMI has to be paid
	 * 
	 * @return List<CreditTO>
	 */
	public List<CreditTO> fetchLoansForEMIPayment() {

		String query = "SELECT L.CUST_ID, L.DEBIT_ACCT_NO, L.EMI, L.LOAN_ACCT_NO, C.MIN_BALANCE, L.EMI_DUE_DATE, L.LOAN_AMOUNT, L.INTEREST_RATE"
				+ " FROM LOAN_ACCOUNT L INNER JOIN BANK_ACCOUNT B ON B.ACCT_NO = L.DEBIT_ACCT_NO"
				+ " INNER JOIN ACCOUNT_CONFIG C ON C.ACCT_TYPE = B.ACCT_TYPE"
				+ " WHERE LOAN_STATUS = 'A' AND EMI_DUE_DATE <= DATE(NOW())";

		logger.debug("Runnng query : {}", query);
		List<CreditTO> loans = jdbcTemplate.query(query, new LoanMapper());
		logger.debug("Loans for emi payment : {}", loans);
		return loans;
	}

	/**
	 * Fetches last installment details of a loan account
	 * 
	 * @param custId
	 * @param loanAcct
	 * @return AmortizationDTO 
	 */
	public AmortizationDTO fetchLastInstallmentForLoan(int custId, String loanAcct) {

		String query = "SELECT INSTALLMENT_NO, CLOSING_PRINCIPAL, INTEREST_RATE FROM AMORTIZATION WHERE CUST_ID = "
				+ custId + " AND LOAN_ACCT_NO = " + loanAcct + " AND INSTALLMENT_NO IN "
				+ "(SELECT MAX(INSTALLMENT_NO) FROM AMORTIZATION WHERE CUST_ID = " + custId + " AND LOAN_ACCT_NO = '"
				+ loanAcct + "')";

		logger.debug("Runnng query : {}", query);
		AmortizationDTO amortDTO = null;
		List<AmortizationDTO> installments = jdbcTemplate.query(query, new AmortizationMapper());

		if (!installments.isEmpty()) {
			amortDTO = installments.get(0);
		}
		logger.debug("Last installment for loan : {}", amortDTO);
		return amortDTO;
	}

	/**
	 * Creates a new installment for EMI payment
	 * 
	 * @param amortDTO
	 */
	public void createInstallment(AmortizationDTO amortDTO) {

		String query = "INSERT INTO AMORTIZATION (CUST_ID, INSTALLMENT_NO, LOAN_ACCT_NO, CLOSING_PRINCIPAL,"
				+ " INSTALLMENT_AMOUNT, INSTALLMENT_DATE, INTEREST_COMPONENT, INTEREST_RATE, LST_UPDT_ID,"
				+ " LST_UPDT_TS, OPENING_PRINCIPAL, PRINCIPAL_COMPONENT) VALUES(" + amortDTO.getCustId() + ","
				+ amortDTO.getInstallmentNo() + ",'" + amortDTO.getLoanAcctNo() + "'," + amortDTO.getClosingPrincipal() + ","
				+ amortDTO.getInstallmentAmount() + ",'" + amortDTO.getInstallmentDate() + "'," + amortDTO.getInterestComponent() + ","
				+ amortDTO.getInterestRate() + "," + " 'admin', NOW(), " + amortDTO.getOpeningPrincipal() + "," + amortDTO.getPrincipalComponent() + ")";

		logger.debug("Runnng query : {}", query);

		int count = jdbcTemplate.update(query);
		logger.info("{} record inserted into Amortization table", count);

	}
	
	/**
	 * Updates the existing loan record 
	 * 
	 * @param loanDTO
	 * @param amortDTO
	 */
	public void updateLoanAccount(LoanAccountDTO loanDTO, AmortizationDTO amortDTO) {

		if (BigDecimal.valueOf(0).compareTo(amortDTO.getClosingPrincipal().setScale(0, RoundingMode.FLOOR)) == 0) {
			String query = "UPDATE LOAN_ACCOUNT l SET l.LOAN_STATUS='C',EMI_DUE_DATE = NULL WHERE l.LOAN_ACCT_NO = '"
					+ loanDTO.getLoanAcctNo() + "'";
			
			logger.debug("Runnng query : {}", query);
			int count = jdbcTemplate.update(query);
			
			logger.info("{} record updated in loan_account table", count);
			logger.info("Loan {} is closed", loanDTO.getLoanAcctNo());
			return;
		}

		LocalDate nxtEmi = new java.sql.Date(amortDTO.getInstallmentDate().getTime()).toLocalDate();
		Date emiDueDate = java.sql.Date.valueOf(nxtEmi.plusDays(1));

		String query = "UPDATE LOAN_ACCOUNT SET EMI_DUE_DATE = '" + emiDueDate + "' WHERE LOAN_ACCT_NO = '"
				+ loanDTO.getLoanAcctNo() + "'";
		
		logger.debug("Runnng query : {}", query);
		int count = jdbcTemplate.update(query);

		logger.info("{} record updated in loan_account table", count);
	}

}
