package com.infosys.infybank.core.persistence;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.business.NotificationService;
import com.infosys.infybank.core.to.CreditTO;
 
@Repository
public class FundTransferDAO {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	AccountDAO acctDAO;

	@Autowired
	NotificationService notificationService;

	public boolean transferfund() {
		return false;
	}

	/**
	 * Fetches all fund transfers that are pending for today
	 * 
	 * @return List of Fund Transfers in CreditTO objects
	 */
	public List<CreditTO> fetchPendingFundTransfers() {

		String query = "SELECT F.FT_ID, FC.CUST_ID FROM_CUSTOMER, FC.EMAIL_ID FROM_EMAIL, F.FT_AMOUNT, F.FROM_ACCT"
				+ ", TA.ACCT_NO, TC.CUST_ID TO_CUSTOMER, TC.EMAIL_ID TO_EMAIL, AC.MIN_BALANCE, F.LST_UPDT_TS"
				+ " FROM FUND_TRANSFER F INNER JOIN BANK_ACCOUNT FA ON F.FROM_ACCT = FA.ACCT_NO INNER JOIN CUSTOMER FC ON FA.CUST_ID = FC.CUST_ID"
				+ " INNER JOIN PAYEE P ON F.PAYEE_ID = P.PAYEE_ID INNER JOIN BANK_ACCOUNT TA ON TA.ACCT_NO = P.ACCT_NO"
				+ " INNER JOIN CUSTOMER TC ON TC.CUST_ID = TA.CUST_ID INNER JOIN ACCOUNT_CONFIG AC ON FA.ACCT_TYPE = AC.ACCT_TYPE"
				+ " WHERE F.FT_TYPE ='S' and DATE(F.FT_DATE)<=DATE(NOW()) AND F.STATUS = 'P' UNION ALL"
				+ " SELECT F.FT_ID, FA.CUST_ID FROM_CUSTOMER, C.EMAIL_ID FROM_EMAIL, F.FT_AMOUNT, F.FROM_ACCT"
				+ ", F.TO_ACCT, FA.CUST_ID TO_CUSTOMER, C.EMAIL_ID TO_EMAIL, AC.MIN_BALANCE, F.LST_UPDT_TS"
				+ " FROM FUND_TRANSFER F INNER JOIN BANK_ACCOUNT FA ON F.FROM_ACCT = FA.ACCT_NO" 
				+ " INNER JOIN CUSTOMER C ON FA.CUST_ID = C.CUST_ID INNER JOIN ACCOUNT_CONFIG AC ON FA.ACCT_TYPE = AC.ACCT_TYPE"
				+ " WHERE F.FT_TYPE = 'O' AND DATE(F.FT_DATE) <= DATE(NOW()) AND F.STATUS = 'P' ORDER BY LST_UPDT_TS ASC";

		logger.debug("Runnng query : {}", query);
		List<CreditTO> transfers = jdbcTemplate.query(query, new FundTransferMapper());
		logger.debug("Pending Transfer Details : {}", transfers);

		return transfers;
	}

	/**
	 * Fetches balance details of From and To Accounts for Fund Transfer
	 * 
	 * @param acctNo
	 *            Account No. for which details are required
	 * @return Account details in CreditTO object
	 */
	public CreditTO fetchBalanceForFromAndToAccount(String fromAcctNo, String toAcctNo) {

		CreditTO creditTO = null;

		String query = "SELECT FA.ACCT_NO, FA.BALANCE, TA.ACCT_NO, TA.BALANCE FROM BANK_ACCOUNT FA CROSS JOIN BANK_ACCOUNT TA "
				+ "WHERE FA.ACCT_NO = '" + fromAcctNo + "' AND TA.ACCT_NO = '" + toAcctNo + "'";

		logger.debug("Runnng query : {}", query);
		List<CreditTO> bankAccts = jdbcTemplate.query(query, new FromToAccountMapper());

		if (!bankAccts.isEmpty()) {
			creditTO = bankAccts.get(0);
		}
		logger.debug("Balance details for from and to accounts are : {}", creditTO);

		return creditTO;

	}

	/**
	 * Marks a particular fund transfer as completed
	 * 
	 * @param ftId
	 */
	public void markFundTransferAsCompleted(int ftId) {

		String query = "UPDATE FUND_TRANSFER F SET STATUS = 'C' WHERE FT_ID = " + ftId;
		logger.debug("Runnng query : {}", query);
		jdbcTemplate.update(query);
		logger.debug("Fund Transfer with id {} marked as completed.", ftId);
	}

}