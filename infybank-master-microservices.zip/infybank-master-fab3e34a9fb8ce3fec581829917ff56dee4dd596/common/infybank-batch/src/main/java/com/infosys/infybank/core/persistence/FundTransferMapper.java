package com.infosys.infybank.core.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infosys.infybank.core.to.CreditTO;
 
public final class FundTransferMapper implements RowMapper<CreditTO> {
    
    public CreditTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		CreditTO creditTO = new CreditTO();
		creditTO.setRefId("" + rs.getInt(1));
		creditTO.setCustId(rs.getInt(2));
		creditTO.setEmailId(rs.getString(3));
		creditTO.setAmount(rs.getBigDecimal(4));
		creditTO.setAcctNo(rs.getString(5));
		creditTO.setToAccount(rs.getString(6));
		creditTO.setToCustId(rs.getInt(7));;
		creditTO.setToEmailId(rs.getString(8));
		creditTO.setMinBal(rs.getBigDecimal(9));
        return creditTO;
    }
}