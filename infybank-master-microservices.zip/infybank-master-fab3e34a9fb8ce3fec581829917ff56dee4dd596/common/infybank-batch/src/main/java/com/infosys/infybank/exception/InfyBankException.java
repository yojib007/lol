package com.infosys.infybank.exception;
 
/**
 * The Class InfyBankException.
 */
public class InfyBankException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** The error code. */
	private final String errorCode;
	
	/**
	 * Instantiates a new infy bank service exception.
	 *
	 * @param code
	 *            the code
	 * @param message
	 *            the message
	 */
	public InfyBankException(String code, String message) {
		super(message);
		this.errorCode = code;

	}

	/**
	 * Gets the error code.
	 *
	 * @return the error code
	 */
	public String getErrorCode() {
		return errorCode;
	}


}
