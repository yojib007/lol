package com.infosys.infybank.client;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.core.business.BatchService;

public class InfyBankBatchJob {

	private static Logger logger = LoggerFactory.getLogger(InfyBankBatchJob.class);

	ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

	public static void main(String[] args) {
		if (args[0] != null) {
			logger.debug("Batch Processing starting with batch type {}", args[0]);
			new InfyBankBatchJob().process(args[0]);
		}
	}

	void process(String arg) {
		BatchService service = (BatchService) ctx.getBean("batchService");
		service.processBatch(arg);
	}

}