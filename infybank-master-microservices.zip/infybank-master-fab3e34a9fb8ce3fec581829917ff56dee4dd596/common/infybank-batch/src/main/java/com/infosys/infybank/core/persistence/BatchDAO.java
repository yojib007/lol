package com.infosys.infybank.core.persistence;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
 
@Repository
public class BatchDAO {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	JdbcTemplate jdbcTemplate;

	/**
	 * Checks if a batch has already run for the day
	 * 
	 * @param batchType
	 * @param txnDate
	 * @return boolean indicating batch has run or not
	 */
	public boolean hasBatchRunAlready(String batchType, Date txnDate) {

		String query = "SELECT BATCH_ID FROM BATCH_STATUS WHERE CREDIT_TYPE = '" + batchType + "' and TXN_DATE = '"
				+ txnDate + "' AND STATUS = 'S' LIMIT 1";

		try {
			logger.debug("Runnng query : {}", query);
			jdbcTemplate.queryForObject(query, Integer.class);
		} catch (EmptyResultDataAccessException e) {
			return false;
		}
		return true;
	}

	/**
	 * Creates a record in Batch table for a given batch type and date
	 * 
	 * @param batchType
	 * @param txnDate
	 */
	public void createBatch(String batchType, Date txnDate) {

		String query = "INSERT INTO BATCH_STATUS (CREDIT_TYPE, TXN_DATE, STATUS)" + " VALUES('" + batchType + "','"
				+ txnDate + "','S')";

		logger.debug("Runnng query : {}", query);
		int count = jdbcTemplate.update(query);
		logger.info("{} record inserted into Batch Status table", count);
	}
}
