package com.infosys.infybank.core.persistence;
 
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infosys.infybank.core.to.CreditTO;

public final class LoanMapper implements RowMapper<CreditTO> {

	public CreditTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		CreditTO creditTO = new CreditTO();
		creditTO.setCustId(rs.getInt(1));
		creditTO.setAcctNo(rs.getString(2));
		creditTO.setEmi(rs.getBigDecimal(3));
		creditTO.setToAccount(rs.getString(4));
		creditTO.setMinBal(rs.getBigDecimal(5));
		creditTO.setEmiDueDate(rs.getDate(6));
		creditTO.setAmount(rs.getBigDecimal(7));
		creditTO.setInterestRate(rs.getBigDecimal(8));
		return creditTO;
	}
}