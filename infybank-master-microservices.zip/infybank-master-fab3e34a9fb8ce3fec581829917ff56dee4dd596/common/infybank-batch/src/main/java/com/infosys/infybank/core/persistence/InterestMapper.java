package com.infosys.infybank.core.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infosys.infybank.core.to.CreditTO;
 
public final class InterestMapper implements RowMapper<CreditTO> {
    
    public CreditTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		CreditTO creditTO = new CreditTO();
		creditTO.setCustId(rs.getInt(1));
		creditTO.setAcctNo(rs.getString(2));
		creditTO.setBalance(rs.getBigDecimal(3));
		creditTO.setInterestRate(rs.getBigDecimal(4));
		creditTO.setUserId(rs.getString(5));
		creditTO.setAcctType(rs.getString(6).charAt(0));
		creditTO.setEmailId(rs.getString(7));
        return creditTO;
    }
}