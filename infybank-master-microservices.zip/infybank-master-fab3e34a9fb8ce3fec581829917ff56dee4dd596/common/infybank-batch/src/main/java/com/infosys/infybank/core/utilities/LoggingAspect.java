package com.infosys.infybank.core.utilities;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * The Class LoggingAspect.
 */
@Aspect
@Component
public class LoggingAspect {

	/** The logger. */
	private Logger logger = null;

	/**
	 * Log around all methods.
	 *
	 * @param joinPoint
	 *            the join point
	 * @return the object
	 * @throws Throwable
	 *             the throwable
	 */
	@Around("execution(* com.infosys.infybank.core..*(..)) ")
	public Object logAroundAllMethods(ProceedingJoinPoint joinPoint) throws Throwable {
		getLog(joinPoint);
		long startTime = System.currentTimeMillis();
		String className = joinPoint.getSignature().getDeclaringTypeName();
		String methodName = joinPoint.getSignature().getName();

		logger.info("{} : Entering into {} with param {}", className, methodName);
		String s = Arrays.toString(joinPoint.getArgs());
		logger.info("Param passed is {}", s);
		Object result = joinPoint.proceed();

		long endTime = System.currentTimeMillis();

		logger.info("{} : Exiting {}  ", className, methodName);
		logger.info("with result {} -- execution completed in {} ms", result, endTime - startTime);
		
		return result;
	}

	protected void getLog(JoinPoint jp) {
		logger = LoggerFactory.getLogger(jp.getTarget().getClass());

	}

}