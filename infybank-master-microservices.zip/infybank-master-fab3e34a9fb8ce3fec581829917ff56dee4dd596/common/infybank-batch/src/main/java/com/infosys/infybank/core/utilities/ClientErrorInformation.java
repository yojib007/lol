package com.infosys.infybank.core.utilities;

/**
 * The Class ClientErrorInformation.
 */
public class ClientErrorInformation {

	int errorCode;

	String errorMsg;

	/**
	 * Sets the error code.
	 *
	 * @param value
	 *            the new error code
	 */
	public void setErrorCode(int value) {
		errorCode = value;

	}

	/**
	 * Sets the message.
	 *
	 * @param msg
	 *            the new message
	 */
	public void setMessage(String msg) {
		errorMsg = msg;

	}

	/**
	 * Gets the error msg.
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Gets the error code.
	 *
	 * @return the error code
	 */
	public int getErrorCode() {
		return errorCode;
	}

}
