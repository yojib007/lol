package com.infosys.infybank.core.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infosys.infybank.core.to.CreditTO;
  
public final class FromToAccountMapper implements RowMapper<CreditTO> {
    
    public CreditTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		CreditTO creditTO = new CreditTO();
		creditTO.setAcctNo(rs.getString(1));
		creditTO.setBalance(rs.getBigDecimal(2));
		creditTO.setToAccount(rs.getString(3));
		creditTO.setToBalance(rs.getBigDecimal(4));
        return creditTO;
    }
}