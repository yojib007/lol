package com.infosys.infybank.core.utilities;



public final class CommonUtil {
	private CommonUtil(){
	
	}
	
}
