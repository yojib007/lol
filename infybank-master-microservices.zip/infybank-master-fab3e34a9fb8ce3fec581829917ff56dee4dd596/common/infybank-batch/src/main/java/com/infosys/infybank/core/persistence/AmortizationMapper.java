package com.infosys.infybank.core.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infosys.infybank.core.to.AmortizationDTO;
 
public final class AmortizationMapper implements RowMapper<AmortizationDTO> {

	public AmortizationDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		AmortizationDTO amortDTO = new AmortizationDTO();
		amortDTO.setInstallmentNo(rs.getInt(1));
		amortDTO.setClosingPrincipal(rs.getBigDecimal(2));
		amortDTO.setInterestRate(rs.getBigDecimal(3));
		return amortDTO;
	}
}