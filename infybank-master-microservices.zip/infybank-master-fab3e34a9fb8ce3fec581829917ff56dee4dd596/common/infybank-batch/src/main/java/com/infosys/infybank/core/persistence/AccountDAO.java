package com.infosys.infybank.core.persistence;

import java.math.BigDecimal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.to.CreditTO;
 
@Repository
public class AccountDAO {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	JdbcTemplate jdbcTemplate;

	/**
	 * Fetches all bank accounts to which interest has to be credited
	 * 
	 * @return List of Accounts in CreditTO objects
	 */
	public List<CreditTO> fetchAcctsForInterestCredit() {

		String query = "SELECT B.CUST_ID, B.ACCT_NO, B.BALANCE, A.INTEREST_RATE, A.LST_UPDT_ID, A.ACCT_TYPE, C.EMAIL_ID"
				+ " FROM ACCOUNT_CONFIG A INNER JOIN BANK_ACCOUNT B ON A.ACCT_TYPE = B.ACCT_TYPE INNER JOIN CUSTOMER C ON B.CUST_ID = C.CUST_ID"
				+ " WHERE A.INTEREST_RATE > 0.0";

		logger.debug("Runnng query : {}", query);
		List<CreditTO> bankAccts = jdbcTemplate.query(query, new InterestMapper());
		logger.debug("Accounts for interest credit : {}", bankAccts);

		return bankAccts;
	}

	/**
	 * Fetches details of a particular account for salary credit
	 * 
	 * @param acctNo
	 *            Account No. for which details are required
	 * @return Account details in CreditTO object
	 */
	public CreditTO fetchAcctForSalaryCredit(String acctNo) {

		CreditTO creditTO = null;
		String query = "SELECT B.CUST_ID, B.ACCT_NO, B.BALANCE, C.EMAIL_ID FROM BANK_ACCOUNT B INNER JOIN CUSTOMER C ON B.CUST_ID = C.CUST_ID WHERE B.ACCT_NO = '"
				+ acctNo + "' AND B.SALARIED = 'Y'";

		logger.debug("Runnng query : {}", query);
		List<CreditTO> bankAccts = jdbcTemplate.query(query, new SalaryMapper());

		if (!bankAccts.isEmpty()) {
			creditTO = bankAccts.get(0);
		}
		logger.debug("Accounts details for salary credit : {}", creditTO);

		return creditTO;

	}

	/**
	 * Fetches balance details of a single account
	 * 
	 * @param acctNo
	 *            Account No. for which details are required
	 * @return Account details in CreditTO object
	 */
	public BigDecimal fetchAccountBalance(String acctNo) {

		String query = "SELECT BALANCE FROM BANK_ACCOUNT WHERE ACCT_NO = ?";

		logger.debug("Runnng query : {}", query);
		
		BigDecimal balance = jdbcTemplate.queryForObject(query, new Object[]{acctNo}, BigDecimal.class);

		logger.debug("Balance for account {} is : {}", acctNo, balance);

		return balance;

	}
	/**
	 * Updates balance for a given bank account
	 * 
	 * @param creditTO
	 */
	public void updateBalanceForAccount(CreditTO creditTO) {

		String query1 = "UPDATE BANK_ACCOUNT SET BALANCE = " + creditTO.getNewBalance() + ", LST_UPDT_TS = NOW(),"
				+ "LST_UPDT_ID = 'admin' WHERE ACCT_NO = '" + creditTO.getAcctNo() + "'";

		logger.debug("Runnng query : {}", query1);
		int count = jdbcTemplate.update(query1);
		logger.info("Balance updated for {} record in Bank Account table", count);
		createAccountTransaction(creditTO);
	}

	/**
	 * Creates a record in Account Transaction table
	 * 
	 * @param creditTO
	 */
	public void createAccountTransaction(CreditTO creditTO) {

		BigDecimal amount = creditTO.getNewBalance().subtract(creditTO.getBalance()).abs();
		
		String refId = (creditTO.getRefId() == null) ? "NULL" : "'" + creditTO.getRefId() + "'";

		String query = "INSERT INTO ACCOUNT_TRANSACTION (ACCT_NO, CLOSING_BAL, CUST_ID, LST_UPDT_ID, OPENING_BAL, REMARKS, TXN_AMOUNT, TXN_TYP, TXN_DATE, TXN_CATEGORY, REF_ID) "
				+ "VALUES('" + creditTO.getAcctNo() + "'," + creditTO.getNewBalance() + "," + creditTO.getCustId()
				+ ",'admin'," + creditTO.getBalance() + ",'" + creditTO.getRemarks() + "'," + amount + ",'"
				+ creditTO.getTxnType() + "','" + new java.sql.Date(creditTO.getCreditDate().getTime()) + "','"
				+ creditTO.getBatchType() + "'," + refId + ")";

		logger.debug("Runnng query : {}", query);
		int count = jdbcTemplate.update(query);
		logger.info("{} record inserted into Account Transaction table", count);

	}
}
