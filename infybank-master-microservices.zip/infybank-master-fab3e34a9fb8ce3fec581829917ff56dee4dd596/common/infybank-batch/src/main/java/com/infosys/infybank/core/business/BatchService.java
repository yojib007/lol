package com.infosys.infybank.core.business;


import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.infosys.infybank.core.persistence.AccountDAO;
import com.infosys.infybank.core.persistence.BatchDAO;
import com.infosys.infybank.core.persistence.CreditRepository;
import com.infosys.infybank.core.persistence.FundTransferDAO;
import com.infosys.infybank.core.persistence.LoanDAO;
import com.infosys.infybank.core.to.AmortizationDTO;
import com.infosys.infybank.core.to.CreditTO;
import com.infosys.infybank.core.to.LoanAccountDTO;
import com.infosys.infybank.core.utilities.RegexUtil;

@Service
public class BatchService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private static final String EXCEPTION_MESSAGE = "Exception occurred with following stack trace : ";

	@Autowired
	CreditRepository creditRepo;

	@Autowired
	FundTransferDAO ftdao;

	@Autowired
	BatchDAO batchDAO;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	AccountDAO acctDAO;

	@Autowired
	LoanDAO loanDAO;

	@Autowired
	NotificationService notificationService;

	/**
	 * The core entry point for processing all batch types
	 * 
	 * @param batchType
	 */
	public void processBatch(String batchType) {

		Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		if (!batchDAO.hasBatchRunAlready(batchType, date)) {
			if ("I".equals(batchType)) {
				logger.debug("Starting Interest Credit Batch");
				creditInterest(batchType, date);
			} else if ("S".equals(batchType)) {
				logger.debug("Starting Salary Credit Batch");
				creditSalary(batchType, date);
			} else if ("F".equals(batchType)) {
				logger.debug("Starting Fund Transfer Batch");
				transferFund(batchType, date);
			} else if ("N".equals(batchType)) {
				logger.debug("Starting Pay Installment Batch");
				payInstallment(batchType, date);
			} else {
				logger.error(
						"Batch Type is invalid. Supported values are: I (Interest Credit), S (Salary Credit), F (Fund Transfer) and N (EMI Payment) batches are supported.");
				return;
			}

			batchDAO.createBatch(batchType, date);

		} else {
			logger.debug("Batch Processing already completed for today");
		}
	}

	/**
	 * Business logic for Interest Credit batch
	 * 
	 * @param batchType
	 * @param creditDate
	 */
	public void creditInterest(String batchType, Date creditDate) {
		try {
			char txnType = 'C';
			List<CreditTO> bankAccts = acctDAO.fetchAcctsForInterestCredit();

			if (bankAccts.isEmpty()) {
				logger.debug("No accounts found for interest credit");
			}

			for (CreditTO creditTO : bankAccts) {
				creditTO.setTxnType(txnType);
				creditTO.setCreditDate(creditDate);
				creditTO.setBatchType(batchType);
				BigDecimal rate = creditTO.getInterestRate().divide(BigDecimal.valueOf(100.0));
				BigDecimal interestAmount = creditTO.getBalance().multiply(rate);
				creditTO.setNewBalance(interestAmount.add(creditTO.getBalance()));
				creditTO.setRemarks("Interest Credit");
				logger.debug("Data to be updated : {}", creditTO);
				acctDAO.updateBalanceForAccount(creditTO);
				notificationService.emailNotificationForInterest(creditTO);
			}
		} catch (Exception e) {
			logger.error(EXCEPTION_MESSAGE, e);
		}
	}

	/**
	 * Business logic for Salary Credit batch
	 * 
	 * @param batchType
	 * @param creditDate
	 */
	public void creditSalary(String batchType, Date creditDate) {
		try {
			List<CreditTO> creditTOs = new RegexUtil().readSalaryFile();
			logger.debug("Fetched {} records for salary credit", creditTOs.size());
			logger.debug("Salary Credit Records {}", creditTOs);

			// Processing each record in file one by one
			for (CreditTO fileRec : creditTOs) {
				CreditTO creditTO = acctDAO.fetchAcctForSalaryCredit(fileRec.getAcctNo());

				if (creditTO != null) {
					creditTO.setBatchType(batchType);
					creditTO.setCreditDate(new java.sql.Date(creditDate.getTime()));
					creditTO.setTxnType('C');
					BigDecimal newBalance = (fileRec.getSalary().signum() > 0)
							? creditTO.getBalance().add(fileRec.getSalary()) : creditTO.getBalance();
					creditTO.setNewBalance(newBalance);
					creditTO.setSalary(fileRec.getSalary());
					creditTO.setRemarks("Salary Credit");
					acctDAO.updateBalanceForAccount(creditTO);
					notificationService.emailNotificationForSalary(creditTO);
				} else {
					logger.debug("Account {} is not a salaried acocunt hence salary not credited", fileRec.getAcctNo());
				}
			}
		} catch (Exception e) {
			logger.error(EXCEPTION_MESSAGE, e);

		}
	}

	/**
	 * Business logic for Fund Transfer batch
	 * 
	 * @param batchType
	 * @param creditDate
	 */
	public void transferFund(String batchType, Date creditDate) {
		try {
			logger.debug("Starting process for same bank Account");
			List<CreditTO> transfers = ftdao.fetchPendingFundTransfers();

			if (transfers.isEmpty()) {
				logger.debug("No Fund Transfer records found");
				return;
			}

			for (CreditTO creditTO : transfers) {

				// fetch account balance for both from and to accounts
				// this is not fetched in the initial query because balance will
				// change after each fund transfer
				CreditTO balanceDetails = ftdao.fetchBalanceForFromAndToAccount(creditTO.getAcctNo(),
						creditTO.getToAccount());

				// debit from account and send email notification
				creditTO.setTxnType('D');
				creditTO.setBatchType(batchType);
				creditTO.setCreditDate(new Date());
				creditTO.setRemarks("Scheduled Fund Transfer");
				creditTO.setBalance(balanceDetails.getBalance());
				creditTO.setNewBalance(balanceDetails.getBalance().subtract(creditTO.getAmount()));
				if (creditTO.getNewBalance().compareTo(creditTO.getMinBal()) < 0) {
					logger.debug(
							"Fund Transfer record {} not processed as balance is becoming lower than minimum balance.",
							creditTO.getRefId());
					continue;
				}
				acctDAO.updateBalanceForAccount(creditTO);
				notificationService.emailNotificationForFundTransfer(creditTO);

				// credit to account and send email notification
				CreditTO to = new CreditTO();
				to.setRefId(creditTO.getRefId());
				to.setCustId(creditTO.getToCustId());
				to.setEmailId(creditTO.getToEmailId());
				to.setAmount(creditTO.getAmount());
				to.setAcctNo(creditTO.getToAccount());
				to.setBalance(balanceDetails.getToBalance());
				to.setNewBalance(balanceDetails.getToBalance().add(creditTO.getAmount()));
				to.setTxnType('C');
				to.setBatchType(batchType);
				to.setCreditDate(new Date());
				to.setRemarks(creditTO.getRemarks());
				acctDAO.updateBalanceForAccount(to);
				notificationService.emailNotificationForFundTransfer(to);

				// mark fund transfer as completed so we do not process
				// duplicate
				ftdao.markFundTransferAsCompleted(Integer.parseInt(creditTO.getRefId()));
			}
		} catch (Exception e) {
			logger.error(EXCEPTION_MESSAGE, e);
		}

	}

	public void payInstallment(String batchType, Date creditDate) {
		try {
			List<CreditTO> loans = loanDAO.fetchLoansForEMIPayment();

			if (loans.isEmpty()) {
				logger.debug("No loans for emi payment.");
			}

			for (CreditTO creditTO : loans) {
				creditTO.setBatchType("N");
				creditTO.setTxnType('D');
				creditTO.setCreditDate(creditDate);
				creditTO.setRemarks("Pay Installment");

				BigDecimal balance = acctDAO.fetchAccountBalance(creditTO.getAcctNo());
				creditTO.setBalance(balance);
				creditTO.setNewBalance(balance.subtract(creditTO.getEmi()));
				if (creditTO.getNewBalance().compareTo(creditTO.getMinBal()) >= 0) {
					acctDAO.updateBalanceForAccount(creditTO);
					updateAmmortizationAndLoanAccount(creditTO);
				} else {
					logger.info("Emi cannot be deducted as the new balance exceeds the min bal limit");
				}
			}

		} catch (Exception e) {
			logger.error(EXCEPTION_MESSAGE, e);
		}
	}
	
	private void updateAmmortizationAndLoanAccount(CreditTO creditTO) {

		AmortizationDTO lastInstallment = loanDAO.fetchLastInstallmentForLoan(creditTO.getCustId(), creditTO.getToAccount());

		LoanAccountDTO loanDTO = new LoanAccountDTO();
		loanDTO.setEmi(creditTO.getEmi());
		loanDTO.setEmiDueDate(creditTO.getEmiDueDate());
		loanDTO.setLoanAmount(creditTO.getAmount());
		loanDTO.setInterestRate(creditTO.getInterestRate());
		loanDTO.setLoanAcctNo(creditTO.getToAccount());
		loanDTO.setCustId(creditTO.getCustId());

		AmortizationDTO amortDTO = new AmortizationDTO();
		if (lastInstallment == null) {
			amortDTO.setInstallmentNo(1);
			amortDTO.setOpeningPrincipal(loanDTO.getLoanAmount());
			amortDTO.setInterestRate(loanDTO.getInterestRate());
		} else {
			amortDTO.setInstallmentNo(lastInstallment.getInstallmentNo() + 1);
			amortDTO.setOpeningPrincipal(lastInstallment.getClosingPrincipal());
			amortDTO.setInterestRate(lastInstallment.getInterestRate());
		}

		amortDTO.setCustId(creditTO.getCustId());
		amortDTO.setLoanAcctNo(creditTO.getToAccount());
		amortDTO.setInstallmentDate(loanDTO.getEmiDueDate());
		amortDTO.setInstallmentAmount(loanDTO.getEmi());
		BigDecimal interestComponent = amortDTO.getOpeningPrincipal()
				.multiply(amortDTO.getInterestRate().divide(new BigDecimal(100)));
		BigDecimal principalComponent = loanDTO.getEmi().subtract(interestComponent);
		amortDTO.setInterestComponent(interestComponent);
		amortDTO.setPrincipalComponent(principalComponent);
		amortDTO.setClosingPrincipal(amortDTO.getOpeningPrincipal().subtract(principalComponent));

		if (amortDTO.getOpeningPrincipal().compareTo(amortDTO.getInstallmentAmount()) < 0) {
			amortDTO.setInstallmentAmount(amortDTO.getOpeningPrincipal().add(interestComponent));
			amortDTO.setPrincipalComponent(amortDTO.getOpeningPrincipal());
			amortDTO.setClosingPrincipal(amortDTO.getOpeningPrincipal().subtract(amortDTO.getPrincipalComponent()));
		}

		//insert a new record into the amortization table
		loanDAO.createInstallment(amortDTO);
		
		//update the loan account
		loanDAO.updateLoanAccount(loanDTO, amortDTO);
	}

}
