package com.infosys.infybank.core.persistence;
 
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infosys.infybank.core.to.CreditTO;

public final class SalaryMapper implements RowMapper<CreditTO> {
    
    public CreditTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		CreditTO creditTO = new CreditTO();
		creditTO.setCustId(rs.getInt(1));
		creditTO.setAcctNo(rs.getString(2));
		creditTO.setBalance(rs.getBigDecimal(3));
		creditTO.setEmailId(rs.getString(4));
        return creditTO;
    }
}