package com.infosys.email.service;
 
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.email.ApplicationProperties;
import com.infosys.email.dto.Email;

@Service
public class EmailService {

	@Autowired
	ApplicationProperties appProps;

	public String sendMail(Email email) throws Exception {

		String status = null;

		String host = appProps.getHost();
		final String userName = appProps.getUserName();
		final String password = appProps.getPassword();

		String toMail = email.getToEmail();

		String from = appProps.getFrom();

		String subject = email.getSubject();
		String messageText = email.getEmailMessage();
		MimeMultipart content = new MimeMultipart("related");

		MimeBodyPart bodyPart = new MimeBodyPart();
		bodyPart.setContent(messageText, "text/html; charset=ISO-8859-1");
		content.addBodyPart(bodyPart);

		boolean sessionDebug = false;

		Properties props = System.getProperties();
		props.put("mail.smtp.starttls.enable", appProps.isTlsEnabled());
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", appProps.getPort());
		props.put("mail.smtp.auth", appProps.isAuth());

		Session mailSession = Session.getInstance(props, new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(userName, password);
			}
		});
		Message message = new MimeMessage(mailSession);
		mailSession.setDebug(sessionDebug);
		message.setContent(messageText, "text/html; charset=utf-8");

		Message msg = new MimeMessage(mailSession);
		msg.setFrom(new InternetAddress(from));
		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toMail));
		msg.setSubject(subject);
		msg.setSentDate(new Date());
		msg.setText(messageText);

		Transport transport = mailSession.getTransport(appProps.getProtocol());
		transport.connect(host, userName, password);

		Transport.send(msg);

		status = appProps.getMessage();

		return status;
	}

}
