package com.infosys.email.controller;

import org.slf4j.Logger; 
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.email.dto.Email;
import com.infosys.email.service.EmailService;

@RestController
public class EmailController{

	@Autowired
	EmailService emailService;
	
	private static final Logger logger = LoggerFactory.getLogger(EmailController.class);
	

	@RequestMapping(value="/sendEmail",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, produces="*/*")
	public String sendEmail(@RequestBody Email email) throws Exception {   
			
		try {
			emailService.sendMail(email);
		} 
		catch (Exception e)	{
			logger.error(e.getMessage(),e);
		}
		return "success";
    }
}


