package com.infosys.email;
 
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * WebMvcConfig.java - a simple class which defines beans for reading from
 * .properties
 * 
 * @author ETA Java
 * @version 1.0
 */
@Configuration // Specifies the class as configuration
@EnableWebMvc // enable Spring MVC
@ComponentScan(basePackages = "com.infy.emailwebservice") // Specifies which package
														// to scan to configure
@PropertySource({ "classpath:application.properties" })														// spring beans
@EnableAspectJAutoProxy // enables AOP


public class WebMvcConfig extends WebMvcConfigurerAdapter {
	
	

}
