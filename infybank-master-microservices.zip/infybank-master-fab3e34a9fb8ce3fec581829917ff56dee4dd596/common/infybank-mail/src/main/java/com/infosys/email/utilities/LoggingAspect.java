package com.infosys.email.utilities;
 
import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * The Class LoggingAspect.
 */
@Aspect
@Component
public class LoggingAspect {

	/** The logger. */
	private Logger logger = null;

	/**
	 * Log around all methods.
	 *
	 * @param joinPoint
	 *            the join point
	 * @return the object
	 * @throws Throwable
	 *             the throwable
	 */
	@Around("execution(* com.infy.emailwebservice.core.service.EmailService.*(..)) )")
	public Object logAroundAllMethods(ProceedingJoinPoint joinPoint) throws Throwable {
		getLog(joinPoint);
		long startTime = System.currentTimeMillis();
		String className = joinPoint.getSignature().getDeclaringTypeName();
		String methodName = joinPoint.getSignature().getName();

		logger.info("{} : Entering into {} with param {}", className, methodName);
		logger.info("Param passed is ", Arrays.toString(joinPoint.getArgs()));
		Object result = joinPoint.proceed();

		long endTime = System.currentTimeMillis();

		logger.info("{} : Exiting {}  ", className, methodName);
		logger.info("with result {} -- execution completed in {} ms", result,(endTime - startTime));
		
		return result; 
	}

	protected void getLog(JoinPoint jp) {
		logger = LoggerFactory.getLogger(jp.getTarget().getClass());

	}

}