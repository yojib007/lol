package com.infosys.extservice;
 
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;

import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * ExternalWebMvcConfig.java - a simple class which defines beans for reading
 * from .properties
 * 
 * @author ETA Java
 * @version 1.0
 */

@Configuration // Specifies the class as configuration
@EnableWebMvc // enable Spring MVC
@ComponentScan(basePackages = "com.infosys.extservice") // Specifies which
														// package to scan to
														// configure spring
														// beans
@EnableMongoRepositories("com.infosys.extservice.repository")
@EnableAspectJAutoProxy // enables AOP
@PropertySource({ "classpath:application.properties", "classpath:messages.properties" })
@Import({ AppConfig.class })
public class WebMvcConfig extends WebMvcConfigurerAdapter {
	/**
	 * ResourceBundleMessageSource bean to access the resource bundle for the
	 * given base names
	 * 
	 * @return MessageSource
	 */
	@Bean
	public MessageSource messageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setBasenames("application", "messages");
		return messageSource;
	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**").allowedOrigins("*");
			}
		};
	}

}
