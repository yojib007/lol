package com.infosys.extservice.service;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.extservice.entity.AadharMaster;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.repository.AadharRepository;


/**
 * The Class AadharService.
 */
@Service
public class AadharService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The aadhar repository. */
	@Autowired
	AadharRepository aadharRepository;

	/**
	 * Perform KYC authentication.
	 *
	 * @param aadharId            the aadhar id
	 * @param firstName            the first name
	 * @param lastName            the last name
	 * @return true, if successful
	 * @throws ExternalServiceException the external service exception
	 */

	public boolean isInputValid(String aadharId, String firstName, String lastName) throws ExternalServiceException {
		if (!(aadharId.matches("[0-9]{12}")))
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_AADHAR_INVALID.toString());
		else if (firstName.length() == 0)
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_FIRSTNAME_INVALID.toString());
		else if (lastName.length() == 0)
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_LASTNAME_INVALID.toString());
		else
			return true;
	}

	/**
	 * Checks if is aadhar valid.
	 *
	 * @param aadharId the aadhar id
	 * @param firstName the first name
	 * @param lastName the last name
	 * @return true, if is aadhar valid
	 * @throws ExternalServiceException the external service exception
	 */
	public boolean isAadharValid(String aadharId, String firstName, String lastName) throws ExternalServiceException {

		AadharMaster aadhar = null;
		boolean valid = false;

		// If input is valid then fetch the aadhar record from the database
		if (isInputValid(aadharId, firstName, lastName)) {
			logger.debug("Input Validation Passed");
			aadhar = aadharRepository.findOne(aadharId);
			logger.debug("Aadhar details from database: {}", aadhar);
		}
		// Aadhar is valid when Aadhar Id, First Name and Last Name match
		if ((aadhar != null) && (aadhar.getFirstName().equalsIgnoreCase(firstName))
				&& (aadhar.getLastName().equalsIgnoreCase(lastName))) {
			logger.debug("Aadhar is valid");
			valid = true;
		}
		return valid;

	}

}
