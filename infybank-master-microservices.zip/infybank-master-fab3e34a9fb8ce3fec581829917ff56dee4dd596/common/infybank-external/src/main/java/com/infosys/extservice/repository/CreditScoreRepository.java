/**
 * 
 */
package com.infosys.extservice.repository;
 
import org.springframework.data.mongodb.repository.MongoRepository;


import com.infosys.extservice.entity.CreditScoreMaster;

/**
 * The Interface CreditScoreRepository.
 */
public interface CreditScoreRepository extends MongoRepository<CreditScoreMaster, String> {

}
