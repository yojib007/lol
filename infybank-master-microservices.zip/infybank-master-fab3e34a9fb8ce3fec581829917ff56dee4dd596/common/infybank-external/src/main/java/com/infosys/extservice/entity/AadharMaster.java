package com.infosys.extservice.entity;
 
import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "aadhar_master")
public class AadharMaster implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String aadharId;

	private String firstName;

	private String lastName;

	/**
	 * Gets the aadhar id.
	 *
	 * @return the aadhar id
	 */
	public String getAadharId() {
		return this.aadharId;
	}

	/**
	 * Sets the aadhar id.
	 *
	 * @param aadharId
	 *            the new aadhar id
	 */
	public void setAadharId(String aadharId) {
		this.aadharId = aadharId;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName
	 *            the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName
	 *            the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "AadharMaster [aadharId=" + aadharId + ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}

}
