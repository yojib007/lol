package com.infosys.extservice.controller;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.extservice.dto.CreditScoreDTO;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.service.CreditScoreService;

@RestController
public class CreditScoreController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CreditScoreService creditScoreService;

	/**
	 * Query with panNo and cibilScore.
	 *
	 * @param panNo
	 *            the pan Number
	 * @param cibilScore
	 *            the Cibil Score
	 * @return cibilScore
	 */

	@RequestMapping(value = "/${project.version}/creditScore", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<CreditScoreDTO> viewCreditScore(@RequestParam("panNo") String panNo)
			throws ExternalServiceException {

		logger.debug("panNo: " + panNo);

		CreditScoreDTO dto = new CreditScoreDTO();
		dto.setCreditScore(creditScoreService.viewCreditScore(panNo));

		logger.debug("{}", dto.toString());
		return new ResponseEntity<CreditScoreDTO>(dto, HttpStatus.OK);

	}
}
/*
 * http://localhost:8081/extservice/v1/creditScore?panNo=SKY1234567
 */
