package com.infosys.extservice.service;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.extservice.dto.IFSCMasterDTO;
import com.infosys.extservice.entity.IFSCMaster;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.repository.IFSCRepository;

/**
 * The Class IFSCService.
 */

@Service
public class IFSCService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	IFSCRepository ifscRepository;

	/**
	 * Ifsc validation
	 *
	 * @param ifscCode
	 *            the ifsc code
	 * @param bankName
	 *            the bank name
	 * @param branchName
	 *            the branch name
	 * @return true, if successful
	 * @throws ExternalServiceException
	 */

	public IFSCMasterDTO isValidIfscCode(String ifscCode) throws ExternalServiceException {
		if (ifscCode.length() == 0) {
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_IFSC_MANDATORY.toString());
		}

		if (!(ifscCode.matches("[0-9A-Za-z]{11}"))) {
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_IFSC_INVALID.toString());
		}
		
		logger.debug("Input Validation passed");
		IFSCMaster ifscMaster = ifscRepository.findOne(ifscCode);

		logger.debug("IFSC Details from database: {}", ifscMaster);
		if (ifscMaster != null) {
			return IFSCMasterDTO.prepareDTO(ifscMaster);
		} else {
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_IFSC_CODE_NOT_FOUND.toString());
		}

	}
}
