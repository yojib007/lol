package com.infosys.extservice.controller;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.extservice.dto.IFSCMasterDTO;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.service.IFSCService;

/**
 * @author Infosys The Class Ifsc Controller.
 */
@RestController
public class IFSCController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	IFSCService ifscService;

	/**
	 * This request handles the request for validating the ifsc code
	 * 
	 * @param ifscCode,
	 *            the Ifsc Code
	 * @param bankName,
	 *            the Bank Name
	 * @param branchName,
	 *            the Branch Name
	 * @return true, if successful
	 * @throws ExternalServiceException
	 */
	@RequestMapping(value = "/${project.version}/ifsc", method = RequestMethod.GET)
	public ResponseEntity<IFSCMasterDTO> validateIfscCode(@RequestParam("ifscCode") String ifscCode)
			throws ExternalServiceException {

		logger.debug("IfscCode: {}", ifscCode);
		IFSCMasterDTO dto = ifscService.isValidIfscCode(ifscCode); 
		logger.debug("{}", dto);
		return new ResponseEntity<IFSCMasterDTO>(dto, HttpStatus.OK);

	}
}
