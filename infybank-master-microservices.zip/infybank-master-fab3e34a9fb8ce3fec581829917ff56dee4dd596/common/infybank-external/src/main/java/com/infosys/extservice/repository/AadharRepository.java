package com.infosys.extservice.repository;
 

import org.springframework.data.mongodb.repository.MongoRepository;


import com.infosys.extservice.entity.AadharMaster;

/**
 * The Interface AadharRepository.
 */
public interface AadharRepository extends MongoRepository<AadharMaster, String>{
	
}