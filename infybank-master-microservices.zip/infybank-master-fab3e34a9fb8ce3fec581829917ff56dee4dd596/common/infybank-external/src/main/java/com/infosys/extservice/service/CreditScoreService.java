package com.infosys.extservice.service;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.extservice.entity.CreditScoreMaster;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.repository.CreditScoreRepository;


/**
 * The Class CreditScoreService.
 */
@Service
public class CreditScoreService {
	
	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The credit score repository. */
	@Autowired
	CreditScoreRepository creditScoreRepository;

	/**
	 * View Credit Score.
	 *
	 * @param panNo the pan no
	 * @return cibil score
	 * @throws ExternalServiceException the external service exception
	 */

	public int viewCreditScore(String panNo) throws ExternalServiceException {

		if (panNo.length() == 0) {
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_PAN_MANDATORY.toString());
		}

		if (!(panNo.matches("[0-9A-Za-z]{10}"))) {
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_PAN_INVALID.toString());
		}
		
		logger.debug("Input Validation passed");

		CreditScoreMaster cibilScoreRet = creditScoreRepository.findOne(panNo);

		logger.debug("CreditScore from database: {}", cibilScoreRet);

		if (cibilScoreRet == null) {
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_CREDITSCORE_NOT_PRESENT.toString());
		}
		return cibilScoreRet.getCibilScore();
	}

}
