/**
 * 
 */
package com.infosys.extservice.controller;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.extservice.dto.AadharDTO;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.service.AadharService;

/**
 * The Class AadharController.
 */
@RestController
public class AadharController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	AadharService aadharService;

	/**
	 * Query with id and name.
	 *
	 * @param aadharId
	 *            the aadhar id
	 * @param firstName
	 *            the first name
	 * @param lastName
	 *            the last name
	 * @return true, if successful
	 * @throws ExternalServiceException
	 */
	@RequestMapping(value = "/${project.version}/aadhar", method = RequestMethod.GET)
	public ResponseEntity<AadharDTO> validateAadharId(@RequestParam("aadharId") String aadharId,
			@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName)
			throws ExternalServiceException {
		
		logger.debug("AadharId: {}, firstName: {}, lastName: {}", new Object[]{aadharId, firstName, lastName});
		AadharDTO dto = new AadharDTO();
		dto.setAadharValid(aadharService.isAadharValid(aadharId, firstName, lastName));

		logger.debug(dto.toString());
		return new ResponseEntity<AadharDTO> (dto, HttpStatus.OK);

	}
}
