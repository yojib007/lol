
package com.infosys.extservice.repository;
 
import org.springframework.data.mongodb.repository.MongoRepository;


import com.infosys.extservice.entity.IFSCMaster;


/**
 * The Interface IFSCRepository.
 */
public interface IFSCRepository extends MongoRepository<IFSCMaster, String> {

}
