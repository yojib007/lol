package com.infosys.extservice;
 
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

import com.mongodb.MongoClient;

/**
 * The Class ExternalAppConfig.
 */
@Configuration
public class AppConfig {

	/** The hostname. */
	@Value("${spring.data.mongodb.hostname}")
	private String hostname;

	/** The port. */
	@Value("${spring.data.mongodb.port}")
	private int port;

	/** The db. */
	@Value("${spring.data.mongodb.database}")
	private String db;

	/**
	 * Mongo db factory.	 *
	 * @return the mongo db factory	
	 */
	@Bean
	public MongoDbFactory mongoDbFactory() {

		return new SimpleMongoDbFactory(new MongoClient(hostname, port), db);
	}

	/**
	 * Mongo template.	 *
	 * @return the mongo template
	 
	 */
	@Bean
	public MongoTemplate mongoTemplate(){
		DbRefResolver dbRefResolver = new DefaultDbRefResolver(mongoDbFactory());
		
		MappingMongoConverter converter = new MappingMongoConverter(dbRefResolver,new MongoMappingContext());
		converter.setTypeMapper(new DefaultMongoTypeMapper(null));

		return new MongoTemplate(mongoDbFactory(), converter);

	}
	
	
}
