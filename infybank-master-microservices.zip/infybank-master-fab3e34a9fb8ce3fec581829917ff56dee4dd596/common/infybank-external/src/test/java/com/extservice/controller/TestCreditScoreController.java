package com.extservice.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.infosys.extservice.WebMvcConfig;
 

/**
 * The Class TestCreditScoreController.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebMvcConfig.class })
@WebAppConfiguration
public class TestCreditScoreController {

	/** The ctx. */
	@Autowired
	private WebApplicationContext ctx;

	/** The mock mvc. */
	private MockMvc mockMvc;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}

	/**
	 * Testcredit score for corresponding pan no.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testcreditScoreForCorrespondingPanNo() throws Exception {
		// fail("Not yet implemented");
		String id = "ABCDE1234F";
		mockMvc.perform(get("/v1/creditScore?panNo={id}", id).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				// .andExpect(jsonPath("$.panNo", is("ABCDE1234F")))
				.andExpect(MockMvcResultMatchers.content().json("400"));

	}

	/**
	 * Test invalid ifsc length.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testInvalidIFSCLength() throws Exception {
		String id = "ABCD12E";
		mockMvc.perform(get("/v1/creditScore?panNo={id}", id).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is5xxServerError()).andExpect(jsonPath("$.errorCode", is(500)))
				.andExpect(jsonPath("$.errorMsg", is("Pan Number must be alphanumeric of size 10")));

		// .andDo(print());
	}

}
