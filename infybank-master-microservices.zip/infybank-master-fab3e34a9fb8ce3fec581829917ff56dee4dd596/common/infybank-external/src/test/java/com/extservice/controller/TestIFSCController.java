package com.extservice.controller;
 
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.infosys.extservice.WebMvcConfig;

/**
 * The Class TestIFSCController.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebMvcConfig.class })

@WebAppConfiguration
public class TestIFSCController {
	
	/** The ctx. */
	@Autowired
	private WebApplicationContext ctx;

	/** The mock mvc. */
	private MockMvc mockMvc;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}
	
	/**
	 * Test valid ifsc.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testValidIFSC() throws Exception {
		String id = "IC001234567";
		mockMvc.perform(get("/v1/ifsc?ifscCode={id}", id).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$.ifscCode", is("IC001234567")))
				.andExpect(jsonPath("$.bankName", is("ICICI Bank")))
				.andExpect(jsonPath("$.branchName", is("JP Nagar")));

		// .andDo(print());
	}

	/**
	 * Test invalid ifsc length.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testInvalidIFSCLength() throws Exception {
		String id = "IC001234";
		mockMvc.perform(get("/v1/ifsc?ifscCode={id}", id).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is5xxServerError()).andExpect(jsonPath("$.errorCode", is(500)))
				.andExpect(jsonPath("$.errorMsg", is("IFSC code must be 11 characters")));

		// .andDo(print());
	}

	/**
	 * Test ifsc does not exist.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testIFSCDoesNotExist() throws Exception {
		String id = "IC001234456";
		mockMvc.perform(get("/v1/ifsc?ifscCode={id}", id).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is5xxServerError()).andExpect(jsonPath("$.errorCode", is(500)))
				.andExpect(jsonPath("$.errorMsg", is("IFSC code not found for the given details")));

		// .andDo(print());
	}
}
