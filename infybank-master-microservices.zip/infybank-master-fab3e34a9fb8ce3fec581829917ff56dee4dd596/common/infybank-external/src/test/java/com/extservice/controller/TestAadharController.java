package com.extservice.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.infosys.extservice.WebMvcConfig;

 
/**
 * The Class TestAadharController.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebMvcConfig.class })
@WebAppConfiguration
public class TestAadharController {

	/** The ctx. */
	@Autowired
	private WebApplicationContext ctx;

	/** The mock mvc. */
	private MockMvc mockMvc;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}
	
	/**
	 * Test validate aadhar id.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testValidateAadharId() throws Exception {
		// fail("Not yet implemented");
		String id = "112233445566";
		mockMvc.perform(get("/v1/aadhar?aadharId={id}&firstName=Tyrion&lastName=Lannister", id)
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
		/*
		 * .andExpect(jsonPath("$.aadharId", is("112233445566")))
		 * .andExpect(jsonPath("$.firstName", is("Tyrion")))
		 * .andExpect(jsonPath("$.lastName", is("Lannister")));
		 */
	}

	/**
	 * Test invalid aadhar length.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testInvalidAadharLength() throws Exception {
		String id = "1122334455";
		mockMvc.perform(get("/v1/aadhar?aadharId={id}&firstName=Tyrion&lastName=Lannister", id)
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().is5xxServerError())
				.andExpect(jsonPath("$.errorCode", is(500)))
				.andExpect(jsonPath("$.errorMsg", is("Aadhar id must be 12 digit number")));
			
		// .andDo(print());
	}
	
	/**
	 * Test aadhar does not exist.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testAadharDoesNotExist() throws Exception {
		String id = "665544332211";
		mockMvc.perform(get("/v1/aadhar?aadharId={id}&firstName=Tyrion&lastName=Lannister", id)
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().is5xxServerError())
				.andExpect(jsonPath("$.errorCode", is(500)))
				.andExpect(jsonPath("$.errorMsg", is("Aadhar not found for the given details")));

		// .andDo(print());
	}

}
