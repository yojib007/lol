package com.extservice.service;
 
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.extservice.AppConfig;
import com.infosys.extservice.dto.IFSCMasterDTO;
import com.infosys.extservice.entity.IFSCMaster;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.repository.IFSCRepository;
import com.infosys.extservice.service.IFSCService;


/**
 * The Class IFSCServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
@TestPropertySource(properties = {
	    "spring.data.mongodb.hostname=testValue",
	    "spring.data.mongodb.port=100",
	    "spring.data.mongodb.database =data"
	})
public class IFSCServiceTest {

	/** The e. */
	@Rule
	public ExpectedException e = ExpectedException.none();
	
	/** The ifsc repository. */
	@Mock
	IFSCRepository ifscRepository;
	
	/** The ifsc service. */
	@InjectMocks
	private IFSCService ifscService;

	/** The ifsc master. */
	private static IFSCMaster ifscMaster;

	/**
	 * Initialise.
	 */
	@BeforeClass
	public static void initialise() {
		ifscMaster = new IFSCMaster();
		ifscMaster.setIfscCode("12312312312");
	}

	/**
	 * Inits the.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test ifsc service with length zero.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void TestIFSCServiceWithLengthZero() throws ExternalServiceException {

		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_IFSC_MANDATORY.toString());

		ifscService.isValidIfscCode("");
	}

	/**
	 * Test ifsc service with length not equal to eleven.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void TestIFSCServiceWithLengthNotEqualToEleven() throws ExternalServiceException {

		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_IFSC_INVALID.toString());

		ifscService.isValidIfscCode("1234567890");
	}

	/**
	 * Test is valid ifsc code with null.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testIsValidIfscCodeWithNull() throws ExternalServiceException {

		Mockito.when(ifscRepository.findOne(Mockito.anyString())).thenReturn(null);
		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_IFSC_CODE_NOT_FOUND.toString());
		ifscService.isValidIfscCode("12345678901");
	}

	/**
	 * Test is valid ifsc code with valid input.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testIsValidIfscCodeWithValidInput() throws ExternalServiceException {

		Mockito.when(ifscRepository.findOne(Mockito.anyString())).thenReturn(ifscMaster);
		org.junit.Assert.assertEquals(IFSCMasterDTO.prepareDTO(ifscMaster).getIfscCode(),
				ifscService.isValidIfscCode("12312312312").getIfscCode());
	}
}