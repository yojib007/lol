package com.extservice.service;
 
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.extservice.AppConfig;
import com.infosys.extservice.entity.AadharMaster;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.repository.AadharRepository;
import com.infosys.extservice.service.AadharService;


/**
 * The Class AadharServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
@TestPropertySource(properties = {
	    "spring.data.mongodb.hostname=testValue",
	    "spring.data.mongodb.port=100",
	    "spring.data.mongodb.database =data"
	})
public class AadharServiceTest {
	
	/** The aadhar repository. */
	@Mock
	AadharRepository aadharRepository;
	
	/** The aadhar service. */
	@InjectMocks
	AadharService aadharService;
	
	/** The e. */
	@Rule
	public ExpectedException e = ExpectedException.none();

	/**
	 * Initialise.
	 */
	@Before
	public void initialise() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test is input valid with invalid aadhar id.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testIsInputValidWithInvalidAadharId() throws ExternalServiceException {
		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_AADHAR_INVALID.toString());
		aadharService.isInputValid("1234567891447", "", "");

	}

	/**
	 * Test is valid input details with invalid first name.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testIsValidInputDetailsWithInvalidFirstName() throws ExternalServiceException {

		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_FIRSTNAME_INVALID.toString());
		aadharService.isInputValid("123456789144", "", "");
	}

	/**
	 * Test is valid input details with invalid last name.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testIsValidInputDetailsWithInvalidLastName() throws ExternalServiceException {

		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_LASTNAME_INVALID.toString());
		aadharService.isInputValid("123456789144", "abhishek", "");
	}

	/**
	 * Test is valid input details with valid.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testIsValidInputDetailsWithValid() throws ExternalServiceException {

		assertTrue(aadharService.isInputValid("123456789144", "abhishek", "saxena"));
	}

	/**
	 * Test is valid aadhar id with null.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testIsValidAadharIdWithNull() throws ExternalServiceException {

		Mockito.when(
				aadharRepository.findOne(Mockito.anyString()))
				.thenReturn(null);
		assertFalse(aadharService.isAadharValid("123456789012", "a", "b"));
	}

	/**
	 * Test is valid aadhar id without null.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testIsValidAadharIdWithoutNull() throws ExternalServiceException {
		AadharMaster a = new AadharMaster();
		a.setAadharId("123456789012");
		a.setFirstName("a");
		a.setLastName("b");
		Mockito.when(
				aadharRepository.findOne(Mockito.anyString()))
				.thenReturn(a);
		assertTrue(aadharService.isAadharValid("123456789012", "a", "b"));
	}

}
