package com.extservice.service;
 
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.extservice.AppConfig;
import com.infosys.extservice.entity.CreditScoreMaster;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.repository.CreditScoreRepository;
import com.infosys.extservice.service.CreditScoreService;

/**
 * The Class ViewCreditScoreTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
@TestPropertySource(properties = {
	    "spring.data.mongodb.hostname=testValue",
	    "spring.data.mongodb.port=100",
	    "spring.data.mongodb.database =data"
	})
public class ViewCreditScoreTest {
	
	/** The credit score repository. */
	@Mock
	CreditScoreRepository creditScoreRepository;

	/** The credit score service. */
	@InjectMocks
	private static CreditScoreService creditScoreService;

	/** The pan no. */
	String panNo;
	
	/** The e. */
	@Rule
	public ExpectedException e = ExpectedException.none();

	/**
	 * Initialise.
	 */
	@Before
	public void initialise() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test view credit score pan no null.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testViewCreditScorePanNoNull() throws ExternalServiceException {

		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_PAN_MANDATORY.toString());
		creditScoreService.viewCreditScore("");

	}

	/**
	 * Test view credit score pan no not null.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testViewCreditScorePanNoNotNull() throws ExternalServiceException {

		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_PAN_INVALID.toString());
		creditScoreService.viewCreditScore("124356789");
	}

	/**
	 * Test credit score.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testCreditScore() throws ExternalServiceException {

		panNo = "1234567890";
		CreditScoreMaster credit = new CreditScoreMaster();
		credit.setPanNo(panNo);
		Mockito.when(creditScoreRepository.findOne(Mockito.anyString())).thenReturn(credit);
		assertEquals(credit.getCibilScore(), creditScoreService.viewCreditScore(panNo));

	}

	/**
	 * Test credit score null.
	 *
	 * @throws ExternalServiceException the external service exception
	 */
	@Test
	public void testCreditScoreNull() throws ExternalServiceException {

		Mockito.when(creditScoreRepository.findOne(Mockito.anyString())).thenReturn(null);
		e.expect(ExternalServiceException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_CREDITSCORE_NOT_PRESENT.toString());
		creditScoreService.viewCreditScore("ABCD123456");

	}

}