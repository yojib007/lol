package com.infosys.infybank.core.service;
 
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.infybank.core.dto.LoginDTO;
import com.infosys.infybank.core.dto.UserDTO;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.repository.LoginRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class LoginService.
 */
@Service
public class LoginService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	RandomPasswordGeneratorService passwordService;

	/** The login repository. */
	@Autowired
	LoginRepository loginRepo;

	/**
	 * Authenticate the user at the time of login
	 *
	 * @param obj
	 *            the obj
	 * @return the user DTO
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public UserDTO authenticate(LoginDTO obj) throws InfyBankException {

		// Fetch the user details from the database
		Login login = loginRepo.findByUserId(obj.getUserId());
		if (login == null) {
			throw new InfyBankException(ExceptionConstants.LOGIN_ID_INVALID.toString());
		}

		// If user exists then make sure that the password matches. Database
		// stores encrypted password so first we encrypt the user provided
		// password with the same algorithm before comparing
		String userEnteredPwdHash = passwordService.encryptPassword(obj.getPassword());
		logger.info("userEnteredPwdHash {}", userEnteredPwdHash);
		if (!login.getPassword().equals(userEnteredPwdHash)) {
			throw new InfyBankException(ExceptionConstants.LOGIN_ID_INVALID.toString());
		}
		
		// convert entity to dto
		UserDTO userDTO = UserDTO.prepareDTO(login);
		logger.debug("Authentication successful. Details for user : {}", userDTO);
		
		return userDTO;

	}

	/**
	 * Verify whether the user name already exists. It is used during
	 * registration to create a login id for a new customer.
	 *
	 * @param userName
	 *            the user name
	 * @return the list
	 */
	public List<String> getUserIdsStartingWithName(String userName) {
		List<String> users = loginRepo.findUserHavingUserNameLike(userName); 
		logger.debug("Existing users with name {} : {}", userName, users);
		return users;
	}

	/**
	 * Create the login entries for a new user at the time of registration
	 *
	 * @param login
	 *            the login
	 * @return the login
	 */
	public Login saveLoginDetails(Login login) {

		return loginRepo.saveAndFlush(login);
	}

	/**
	 * Gets the login details. It is used for admin functionality to verify that
	 * only user with admin role can perform those operations.
	 *
	 * @param userId
	 *            the user id
	 * @return the login details
	 */
	public Login getLoginDetails(String userId) {

		Login login = loginRepo.findByUserId(userId); 
		logger.debug("Details for user {} : {}", userId, login);
		return login;
	}
}