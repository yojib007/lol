package com.infosys.infybank.fundtransfer.entity;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

/**
 * The Class FundTransfer.
 */
@Entity
@Table(name = "fund_transfer")
public class FundTransfer implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The ft id. */
	@Id

	@Column(name = "FT_ID", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ftId;

	/** The from acct. */
	@Column(name = "FROM_ACCT", nullable = false, length = 20)
	private String fromAcct;

	/** The to acct. */
	@Column(name = "TO_ACCT", length = 20)
	private String toAcct;

	/** The payee id. */
	@Column(name = "PAYEE_ID")
	private int payeeId;

	/** The ft type. */
	@Column(name = "FT_TYPE", nullable = false, length = 1)
	private char ftType;

	/** The ft amount. */
	@Column(name = "FT_AMOUNT", nullable = false, precision = 12, scale = 4)
	private BigDecimal ftAmount;

	/** The remarks. */
	@Column(name = "REMARKS", length = 100)
	private String remarks;

	/** The status. */
	@Column(name = "STATUS", nullable = false, length = 1)
	private char status;

	/** The ft date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "FT_DATE", nullable = false, length = 10)
	private Date ftDate;

	/** The lst updt ts. */
	@Temporal(TemporalType.TIMESTAMP)
	@Generated(GenerationTime.ALWAYS)
	@Column(name = "LST_UPDT_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lstUpdtTs;

	/** The lst updt id. */
	@Column(name = "LST_UPDT_ID", nullable = false, length = 10)
	private String lstUpdtId;

	/**
	 * Gets the ft id.
	 *
	 * @return the ft id
	 */
	public long getFtId() {
		return this.ftId;
	}

	/**
	 * Sets the ft id.
	 *
	 * @param ftId
	 *            the new ft id
	 */
	public void setFtId(long ftId) {
		this.ftId = ftId;
	}

	/**
	 * Gets the from acct.
	 *
	 * @return the from acct
	 */
	public String getFromAcct() {
		return this.fromAcct;
	}

	/**
	 * Sets the from acct.
	 *
	 * @param fromAcct
	 *            the new from acct
	 */
	public void setFromAcct(String fromAcct) {
		this.fromAcct = fromAcct;
	}

	/**
	 * Gets the to acct.
	 *
	 * @return the to acct
	 */
	public String getToAcct() {
		return this.toAcct;
	}

	/**
	 * Sets the to acct.
	 *
	 * @param toAcct
	 *            the new to acct
	 */
	public void setToAcct(String toAcct) {
		this.toAcct = toAcct;
	}

	/**
	 * Gets the payee id.
	 *
	 * @return the payee id
	 */
	public int getPayeeId() {
		return this.payeeId;
	}

	/**
	 * Sets the payee id.
	 *
	 * @param payeeId
	 *            the new payee id
	 */
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	/**
	 * Gets the ft type.
	 *
	 * @return the ft type
	 */
	public char getFtType() {
		return this.ftType;
	}

	/**
	 * Sets the ft type.
	 *
	 * @param ftType
	 *            the new ft type
	 */
	public void setFtType(char ftType) {
		this.ftType = ftType;
	}

	/**
	 * Gets the ft amount.
	 *
	 * @return the ft amount
	 */
	public BigDecimal getFtAmount() {
		return this.ftAmount;
	}

	/**
	 * Sets the ft amount.
	 *
	 * @param ftAmount
	 *            the new ft amount
	 */
	public void setFtAmount(BigDecimal ftAmount) {
		this.ftAmount = ftAmount;
	}

	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return this.remarks;
	}

	/**
	 * Sets the remarks.
	 *
	 * @param remarks
	 *            the new remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public char getStatus() {
		return this.status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status
	 *            the new status
	 */
	public void setStatus(char status) {
		this.status = status;
	}

	/**
	 * Gets the ft date.
	 *
	 * @return the ft date
	 */
	public Date getFtDate() {
		return this.ftDate;
	}

	/**
	 * Sets the ft date.
	 *
	 * @param ftDate
	 *            the new ft date
	 */
	public void setFtDate(Date ftDate) {
		this.ftDate = ftDate;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return this.lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return this.lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	@Override
	public String toString() {
		return "FundTransfer [ftId=" + ftId + ", fromAcct=" + fromAcct + ", toAcct=" + toAcct + ", payeeId=" + payeeId
				+ ", ftType=" + ftType + ", ftAmount=" + ftAmount + ", remarks=" + remarks + ", status=" + status
				+ ", ftDate=" + ftDate + ", lstUpdtTs=" + lstUpdtTs + ", lstUpdtId=" + lstUpdtId + "]";
	}

}
