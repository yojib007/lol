package com.infosys.infybank.core.entity;
 
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

/**
 * The Class Login.
 */
@Entity
@Table(name = "LOGIN")
public class Login implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	@Id

	@Column(name = "CUST_ID", unique = true, nullable = false)
	private int custId;

	/** The user id. */
	@Column(name = "USER_ID", nullable = false, length = 10)
	private String userId;

	/** The password. */
	@Column(name = "PASSWORD", nullable = false, length = 255)
	private String password;

	/** The role. */
	@Column(name = "ROLE", nullable = false, length = 1)
	private char role;

	/** The lst updt ts. */
	@Temporal(TemporalType.TIMESTAMP)
	@Generated(GenerationTime.ALWAYS)
	@Column(name = "LST_UPDT_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lstUpdtTs;

	/** The lst updt id. */
	@Column(name = "LST_UPDT_ID", nullable = false, length = 10)
	private String lstUpdtId;
	

	public Login(){
		/*default constructor*/
	}
	
	public Login(int custId, String userId, String password, char role,String lstUpdtId) {
		super();
		this.custId = custId;
		this.userId = userId;
		this.password = password;
		this.role = role;
		this.lstUpdtId=lstUpdtId;
	}



	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return this.custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId
	 *            the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return this.password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password
	 *            the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the role.
	 *
	 * @return the role
	 */
	public char getRole() {
		return this.role;
	}

	/**
	 * Sets the role.
	 *
	 * @param role
	 *            the new role
	 */
	public void setRole(char role) {
		this.role = role;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return this.lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return this.lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Login [custId=" + custId + ", userId=" + userId + ", password=" + password + ", role=" + role
				+ ", lstUpdtTs=" + lstUpdtTs + ", lstUpdtId=" + lstUpdtId + "]";
	}

}
