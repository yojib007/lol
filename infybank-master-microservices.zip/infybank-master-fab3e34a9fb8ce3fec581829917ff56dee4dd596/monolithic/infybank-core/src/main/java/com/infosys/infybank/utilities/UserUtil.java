package com.infosys.infybank.utilities;
 
import java.util.List;

/**
 * The Class UserUtil.
 */
public class UserUtil {

	private UserUtil(){
		throw new IllegalAccessError("Utility class cannot be instantiated");
	}
	

	/**
	 * Creates the user id.
	 *
	 * @param userIds
	 *            the user list
	 * @param suggestedUserId
	 *            the user id suggestion
	 * @return the string
	 */
	public static String createUserId(List<String> userIds, String suggestedUserId) {
		String userId = suggestedUserId;
		for (int i = 1; i < 100; i++) {
			if (userIds.contains(userId)) {
				userId = suggestedUserId + i;
			}
		}
		return userId;
	}

	/**
	 * Suggest user id from name.
	 *
	 * @param firstName
	 *            the first name
	 * @param lastName
	 *            the last name
	 * @return the string
	 */
	public static String createUserIdFromName(String firstName, String lastName) {
		// extract first 4 characters from first name and last name. Pad with # if name is shorter
		String fName = String.format("%-4.4s", firstName).replace(' ', '#');
		String lName = String.format("%-4.4s", lastName).replace(' ', '#');
		return fName.toLowerCase() + lName.toLowerCase();
	}
	
}