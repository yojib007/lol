package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;
import java.util.List;

/**
 * The Class AmmortizationScheduleDTO.
 */
public class AmortizationScheduleDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The ammortization list. */
	private List<AmortizationDTO> ammortizationList;
	
	/** The total no of installments. */
	private int totalNoOfInstallments;
	
	/**
	 * Gets the ammortization list.
	 *
	 * @return the ammortization list
	 */
	public List<AmortizationDTO> getAmmortizationList() {
		return ammortizationList;
	}
	
	/**
	 * Sets the ammortization list.
	 *
	 * @param ammortizationList the new ammortization list
	 */
	public void setAmmortizationList(List<AmortizationDTO> ammortizationList) {
		this.ammortizationList = ammortizationList;
	}
	
	/**
	 * Gets the total no of installments.
	 *
	 * @return the total no of installments
	 */
	public int getTotalNoOfInstallments() {
		return totalNoOfInstallments;
	}
	
	/**
	 * Sets the total no of installments.
	 *
	 * @param totalNoOfInstallments the new total no of installments
	 */
	public void setTotalNoOfInstallments(int totalNoOfInstallments) {
		this.totalNoOfInstallments = totalNoOfInstallments;
	}

	@Override
	public String toString() {
		return "AmortizationScheduleDTO [ammortizationList=" + ammortizationList + ", totalNoOfInstallments="
				+ totalNoOfInstallments + "]";
	}
	
	
}
