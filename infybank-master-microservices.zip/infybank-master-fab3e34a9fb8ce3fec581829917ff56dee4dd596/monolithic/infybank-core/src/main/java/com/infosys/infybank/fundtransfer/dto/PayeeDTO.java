package com.infosys.infybank.fundtransfer.dto;
 
import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.infosys.infybank.fundtransfer.entity.Payee;

/**
 * The Class PayeeDTO.
 */
public class PayeeDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The payee id. */
	@NotNull(message = "payee.payeeId.mandatory")
	private int payeeId;

	/** The name. */
	@NotBlank(message = "payee.name.mandatory")
	private String name;

	/** The nick name. */
	@NotBlank(message = "payee.nickname.mandatory")
	private String nickName;

	/** The acct no. */
	@NotBlank(message = "payee.acctno.mandatory")
	@Length(min = 10, max = 10, message = "payee.accountNo.size")
	private String acctNo;

	/** The user id. */
	@NotBlank(message = "payee.userId.mandatory")
	private String userId;

	/** The ifsc code. */
	private String ifscCode;

	/** The acct type. */
	private char acctType;

	/** The cust id. */
	private int custId;

	/** The status. */
	private char status;

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the payee id.
	 *
	 * @return the payee id
	 */
	public int getPayeeId() {
		return payeeId;
	}

	/**
	 * Sets the payee id.
	 *
	 * @param payeeId the new payee id
	 */
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the nick name.
	 *
	 * @return the nick name
	 */
	public String getNickName() {
		return nickName;
	}

	/**
	 * Sets the nick name.
	 *
	 * @param nickName the new nick name
	 */
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return acctNo;
	}

	/**
	 * Sets the acct no.
	 *
	 * @param acctNo the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	/**
	 * Gets the acct type.
	 *
	 * @return the acct type
	 */
	public char getAcctType() {
		return acctType;
	}

	/**
	 * Sets the acct type.
	 *
	 * @param acctType the new acct type
	 */
	public void setAcctType(char acctType) {
		this.acctType = acctType;
	}

	/**
	 * Gets the ifsc code.
	 *
	 * @return the ifsc code
	 */
	public String getIfscCode() {
		return ifscCode;
	}

	/**
	 * Sets the ifsc code.
	 *
	 * @param ifscCode the new ifsc code
	 */
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Prepare entity.
	 *
	 * @param payeeDTO the payee dto
	 * @return the payee
	 */
	public static Payee prepareEntity(PayeeDTO payeeDTO) {
		Payee payeeEntity = new Payee();
		payeeEntity.setPayeeId(payeeDTO.getPayeeId());
		payeeEntity.setCustId(payeeDTO.getCustId());
		payeeEntity.setPayeeName(payeeDTO.getName());
		payeeEntity.setNickName(payeeDTO.getNickName());
		payeeEntity.setAcctType(payeeDTO.getAcctType());
		payeeEntity.setAcctNo(payeeDTO.getAcctNo());
		payeeEntity.setIfscCode(payeeDTO.getIfscCode());
		payeeEntity.setLstUpdtId(payeeDTO.getUserId());
		return payeeEntity;
	}

	/**
	 * Prepare dto.
	 *
	 * @param payeeEntity the payee entity
	 * @return the payee dto
	 */
	public static PayeeDTO prepareDTO(Payee payeeEntity) {

		PayeeDTO payeeDTO = new PayeeDTO();
		payeeDTO.setPayeeId(payeeEntity.getPayeeId());
		payeeDTO.setCustId(payeeEntity.getCustId());
		payeeDTO.setName(payeeEntity.getPayeeName());
		payeeDTO.setNickName(payeeEntity.getNickName());
		payeeDTO.setAcctType(payeeEntity.getAcctType());
		payeeDTO.setAcctNo(payeeEntity.getAcctNo());
		payeeDTO.setUserId(payeeEntity.getLstUpdtId());
		payeeDTO.setIfscCode(payeeEntity.getIfscCode());
		payeeDTO.setStatus(payeeEntity.getStatus());
		return payeeDTO;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(char status) {

		this.status = status;

	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public char getStatus() {
		return status;
	}

}
