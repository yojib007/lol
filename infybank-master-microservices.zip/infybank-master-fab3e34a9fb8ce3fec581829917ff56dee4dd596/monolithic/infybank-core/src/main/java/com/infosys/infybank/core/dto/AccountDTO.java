package com.infosys.infybank.core.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.BankAccountId;

/**
 * The Class AccountDTO.
 */
public class AccountDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The acct no. */
	private String acctNo;

	/** The cust id. */
	private int custId;

	/** The acct type. */
	private char acctType;

	/** The balance. */
	@NotNull(message = "balance.mandatory")
	private BigDecimal balance;

	/** The salaried. */
	private char salaried;

	/** The lst updt ts. */
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date lstUpdtTs;

	/** The lst updt id. */
	private String lstUpdtId;
	/** The user id. */
	@NotBlank(message = "userId.format.invalid")
	private String userId;

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId
	 *            the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return acctNo;
	}

	/**
	 * Sets the acct no.
	 *
	 * @param acctNo
	 *            the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the acct type.
	 *
	 * @return the acct type
	 */
	public char getAcctType() {
		return acctType;
	}

	/**
	 * Sets the acct type.
	 *
	 * @param acctType
	 *            the new acct type
	 */
	public void setAcctType(char acctType) {
		this.acctType = acctType;
	}

	/**
	 * Gets the balance.
	 *
	 * @return the balance
	 */
	public BigDecimal getBalance() {
		return balance;
	}

	/**
	 * Sets the balance.
	 *
	 * @param balance
	 *            the new balance
	 */
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	/**
	 * Gets the salaried.
	 *
	 * @return the salaried
	 */
	public char getSalaried() {
		return salaried;
	}

	/**
	 * Sets the salaried.
	 *
	 * @param salaried
	 *            the new salaried
	 */
	public void setSalaried(char salaried) {
		this.salaried = salaried;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	/**
	 * Prepare entity.
	 *
	 * @param accountDTO
	 *            the account DTO
	 * @return the bank account
	 */
	public static BankAccount prepareEntity(AccountDTO accountDTO) {
		BankAccount account = new BankAccount();
		account.setAcctType(accountDTO.getAcctType());
		account.setBalance(accountDTO.getBalance());
		account.setSalaried(accountDTO.getSalaried());
		account.setLstUpdtId(accountDTO.getUserId());
		account.setBankAccountId(new BankAccountId(accountDTO.getCustId(), accountDTO.getAcctNo()));
		return account;
	}

	/**
	 * Prepare dto
	 *
	 * @param bankAccount the bank account entity
	 * @return the account dto
	 */
	public static AccountDTO valueOf(BankAccount bankAccount){
		AccountDTO accountDTO = new AccountDTO();
		accountDTO.setCustId(bankAccount.getBankAccountId().getCustId());
		accountDTO.setAcctNo(bankAccount.getBankAccountId().getAcctNo());
		accountDTO.setBalance(bankAccount.getBalance());
		accountDTO.setAcctType(bankAccount.getAcctType());
		accountDTO.setSalaried(bankAccount.getSalaried());
		accountDTO.setLstUpdtId(bankAccount.getLstUpdtId());
		accountDTO.setLstUpdtTs(bankAccount.getLstUpdtTs());
		
		return accountDTO;
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AccountDTO [acctNo=" + acctNo + ", custId=" + custId + ", acctType=" + acctType + ", balance=" + balance
				+ ", salaried=" + salaried + ", lstUpdtTs=" + lstUpdtTs + ", lstUpdtId=" + lstUpdtId + "]";
	}

}
