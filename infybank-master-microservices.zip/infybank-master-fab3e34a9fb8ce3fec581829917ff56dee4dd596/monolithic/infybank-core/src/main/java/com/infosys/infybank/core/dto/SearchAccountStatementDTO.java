package com.infosys.infybank.core.dto;
 
import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * The Class SearchAccountStatementDTO.
 */
public class SearchAccountStatementDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The cust id. */
	private int custId;
	
	/** The acct no. */
	@NotBlank
	@Pattern(regexp = "\\d{10}", message = "acctno.format.invalid")
	private String acctNo;
	
	/** The start date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date startDate;
	
	/** The end date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date endDate;
	
	/** The from amount. */
	private Double fromAmount;
	
	/** The to amount. */
	private Double toAmount;
	
	/** The txn type. */
	private Character txnType;
	
	/** The last month. */
	private boolean lastMonth;

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return acctNo;
	}

	/**
	 * Sets the acct no.
	 *
	 * @param acctNo the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the from amount.
	 *
	 * @return the from amount
	 */
	public Double getFromAmount() {
		return fromAmount;
	}

	/**
	 * Sets the from amount.
	 *
	 * @param fromAmount the new from amount
	 */
	public void setFromAmount(Double fromAmount) {
		this.fromAmount = fromAmount;
	}

	/**
	 * Gets the to amount.
	 *
	 * @return the to amount
	 */
	public Double getToAmount() {
		return toAmount;
	}

	/**
	 * Sets the to amount.
	 *
	 * @param toAmount the new to amount
	 */
	public void setToAmount(Double toAmount) {
		this.toAmount = toAmount;
	}

	/**
	 * Gets the txn type.
	 *
	 * @return the txn type
	 */
	public Character getTxnType() {
		return txnType;
	}

	/**
	 * Sets the txn type.
	 *
	 * @param txnType the new txn type
	 */
	public void setTxnType(Character txnType) {
		this.txnType = txnType;
	}

	/**
	 * Gets the last month.
	 *
	 * @return the last month
	 */
	public boolean getLastMonth() {
		return lastMonth;
	}

	/**
	 * Sets the last month.
	 *
	 * @param lastMonth the new last month
	 */
	public void setLastMonth(boolean lastMonth) {
		this.lastMonth = lastMonth;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SearchAccountStatementDTO [custId=" + custId + ", acctNo=" + acctNo + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", fromAmount=" + fromAmount + ", toAmount=" + toAmount + ", txnType="
				+ txnType + ", lastMonth=" + lastMonth + "]";
	}

}
