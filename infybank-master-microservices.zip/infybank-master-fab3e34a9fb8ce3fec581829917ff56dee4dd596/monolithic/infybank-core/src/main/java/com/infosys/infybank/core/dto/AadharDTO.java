package com.infosys.infybank.core.dto;
 
import java.io.Serializable;

/**
 * The Class IFSCMasterDTO.
 */
public class AadharDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** Aadhar Valid Flag */
	private boolean aadharValid;

	/**
	 * Gets the aadhar valid flag
	 *
	 * @return the aadhar valid flag
	 */
	public boolean isAadharValid() {
		return this.aadharValid;
	}

	/**
	 * Sets the aadhar valid flag
	 *
	 * @param aadharValid aadhar valid flag
	 */
	public void setAadharValid(boolean aadharValid) {
		this.aadharValid = aadharValid;
	}

}
