package com.infosys.infybank.loan.service;
 
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * The Class LoanUtil.
 */
public class LoanUtil {
	
	private LoanUtil() {
		throw new IllegalAccessError("Utility class cannot be instantiated");
	}
	
	/**
	 * Calculate emi.
	 *
	 * @param principal
	 *            the principal
	 * @param rateOfInterest
	 *            the rate of interest
	 * @param tenure
	 *            the tenure
	 * @return the big decimal
	 */
	public static BigDecimal calculateEmi(BigDecimal principal, BigDecimal rateOfInterest, int tenure) {
		if (principal == BigDecimal.valueOf(0) || rateOfInterest == BigDecimal.valueOf(0) || tenure == 0) {
			return BigDecimal.valueOf(0);
		}
		BigDecimal numerator = principal.multiply(rateOfInterest.divide(new BigDecimal(100)))
				.multiply((BigDecimal.valueOf(1d).add(rateOfInterest.divide(BigDecimal.valueOf(100)))).pow(tenure,
						MathContext.DECIMAL32));
		BigDecimal denominator = ((BigDecimal.valueOf(1d).add(rateOfInterest.divide(BigDecimal.valueOf(100))))
				.pow(tenure, MathContext.DECIMAL32)).subtract(BigDecimal.valueOf(1d));
		return numerator.divide(denominator, 6, RoundingMode.HALF_EVEN);
	}

	/**
	 * Calculate tenure.
	 *
	 * @param principal
	 *            the principal
	 * @param rateOfInterest
	 *            the rate of interest
	 * @param emi
	 *            the emi
	 * @return the big decimal
	 */
	public static BigDecimal calculateTenure(BigDecimal principal, BigDecimal rateOfInterest, BigDecimal emi) {
		Double emiDouble = emi.doubleValue();
		Double logEmiDouble = Math.log(emiDouble);
		BigDecimal pr = principal.multiply(rateOfInterest.divide(new BigDecimal(100)));
		Double prDouble = pr.doubleValue();
		Double emiMinusPr = emiDouble - prDouble;
		Double logEmiMinusPr = Math.log(emiMinusPr);
		Double rateOfInterstDouble = (rateOfInterest.doubleValue()) / 100;
		Double tenureDouble = (logEmiDouble - logEmiMinusPr) / Math.log(1 + rateOfInterstDouble);
		return BigDecimal.valueOf(tenureDouble).setScale(0, RoundingMode.HALF_UP);
	}

	
}
