package com.infosys.infybank.core.entity;
 
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;


/**
 * The Class Otp.
 */
@Entity
@Table(name = "OTP")
public class Otp implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	/** The email id. */
	@Column(name = "EMAIL_ID", nullable = false, length = 100)
	private String emailId;

	/** The cust id. */
	@Column(name = "CUST_ID", nullable = false)
	private int custId;

	/** The generated ts. */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "GENERATED_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Generated(GenerationTime.ALWAYS)
	private Date generatedTs;

	/** The otp type. */
	@Column(name = "OTP_TYPE", nullable = false, length = 1)
	private char otpType;

	/** The otp. */
	@Column(name = "OTP", nullable = false)
	private String otpString;
	
	/** The payee id. */
	@Column(name = "PAYEE_ID", nullable = true)
	private int payeeId;
	
	/**
	 * Instantiates a new otp.
	 */
	public Otp(){
		/*default constructor*/
	}
	
	/**
	 * Instantiates a new otp.
	 *
	 * @param custId the cust id
	 * @param emailId the email id
	 * @param otpType the otp type
	 * @param otpString the otp string
	 * @param payeeId the payee id
	 */
	
	public Otp(int custId, String emailId, char otpType, String otpString, int payeeId) {
		super();
		this.emailId = emailId;
		this.custId = custId;
		this.otpType = otpType;
		this.otpString = otpString;
		this.payeeId = payeeId;
		
	}

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the payee id.
	 *
	 * @return the payee id
	 */
	public int getPayeeId() {
		return payeeId;
	}

	/**
	 * Sets the payee id.
	 *
	 * @param payeeId the new payee id
	 */
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id
	 *            the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Gets the generated ts.
	 *
	 * @return the generated ts
	 */
	public Date getGeneratedTs() {
		return this.generatedTs;
	}

	/**
	 * Sets the generated ts.
	 *
	 * @param generatedTs
	 *            the new generated ts
	 */
	public void setGeneratedTs(Date generatedTs) {
		this.generatedTs = generatedTs;
	}

	/**
	 * Gets the otp type.
	 *
	 * @return the otp type
	 */
	public char getOtpType() {
		return this.otpType;
	}

	/**
	 * Sets the otp type.
	 *
	 * @param otpType
	 *            the new otp type
	 */
	public void setOtpType(char otpType) {
		this.otpType = otpType;
	}

	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Sets the email id.
	 *
	 * @param emailId
	 *            the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * Gets the otp.
	 *
	 * @return the otp
	 */
	public String getOtp() {
		return otpString;
	}

	/**
	 * Sets the otp.
	 *
	 * @param otp
	 *            the new otp
	 */
	public void setOtp(String otp) {
		this.otpString = otp;
	}

	/**
	 * Instantiates a new otp.
	 *
	 * @return the string
	 */
	

	@Override
	public String toString() {
		return "Otp [id=" + id + ", emailId=" + emailId + ", custId=" + custId + ", generatedTs=" + generatedTs
				+ ", otpType=" + otpType + ", otpString=" + otpString + ", payeeId=" + payeeId + "]";
	}


	
	
	
}
