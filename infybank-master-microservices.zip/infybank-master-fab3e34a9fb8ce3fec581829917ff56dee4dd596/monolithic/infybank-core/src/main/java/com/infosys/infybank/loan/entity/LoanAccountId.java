package com.infosys.infybank.loan.entity;
 
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The Class LoanAccountId.
 */
@Embeddable
public class LoanAccountId implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	@Column(name = "CUST_ID", nullable = false)
	private int custId;

	/** The loan acct no. */
	@Column(name = "LOAN_ACCT_NO", nullable = false, length = 20)
	private String loanAcctNo;

	public LoanAccountId(){
		/*default constructor*/
	}
	
	/**
	 * Instantiates a new loan account id.
	 *
	 * @param custId the cust id
	 * @param loanAcctNo the loan acct no
	 */
	public LoanAccountId(int custId, String loanAcctNo) {
		this.custId = custId;
		this.loanAcctNo = loanAcctNo;
	}

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return this.custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the loan acct no.
	 *
	 * @return the loan acct no
	 */
	public String getLoanAcctNo() {
		return this.loanAcctNo;
	}

	/**
	 * Sets the loan acct no.
	 *
	 * @param loanAcctNo the new loan acct no
	 */
	public void setLoanAcctNo(String loanAcctNo) {
		this.loanAcctNo = loanAcctNo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		if (other == null)
			return false;
		if (!(other instanceof LoanAccountId))
			return false;
		LoanAccountId castOther = (LoanAccountId) other;
		
		Boolean condition1 = this.getCustId() == castOther.getCustId();
		Boolean condition2 = this.getLoanAcctNo() == castOther.getLoanAcctNo();
		Boolean condition3 = (this.getLoanAcctNo() != null) && (castOther.getLoanAcctNo() != null) 
				&& (this.getLoanAcctNo().equals(castOther.getLoanAcctNo()));
		
		return condition1 && (condition2
				|| condition3);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		int result = 17;

		result = 37 * result + this.getCustId();
		result = 37 * result + (getLoanAcctNo() == null ? 0 : this.getLoanAcctNo().hashCode());
		return result;
	}

}
