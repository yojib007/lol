package com.infosys.infybank.core.service;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * The Class OTPGenerator.
 */
@Service
public class OTPGeneratorService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * Creates the OTP.
	 *
	 * @return the long
	 */
	public String createOTP() {

		Integer otp = (int) (Math.random() * 900000) + 1000;
		logger.info(String.format("%06d", otp));
		return String.format("%06d", otp);

	}
}
