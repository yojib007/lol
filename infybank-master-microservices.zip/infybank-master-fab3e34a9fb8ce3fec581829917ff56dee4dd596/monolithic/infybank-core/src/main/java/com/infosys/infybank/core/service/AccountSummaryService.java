package com.infosys.infybank.core.service;
 
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.infybank.core.dto.AccountDTO;
import com.infosys.infybank.core.dto.AccountSummaryDTO;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.repository.AccountRepository;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.loan.dto.LoanAccountDTO;
import com.infosys.infybank.loan.entity.Amortization;
import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.service.AmortizationService;
import com.infosys.infybank.loan.service.LoanService;

@Service
public class AccountSummaryService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The amortization service **/
	@Autowired
	AmortizationService amortizationService;

	/** The account repository **/
	@Autowired
	AccountRepository acctRepo;

	/** The customer service. */
	@Autowired
	CustomerService custService;

	/** The Loan service **/
	@Autowired
	LoanService loanService;

	/**
	 * To get account summary for the param customerId
	 * 
	 * @param custId
	 *            the CustomerId
	 * @return List of the accountsummaryDTO
	 * @throws InfyBankException
	 */
	public AccountSummaryDTO getAccountSummary(int custId) throws InfyBankException {

		// check if custId is valid
		custService.getCustomerDetails(custId);

		AccountSummaryDTO acctSummaryDTO = new AccountSummaryDTO();
		fetchAllBankAccounts(custId, acctSummaryDTO);
		fetchActiveLoanAccounts(custId, acctSummaryDTO);

		return acctSummaryDTO;
	}

	/**
	 * To get the list of all the bank accounts
	 * 
	 * @param custId
	 *            the customerId
	 * @param acctSummaryDTO 
	 * @return list of accountDTO
	 * @throws InfyBankException
	 */
	private void fetchAllBankAccounts(int custId, AccountSummaryDTO acctSummaryDTO) {

		// fetch bank accounts for the given customer from database
		List<BankAccount> bankAccts = acctRepo.findByBankAccountIdCustId(custId);

		// Convert entity objects to DTOs and calculate total assets which is
		// total money in all bank accounts
		List<AccountDTO> acctDTOs = new ArrayList<AccountDTO>();
		BigDecimal totalAssets = BigDecimal.valueOf(0);
		for (BankAccount bankAcct : bankAccts) {
			AccountDTO accountDTO = AccountDTO.valueOf(bankAcct);
			accountDTO.setBalance(bankAcct.getBalance().setScale(2, RoundingMode.HALF_UP));
			acctDTOs.add(accountDTO);
			totalAssets = totalAssets.add(bankAcct.getBalance());
		}

		logger.debug("Bank account details: {}", acctDTOs);
		logger.debug("Total assets: {}", totalAssets);
		
		acctSummaryDTO.setAccounts(acctDTOs);
		acctSummaryDTO.setTotalAssets(totalAssets);
		
	}

	/**
	 * To get the list of all the loan accounts
	 * 
	 * @param custId
	 *            the customerId
	 * @param acctSummaryDTO 
	 * @return list of loan accountDTO
	 * @throws InfyBankException
	 */
	private void fetchActiveLoanAccounts(int custId, AccountSummaryDTO acctSummaryDTO) {

		// fetch all active loan accounts for the customer
		List<LoanAccount> loanAccts = loanService.getLoanAccountForCustIdAndStatus(custId, 'A');
		List<LoanAccountDTO> loanAcctDTOs = new ArrayList<LoanAccountDTO>();

		// return empty list if there are no active loan accounts
		BigDecimal totalPrincipalAmount = new BigDecimal(0);
		BigDecimal totalLiabilities = new BigDecimal(0);
		if (!(loanAccts == null || loanAccts.isEmpty())) {
			// convert entity objects to dtos and compute total liabilities which is
			// total outstanding principal remaining from all active loan accounts
			for (LoanAccount loanAcct : loanAccts) { 
				List<Amortization> amortizationList = amortizationService.getAmortizationDetails(custId,
						loanAcct.getId().getLoanAcctNo());
				if (!(amortizationList == null || amortizationList.isEmpty())) {
					for (Amortization ammortization : amortizationList) {
						totalPrincipalAmount = totalPrincipalAmount.add(ammortization.getPrincipalComponent());
					}
				}
				BigDecimal outstandingBalance = loanAcct.getLoanAmount().subtract(totalPrincipalAmount);
				LoanAccountDTO loanAcctDTO = LoanAccountDTO.valueOf(loanAcct);
				loanAcctDTO.setOutstandingBalance(outstandingBalance.setScale(2, RoundingMode.HALF_UP));
				BigDecimal emi = loanAcct.getEmi() != null ? loanAcct.getEmi().setScale(2, RoundingMode.HALF_UP) : null;
				loanAcctDTO.setEmi(emi);
				loanAcctDTOs.add(loanAcctDTO);
				totalLiabilities = totalLiabilities.add(outstandingBalance);
			}
		}

		logger.debug("Loan account details: {}", loanAcctDTOs);
		logger.debug("Total liabilities: {}", totalLiabilities);
		
		acctSummaryDTO.setLoanAccounts(loanAcctDTOs);
		acctSummaryDTO.setTotalLiability(totalLiabilities);
		
	}

}
