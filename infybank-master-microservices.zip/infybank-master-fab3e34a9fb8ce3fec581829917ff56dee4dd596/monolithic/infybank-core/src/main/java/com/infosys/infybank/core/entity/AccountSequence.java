package com.infosys.infybank.core.entity;
 
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The Class AccountSequence.
 */
@Entity
@Table(name = "accno_seq")
public class AccountSequence implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	/** The current acct gen. */
	@Column(name = "ACCT_CURRENT_NO")
	private Integer currentAcctGen;

	/**
	 * Instantiates a new account sequence.
	 */
	public AccountSequence() {
		/*default constructor*/
	}

	/**
	 * Instantiates a new account sequence.
	 *
	 * @param startAcctNo the start acct no
	 */
	public AccountSequence(Integer startAcctNo) {
		this.currentAcctGen = startAcctNo;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id
	 *            the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Gets the current acct gen.
	 *
	 * @return the current acct gen
	 */
	public Integer getCurrentAcctGen() {
		return currentAcctGen;
	}

	/**
	 * Sets the current acct gen.
	 *
	 * @param currentAcctGen the new current acct gen
	 */
	public void setCurrentAcctGen(Integer currentAcctGen) {
		this.currentAcctGen = currentAcctGen;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AccountSequence [id=" + id + ", currentAcctGen=" + currentAcctGen + "]";
	}

}
