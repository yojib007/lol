package com.infosys.infybank.loan.service;
 
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.service.LoginService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.loan.dto.LoanConfigDTO;
import com.infosys.infybank.loan.dto.LoanConfigEditDTO;
import com.infosys.infybank.loan.entity.LoanConfig;
import com.infosys.infybank.loan.repository.LoanConfigRepository;

/**
 * The Class LoanService.
 */
@Service
public class LoanConfigService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The Configuration Bean */
	@Autowired
	ApplicationProperties appProps;

	/** The Constant ADMIN_ROLE. */
	public static final char ADMIN_ROLE = 'A';

	/** The loan config repository. */
	@Autowired
	private LoanConfigRepository loanConfigRepo;

	/** The login service. */
	@Autowired
	private LoginService loginService;

	/**
	 * View loan rates.
	 *
	 * @return list of LoanConfigDTO
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public List<LoanConfigDTO> viewLoanRates() throws InfyBankException {

		// Fetch all loan configurations from database
		List<LoanConfig> loanConfigs = loanConfigRepo.findAllByOrderByIdCreditScoreStart();
		logger.debug("Loan Configurations fetched from database {}", loanConfigs);

		List<LoanConfigDTO> loanConfigDTOs = new ArrayList<LoanConfigDTO>();

		// Loan Configuration must be setup in database. If not then throw
		// exception as loan functionality will not work.
		if (loanConfigs == null || loanConfigs.isEmpty()) {
			logger.warn("Loan Configuration is not setup in database");
			throw new InfyBankException(ExceptionConstants.LOANCONFIG_RETRIEVAL_FAILED.toString());
		} else {
			logger.info("LoanConfig entity objects retrieved successfully");

			// Convert loan configuration entities to DTO
			for (LoanConfig loanConfig : loanConfigs) {
				loanConfigDTOs.add(LoanConfigDTO.valueOf(loanConfig));
			}
		}
		logger.debug("Loan Configuration DTOs created {}", loanConfigDTOs);
		return loanConfigDTOs;
	}

	/**
	 * 
	 * Validates the data before updating the loan configuration
	 * 
	 * @param loanConfigEditDTO
	 * @throws InfyBankException
	 */

	public void validateLoanConfig(LoanConfigEditDTO loanConfigEditDTO) throws InfyBankException {

		logger.debug("Loan Configuration Edit DTO {}", loanConfigEditDTO);

		// allow this operation only if user is admin
		Login login = loginService.getLoginDetails(loanConfigEditDTO.getLstUpdtId());
		if (login == null || login.getRole() != ADMIN_ROLE) {
			logger.debug("Role of user is {}", login.getRole());
			throw new InfyBankException(ExceptionConstants.INFYBANK_UNAUTHORIZED.toString());
		}

		List<LoanConfigDTO> loanConfigDTOs = loanConfigEditDTO.getLoanConfigDtoList();

		// Loan configuration cannot be made empty
		if (loanConfigDTOs == null || loanConfigDTOs.isEmpty()) {
			throw new InfyBankException(ExceptionConstants.LOANCONFIG_EMPTY.toString());
		}

		// The first loan configuration must start with a score of 300
		if (loanConfigDTOs.get(0).getCreditScoreStart() != appProps.getCibilMinScore()) {
			logger.warn("The first row for loan configuration must start with {}", appProps.getCibilMinScore());
			throw new InfyBankException(ExceptionConstants.LOANCONFIG_INVALID_START.toString());
		}

		// The last loan configuration must end with a score of 900
		if (loanConfigDTOs.get(loanConfigDTOs.size() - 1).getCreditScoreEnd() != appProps.getCibilMaxScore()) {
			logger.warn("The last row for loan configuration must end with {}", appProps.getCibilMaxScore());
			throw new InfyBankException(ExceptionConstants.LOANCONFIG_INVALID_END.toString());
		}

		LoanConfigDTO dto;
		int prevEndScore = 0;

		// Validate that there should be interest setup for each CIBIL score
		// between 300 and 900.
		// In other words there should not be any overlaps or gaps.
		for (int index = 0; index < loanConfigDTOs.size(); index++) {
			dto = loanConfigDTOs.get(index);
			if (index != 0) {
				prevEndScore = loanConfigDTOs.get(index - 1).getCreditScoreEnd();
				if (dto.getCreditScoreStart() > prevEndScore + 1) {
					logger.warn("There can be no gaps in the credit score configuration)");
					throw new InfyBankException(ExceptionConstants.LOANCONFIG_MISSING_SCORE_RANGE.toString());
				} else if (dto.getCreditScoreStart() < prevEndScore + 1) {
					logger.warn("There can be no overlaps in the credit score configuration)");
					throw new InfyBankException(ExceptionConstants.LOANCONFIG_OVERLAPPING_SCORE_RANGE.toString());
				}
			}
		}

	}

	/**
	 * Saves the loan configurations to the database
	 * 
	 * @param loanConfigEditDTO
	 * @throws InfyBankException
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public void saveLoanConfig(LoanConfigEditDTO loanConfigEditDTO) throws InfyBankException {

		// delete all existing entries from the database
		loanConfigRepo.deleteAll();

		List<LoanConfigDTO> loanConfigDTOs = loanConfigEditDTO.getLoanConfigDtoList();

		// save the new values
		for (LoanConfigDTO loanConfigDTO : loanConfigDTOs) {
			loanConfigRepo.save(LoanConfigDTO.prepareEntity(loanConfigDTO));
		}
		loanConfigRepo.flush();

	}

	/**
	 * 
	 * @param creditScore
	 * @return
	 * @throws InfyBankException
	 */
	public LoanConfig getLoanConfigForCreditScore(Integer creditScore) throws InfyBankException {
		LoanConfig loanConfig = loanConfigRepo.getLoanConfigForCreditScore(creditScore);
		if (loanConfig == null) {
			throw new ResourceNotFoundException(ExceptionConstants.LOAN_CONFIG_DETAILS_NOT_AVAILABLE.toString());
		}
		return loanConfig;

	}
}
