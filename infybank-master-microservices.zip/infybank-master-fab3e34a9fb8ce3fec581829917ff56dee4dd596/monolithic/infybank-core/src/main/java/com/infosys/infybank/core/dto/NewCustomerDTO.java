package com.infosys.infybank.core.dto;
 
import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

/**
 * The Class NewCustomerDTO.
 */

public class NewCustomerDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The aadhar id. */
	@NotBlank(message = "newcustomer.aadharId.mandatory")
	@Pattern(regexp = "[0-9]{12}", message = "newcustomer.aadharId.invalid")
	private String aadharId;

	/** The cust id. */
	private int custId;

	/** The first name. */
	@NotBlank(message = "newcustomer.firstname.mandatory")
	@Length(min = 3, max = 20, message = "newcustomer.firstname.size")
	private String firstName;

	/** The last name. */
	@NotBlank(message = "newcustomer.lastname.mandatory")
	@Length(min = 1, max = 20, message = "newcustomer.lastname.size")
	private String lastName;

	/** The email id. */
	@NotBlank(message = "newcustomer.email.mandatory")
	@Email(message = "newcustomer.email.valid")
	private String emailId;

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the aadhar id.
	 *
	 * @return the aadhar id
	 */
	public String getAadharId() {
		return aadharId;
	}

	/**
	 * Sets the aadhar id.
	 *
	 * @param aadharId
	 *            the new aadhar id
	 */
	public void setAadharId(String aadharId) {
		this.aadharId = aadharId;
	}

	/**
	 * Gets the firstName.
	 *
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the firstName.
	 *
	 * @param firstName
	 *            the new firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName
	 *            the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Sets the email id.
	 *
	 * @param emailId
	 *            the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NewCustomerDTO [aadharId=" + aadharId + ", custId=" + custId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", emailId=" + emailId + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */

}
