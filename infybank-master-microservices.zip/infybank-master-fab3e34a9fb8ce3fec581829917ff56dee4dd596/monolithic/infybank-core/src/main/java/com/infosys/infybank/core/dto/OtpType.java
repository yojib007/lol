package com.infosys.infybank.core.dto;
 
/**  
* OtpType.java - enum to represent the type of OTP 
* 
* */
public enum OtpType {
	
	/** The account open. */
	ACCOUNT_OPEN("A"),
    
	/** The add payee. */
    ADD_PAYEE("P");
	
	/** The type. */
	private final String type;
	
	/**
	 * Instantiates a new otp type.
	 *
	 * @param type the type
	 */
	private OtpType(String type){
		this.type=type;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString(){
		return this.type;
	}
	
}
