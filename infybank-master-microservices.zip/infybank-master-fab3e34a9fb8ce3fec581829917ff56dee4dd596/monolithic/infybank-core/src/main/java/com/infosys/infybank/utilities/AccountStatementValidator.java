package com.infosys.infybank.utilities;
 
import java.util.Date;

import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

public class AccountStatementValidator {

	private AccountStatementValidator() {
		throw new IllegalAccessError("Utility class cannot be instantiated");
	}

	/**
	 * To validate transaction type
	 * 
	 * @param txnType
	 * @return true if successful
	 */
	public static boolean isTransactionTypeValid(char txnType) {
		switch (Character.toUpperCase(txnType)) {
		case 'C':
		case 'D':
		case 0:
			return true;
		default:
			return false;
		}
	}

	/**
	 * To validate todate and fromdate
	 * 
	 * @param fromDate
	 *            the fromDate
	 * @param toDate
	 *            the Todate
	 * @throws InfyBankException
	 */
	public static void validateFromToDate(boolean lastMonth, Date fromDate, Date toDate) throws InfyBankException {
		
		if (lastMonth){
			if(fromDate != null || toDate != null) {
				throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_DATE_INVALID.toString());
			}	
			return;
		}
		
		Date current = new Date();
		if (fromDate == null) {
			throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_START_DATE_INVALID.toString());
		} else {
			if (toDate == null) {
				throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_END_DATE_INVALID.toString());
			} else if (fromDate.compareTo(toDate) > 0) {
				throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_FROM_TO_DATE_INVALID.toString());
			} else if (fromDate.after(current) || toDate.after(current)) {
				throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_FROMTODATE_INVALID.toString());
			}

		}

	}

	/**
	 * To validate toAmount and Fromamount
	 * 
	 * @param fromAmount
	 * @param toAmount
	 * @throws InfyBankException
	 */
	public static void validateFromToAmount(Double fromAmount, Double toAmount) throws InfyBankException {

		// both from and to amount must be present or both must be null
		if (fromAmount == null) {
			if (toAmount == null) {
				return;
			} else {
				throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_FROM_AMOUNT_INVALID.toString());
			}
		} else {
			if (toAmount == null) {
				throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_TO_AMOUNT_INVALID.toString());
			}
		}

		// none of the amounts must be negative.
		// from amount must be less than to amount
		if (fromAmount < 0.0) {
			throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_FROM_AMOUNT_INVALID.toString());
		} else if (toAmount <= 0.0) {
			throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_TO_AMOUNT_INVALID.toString());
		} else if (fromAmount >= toAmount) {
			throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_FROMTO_AMOUNT_INVALID.toString());
		}

	}

}
