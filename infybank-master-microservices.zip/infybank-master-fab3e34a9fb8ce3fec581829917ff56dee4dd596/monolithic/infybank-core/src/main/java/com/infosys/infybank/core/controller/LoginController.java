package com.infosys.infybank.core.controller;
 
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.core.dto.LoginDTO;
import com.infosys.infybank.core.dto.UserDTO;
import com.infosys.infybank.core.service.LoginService;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class LoginController
 * 
 *
 */
@RestController
public class LoginController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	LoginService loginService;

	/**
	 * This controller handles the request for authentication of the Login
	 * details.
	 * 
	 * @param loginDTO
	 *            , the object
	 * @return UserDTO
	 * @throws InfyBankException
	 */

	@RequestMapping(value = "/${project.version}/login", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public UserDTO authenticate(@Valid @RequestBody LoginDTO loginDTO) throws InfyBankException {
		logger.debug("Data received is: {}", loginDTO);
		return loginService.authenticate(loginDTO);
	}
}
