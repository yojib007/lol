package com.infosys.infybank.core.dto;
 
import java.io.Serializable;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.stereotype.Component;


/**
 * The Class OtpDTO.
 *
 * @author Infosys
 */
@Component
public class OtpDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The otp. */
	@NotBlank(message = "newcustomer.otp.mandatory")
	private String otp;

	/** The email id. */
	@NotBlank(message = "newcustomer.email.mandatory")
	@Email(message = "newcustomer.email.valid")
	private String emailId;

	/** The otp type. */
	private String otpType;

	/**
	 * Gets the otp.
	 *
	 * @return the otp
	 */
	public String getOtp() {
		return otp;
	}

	/**
	 * Sets the otp.
	 *
	 * @param otp
	 *            the new otp
	 */
	public void setOtp(String otp) {
		this.otp = otp;
	}

	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Sets the email id.
	 *
	 * @param emailId
	 *            the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * Gets the otp type.
	 *
	 * @return the otp type
	 */
	public String getOtpType() {
		return otpType;
	}

	/**
	 * Sets the otp type.
	 *
	 * @param otpType
	 *            the new otp type
	 */
	public void setOtpType(String otpType) {
		this.otpType = otpType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OtpDTO [otp=" + otp + ", emailId=" + emailId + ", otpType=" + otpType + "]";
	}

}
