package com.infosys.infybank.fundtransfer.dto;
 
/**
 * FundTransferType.java - enum to represent the type of fund transfer
 * 
 */
public enum FundTransferType {

	/** Funds Transfer to one's own bank account */
	OWN_ACCT_TRANSFER("O"),

	/** Funds Transfer to InfyBank account of a different customer */
	SAME_BANK_TRANSFER("S"),

	/** Funds Transfer to bank account with a different bank */
	EXTERNAL_BANK_TRANSFER("E");

	/** The type. */
	private final String type;

	/**
	 * Instantiates a new fund transfer type.
	 *
	 * @param type
	 *            the type
	 */
	private FundTransferType(String type) {
		this.type = type;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString() {
		return this.type;
	}

	/**
	 * Parse FundTransferType enum from the string value
	 * 
	 * @param value
	 *            the value to be parsed
	 * @return FundTransferType enum
	 * 
	 */
	public static FundTransferType fromString(String value) {
		for (FundTransferType t : FundTransferType.values()) {
			if (t.type.equalsIgnoreCase(value)) {
				return t;
			}
		}
		return null;
	}
}
