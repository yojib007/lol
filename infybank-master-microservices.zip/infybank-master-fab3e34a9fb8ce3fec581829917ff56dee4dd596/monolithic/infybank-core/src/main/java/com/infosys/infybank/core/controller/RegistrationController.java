package com.infosys.infybank.core.controller;
 
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.core.dto.NewCustomerDTO;
import com.infosys.infybank.core.dto.OtpDTO;
import com.infosys.infybank.core.dto.OtpType;
import com.infosys.infybank.core.dto.RegistrationDTO;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.core.service.RandomPasswordGeneratorService;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class RegistrationController.
 */
@RestController
public class RegistrationController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The customer service. */
	@Autowired
	CustomerService custService;

	@Autowired
	RandomPasswordGeneratorService pswdService;

	/**
	 * ensures that HTTP requests to /${project.version}/customers- POST based
	 * request are mapped to the generateOTP() method which accepts entered
	 * input in JSON format
	 *
	 * @param custDTO
	 *            the obj
	 * @return true- if OTP generation is successful
	 * @exception InfyBankException
	 *                the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/generate-otp", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.CREATED)
	public void generateOTP(@Valid @RequestBody NewCustomerDTO custDTO) throws InfyBankException {
		logger.debug("OTP generation request details : {}", custDTO);
		custService.generateOTP(custDTO);

	}

	/**
	 * Verify OTP.
	 *
	 * @param otpDTO
	 *            the obj
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/confirm-otp", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public boolean verifyOTP(@Valid @RequestBody OtpDTO otpDTO) throws InfyBankException {
		logger.debug("OTP verification request details : {}", otpDTO);
		return custService.verifyOTP(otpDTO.getOtp(), otpDTO.getEmailId(), OtpType.ACCOUNT_OPEN);

	}

	/**
	 * Register customer.
	 *
	 * @param dto
	 *            the obj
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/register", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.CREATED)
	public void registerCustomer(@Valid @RequestBody RegistrationDTO dto) throws InfyBankException {

		logger.debug("Register customer request details : {}", dto);
		custService.verifyEmailAndAadhar(dto.getAadharId(), dto.getEmailId(), dto.getFirstName(), dto.getLastName());
		String password = pswdService.generatePassword();
		Login login = custService.createCustomerAndAccount(dto, password);
		custService.notifyCustomer(dto.getEmailId(), login.getUserId(), password);

	}
}
