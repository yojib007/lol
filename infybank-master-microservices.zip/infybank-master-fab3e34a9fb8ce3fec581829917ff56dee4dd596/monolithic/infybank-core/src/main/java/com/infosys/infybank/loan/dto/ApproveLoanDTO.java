package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;


/**
 * The Class ApproveLoanDTO.
 */
public class ApproveLoanDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The approve. */
	private boolean approve;
	
	/** The interest rate. */
	@NotNull(message = "loanconfig.interestrate.mandatory")
	private BigDecimal interestRate;
	
	/** The remarks. */
	@NotBlank(message = "remarks.mandatory")
	private String remarks;
	
	/** The admin user id. */
	@NotBlank
	@Pattern(regexp = "\\w+", message = "userId.format.invalid")
	private String adminUserId;
	
	/**
	 * Gets the interest rate.
	 *
	 * @return the interest rate
	 */
	public BigDecimal getInterestRate() {
		return interestRate;
	}
	
	/**
	 * Sets the interest rate.
	 *
	 * @param interestRate the new interest rate
	 */
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	
	/**
	 * Checks if is approve.
	 *
	 * @return true, if is approve
	 */
	public boolean isApprove() {
		return approve;
	}
	
	/**
	 * Sets the approve.
	 *
	 * @param approve the new approve
	 */
	public void setApprove(boolean approve) {
		this.approve = approve;
	}
	
	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	
	/**
	 * Sets the remarks.
	 *
	 * @param remarks the new remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	/**
	 * Gets the admin user id.
	 *
	 * @return the admin user id
	 */
	public String getAdminUserId() {
		return adminUserId;
	}
	
	/**
	 * Sets the admin user id.
	 *
	 * @param adminUserId the new admin user id
	 */
	public void setAdminUserId(String adminUserId) {
		this.adminUserId = adminUserId;
	}
	
	
}
