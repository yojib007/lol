package com.infosys.infybank.core.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.infosys.infybank.loan.dto.LoanAccountDTO;

/**
 * The Class AccountSummaryDTO.
 */
public class AccountSummaryDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The account dto list. */
	private List<AccountDTO> accounts;
	
	/** The loan account dto list. */
	private List<LoanAccountDTO> loanAccounts;
	
	/** The total assets. */
	private BigDecimal totalAssets;
	
	/** The total liability. */
	private BigDecimal totalLiability;

	/**
	 * Gets the account dto list.
	 *
	 * @return the account dto list
	 */
	public List<AccountDTO> getAccounts() {
		return accounts;
	}

	/**
	 * Sets the account dto list.
	 *
	 * @param accountDtoList the new account dto list
	 */
	public void setAccounts(List<AccountDTO> accountDtoList) {
		this.accounts = accountDtoList;
	}

	/**
	 * Gets the loan account dto list.
	 *
	 * @return the loan account dto list
	 */
	public List<LoanAccountDTO> getLoanAccounts() {
		return loanAccounts;
	}

	/**
	 * Sets the loan account dto list.
	 *
	 * @param loanAccountDtoList the new loan account dto list
	 */
	public void setLoanAccounts(List<LoanAccountDTO> loanAccountDtoList) {
		this.loanAccounts = loanAccountDtoList;
	}

	/**
	 * Gets the total assets.
	 *
	 * @return the total assets
	 */
	public BigDecimal getTotalAssets() {
		return totalAssets;
	}

	/**
	 * Sets the total assets.
	 *
	 * @param totalAssets the new total assets
	 */
	public void setTotalAssets(BigDecimal totalAssets) {
		this.totalAssets = totalAssets;
	}

	/**
	 * Gets the total liability.
	 *
	 * @return the total liability
	 */
	public BigDecimal getTotalLiability() {
		return totalLiability;
	}

	/**
	 * Sets the total liability.
	 *
	 * @param totalLiability the new total liability
	 */
	public void setTotalLiability(BigDecimal totalLiability) {
		this.totalLiability = totalLiability;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AccountSummaryDTO [accountDtoList=" + accounts + ", loanAccountDtoList=" + loanAccounts
				+ ", totalAssets=" + totalAssets + ", totalLiability=" + totalLiability + "]";
	}

}
