package com.infosys.infybank.loan.service;
 
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.infybank.core.dto.AccountTransactionCategory;
import com.infosys.infybank.core.dto.AccountTransactionType;
import com.infosys.infybank.core.dto.Email;
import com.infosys.infybank.core.entity.AccountConfig;
import com.infosys.infybank.core.entity.AccountTransaction;
import com.infosys.infybank.core.entity.BankAccount;

import com.infosys.infybank.core.service.AccountConfigService;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.AccountTransactionService;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.core.service.NotificationService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.loan.dto.LoanPrepayDTO;
import com.infosys.infybank.loan.entity.Amortization;
import com.infosys.infybank.loan.entity.AmortizationId;
import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.entity.LoanAccountId;
import com.infosys.infybank.loan.repository.AmortizationRepository;
import com.infosys.infybank.loan.repository.LoanRepository;

/**
 * The Class LoanPrepayService.
 */
@Service
public class LoanPrepayService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The amortization repository. */
	@Autowired
	AmortizationRepository amortRepo;

	@Autowired
	NotificationService notificationService;

	/** The loan account repository. */
	@Autowired
	LoanRepository loanRepo;

	/** The account service. */
	@Autowired
	AccountService acctService;

	/** The account config service. */
	@Autowired
	AccountConfigService acctConfigService;

	/** The customer service. */
	@Autowired
	CustomerService custService;

	/** The acct trans service. */
	@Autowired
	AccountTransactionService acctTxnService;

	/** The loan account service. */
	@Autowired
	LoanService loanService;

	/** The Constant SAME_EMI. */
	public static final String SAME_EMI = "SE";

	/** The Constant SAME_TENURE. */
	public static final String SAME_TENURE = "ST";

	/**
	 * Loan prepay for customer.
	 *
	 * @param custId
	 *            the cust id
	 * @param prepayDTO
	 *            the obj
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public void loanPrepayForCustomer(int custId, LoanPrepayDTO prepayDTO) throws InfyBankException {

		String loanAcctNo = prepayDTO.getLoanAcctNo();

		if (!(isValidPaymentOption(prepayDTO)))
			throw new InfyBankException(ExceptionConstants.LOANPREPAY_INVALID_OPTION.toString());

		// check if custId is valid
		custService.getCustomerDetails(custId);

		BankAccount fromBankAcct = acctService.getAccountDetails(custId, prepayDTO.getFromAccount());
		if (fromBankAcct == null)
			throw new InfyBankException(ExceptionConstants.LOANPREPAY_INVALID_FROMACCOUNT.toString());

		if (!(isValidLoanAmount(loanAcctNo, custId)))
			throw new InfyBankException(ExceptionConstants.INVALID_LOAN_AMOUNT.toString());

		if (!(isValidTxnDate(loanAcctNo, custId)))
			throw new InfyBankException(ExceptionConstants.CANNOT_PERFORM_TRANSACTION.toString());

		if (!(minBalanceCheck(custId, prepayDTO)))
			throw new InfyBankException(ExceptionConstants.BALANCE_LESSTHAN_MINBAL.toString());

		logger.debug("Validation successful for loan prepayment");
		loanPrepay(custId, prepayDTO, fromBankAcct);
	}

	/**
	 * Loan prepay.
	 *
	 * @param custId
	 *            the cust id
	 * @param prepayDTO
	 *            the obj
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public void loanPrepay(int custId, LoanPrepayDTO prepayDTO, BankAccount bankAccount) throws InfyBankException {

		BigDecimal prepayAmount = prepayDTO.getPrepayAmount();
		String loanAcctNo = prepayDTO.getLoanAcctNo();

		LoanAccount loanAccount = loanRepo.findOne(new LoanAccountId(custId, loanAcctNo));

		List<Amortization> list = amortRepo.getAmortizationDetails(custId, loanAcctNo);

		BigDecimal totalPrincipalAmount = new BigDecimal(0);
		BigDecimal closingPrincipal;
		if (list == null || list.isEmpty()) {
			closingPrincipal = loanAccount.getLoanAmount();
		} else {
			closingPrincipal = list.get(list.size() - 1).getClosingPrincipal();
			for (Amortization amortization : list) {
				totalPrincipalAmount = totalPrincipalAmount.add(amortization.getPrincipalComponent());
			}
		}

		BigDecimal outstandingAmount = loanAccount.getLoanAmount().subtract(totalPrincipalAmount);

		if ((outstandingAmount.subtract(prepayAmount))
				.compareTo(loanAccount.getLoanAmount().divide(BigDecimal.valueOf(10))) < 0) {
			throw new InfyBankException(ExceptionConstants.LOANPREPAY_INVALID_AMOUNT.toString());
		}

		BigDecimal remainingAmount = closingPrincipal
				.add(closingPrincipal.multiply(loanAccount.getInterestRate().divide(BigDecimal.valueOf(100))));

		remainingAmount = remainingAmount.subtract(prepayAmount);

		BigDecimal remainingPrincipal = remainingAmount
				.subtract(closingPrincipal.multiply(loanAccount.getInterestRate().divide(new BigDecimal(100))));

		BigDecimal newBal = bankAccount.getBalance().subtract(prepayAmount);

		Amortization ammo;

		int noOfInstallmentsRemaining;

		if (!(list == null || list.isEmpty())) {

			ammo = list.get(list.size() - 1);
			AmortizationId id = ammo.getId();
			noOfInstallmentsRemaining = loanAccount.getTenure() - id.getInstallmentNo();
			id.setInstallmentNo(id.getInstallmentNo() + 1);
			ammo.setOpeningPrincipal(ammo.getClosingPrincipal());

			ammo.setId(id);
			ammo.setClosingPrincipal(remainingPrincipal);
			updateAmortization(ammo, prepayDTO, loanAccount);

		} else {

			ammo = new Amortization();
			AmortizationId id = new AmortizationId();
			ammo.setOpeningPrincipal(loanAccount.getLoanAmount());
			id.setCustId(custId);
			noOfInstallmentsRemaining = loanAccount.getTenure();
			id.setInstallmentNo(1);
			id.setLoanAcctNo(prepayDTO.getLoanAcctNo());
			ammo.setId(id);
			ammo.setClosingPrincipal(remainingPrincipal);
			updateAmortization(ammo, prepayDTO, loanAccount);
		}

		bankAccount.setBalance(newBal);
		
		acctService.performTransaction(prepayDTO.getPrepayAmount(),prepayDTO.getLoanAcctNo(), bankAccount, AccountTransactionType.DEBIT, AccountTransactionCategory.LOAN_PAYMENT);

		String emailId = custService.getEmailIdforCustomer(custId);

		// update of tenure or EMI

		if (prepayDTO.getPaymentOption().equals(SAME_TENURE))
			updateLoanEMI(ammo, loanAccount, noOfInstallmentsRemaining);

		else if (prepayDTO.getPaymentOption().equals(SAME_EMI))
			updateLoanTenure(ammo, loanAccount);

		notifyCustomer(emailId, prepayDTO.getPrepayAmount(), loanAcctNo, outstandingAmount);

	}
	/**
	 * creates and populates an email instance 
	 * and invokes the notifyCustomer method from NotificationService
	 * @param emailId
	 * 				the emailId of the customer
	 * @param prepayAmount
	 * 			the prepay amount
	 * @param loanAcctNo
	 * 			the loanAcctNo of the customer's loan account
	 * @return void
	 */
	private void notifyCustomer(String emailId, BigDecimal prepayAmount, String loanAcctNo,
			BigDecimal outstandingAmount) {
		Email email = new Email();
		email.setToEmail(emailId);
		email.setSubject("Prepayment alert for your InfyBank Loan");

		String message = java.text.MessageFormat.format(
				"Dear Customer,\n \t You have successfully made a prepayment of {0}"
						+ " towards your loanAccount no: {1}. Your remaining outstanding balance is {2}. \n\n Sincerely,\n InfyBank Customer Care",
						prepayAmount, loanAcctNo, outstandingAmount);

		email.setEmailMessage(message);
		
		notificationService.notifyCustomer(email);
		
	}

	/**
	 * Checks if is valid payment option.
	 *
	 * @param prepayDTO
	 *            the obj
	 * @return true, if is valid payment option
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public boolean isValidPaymentOption(LoanPrepayDTO prepayDTO) {

		return (prepayDTO.getPaymentOption().equals(SAME_EMI) || prepayDTO.getPaymentOption().equals(SAME_TENURE))
				? true : false;

	}

	/**
	 * Checks if is valid txn date.
	 *
	 * @param loanAcctNo
	 *            the loan acct no
	 * @param custId
	 *            the cust id
	 * @return true, if is valid txn date
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public boolean isValidTxnDate(String loanAcctNo, int custId) {

		List<AccountTransaction> acctTransList = acctTxnService.getTxnDetailForLoanByCustId(loanAcctNo, custId);
		if (acctTransList == null || acctTransList.isEmpty())
			return true;
		LocalDate txnDate = LocalDate.parse(acctTransList.get(0).getTxnDate().toString());
	
		return ChronoUnit.DAYS.between(txnDate, LocalDate.now())>=2 ? true : false;

	}

	/**
	 * Checks if is valid loan amount.
	 *
	 * @param loanAcctNo
	 *            the loan acct no
	 * @param custId
	 *            the cust id
	 * @return true, if is valid loan amount
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public boolean isValidLoanAmount(String loanAcctNo, int custId) throws InfyBankException {

		LoanAccount loanAccount = loanRepo.findOne(new LoanAccountId(custId, loanAcctNo));
		if (loanAccount == null)
			throw new ResourceNotFoundException(ExceptionConstants.LOANACCOUNT_INVALID_CUSTOMER.toString());
		BigDecimal loanAmount = loanAccount.getLoanAmount();

		BigDecimal principalAmount;
		List<Amortization> list = amortRepo.getAmortizationDetails(custId, loanAcctNo);

		if (list == null || list.isEmpty())
			principalAmount = loanAmount;
		else
			principalAmount = list.get(list.size() - 1).getClosingPrincipal();

		if (principalAmount == null)
			throw new InfyBankException(ExceptionConstants.LOANACCOUNT_INVALID_CUSTOMER.toString());

		if (loanAmount == null)
			throw new InfyBankException(ExceptionConstants.LOANACCOUNT_INVALID_CUSTOMER.toString());

		return ((loanAmount.divide(new BigDecimal(10))).compareTo(principalAmount) < 0) ? true : false;

	}

	/**
	 * Min balance check.
	 *
	 * @param custId
	 *            the cust id
	 * @param obj
	 *            the obj
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public boolean minBalanceCheck(int custId, LoanPrepayDTO obj) {
		LoanAccount loanAccount = loanRepo.findOne(new LoanAccountId(custId, obj.getLoanAcctNo()));

		BankAccount bankAccount = acctService.getAccountDetails(custId, loanAccount.getDebitAcctNo());

		AccountConfig acctConfig = acctConfigService.getAccountConfigDetails(bankAccount);

		BigDecimal minBal = acctConfig.getMinBalance();
		BigDecimal balance = bankAccount.getBalance();
		BigDecimal newBal = balance.subtract(obj.getPrepayAmount());

		return (newBal.compareTo(minBal) >= 0) ? true : false;

	}

	private void updateAmortization(Amortization a, LoanPrepayDTO obj, LoanAccount loanAccount) {

		a.setInstallmentAmount(obj.getPrepayAmount());
		a.setPrincipalComponent(obj.getPrepayAmount());
		a.setInterestComponent(BigDecimal.valueOf(0));
		a.setInstallmentDate(new Date());
		a.setInterestRate(loanAccount.getInterestRate());
		a.setLstUpdtId(loanAccount.getLstUpdtId());
		a.setLstUpdtTs(new Date());
		amortRepo.saveAndFlush(a);
	}

	/**
	 * Update loan emi.
	 *
	 * @param a
	 *            the ammortization
	 * @param loanAcct
	 *            the loan account
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private boolean updateLoanEMI(Amortization a, LoanAccount loanAcct, int noOfInstallmentsRemaining) {

		BigDecimal newEmi = LoanUtil.calculateEmi(a.getClosingPrincipal(), loanAcct.getInterestRate(),
				noOfInstallmentsRemaining);

		loanAcct.setEmi(newEmi);

		loanRepo.saveAndFlush(loanAcct);

		return true;
	}

	/**
	 * Update loan tenure.
	 *
	 * @param a
	 *            the ammortization
	 * @param loanAcct
	 *            the loan account
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private boolean updateLoanTenure(Amortization a, LoanAccount loanAcct) {

		BigDecimal tenure = LoanUtil.calculateTenure(a.getClosingPrincipal(), loanAcct.getInterestRate(),
				loanAcct.getEmi());

		int newTenure = tenure.intValue();

		loanAcct.setTenure(newTenure + a.getId().getInstallmentNo());

		loanRepo.saveAndFlush(loanAcct);

		return true;
	}
}
