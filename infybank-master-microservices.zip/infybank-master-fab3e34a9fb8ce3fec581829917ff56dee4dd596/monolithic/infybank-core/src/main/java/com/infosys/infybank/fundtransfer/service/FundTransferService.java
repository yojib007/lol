package com.infosys.infybank.fundtransfer.service;
 
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.AccountTransactionCategory;
import com.infosys.infybank.core.dto.AccountTransactionType;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.service.AccountConfigService;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.fundtransfer.dto.FundTransferDTO;
import com.infosys.infybank.fundtransfer.dto.FundTransferType;
import com.infosys.infybank.fundtransfer.entity.FundTransfer;
import com.infosys.infybank.fundtransfer.entity.Payee;
import com.infosys.infybank.fundtransfer.repository.FundTransferRepository;
import com.infosys.infybank.fundtransfer.repository.PayeeRepository;
import com.infosys.infybank.utilities.DateField;
import com.infosys.infybank.utilities.DateUtil;

/**
 * The Class FundTransferService.
 */
@Service
public class FundTransferService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** the Account Config Service *. */
	@Autowired
	private AccountConfigService acctConfigService;

	/** The customer repository. */
	@Autowired
	CustomerService custService;

	/** the Account Service *. */
	@Autowired
	private AccountService acctService;

	/** the fund transfer repository *. */
	@Autowired
	private FundTransferRepository ftRepo;

	/** the payee repository *. */
	@Autowired
	private PayeeRepository payeeRepo;

	/** The Configuration Bean */
	@Autowired
	ApplicationProperties appProps;

	/** The Constant TRANSFER_COMPLETE. */
	public static final char TRANSFER_COMPLETE = 'C';

	/** The Constant TRANSFER_PENDING. */
	public static final char TRANSFER_PENDING = 'P';

	/** The Constant PAYEE_CONFIRMED. */
	public static final char PAYEE_CONFIRMED = 'C';

	/**
	 * Method to transfer fund.
	 *
	 * @param custId
	 *            the customer Id
	 * @param ftDTO
	 *            the fundtranfer DTO
	 * @return true if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public List<BankAccount> transferFunds(int custId, FundTransferDTO ftDTO) throws InfyBankException {

		validateFundTransferInput(ftDTO);
		logger.debug("Field validations successful for funds transfer");

		// check if custId is valid
		custService.getCustomerDetails(custId);

		// verify From acct is fine
		BankAccount fromAcct = verifyCustAcct(custId, ftDTO.getFromAccountNo());

		BankAccount toAcct = null;

		FundTransferType type = FundTransferType.fromString(ftDTO.getFundTransferType());

		switch (type) {
		case OWN_ACCT_TRANSFER:
			// verify To acct is fine
			toAcct = verifyCustAcct(custId, ftDTO.getToAccountNo());
			break;
		case SAME_BANK_TRANSFER:
			toAcct = getPayeeAccount(ftDTO.getPayeeId());
			break;
		case EXTERNAL_BANK_TRANSFER:
			break;
		}

		// check for enough fund for transfer
		if (!hasMinBalance(fromAcct, ftDTO.getAmount())) {
			throw new InfyBankException(ExceptionConstants.INSUFFICIENT_FUND.toString());
		}
		
		List<BankAccount> fromToAccounts = new ArrayList<BankAccount>();
		fromToAccounts.add(fromAcct);
		fromToAccounts.add(toAcct);
		
		return fromToAccounts;

	}

	/**
	 * To validate the Input provided.
	 *
	 * @param transferDTO
	 *            the dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private void validateFundTransferInput(FundTransferDTO transferDTO) throws InfyBankException {

		// Fund transfer type must be valid
		String fundTransferType = transferDTO.getFundTransferType();
		FundTransferType type = FundTransferType.fromString(fundTransferType);
		if (type == null)
			throw new InfyBankException(ExceptionConstants.FT_TYPE_INVALID.toString());

		switch (type) {
		case OWN_ACCT_TRANSFER:
			// in case of transfer to one's own account then to account no. must
			// be a valid entry
			if (transferDTO.getToAccountNo() == null || transferDTO.getToAccountNo().trim().length() < 10) {
				throw new InfyBankException(ExceptionConstants.FT_TOACCOUNT_MANDATORY.toString());
			}
			break;
		case SAME_BANK_TRANSFER:
		case EXTERNAL_BANK_TRANSFER:
			// Payee Id is mandatory for transfer to someone else's account
			if (transferDTO.getPayeeId() == 0) {
				throw new InfyBankException(ExceptionConstants.FT_PAYEEID_MANDATORY.toString());
			}
			validatePayeeForFundTransfer(transferDTO.getPayeeId());
			break;
		}

		// Transfer Date must not be a past date
		LocalDate transferDate = transferDTO.getFundTransferDate().toInstant().atZone(ZoneId.systemDefault())
				.toLocalDate();
		if (transferDate.isBefore(LocalDate.now())) {
			throw new InfyBankException(ExceptionConstants.FT_DATE_INVALID.toString());
		}

	}

	/**
	 * Save fund transfer details to database
	 * 
	 * @param ftDTO
	 *            fund transfer details
	 * @param fromAcct
	 *            account from which to transfer funds
	 * @param toAcct
	 *            account to which to transfer funds
	 * @throws InfyBankException
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public void saveTransfer(FundTransferDTO ftDTO, BankAccount fromAcct, BankAccount toAcct) throws InfyBankException {

		FundTransfer fundTransfer = FundTransferDTO.prepareEntity(ftDTO);
		fundTransfer = ftRepo.saveAndFlush(fundTransfer);

		if (isTransferNow(fundTransfer.getFtDate())) {
			acctService.performTransaction(fundTransfer.getFtAmount(), null, fromAcct, AccountTransactionType.DEBIT, AccountTransactionCategory.FUNDS_TRANSFER);
			if (toAcct != null) {
				acctService.performTransaction(fundTransfer.getFtAmount(), null, toAcct, AccountTransactionType.CREDIT, AccountTransactionCategory.FUNDS_TRANSFER);
				fundTransfer.setStatus(TRANSFER_COMPLETE);
				ftRepo.saveAndFlush(fundTransfer);
			}
		}
	}

	/**
	 * Fetches Fund Transfers that are at pending state for a given Payee
	 *
	 * @param payeeId
	 *            the payee id for whom fund transfers need to be found
	 * @return list of fund transfer entity objects
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public List<FundTransfer> getPendingTransfersForPayee(int payeeId) throws InfyBankException {

		return ftRepo.findByPayeeIdAndStatus(payeeId, TRANSFER_PENDING);
	}

	/**
	 * To validate the Input provided.
	 *
	 * @param payeeId
	 *            the payee id
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private void validatePayeeForFundTransfer(int payeeId) throws InfyBankException {

		// Validate that payee must exist for fund transfer
		Payee payee = payeeRepo.findOne(payeeId);
		if (payee == null)
			throw new InfyBankException(ExceptionConstants.PAYEE_DOESNOT_EXIST.toString());

		// Fund Transfer cannot be performed for upto 3000 secs after Payee
		// confirmation
		Date confirmedTime = payee.getLstUpdtTs();
		long expiryLimit = appProps.getFtLimit();
		Date date2 = DateUtil.addDuration(confirmedTime, DateField.SECOND, expiryLimit);
		if (new Date().before(date2)) {
			throw new InfyBankException(ExceptionConstants.PAYEE_TRANSFER_NOTALLOWED.toString());
		}
	}

	/**
	 * To get payee account.
	 *
	 * @param payeeId
	 *            the payeeId
	 * @return account with param payeeCustId and PayeeAccountNo
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private BankAccount getPayeeAccount(int payeeId) throws InfyBankException {
		Payee payee = payeeRepo.findOne(payeeId);

		if (payee == null)
			throw new InfyBankException(ExceptionConstants.PAYEE_DOESNOT_EXIST.toString());
		if (payee.getStatus() != PAYEE_CONFIRMED)
			throw new InfyBankException(ExceptionConstants.PAYEE_NOT_CONFIRMED.toString());

		return verifyAccount(payee.getAcctNo());
	}

	/**
	 * To transfer on particular date.
	 *
	 * @param input
	 *            the date
	 * @return true if successful
	 */
	private boolean isTransferNow(Date input) {
		LocalDate transferDate = DateUtil.getLocalDate(input);
		return transferDate.compareTo(LocalDate.now()) == 0 ? true : false;
	}

	/**
	 * To Check whether account has minimum balance.
	 *
	 * @param acct
	 *            the account
	 * @param amountToBededcuted
	 *            the amount to be deducted
	 * @return true if successful
	 */
	private boolean hasMinBalance(BankAccount acct, BigDecimal amountToBededcuted) throws InfyBankException {
		BigDecimal minAmount = acctConfigService.getMinimumBalance(acct.getAcctType());
		BigDecimal currentAmount = acct.getBalance();
		BigDecimal value = currentAmount.subtract(amountToBededcuted);
		return (value.longValue() < minAmount.longValue()) ? false : true;

	}

	/**
	 * To verify the customer Account.
	 *
	 * @param custId
	 *            the customerId
	 * @param acctNo
	 *            the accountNo
	 * @return account if data exists in bankAccount table
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */

	private BankAccount verifyCustAcct(int custId, String acctNo) throws InfyBankException {
		BankAccount acct = acctService.getAccountDetails(custId, acctNo);
		if (acct == null)
			throw new InfyBankException(ExceptionConstants.CUSTOMER_ACCOUNT_DETAILS_NOT_PRESENT.toString());
		return acct;
	}

	/**
	 * Verify account.
	 *
	 * @param acctNo
	 *            the acct no
	 * @return the bank account
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private BankAccount verifyAccount(String acctNo) throws InfyBankException {
		BankAccount acct = acctService.getAcctDetail(acctNo);
		if (acct == null)
			throw new InfyBankException(ExceptionConstants.CUSTOMER_ACCOUNT_DETAILS_NOT_PRESENT.toString());
		return acct;
	}
}
