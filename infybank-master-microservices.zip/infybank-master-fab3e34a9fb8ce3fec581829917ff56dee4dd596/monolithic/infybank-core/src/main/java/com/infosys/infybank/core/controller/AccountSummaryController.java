package com.infosys.infybank.core.controller;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.core.dto.AccountSummaryDTO;
import com.infosys.infybank.core.service.AccountSummaryService;
import com.infosys.infybank.exception.InfyBankException;

/**
 * 
 * The accountSummaryController
 *
 */
@RestController
public class AccountSummaryController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	AccountSummaryService acctSummaryService;

	/**
	 * This controller handles the request for getting the account summary for a
	 * customer
	 * 
	 * @param custId
	 *            the customerId
	 * @return AccountSummaryDTO
	 * @throws InfyBankException
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/account-summary", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public AccountSummaryDTO getAccountSummary(@PathVariable("custId") int custId) throws InfyBankException {
		logger.debug("Data received is {}", custId);
		return acctSummaryService.getAccountSummary(custId);
	}

}
