package com.infosys.infybank.loan.repository;
 
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.loan.entity.Amortization;
import com.infosys.infybank.loan.entity.AmortizationId;

/**
 * The Interface AmmortizationRepository.
 */
@Repository
public interface AmortizationRepository extends JpaRepository<Amortization, AmortizationId> {
	
	/**
	 * Gets the amortization details.
	 *
	 * @param custId the cust id
	 * @param loanAcctNo the loan acct no
	 * @return the amortization details
	 */
	@Query(value = "select a from Amortization a where a.id.custId=:custId and " + "a.id.loanAcctNo=:loanAcctNo"
			+ " order by a.id.installmentNo")
	public List<Amortization> getAmortizationDetails(@Param("custId") int custId,
			@Param("loanAcctNo") String loanAcctNo);

	/**
	 * Gets the last prepayment date.
	 *
	 * @return the last prepayment date
	 */
	@Query(value = "select max(a.installmentDate) from Amortization a where a.interestComponent=0")
	public Date getLastPrepaymentDate();
}
