package com.infosys.infybank.core.service;
 
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.infosys.infybank.core.dto.OtpStatus;
import com.infosys.infybank.core.dto.OtpType;
import com.infosys.infybank.core.entity.Otp;
import com.infosys.infybank.core.repository.OTPRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.utilities.DateField;
import com.infosys.infybank.utilities.DateUtil;
/**
 * The Class OTPService.
 */
@Service
public class OTPService {

	@Autowired
	OTPGeneratorService otpGeneratorService;
	
	/** The otp repository. */
	@Autowired
	OTPRepository otpRepo;

	/** Expiry Limit */
	@Value("${otp.expiry.limit.insec}")
	long expiryLimit;
	
	/**
	 * Generate and save OTP for customer.
	 *
	 * @param emailId
	 *            the email id
	 * @param otpType
	 *            the otp type
	 * @return the long
	 */
	public Otp saveOTPForCustomer(int custId, String emailId, OtpType otpType, int payeeId) {
		String otpString = otpGeneratorService.createOTP();
		Otp otp = new Otp(custId, emailId, otpType.toString().charAt(0), otpString, payeeId);
		return otpRepo.saveAndFlush(otp);
	}

	/**
	 * Checks if is valid OTP.
	 *
	 * @param otp
	 *            the otp
	 * @param emailId
	 *            the email id
	 * @param otpType
	 *            the otp type
	 * @return the otp status
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public OtpStatus isOTPValid(String otp, String emailId, OtpType otpType) throws InfyBankException {

		List<Otp> otps = otpRepo.findFirstByEmailIdAndOtpTypeOrderByGeneratedTsDesc(emailId,
				otpType.toString().charAt(0));
		return checkOtp(otps, otp);
	}

	public OtpStatus isValidOTPForPayee(String otp, int custId, int payeeId) throws InfyBankException {

		List<Otp> otps = otpRepo.findByCustIdAndPayeeIdOrderByGeneratedTsDesc(custId, payeeId);
		return checkOtp(otps, otp);
	}

	/**
	 * Checks if OTP is valid
	 *
	 * @param otps
	 *            list of OTP fetched from database
	 * @param otp
	 *            OTP string provided by end user
	 * @return OTPStatus
	 */
	public OtpStatus checkOtp(List<Otp> otps, String otp) throws InfyBankException {

		if (otps == null || otps.isEmpty()) {
			throw new InfyBankException(ExceptionConstants.OTP_NOT_FOUND.toString());
		}

		Otp latestOtp = otps.get(0);

		if (otp.equals(latestOtp.getOtp())) {
			if (hasOtpExpired(latestOtp.getGeneratedTs())) {
				return OtpStatus.EXPIRED;
			}
			return OtpStatus.VALID;
		}
		return OtpStatus.INVALID;
	}

	/**
	 * Checks for otp expired.
	 *
	 * @param otpCreation
	 *            the otp creation
	 * @return true, if successful
	 * @throws InfyBankException 
	 */
	private boolean hasOtpExpired(Date otpGeneratedTs) throws InfyBankException {
		Date date2 = DateUtil.addDuration(otpGeneratedTs, DateField.SECOND, expiryLimit);
		if (!(new Date().before(date2))) {
			return true;
		}
		return false;
	}
}
