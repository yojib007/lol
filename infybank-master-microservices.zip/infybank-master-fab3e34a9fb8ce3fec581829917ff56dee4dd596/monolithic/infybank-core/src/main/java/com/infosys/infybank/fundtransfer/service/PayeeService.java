package com.infosys.infybank.fundtransfer.service;
 
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.CustomerDTO;
import com.infosys.infybank.core.dto.Email;
import com.infosys.infybank.core.dto.OtpDTO;
import com.infosys.infybank.core.dto.OtpStatus;
import com.infosys.infybank.core.dto.OtpType;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.Otp;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.core.service.NotificationService;
import com.infosys.infybank.core.service.OTPService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.fundtransfer.dto.IFSCMasterDTO;
import com.infosys.infybank.fundtransfer.dto.PayeeDTO;
import com.infosys.infybank.fundtransfer.entity.FundTransfer;
import com.infosys.infybank.fundtransfer.entity.Payee;
import com.infosys.infybank.fundtransfer.repository.PayeeRepository;

/**
 * The Class PayeeService.
 */
@Service
public class PayeeService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The Constant ACCOUNT_OPEN. */
	public static final String ACCOUNT_OPEN = "A";

	/** The Constant ADD_PAYEE. */
	public static final String ADD_PAYEE = "P";

	/** The Constant PAYEE_DELETED. */
	public static final char PAYEE_DELETED = 'D';

	/** The Constant PAYEE_CONFIRMED. */
	public static final char PAYEE_CONFIRMED = 'C';

	/** The Constant PAYEE_SUBMITTED. */
	public static final char PAYEE_SUBMITTED = 'S';

	/** The payee repository. */
	@Autowired
	PayeeRepository payeeRepo;

	/** The fund transfer repository. */
	@Autowired
	FundTransferService ftService;

	/** The Otp service. */
	@Autowired
	OTPService otpService;

	/** the Customer Service *. */
	@Autowired
	CustomerService custService;

	/** the account service *. */
	@Autowired
	AccountService acctService;

	@Autowired
	NotificationService notificationService;

	/** The rest template. */
	@Autowired
	RestTemplate restTemplate;

	/** The Configuration Bean */
	@Autowired
	ApplicationProperties appProps;

	/**
	 * Add a payee
	 *
	 * @param payeeDTO
	 *            the object
	 * @return add payee with param object and custId
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public boolean addPayee(PayeeDTO payeeDTO) throws InfyBankException {

		// Validate request and fetch customer details
		CustomerDTO customerDTO = validateAddPayee(payeeDTO);

		// Add payee to database and create OTP record
		Otp otp = addCustomerPayee(payeeDTO, customerDTO);

		// send email notification to customer about payee creation
		notifyCustomer(customerDTO.getEmailId(), otp.getOtp(), otp.getGeneratedTs());

		return true;
	}

	/**
	 * creates and populates an email instance and invokes the notifyCustomer
	 * method from NotificationService
	 * 
	 * @param emailId
	 *            the emailId of the customer
	 * @param otp
	 *            the generated otp String
	 * @param generatedTs
	 *            the timestamp when the otp String was generated
	 * @return void
	 */
	private void notifyCustomer(String emailId, String otp, Date generatedTs) {
		Email email = new Email();
		email.setToEmail(emailId);

		email.setSubject("OTP confirmation alert for your new Payee");

		String message = java.text.MessageFormat.format("Dear Customer,\n\n\t  Please use {0} as"
				+ " as One Time Password (OTP) to confirm the payee you have added. This OTP was generated on {1} and expires in 5 minutes."
				+ "\r\n You can transfer funds to this payee 1 hour after payee confirmation. "
				+ "Looking forward to more opportunities to be of service to you. "
				+ "\n\n Sincerely,\n InfyBank Customer Care", otp, generatedTs);

		email.setEmailMessage(message);

		notificationService.notifyCustomer(email);
	}

	/**
	 * Vaidates data for add payee
	 *
	 * @param payeeDTO
	 *            the object
	 * @return add payee with param object and custId
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public CustomerDTO validateAddPayee(PayeeDTO payeeDTO) throws InfyBankException {

		// to account must be valid
		if (!payeeDTO.getAcctNo().matches("[0-9]{10}")) {
			throw new InfyBankException(ExceptionConstants.PAYEE_ACCOUNTNO_INVALID.toString());
		}

		// account no. must exist on InfyBank if transfer is to own account or
		// someone else's Infybank account
		String ifscCode = payeeDTO.getIfscCode();
		if (ifscCode == null) {
			if (!isBankAccountValid(payeeDTO.getAcctNo())) {
				throw new InfyBankException(ExceptionConstants.PAYEE_ACCOUNTNO_INVALID.toString());
			}
		}

		// Account Type must be valid
		try {
			acctService.verifyAcctType(payeeDTO.getAcctType());
		} catch (InfyBankException e) {
			throw new InfyBankException(ExceptionConstants.PAYEE_ACCOUNT_TYPE_INVALID.toString());
		}

		// Customer must exist
		CustomerDTO customerDTO = custService.viewCustomerProfile(payeeDTO.getCustId());

		// Account must not be for the customer who is adding a payee. Payee is
		// not required for transfer to self owned acocunts
		if (acctService.isBankAccountValid(payeeDTO.getCustId(), payeeDTO.getAcctNo()))
			throw new InfyBankException(ExceptionConstants.PAYEE_SAMECUSTOMER_ACCOUNT.toString());

		// IFSC Code must be valid
		if (ifscCode != null && !(isValidIFSC(ifscCode))) {
			throw new InfyBankException(ExceptionConstants.PAYEE_IFSC_INVALID.toString());
		}

		// Payee must not already exist for the same customer
		if (isDuplicatePayee(payeeDTO.getAcctNo(), payeeDTO.getCustId())) {
			throw new InfyBankException(ExceptionConstants.PAYEE_ALREADY_ADDED.toString());
		}

		return customerDTO;
	}

	/**
	 * Method to add customer payee.
	 *
	 * @param payeeDTO
	 *            the object
	 * @return true if OTP is generated
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private Otp addCustomerPayee(PayeeDTO payeeDTO, CustomerDTO customerDTO) throws InfyBankException {

		// Create entity from DTO and save to database
		Payee payee = PayeeDTO.prepareEntity(payeeDTO);
		payee.setStatus(PAYEE_SUBMITTED);
		payee.setLstUpdtId(payeeDTO.getUserId());

		Payee createdPayee = payeeRepo.saveAndFlush(payee);

		// Generate and store OTP to be used later for confirmation of new payee
		String email = customerDTO.getEmailId();
		Otp otp = otpService.saveOTPForCustomer(payeeDTO.getCustId(), email, OtpType.ADD_PAYEE,
				createdPayee.getPayeeId());
		if (otp == null) {
			throw new InfyBankException(ExceptionConstants.CUSTOMER_OTP_GENERATION_FAILED.toString());
		}

		return otp;

	}

	/**
	 * Checks payee is not duplicate.
	 *
	 * @param acctNo
	 *            the acct no
	 * @param custId
	 *            the cust id
	 * @return true, if payee is not duplicate
	 */
	private boolean isDuplicatePayee(String acctNo, int custId) {
		Payee payeeRet = payeeRepo.findPayeeByAcctNumber(acctNo, custId);
		return (payeeRet != null && payeeRet.getPayeeId() != 0) ? true : false;

	}

	/**
	 * check ifsccode is valid.
	 *
	 * @param ifscCode
	 *            the ifsccode
	 * @return true if ifsc details are available
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */

	private boolean isValidIFSC(String ifscCode) throws InfyBankException {

		// IFSC Code must be of 11 characters
		if (ifscCode.length() != 11) {
			throw new InfyBankException(ExceptionConstants.PAYEE_IFSC_CODE_INVALID.toString());
		}

		// Generate URL for invoking external service to validate IFSC
		String url = appProps.getIfscUrl();
		logger.info("External URL for ifsc {}", url);
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url).queryParam("ifscCode", ifscCode);
		String urlWithParam = builder.toUriString();

		// Validate IFSC
		IFSCMasterDTO ifscMasterDTO = null;
		try {
			ifscMasterDTO = restTemplate.getForObject(urlWithParam, IFSCMasterDTO.class);
		} catch (Exception exp) {
			logger.error("Exception caught", exp);
			throw new InfyBankException(ExceptionConstants.GENERAL_ERROR.toString());
		}

		logger.info("return value from external for ifsc {}", ifscMasterDTO);
		return (ifscMasterDTO == null) ? false : true;

	}

	/**
	 * Checks if is bank account valid.
	 *
	 * @param acctNo
	 *            the acct no
	 * @return true, if is bank account valid
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private boolean isBankAccountValid(String acctNo) {

		BankAccount bankAccount = acctService.getAcctDetail(acctNo);
		return (bankAccount == null) ? false : true;

	}

	/**
	 * Confirm Payee
	 *
	 * @param custId
	 *            the customer Id
	 * @param payeeId
	 *            the payee Id
	 * @param otpDTO
	 *            the otp dto
	 * @return true if payee repository return the data
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public void confirmPayee(int custId, int payeeId, OtpDTO otpDTO) throws InfyBankException {

		// check if custId is valid
		custService.getCustomerDetails(custId);

		// Fetch payee details from the database
		Payee payee = payeeRepo.getPayeeForCustomer(custId, payeeId);

		// The Payee must exist and must not already be confirmed
		if (payee == null) {
			throw new ResourceNotFoundException(ExceptionConstants.PAYEE_DOESNOT_EXIST.toString());
		} else if (payee.getStatus() == PAYEE_CONFIRMED) {
			throw new InfyBankException(ExceptionConstants.PAYEE_ALREADY_CONFIRMED.toString());
		}

		// check if OTP is valid
		OtpStatus otpStatus = otpService.isValidOTPForPayee(otpDTO.getOtp(), custId, payeeId);

		switch (otpStatus) {
		case VALID:
			updatePayeeStatus(custId, payeeId); break;
		case INVALID:
			throw new InfyBankException(ExceptionConstants.PAYEE_INVALID_OTP.toString()); 
		case EXPIRED:
			throw new InfyBankException(ExceptionConstants.PAYEE_EXPIRED_OTP.toString());
		}
	}

	/**
	 * Update payee status.
	 *
	 * @param custId
	 *            the cust id
	 * @param payeeId
	 *            the payee id
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public void updatePayeeStatus(int custId, int payeeId) {
		payeeRepo.updatePayeeStatus(custId, payeeId, PAYEE_CONFIRMED);
	}

	/**
	 * Method to find Active Payee.
	 *
	 * @param custId
	 *            the customerId
	 * @return payeeDTO if payeeList is not empty
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public List<PayeeDTO> findPayeesByStatus(int custId, char status) throws InfyBankException {

		// check if custId is valid
		custService.getCustomerDetails(custId);

		// Fetch all Confirmed and Submitted Payees from the database
		List<Payee> payees = payeeRepo.getConfirmedPayees(custId, status);

		// Convert entity to dto
		List<PayeeDTO> payeeDTOs = new ArrayList<PayeeDTO>();
		for (Payee payee : payees) {
			payeeDTOs.add(PayeeDTO.prepareDTO(payee));
		}
		return payeeDTOs;
	}

	/**
	 * Method to delete payee.
	 *
	 * @param custId
	 *            the customer Id
	 * @param payeeId
	 *            the payee Id
	 * @return true if updatepayeemethod is not null
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public void deletePayee(int custId, int payeeId) throws InfyBankException {

		// check if custId is valid
		custService.getCustomerDetails(custId);

		// Payee for the customer must be in Submitted or Confirmed status
		Payee payee = payeeRepo.getPayeeForCustomer(custId, payeeId);
		if (payee == null) {
			throw new ResourceNotFoundException(ExceptionConstants.PAYEE_DOESNOT_EXIST.toString());
		}

		// There should not be any pending funds transfer for the payee
		if (payee.getStatus() == PAYEE_CONFIRMED) {
			List<FundTransfer> fundTransfers = ftService.getPendingTransfersForPayee(payeeId);
			if (fundTransfers.size() > 0) {
				throw new InfyBankException(ExceptionConstants.PAYEE_FUNDTRANSFER_PENDING.toString());
			}
		}

		int returnValue = payeeRepo.updatePayeeStatus(custId, payeeId, PAYEE_DELETED);
		if (returnValue <= 0) {
			logger.error("Payee could not be updated in database");
			throw new InfyBankException(ExceptionConstants.SERVER_ERROR.toString());
		}

	}

}
