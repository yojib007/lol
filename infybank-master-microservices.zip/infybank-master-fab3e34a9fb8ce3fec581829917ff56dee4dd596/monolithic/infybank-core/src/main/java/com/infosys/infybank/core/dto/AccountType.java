package com.infosys.infybank.core.dto;
 
/**
 * AccountType.java - enum to represent the type of account
 * 
 */
public enum AccountType {

	/** Savings Bank Account */
	SAVINGS_BANK_ACCOUNT("S"),

	/** Current Account */
	CURRENT_ACCOUNT("C"),

	/** Loan Account */
	LOAN_ACCOUNT("L");

	/** The type. */
	private final String type;

	/**
	 * Instantiates a new account type.
	 *
	 * @param type
	 *            the type
	 */
	private AccountType(String type) {
		this.type = type;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString() {
		return this.type;
	}

	/**
	 * Parse AccountType enum from the string value
	 * 
	 * @param value
	 *            the value to be parsed
	 * @return AccountType enum
	 * 
	 */
	public static AccountType fromString(String value) {
		for (AccountType t : AccountType.values()) {
			if (t.type.equalsIgnoreCase(value)) {
				return t;
			}
		}
		return null;
	}
}
