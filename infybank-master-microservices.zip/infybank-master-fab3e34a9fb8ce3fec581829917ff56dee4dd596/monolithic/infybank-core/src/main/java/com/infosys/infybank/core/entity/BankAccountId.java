package com.infosys.infybank.core.entity;
 
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The Class BankAccountId.
 */
@Embeddable
public class BankAccountId implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	@Column(name = "CUST_ID", nullable = false)
	private int custId;

	/** The acct no. */
	@Column(name = "ACCT_NO", nullable = false, length = 20)
	private String acctNo;
	
	
	public BankAccountId() {
		/*default constructor*/
	}
	
	public BankAccountId(int custId, String acctNo) {
		this.custId = custId;
		this.acctNo = acctNo;
	}



	@Override
	public String toString() {
		return "BankAccountId [custId=" + custId + ", acctNo=" + acctNo + "]";
	}



	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return this.custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return this.acctNo;
	}

	/**
	 * Sets the acct no.
	 *
	 * @param acctNo
	 *            the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		if (other == null)
			return false;
		if (!(other instanceof BankAccountId))
			return false;
		BankAccountId castOther = (BankAccountId) other;
		return (this.getCustId() == castOther.getCustId())
				&& (this.getAcctNo() == castOther.getAcctNo());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		int result = 17;
		result = 37 * result + this.getCustId();
		result = 37 * result + (getAcctNo() == null ? 0 : this.getAcctNo().hashCode());
		return result;
	}

}
