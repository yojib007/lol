package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

import com.infosys.infybank.loan.entity.LoanConfig;
import com.infosys.infybank.loan.entity.LoanConfigId;

/**
 * The Class LoanConfigDTO.
 */
public class LoanConfigDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The credit score start. */
	private int creditScoreStart;

	/** The credit score end. */
	private int creditScoreEnd;

	/** The loan approval ind. */
	@Pattern(regexp = "N|Y")
	private char loanApprovalInd;

	/** The interest rate. */
	@NotNull(message = "loanconfig.interestrate.mandatory")
	private BigDecimal interestRate;

	/** The user id. */
	@NotBlank(message = "loanconfig.userId.mandatory")
	private String userId;

	/**
	 * Gets the credit score start.
	 *
	 * @return the credit score start
	 */
	public int getCreditScoreStart() {
		return creditScoreStart;
	}

	/**
	 * Sets the credit score start.
	 *
	 * @param creditScoreStart
	 *            the new credit score start
	 */
	public void setCreditScoreStart(int creditScoreStart) {
		this.creditScoreStart = creditScoreStart;
	}

	/**
	 * Gets the credit score end.
	 *
	 * @return the credit score end
	 */
	public int getCreditScoreEnd() {
		return creditScoreEnd;
	}

	/**
	 * Sets the credit score end.
	 *
	 * @param creditScoreEnd
	 *            the new credit score end
	 */
	public void setCreditScoreEnd(int creditScoreEnd) {
		this.creditScoreEnd = creditScoreEnd;
	}

	/**
	 * Gets the loan approval ind.
	 *
	 * @return the loan approval ind
	 */
	public char getLoanApprovalInd() {
		return loanApprovalInd;
	}

	/**
	 * Sets the loan approval ind.
	 *
	 * @param loanApprovalInd
	 *            the new loan approval ind
	 */
	public void setLoanApprovalInd(char loanApprovalInd) {
		this.loanApprovalInd = loanApprovalInd;
	}

	/**
	 * Gets the interest rate.
	 *
	 * @return the interest rate
	 */
	public BigDecimal getInterestRate() {
		return interestRate;
	}

	/**
	 * Sets the interest rate.
	 *
	 * @param interestRate
	 *            the new interest rate
	 */
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	/**
	 * Prepare entity.
	 *
	 * @param loanDTO
	 *            the loan DTO
	 * @return the loan config
	 */
	public static LoanConfig prepareEntity(LoanConfigDTO loanDTO) {
		LoanConfig loanConfig = new LoanConfig();
		loanConfig.setInterestRate(loanDTO.getInterestRate());
		LoanConfigId loanConfigId = new LoanConfigId();
		loanConfigId.setCreditScoreStart(loanDTO.getCreditScoreStart());
		loanConfigId.setCreditScoreEnd(loanDTO.creditScoreEnd);
		loanConfig.setId(loanConfigId);
		loanConfig.setInterestRate(loanDTO.getInterestRate());
		loanConfig.setLoanApprovalInd(loanDTO.getLoanApprovalInd());
		loanConfig.setLstUpdtId(loanDTO.getUserId());
		return loanConfig;
	}

	/**
	 * Prepare DTO.
	 *
	 * @param loanConfig
	 *            the loan config
	 * @return the loan config DTO
	 */
	public static LoanConfigDTO valueOf(LoanConfig loanConfig) {
		LoanConfigDTO loanConfigDTO = new LoanConfigDTO();

		loanConfigDTO.setInterestRate(loanConfig.getInterestRate());
		loanConfigDTO.setLoanApprovalInd(loanConfig.getLoanApprovalInd());

		loanConfigDTO.setCreditScoreEnd(loanConfig.getId().getCreditScoreEnd());
		loanConfigDTO.setCreditScoreStart(loanConfig.getId().getCreditScoreStart());
		loanConfigDTO.setUserId(loanConfig.getLstUpdtId());

		return loanConfigDTO;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId
	 *            the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "LoanConfigDTO [creditScoreStart=" + creditScoreStart + ", creditScoreEnd=" + creditScoreEnd
				+ ", loanApprovalInd=" + loanApprovalInd + ", interestRate=" + interestRate + ", userId=" + userId
				+ "]";
	}

}
