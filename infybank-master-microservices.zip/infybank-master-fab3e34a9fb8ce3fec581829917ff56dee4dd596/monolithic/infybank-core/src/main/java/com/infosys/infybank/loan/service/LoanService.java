package com.infosys.infybank.loan.service;
 
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.AccountTransactionDTO;
import com.infosys.infybank.core.entity.AccountTransaction;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.repository.CustomerRepository;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.AccountTransactionService;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.loan.dto.ApplyLoanDTO;
import com.infosys.infybank.loan.dto.ApproveLoanDTO;
import com.infosys.infybank.loan.dto.CreditScoreDTO;
import com.infosys.infybank.loan.dto.LoanAccountDTO;
import com.infosys.infybank.loan.dto.LoanApplicationDTO;
import com.infosys.infybank.loan.dto.ViewLoanDetailsDTO;
import com.infosys.infybank.loan.entity.Amortization;
import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.entity.LoanAccountId;
import com.infosys.infybank.loan.entity.LoanConfig;
import com.infosys.infybank.loan.repository.AmortizationRepository;
import com.infosys.infybank.loan.repository.LoanRepository;
import com.infosys.infybank.utilities.DateField;
import com.infosys.infybank.utilities.DateUtil;

/**
 * The Class LoanAccountService.
 */
@Service
public class LoanService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The loan account repository. */
	@Autowired
	LoanRepository loanRepo;

	/** The amortization repository. */
	@Autowired
	AmortizationRepository amortizationRepo;

	/** The amortization service. */
	@Autowired
	AmortizationService amortizationService;

	/** The loan config service. */
	@Autowired
	LoanConfigService loanConfigService;

	/** The customer service. */
	@Autowired
	CustomerService custService;

	/** The account service. */
	@Autowired
	AccountService acctService;

	/** The account transaction service. */
	@Autowired
	AccountTransactionService acctTxnService;

	/** The Configuration Bean */
	@Autowired
	ApplicationProperties appProps;

	/** The rest template. */
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	CustomerRepository custRepo;

	/** The Constant SUBMITTED. */
	public static final char SUBMITTED = 'S';

	/** The Constant REJECTED. */
	public static final char REJECTED = 'R';

	/** The Constant APPROVED. */
	public static final char APPROVED = 'A';

	/** The Constant CLOSED. */
	public static final char CLOSED = 'C';

	/** The Constant YES. */
	public static final char YES = 'Y';

	/**
	 * Apply personal loan.
	 *
	 * @param applyLoanDTO
	 *            the apply loan dto
	 * @return boolean
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public void applyPersonalLoan(ApplyLoanDTO applyLoanDTO) throws InfyBankException {

		// validate loan tenure
		int tenure = applyLoanDTO.getTenure();
		if (!(tenure >= appProps.getMinLoanTenure() && tenure <= appProps.getMaxLoanTenure())) {
			throw new InfyBankException(ExceptionConstants.INVALID_TENURE.toString());
		}

		// the customer must be valid
		custService.getCustomerDetails(applyLoanDTO.getCustId());

		// Debit account no must exist and must be a salaried account.
		if (!acctService.isAccountSalaried(applyLoanDTO.getCustId(), applyLoanDTO.getDebitAcctNo())) {
			throw new InfyBankException(ExceptionConstants.ACCOUNT_NOT_SALARIED.toString());
		}

		// Customer must not have any existing loans at approved or submitted
		// status
		if (loanRepo.getSubmittedAndApprovedLoans(applyLoanDTO.getCustId()) != null) {
			throw new InfyBankException(ExceptionConstants.LOAN_EXISTS.toString());
		}

		createLoanAccount(applyLoanDTO);

	}

	/**
	 * Create a personal loan account in database
	 *
	 * @param applyLoanDTO
	 *            the apply loan dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	private void createLoanAccount(ApplyLoanDTO applyLoanDTO) throws InfyBankException {

		// Save the loan application to the database
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setId(new LoanAccountId(applyLoanDTO.getCustId(), acctService.generateAccountNumber('L')));
		loanAccount.setLoanAmount(applyLoanDTO.getLoanAmount());
		loanAccount.setTenure(applyLoanDTO.getTenure());
		loanAccount.setDebitAcctNo(applyLoanDTO.getDebitAcctNo());
		loanAccount.setLstUpdtId(applyLoanDTO.getUserId());
		loanAccount.setLstUpdtTs(new Date());
		loanAccount.setLoanStatus(SUBMITTED);
		loanRepo.saveAndFlush(loanAccount);

	}

	/**
	 * Gets the all loan accounts.
	 *
	 * @param custId
	 *            the cust id
	 * @return the all loan accounts
	 */
	public List<LoanAccount> getAllLoanAccounts(int custId) {
		return loanRepo.findById_CustId(custId);
	}

	public List<ViewLoanDetailsDTO> viewAllLoans(int custId) throws InfyBankException {
		List<LoanAccount> loans = getAllLoanAccounts(custId);
		List<ViewLoanDetailsDTO> loanDTOs = new ArrayList<ViewLoanDetailsDTO>();
		for (LoanAccount loanAccount : loans) {
			ViewLoanDetailsDTO viewLoanDetailsDTO = new ViewLoanDetailsDTO();
			viewLoanDetailsDTO.setLoanAcctNo(loanAccount.getId().getLoanAcctNo());
			viewLoanDetailsDTO.setLoanAmount(loanAccount.getLoanAmount());
			viewLoanDetailsDTO.setLoanStatus(loanAccount.getLoanStatus());
			viewLoanDetailsDTO.setTenure(loanAccount.getTenure());
			viewLoanDetailsDTO.setInterestRate(loanAccount.getInterestRate());
			viewLoanDetailsDTO.setLstUpdtTs(loanAccount.getLstUpdtTs());

			if (!(loanAccount.getLoanStatus() == SUBMITTED || loanAccount.getLoanStatus() == REJECTED)) {
				viewLoanDetailsDTO.setEmi(loanAccount.getEmi().setScale(2, RoundingMode.HALF_UP));
				Date expectedClosureDate = DateUtil.addDuration(loanAccount.getOpeningDate(), DateField.DAY,
						loanAccount.getTenure());

				viewLoanDetailsDTO.setExpectedClosureDate(expectedClosureDate);

				BigDecimal totalPrincipalAmount = new BigDecimal(0);
				BigDecimal totalInterestPaid = new BigDecimal(0);

				List<Amortization> ammortizationList = amortizationService.getAmortizationDetails(custId,
						loanAccount.getId().getLoanAcctNo());

				if (!(ammortizationList == null || ammortizationList.isEmpty())) {
					for (Amortization ammortization : ammortizationList) {
						totalPrincipalAmount = totalPrincipalAmount.add(ammortization.getPrincipalComponent());
						totalInterestPaid = totalInterestPaid.add(ammortization.getInterestComponent());
					}
				}
				BigDecimal outstandingAmount = loanAccount.getLoanAmount().subtract(totalPrincipalAmount);
				viewLoanDetailsDTO.setOutstandingBalance(outstandingAmount);
				viewLoanDetailsDTO.setTotalPrincipalAmount(totalPrincipalAmount);
				viewLoanDetailsDTO.setTotalInterestPaid(totalInterestPaid);

			}
			loanDTOs.add(viewLoanDetailsDTO);
		}
		return loanDTOs;
	}

	/**
	 * Gets the all loan accounts for the given status.
	 *
	 * @param custId
	 *            the cust id
	 * @param loanStatus
	 *            the loan status
	 * @return the all loan accounts for the given status
	 */
	public List<LoanAccount> getLoanAccountForCustIdAndStatus(int custId, char loanStatus) {
		return loanRepo.findById_CustIdAndLoanStatus(custId, loanStatus);
	}

	/**
	 * View loan details.
	 *
	 * @param custId
	 *            the cust id
	 * @param loanAcctNo
	 *            the loan acct no
	 * @return the view loan details dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public ViewLoanDetailsDTO viewLoanDetails(int custId, String loanAcctNo) throws InfyBankException {

		// the customer must be valid
		custService.getCustomerDetails(custId);

		// fetch details for the loan account
		LoanAccount loanAccount = loanRepo.findOne(new LoanAccountId(custId, loanAcctNo));
		if (loanAccount == null) {
			throw new ResourceNotFoundException(ExceptionConstants.LOAN_DETAILS_NOT_AVAILABLE.toString());
		}

		ViewLoanDetailsDTO viewLoanDetailsDTO = new ViewLoanDetailsDTO();
		viewLoanDetailsDTO.setLoanAcctNo(loanAccount.getId().getLoanAcctNo());
		viewLoanDetailsDTO.setLoanAmount(loanAccount.getLoanAmount());
		viewLoanDetailsDTO.setLoanStatus(loanAccount.getLoanStatus());
		viewLoanDetailsDTO.setTenure(loanAccount.getTenure());
		viewLoanDetailsDTO.setInterestRate(loanAccount.getInterestRate());

		// customer can see only approved loans
		if (loanAccount.getLoanStatus() == APPROVED || loanAccount.getLoanStatus() == CLOSED) {
			viewLoanDetailsDTO.setEmi(loanAccount.getEmi().setScale(2, RoundingMode.HALF_UP));

			List<Amortization> ammortizationList = amortizationService.getAmortizationDetails(custId, loanAcctNo);

			Date expectedClosureDate = DateUtil.addDuration(loanAccount.getOpeningDate(), DateField.DAY,
					loanAccount.getTenure());
			viewLoanDetailsDTO.setExpectedClosureDate(expectedClosureDate);

			BigDecimal totalPrincipalAmount = new BigDecimal(0);
			BigDecimal totalInterestPaid = new BigDecimal(0);

			if (!(ammortizationList == null || ammortizationList.isEmpty())) {
				for (Amortization ammortization : ammortizationList) {
					totalPrincipalAmount = totalPrincipalAmount.add(ammortization.getPrincipalComponent());
					totalInterestPaid = totalInterestPaid.add(ammortization.getInterestComponent());
				}
			}
			BigDecimal outstandingAmount = loanAccount.getLoanAmount().subtract(totalPrincipalAmount);
			viewLoanDetailsDTO.setOutstandingBalance(outstandingAmount);
			viewLoanDetailsDTO.setTotalPrincipalAmount(totalPrincipalAmount);
			viewLoanDetailsDTO.setTotalInterestPaid(totalInterestPaid);

			Date lastPrepaymentDate = amortizationRepo.getLastPrepaymentDate();
			viewLoanDetailsDTO.setLastPrepaymentDate(lastPrepaymentDate);
		}

		return viewLoanDetailsDTO;
	}

	/**
	 * View submitted loans.
	 *
	 * @return the list
	 * @throws InfyBankException
	 */

	public List<LoanApplicationDTO> viewSubmittedLoans(char loanStatus) throws InfyBankException {

		List<LoanApplicationDTO> loanApplicationDTOs = new ArrayList<LoanApplicationDTO>();

		// fetch all loans from database that are at submitted status
		List<LoanAccount> loanAccts = loanRepo.findByLoanStatus(loanStatus);
		if (loanAccts == null || loanAccts.isEmpty()) {
			return loanApplicationDTOs;
		}

		// convert entity to dto
		LoanApplicationDTO loanApplicationDTO = null;
		for (LoanAccount loanAcct : loanAccts) {
			loanApplicationDTO = new LoanApplicationDTO();
			loanApplicationDTO.setLoanAcctNo(loanAcct.getId().getLoanAcctNo());
			loanApplicationDTO.setTenure(loanAcct.getTenure());
			loanApplicationDTO.setLoanAmount(loanAcct.getLoanAmount());
			loanApplicationDTOs.add(loanApplicationDTO);
		}

		return loanApplicationDTOs;
	}

	/**
	 * 
	 * @param custId
	 * @param creditScore
	 * @return
	 * @throws InfyBankException
	 */

	private LoanConfig getLoanConfig(int custId, Integer creditScore) throws InfyBankException {
		LoanConfig loanConfig = loanConfigService.getLoanConfigForCreditScore(creditScore);
		return loanConfig;
	}

	/**
	 * View loan application.
	 *
	 * @param loanAcctNo
	 *            the loan acct no
	 * @return the view loan application dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public LoanApplicationDTO viewLoanApplication(String loanAcctNo) throws InfyBankException {

		// loan account must exist in the database
		LoanAccount loanAccount = loanRepo.findByIdLoanAcctNo(loanAcctNo);
		if (loanAccount == null) {
			throw new ResourceNotFoundException(ExceptionConstants.LOAN_DETAILS_NOT_AVAILABLE.toString());
		}

		// loan application must be at submitted status
		if (loanAccount.getLoanStatus() != SUBMITTED) {
			throw new InfyBankException(ExceptionConstants.STATUS_NOT_VALID.toString());
		}

		// fetch customer details like name and panNo
		Customer cust = custService.getCustomerDetails(loanAccount.getId().getCustId());

		// fetch salary credit transactions in applicant bank accounts
		List<AccountTransaction> salaryCredits = acctTxnService.getSalaryCredits(loanAccount.getId().getCustId(),
				loanAccount.getDebitAcctNo(), 'C', 'S');

		// validate the no. of salary credits as required by business rule are
		// present and convert credits to dto
		LoanApplicationDTO loanApplicationDTO = getSalaryCredits(loanAccount.getId().getCustId(), loanAccount.getDebitAcctNo());

		// Fetch credit score for the applicant from external service
		Integer creditScore = getCreditScore(loanAccount.getId().getCustId(), cust.getPanNo());

		// Fetch applicable rate of interest depending upon the credit score
		LoanConfig loanConfig = getLoanConfig(loanAccount.getId().getCustId(), creditScore);

		// Calculate EMI, Interest rate etc if applicant is eligible for loan
		if (loanConfig.getLoanApprovalInd() == YES) {
			loanApplicationDTO.setIsCreditScoreEligible(true);
			loanApplicationDTO.setInterestRate(loanConfig.getInterestRate());

			BigDecimal emi = LoanUtil.calculateEmi(loanAccount.getLoanAmount(), loanConfig.getInterestRate(),
					loanAccount.getTenure());
			loanApplicationDTO.setEmi(emi);
			loanApplicationDTO.setIsValidEmi(validateEmi(salaryCredits, emi));
		} else {
			loanApplicationDTO.setIsCreditScoreEligible(false);
			loanApplicationDTO.setIsValidEmi(false);
		}

		loanApplicationDTO.setLoanAcctNo(loanAccount.getId().getLoanAcctNo());
		loanApplicationDTO.setCreditScore(creditScore);
		loanApplicationDTO.setLoanAmount(loanAccount.getLoanAmount());
		loanApplicationDTO.setDebitAcctNo(loanAccount.getDebitAcctNo());
		loanApplicationDTO.setTenure(loanAccount.getTenure());
		loanApplicationDTO.setCustName(cust.getFirstName() + " " + cust.getLastName());

		if (loanApplicationDTO.getIsSalaryCreditedForLastNDays() && loanApplicationDTO.getIsCreditScoreEligible()
				&& loanApplicationDTO.getIsValidEmi()) {
			loanApplicationDTO.setEligible(true);
		} else {
			loanApplicationDTO.setEligible(false);
		}

		return loanApplicationDTO;
	}

	/**
	 * Approve loan.
	 *
	 * @param loanAcctNo
	 *            the loan acct no
	 * @param approveLoanDTO
	 *            the approve loan dto
	 * @return the loan account dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public LoanAccountDTO approveLoan(String loanAcctNo, ApproveLoanDTO approveLoanDTO) throws InfyBankException {

		LoanAccount loanAccount = loanRepo.findByIdLoanAcctNo(loanAcctNo);
		LoanApplicationDTO loanApplicationDTO = viewLoanApplication(loanAcctNo);

		// Approver can approve loan only +-0.25% than the loan rate as per the
		// credit score
		if (loanApplicationDTO.getIsCreditScoreEligible()) {
			if ((approveLoanDTO.getInterestRate().subtract(loanApplicationDTO.getInterestRate())).abs()
					.compareTo(BigDecimal.valueOf(0.25)) > 0) {
				throw new InfyBankException(ExceptionConstants.INVALID_INTEREST_RATE.toString());
			}
		} else {
			if (approveLoanDTO.getInterestRate().equals(BigDecimal.valueOf(0))) {
				throw new InfyBankException(ExceptionConstants.INTEREST_RATE_ZERO.toString());
			}
		}

		if (approveLoanDTO.isApprove()) {
			Date emiDueDate = DateUtil.addDuration(new Date(), DateField.DAY, 1);

			BigDecimal emi = LoanUtil.calculateEmi(loanAccount.getLoanAmount(), approveLoanDTO.getInterestRate(),
					loanAccount.getTenure());

			loanAccount.setEmi(emi);
			loanAccount.setEmiDueDate(emiDueDate);
			loanAccount.setInterestRate(approveLoanDTO.getInterestRate());
			loanAccount.setLoanStatus(APPROVED);
			loanAccount.setOpeningDate(new Date());
			loanAccount.setLstUpdtTs(new Date());
			loanAccount.setLstUpdtId(approveLoanDTO.getAdminUserId());
			loanAccount.setRemarks(approveLoanDTO.getRemarks());
		} else {
			loanAccount.setLoanStatus(REJECTED);
		}

		loanRepo.saveAndFlush(loanAccount);

		return LoanAccountDTO.valueOf(loanAccount);
	}

	/**
	 * Gets the credit score.
	 *
	 * @param custId
	 *            the cust id
	 * @param panNo
	 *            PAN nuber of the customer
	 * @return the credit score
	 */
	public Integer getCreditScore(int custId, String panNo) throws InfyBankException {

		if (panNo == null) {
			Customer customer = custService.getCustomerDetails(custId);
			panNo = customer.getPanNo();
		}

		String url = appProps.getCreditScoreUrl();
		logger.info("External URL for creditScore {}", url);
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url).queryParam("panNo", panNo);
		String urlWithParam = builder.toUriString();
		ResponseEntity<CreditScoreDTO> creditScore = restTemplate.getForEntity(urlWithParam, CreditScoreDTO.class);
		logger.info("return value from external for creditScore {} ", creditScore);

		if (creditScore.getStatusCode() == HttpStatus.OK) {
			return creditScore.getBody().getCreditScore();
		} else {
			throw new InfyBankException(ExceptionConstants.CREDITSCORE_SVC_FAILURE.toString());
		}
	}
	
	/**
	 * 
	 * @param custId
	 * @param acctNo 
	 * @return LoanApplicationDTO
	 * @throws InfyBankException
	 */
	public LoanApplicationDTO getSalaryCredits(int custId, String acctNo) throws InfyBankException {

		LoanApplicationDTO loanApplicationDTO = new LoanApplicationDTO();
		List<AccountTransactionDTO> acctTxnDTOs = new ArrayList<AccountTransactionDTO>();
		int n = Integer.valueOf(appProps.getNoOfSalaryCredits());
		Date lastNthDate = DateUtil.addDuration(new Date(), DateField.DAY, -n);
		List<AccountTransaction> lastNSalaryCredits = acctTxnService.getSalaryCreditsForNDays(custId,
				acctNo, 'C', 'S', lastNthDate);
		if(lastNSalaryCredits.size()<n){
			loanApplicationDTO.setIsSalaryCreditedForLastNDays(false);
			for(AccountTransaction transaction : lastNSalaryCredits) {
				AccountTransactionDTO txnDTO = AccountTransactionDTO.prepareDTO(transaction);
				acctTxnDTOs.add(txnDTO);
			}
		}
		else{
			loanApplicationDTO.setIsSalaryCreditedForLastNDays(true);
			for(int i=0; i<n; i++) {
				AccountTransactionDTO acctTxnDTO = AccountTransactionDTO.prepareDTO(lastNSalaryCredits.get(i));
				acctTxnDTOs.add(acctTxnDTO);
			}
		}
		loanApplicationDTO.setLastNSalaryCredits(acctTxnDTOs);

		return loanApplicationDTO;
	}


	/**
	 * 
	 * @param salaryCredits
	 * @param emi
	 * @return
	 */
	public Boolean validateEmi(List<AccountTransaction> salaryCredits, BigDecimal emi) {
		Boolean isValidEmi;
		if (salaryCredits != null && !salaryCredits.isEmpty()) {
			if (emi.compareTo(BigDecimal.valueOf(0)) != 0 && emi.compareTo(salaryCredits.get(salaryCredits.size() - 1)
					.getTxnAmount().multiply(BigDecimal.valueOf(0.20))) < 0) {
				isValidEmi = true;
			} else {
				isValidEmi = false;
			}
		} else {
			isValidEmi = false;
		}
		return isValidEmi;
	}

}
