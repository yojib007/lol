package com.infosys.infybank.fundtransfer.controller;
 
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.fundtransfer.dto.FundTransferDTO;
import com.infosys.infybank.fundtransfer.service.FundTransferService;


/**
 * The Class FundTransferController.
 */
@RestController
public class FundTransferController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The fund transfer service. */
	@Autowired
	FundTransferService ftService;

	/**
	 * ensures that HTTP requests to /${project.version}/customers- POST based
	 * request are mapped to the generateOTP() method which accepts entered
	 * input in JSON format
	 *
	 * @param custId the cust id
	 * @param ftDTO the dto
	 * @return true- if fundtransfer is successful
	 * @exception InfyBankException the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/fund-transfer", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.CREATED)
	public void transfer(@PathVariable int custId, @Valid @RequestBody FundTransferDTO ftDTO)
			throws InfyBankException {
		logger.debug("Details received for customer {} for fund transfer : {}", custId, ftDTO);
		List<BankAccount> fromToAccounts = ftService.transferFunds(custId, ftDTO);
		ftService.saveTransfer(ftDTO, fromToAccounts.get(0), fromToAccounts.get(1));
	}

}
