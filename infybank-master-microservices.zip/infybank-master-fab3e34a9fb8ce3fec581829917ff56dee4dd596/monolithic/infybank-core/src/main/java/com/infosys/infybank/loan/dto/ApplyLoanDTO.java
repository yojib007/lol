package com.infosys.infybank.loan.dto;
 import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

/**
 * The Class ApplyLoanDTO.
 */
public class ApplyLoanDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	private int custId;
	
	/** The user id. */
	@NotBlank(message = "userId.format.invalid")
	private String userId;
	
	/** The loan amount. */
	@NotNull
	@Min(value = 1, message = "loanAmount.invalid")
	private BigDecimal loanAmount;
	
	/** The tenure. */
	private int tenure;
	
	/** The debit acct no. */
	@NotBlank
	@Pattern(regexp = "\\d{10}", message = "acctno.format.invalid")
	private String debitAcctNo;

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the loan amount.
	 *
	 * @return the loan amount
	 */
	public BigDecimal getLoanAmount() {
		return loanAmount;
	}

	/**
	 * Sets the loan amount.
	 *
	 * @param loanAmount the new loan amount
	 */
	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	/**
	 * Gets the tenure.
	 *
	 * @return the tenure
	 */
	public int getTenure() {
		return tenure;
	}

	/**
	 * Sets the tenure.
	 *
	 * @param tenure the new tenure
	 */
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	/**
	 * Gets the debit acct no.
	 *
	 * @return the debit acct no
	 */
	public String getDebitAcctNo() {
		return debitAcctNo;
	}

	/**
	 * Sets the debit acct no.
	 *
	 * @param debitAcctNo the new debit acct no
	 */
	public void setDebitAcctNo(String debitAcctNo) {
		this.debitAcctNo = debitAcctNo;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ApplyLoanDTO [custId=" + custId + ", loanAmount=" + loanAmount + ", tenure="
				+ tenure + ", debitAcctNo=" + debitAcctNo + "]";
	}

}
