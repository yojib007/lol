package com.infosys.infybank.core.repository;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.entity.AccountConfig;

/**
 * The Interface AccountConfigRepository.
 */
@Repository
public interface AccountConfigRepository extends JpaRepository<AccountConfig, Character> {

	/**
	 * Find minimum balance.
	 *
	 * @param acctType
	 *            the acct type
	 * @return the AccountConfig 
	 */
	
	AccountConfig findByAcctType(char acctType);
	
}
