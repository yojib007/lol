package com.infosys.infybank.loan.controller;
 
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.loan.dto.LoanConfigDTO;
import com.infosys.infybank.loan.dto.LoanConfigEditDTO;
import com.infosys.infybank.loan.service.LoanConfigService;

/**
 * The Class LoanController.
 */
@RestController
public class LoanConfigController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The loan service. */
	@Autowired
	LoanConfigService loanService;

	/**
	 * View loan rates.
	 *
	 * @return the list
	 * @throws InfyBankServiceExceptions
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/loanconfigs", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public List<LoanConfigDTO> viewLoanRates() throws InfyBankException {
		List<LoanConfigDTO> loanConfigDTOs = loanService.viewLoanRates();
		logger.debug("Loan configurations : {}", loanConfigDTOs);
		return loanConfigDTOs;
	}

	/**
	 * Edits the loan rates.
	 *
	 * @param loanConfigDTO
	 *            the loan config DTO
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/loanconfigs", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void modifyLoanRates(@RequestBody LoanConfigEditDTO loanConfigEditDTO) throws InfyBankException {
		logger.debug("New Loan configurations for modification : {}", loanConfigEditDTO);
		loanService.validateLoanConfig(loanConfigEditDTO);
		loanService.saveLoanConfig(loanConfigEditDTO);
	}
}
