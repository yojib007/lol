package com.infosys.infybank.core.service;
 
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

@Service
public class RandomPasswordGeneratorService {
	
	private static final Logger logger = LoggerFactory.getLogger(RandomPasswordGeneratorService.class);

	/**   
	 * Generate random password
	 *
	 * @return the hashed String for Input
	 * @throws InfyBankException
	 */
	public String generatePassword() {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_";
		String password = RandomStringUtils.random(8, characters);
		logger.debug("Random password : {}", password);
		return password;
	}

	/**
	 * Encrypts the password using MD5 hashing algorithm
	 *
	 * @return the hashed password
	 * @throws InfyBankException
	 */
	public String encryptPassword(String password) throws InfyBankException {

		logger.debug("Input password for encryption : {}" , password);
		String encryptedPassword = null;

		try {
			if (password != null) {
				MessageDigest digest = MessageDigest.getInstance("MD5");
				digest.update(password.getBytes(), 0, password.length());
				encryptedPassword = new BigInteger(1, digest.digest()).toString(16);
			}
		} catch (NoSuchAlgorithmException e) {
			logger.error("Exception", e);
			throw new InfyBankException(ExceptionConstants.CUSTOMER_SECURE_PWD_FAILED.toString());
		}

		logger.debug("Encrypted password : {}", encryptedPassword);
		return encryptedPassword;
		
	}

}
