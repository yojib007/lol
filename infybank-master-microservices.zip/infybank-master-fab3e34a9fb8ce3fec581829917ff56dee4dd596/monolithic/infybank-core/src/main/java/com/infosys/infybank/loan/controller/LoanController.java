package com.infosys.infybank.loan.controller;
 
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.loan.dto.AmortizationScheduleDTO;
import com.infosys.infybank.loan.dto.ApplyLoanDTO;
import com.infosys.infybank.loan.dto.ApproveLoanDTO;
import com.infosys.infybank.loan.dto.LoanAccountDTO;
import com.infosys.infybank.loan.dto.LoanApplicationDTO;
import com.infosys.infybank.loan.dto.ViewLoanDetailsDTO;
import com.infosys.infybank.loan.service.AmortizationService;
import com.infosys.infybank.loan.service.LoanService;

/**
 * The Class LoanController.
 */
@RestController
public class LoanController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The loan account service. */
	@Autowired
	LoanService loanService;

	/** The ammortization service. */
	@Autowired
	AmortizationService ammortizationService;

	/**
	 * Apply personal loan.
	 *
	 * @param applyLoanDTO
	 *            the apply loan dto
	 * @return the loan account dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/loans", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.CREATED)
	public void applyPersonalLoan(@PathVariable("custId") int custId, @Valid @RequestBody ApplyLoanDTO applyLoanDTO) throws InfyBankException {
		logger.debug("Loan Application details for customer {} : {}", custId, applyLoanDTO);
		loanService.applyPersonalLoan(applyLoanDTO);
	}

	/**
	 * View loan details.
	 *
	 * @param custId
	 *            the cust id
	 * @param loanAcctNo
	 *            the loan acct no
	 * @return the view loan details dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/loans/{loanAcctNo}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ViewLoanDetailsDTO viewLoanDetails(@PathVariable("custId") int custId,
			@PathVariable("loanAcctNo") String loanAcctNo) throws InfyBankException {
		logger.debug("Loan details required for customer {} with loan account {}", custId, loanAcctNo);
		ViewLoanDetailsDTO detailsDTO = loanService.viewLoanDetails(custId, loanAcctNo);
		logger.debug("Loan Details : {}", detailsDTO);
		return detailsDTO;
	}
	
	/**
	 * View all the loans for a given customer.
	 *
	 * @param custId
	 *            the cust id
	 * @return the list of view loan details dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/loans", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public List<ViewLoanDetailsDTO> viewAllLoans(@PathVariable("custId") int custId) throws InfyBankException {
		logger.debug("Loan details required for customer {} ", custId);
		List<ViewLoanDetailsDTO> loans = loanService.viewAllLoans(custId);
		logger.debug("Loans : {}", loans);
		return loans;
	}

	/**
	 * 
	 * @return
	 * @throws InfyBankException
	 */
	@RequestMapping(value = "/${project.version}/loans", params = {"loanStatus"}, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public List<LoanApplicationDTO> viewSubmittedLoans(@RequestParam(value = "loanStatus") char loanStatus) throws InfyBankException {
		List<LoanApplicationDTO> submittedLoans = loanService.viewSubmittedLoans(loanStatus);
		logger.debug("Submitted Loans : {}", submittedLoans);
		return submittedLoans;
	}

	/**
	 * View loan application.
	 *
	 * @param loanAcctNo
	 *            the loan acct no
	 * @return the view loan application dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/loans/{loanAcctNo}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public LoanApplicationDTO viewLoanApplication(@PathVariable("loanAcctNo") String loanAcctNo)
			throws InfyBankException {
		logger.debug("Loan account {}", loanAcctNo);
		LoanApplicationDTO applicationDTO = loanService.viewLoanApplication(loanAcctNo);
		logger.debug("Loan application details : {}", applicationDTO);
		return applicationDTO;
	}

	/**
	 * Approve loan.
	 *
	 * @param loanAcctNo
	 *            the loan acct no
	 * @param approveLoanDTO
	 *            the approve loan dto
	 * @return the loan account dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/loans/{loanAcctNo}/approve", method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.OK)
	public LoanAccountDTO approveLoan(@PathVariable("loanAcctNo") String loanAcctNo,
			@Valid @RequestBody ApproveLoanDTO approveLoanDTO) throws InfyBankException {
		logger.debug("Loan account for approval : {}", loanAcctNo);
		LoanAccountDTO loanDTO = loanService.approveLoan(loanAcctNo, approveLoanDTO); 
		logger.debug("Loan account details after approval : {}", loanDTO);
		return loanDTO;
	}

	/**
	 * View amortization schedule.
	 *
	 * @param custId
	 *            the cust id
	 * @param loanAcctNo
	 *            the loan acct no
	 * @return the ammortization schedule dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/loans/{loanAcctNo}/ammortization-schedule", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public AmortizationScheduleDTO viewAmmortizationSchedule(@PathVariable("custId") int custId,
			@PathVariable("loanAcctNo") String loanAcctNo) throws InfyBankException {
		logger.debug("Ammortization schedule required for customer {} with loan account {}", custId, loanAcctNo);
		AmortizationScheduleDTO scheduleDTO = ammortizationService.viewAmortizationSchedule(custId, loanAcctNo); 
		logger.debug("Ammortization schedule : {}", scheduleDTO);
		return scheduleDTO;
	}

}
