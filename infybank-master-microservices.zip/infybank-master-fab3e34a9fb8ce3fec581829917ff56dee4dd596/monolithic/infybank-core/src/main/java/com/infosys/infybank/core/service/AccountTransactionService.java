/**
 * 
 */
package com.infosys.infybank.core.service;
 
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.infybank.core.dto.AccountStatementDTO;
import com.infosys.infybank.core.dto.SearchAccountStatementDTO;
import com.infosys.infybank.core.entity.AccountTransaction;
import com.infosys.infybank.core.repository.AccountTransactionRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.utilities.AccountStatementValidator;
import com.infosys.infybank.utilities.DateField;
import com.infosys.infybank.utilities.DateUtil;

/**
 * The Class AccountTransactionService.
 */
@Service
public class AccountTransactionService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The transaction repository. */
	@Autowired
	AccountTransactionRepository acctTxnRepo;

	/** The customer repository. */
	@Autowired
	CustomerService custService;

	/** The account service. */
	@Autowired
	AccountService acctService;

	/**
	 * Gets the salary credit.
	 *
	 * @param custId
	 *            the cust id
	 * @param acctNo
	 *            the acct no
	 * @param txnType
	 *            the txn type
	 * @param txnCategory
	 *            the txn category
	 * @return the salary credit
	 */
	public List<AccountTransaction> getSalaryCredits(int custId, String acctNo, char txnType, char txnCategory) {
		return acctTxnRepo.getSalaryCredit(custId, acctNo, txnType, txnCategory);
	}
	
	/**
	 * Gets the salary credits for the last N days.
	 *
	 * @param custId
	 *            the cust id
	 * @param acctNo
	 *            the acct no
	 * @param txnType
	 *            the txn type
	 * @param txnCategory
	 *            the txn category
	 * @param lastNthDate           
	 *            the lastNthDate
	 * @return the last N salary credits
	 */
	public List<AccountTransaction> getSalaryCreditsForNDays(int custId, String acctNo, char txnType, char txnCategory, Date lastNthDate) {
		return acctTxnRepo.getSalaryCreditForNDays(custId, acctNo, txnType, txnCategory, lastNthDate);
	}

	/**
	 * Perform transaction.
	 *
	 * @param acctTxn
	 *            the entity
	 * @return the integer
	 */
	public Integer performTransaction(AccountTransaction acctTxn) {

		return acctTxnRepo.saveAndFlush(acctTxn).getTxnId();
	}

	/**
	 * Method to get the customer transaction.
	 *
	 * @param searchDTO
	 *            the search account statement dto
	 * @return list of AccountstatementDTO
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public List<AccountStatementDTO> getTransactionsForAccount(SearchAccountStatementDTO searchDTO)
			throws InfyBankException {

		/* Validating transaction type */
		if (searchDTO.getTxnType() != null && !(AccountStatementValidator.isTransactionTypeValid(searchDTO.getTxnType()))) {
			throw new InfyBankException(ExceptionConstants.ACCOUNT_TRANSACTION_TYPE_INVALID.toString());
		}

		Boolean lastMonth = searchDTO.getLastMonth();
		Date fromDate = searchDTO.getStartDate();
		Date toDate = searchDTO.getEndDate();
		
		/* Validating start and end date */
		AccountStatementValidator.validateFromToDate(lastMonth, fromDate, toDate);
		
		/* Finding last month start and end date if lastMonth is true */
		if (lastMonth) {
			fromDate = DateUtil.addDuration(new Date(), DateField.DAY, -30);
			toDate = new Date();
			logger.debug("Statement period for last month : {} to {}", fromDate, toDate);
		}

		// Default start date to first timestamp of the date and end date to last timestamp of the date
		searchDTO.setStartDate(DateUtil.getStartOfDay(fromDate));
		searchDTO.setEndDate(DateUtil.getEndOfDay(toDate));

		AccountStatementValidator.validateFromToAmount(searchDTO.getFromAmount(), searchDTO.getToAmount());

		// check if custId is valid
		custService.getCustomerDetails(searchDTO.getCustId());

		/* Validating account details */
		if (!acctService.isBankAccountValid(searchDTO.getCustId(), searchDTO.getAcctNo())) {
			throw new ResourceNotFoundException(ExceptionConstants.CUSTOMER_ACCOUNT_DETAILS_NOT_PRESENT.toString());
		}

		// fetch transactions from database
		List<AccountTransaction> acctTxns = acctTxnRepo.getTransactions(searchDTO);
		List<AccountStatementDTO> accountStatementDTO = new ArrayList<AccountStatementDTO>();
		
		// convert entity to dto
		accountStatementDTO = new ArrayList<AccountStatementDTO>();
		for (AccountTransaction acctTxn : acctTxns) {
			accountStatementDTO.add(AccountStatementDTO.valueOf(acctTxn));
		}

		return accountStatementDTO;
	}

	// for loan prepay

	/**
	 * Gets the txn detail for loan by cust id.
	 *
	 * @param loanAcctNo
	 *            the loan acct no
	 * @param custId
	 *            the cust id
	 * @return the txn detail for loan by cust id
	 */
	public List<AccountTransaction> getTxnDetailForLoanByCustId(String loanAcctNo, int custId) {

		return acctTxnRepo.findTxnDateByCustid(loanAcctNo, custId);

	}

}
