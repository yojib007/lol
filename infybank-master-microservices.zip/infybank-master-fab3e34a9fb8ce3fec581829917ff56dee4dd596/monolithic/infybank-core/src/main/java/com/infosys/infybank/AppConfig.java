package com.infosys.infybank;
 
import java.math.BigDecimal;
import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * AppConfig.java - a simple class which Specifies the class as
 * configuration,Specifies which package to scan to .
 * 
 * @author ETA Java
 * @version 1.0
 */
@Configuration
@PropertySource({ "classpath:application.properties" })
@EnableTransactionManagement
@EnableJpaRepositories("com.infosys.infybank")
public class AppConfig {
	
	@Autowired
	private Environment env;
	
	/**
     * Ensures that placeholders are replaced with property values
     */
	@Bean
	 static PropertySourcesPlaceholderConfigurer propertyPlaceHolderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

	/**
	 * EntityManagerFactory bean to set up shared JPA EntityManagerFactory in a
	 * Spring application context by Specifying the JDBC DataSource that the JPA
	 * persistence provider is supposed to use for accessing the database,
	 * packages to each for entities existence, Specify the JpaVendorAdapter
	 * implementation and additional hibernate properties
	 * 
	 * @return entityManagerFactory
	 */
	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dataSource());
		em.setPackagesToScan("com.infosys.infybank.core.entity", "com.infosys.infybank.fundtransfer.entity",
				"com.infosys.infybank.loan.entity");
		JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		em.setJpaProperties(additionalProperties());
		return em;
	}

	/**
	 * DataSource bean to specifying the JDBC DataSource that the JPA
	 * persistence provider is supposed to use for accessing the database,
	 * 
	 * @return dataSource
	 */
	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("spring.datasource.driver-class-name"));
		dataSource.setUrl(env.getProperty("spring.datasource.url"));
		dataSource.setUsername(env.getProperty("spring.datasource.username"));
		dataSource.setPassword(env.getProperty("spring.datasource.password"));
		return dataSource;
	}

	/**
	 * PlatformTransactionManager bean to Initialization for TransactionManager
	 * 
	 * @return dataSource
	 */

	@Bean
	public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(emf);
		return transactionManager;
	}

	/**
	 * ApplicationProperties bean for properties
	 * 
	 * @return dataSource
	 */

	@Bean
	public ApplicationProperties applicationProperties() {
		ApplicationProperties props = new ApplicationProperties();
		props.setAadharUrl(env.getProperty("external.aadhar.url"));
		props.setAcctStartDefVal(Integer.parseInt(env.getProperty("account.start.default.value")));
		props.setAmountPref(env.getProperty("customer.default.amount.preference"));
		props.setCreditLimit(new BigDecimal(env.getProperty("customer.default.creditlimit.fornotification")));
		props.setCreditScoreUrl(env.getProperty("external.creditscore.url"));
		props.setDatePref(env.getProperty("customer.default.date.preference"));
		props.setFtLimit(Integer.parseInt(env.getProperty("payee.fundtransfer.limit.insec")));
		props.setIfscCode(env.getProperty("infybank.ifsc.code"));
		props.setIfscUrl(env.getProperty("external.ifsc.url"));
		props.setNoOfSalaryCredits(Integer.parseInt(env.getProperty("no.of.salary.credits")));
		props.setMinLoanTenure(Integer.parseInt(env.getProperty("min.loan.tenure")));
		props.setMaxLoanTenure(Integer.parseInt(env.getProperty("max.loan.tenure")));
		props.setCibilMinScore(Integer.parseInt(env.getProperty("cibil.min.score")));
		props.setCibilMaxScore(Integer.parseInt(env.getProperty("cibil.max.score")));
		props.setEmailServiceUrl(env.getProperty("emailwebservice.url"));

		System.out.println("Props" + props);
		return props;

	}

	/**
	 * Additional Properties to specify table generation strategy and dialect to
	 * be used
	 * 
	 * @return dataSource
	 */
	Properties additionalProperties() {
		Properties properties = new Properties();
		properties.setProperty("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.generate-ddl"));
		properties.setProperty("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
		properties.setProperty("hibernate.show_sql", env.getProperty("spring.jpa.show_sql"));
		return properties;
	}
	
	

}
