package com.infosys.infybank.loan.repository;
 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.loan.entity.LoanConfig;
import com.infosys.infybank.loan.entity.LoanConfigId;


/**
 * The Interface LoanConfigRepository.
 */
@Repository
public interface LoanConfigRepository extends JpaRepository<LoanConfig, LoanConfigId> {
	
	public List<LoanConfig> findAllByOrderByIdCreditScoreStart();
	
	@Query(value = "select l from LoanConfig l where l.id.creditScoreStart <= :creditScore and l.id.creditScoreEnd >= :creditScore)")
	public LoanConfig getLoanConfigForCreditScore(@Param("creditScore") Integer creditScore);

}
