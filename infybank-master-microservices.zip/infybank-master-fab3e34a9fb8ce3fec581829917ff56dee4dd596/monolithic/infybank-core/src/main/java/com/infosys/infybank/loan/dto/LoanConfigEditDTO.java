package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;


/**
 * The Class LoanConfigEditDTO.
 */
public class LoanConfigEditDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The loan config dto list. */
	@NotEmpty
	private List<LoanConfigDTO> loanConfigDtoList;
	
	/** The lst updt id. */
	@NotBlank(message = "last.updated.id.mandatory")
	private String lstUpdtId;

	/**
	 * Gets the loan config dto list.
	 *
	 * @return the loan config dto list
	 */
	public List<LoanConfigDTO> getLoanConfigDtoList() {
		return loanConfigDtoList;
	}

	/**
	 * Sets the loan config dto list.
	 *
	 * @param loanConfigDtoList the new loan config dto list
	 */
	public void setLoanConfigDtoList(List<LoanConfigDTO> loanConfigDtoList) {
		this.loanConfigDtoList = loanConfigDtoList;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LoanConfigEditDTO [loanConfigDtoList=" + loanConfigDtoList + ", lstUpdtId=" + lstUpdtId + "]";
	}
	
	
}
