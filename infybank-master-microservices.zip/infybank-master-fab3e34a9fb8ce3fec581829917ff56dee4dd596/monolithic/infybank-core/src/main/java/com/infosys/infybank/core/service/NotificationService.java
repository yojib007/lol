package com.infosys.infybank.core.service;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.Email;

/**
 * The Class NotificationService.
 */
@Service
public class NotificationService {

	private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

	/** The Configuration Bean */
	@Autowired
	ApplicationProperties appProps;
	

	@Autowired
	private RestTemplate restTemplate;
	
	/**
	 * sends a notification email to the Customer
	 * @param email
	 * @return void
	 * @throws Exception
	 */
	public void notifyCustomer(Email email) {
		try {
			logger.debug("Email : {}", email);
			String sentNotification = restTemplate.postForObject(appProps.getEmailServiceUrl(), email, String.class);
			logger.info("return value from emailwebservice {}", sentNotification);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);

		}
	}

}
