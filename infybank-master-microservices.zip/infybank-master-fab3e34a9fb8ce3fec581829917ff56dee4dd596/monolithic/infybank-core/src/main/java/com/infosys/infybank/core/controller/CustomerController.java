package com.infosys.infybank.core.controller;
 
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.core.dto.CustomerDTO;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class ProfileController.
 */
@RestController
public class CustomerController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CustomerService custService;

	/**
	 * View profile.
	 *
	 * @param custId
	 *            the cust id
	 * @return the customer DTO
	 * @throws InvalidCustomerIdException
	 *             the invalid customer id exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public CustomerDTO viewProfile(@PathVariable int custId) throws InfyBankException {
		CustomerDTO customerDTO = custService.viewCustomerProfile(custId);
		logger.debug("Details for customer {} : {}", custId, customerDTO);
		return customerDTO;
	}

	/**
	 * Update profile
	 * 
	 * @param customerDTO
	 * @param custId
	 * @return true if update successful
	 * @throws InfyBankException
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}", method = RequestMethod.PATCH, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void updateProfile(@Valid @RequestBody CustomerDTO customerDTO, @PathVariable int custId)
			throws InfyBankException {
		logger.debug("Details for updating customer {} : {}", custId, customerDTO);
		customerDTO.setCustId(custId);
		custService.updateCustomerProfile(customerDTO);
	}
}
