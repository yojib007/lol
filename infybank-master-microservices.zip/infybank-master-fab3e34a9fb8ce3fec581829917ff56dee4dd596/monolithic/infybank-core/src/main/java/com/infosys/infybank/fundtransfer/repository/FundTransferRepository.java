/** 
 * 
 */
package com.infosys.infybank.fundtransfer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.fundtransfer.entity.FundTransfer;

/**
 * The Interface FundTransferRepository.
 */
@Repository
public interface FundTransferRepository extends JpaRepository<FundTransfer, Long> {

	/**
	 * Gets the pending fund transfers for a given payee
	 *
	 * @param payeeId
	 *            the payee for whom fund transfers have to be found
	 * @param status
	 *            the pending status
	 * @return the list of fund transfer objects
	 */

	List<FundTransfer> findByPayeeIdAndStatus(int payeeId, char status);

}