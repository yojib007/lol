package com.infosys.infybank.fundtransfer.entity;
 
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.GenericGenerator;

/**
 * The Class Payee.
 */
@Entity
@Table(name = "payee")
@GenericGenerator(name = "payeeIdGen", strategy = "identity")
public class Payee implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The payee id. */
	@Id
	@GeneratedValue(generator = "payeeIdGen")
	@Column(name = "PAYEE_ID", nullable = false)
	private int payeeId;

	/** The cust id. */
	@Column(name = "CUST_ID", nullable = false)
	private int custId;

	/** The payee name. */
	@Column(name = "PAYEE_NAME", nullable = false)
	private String payeeName;

	/** The nick name. */
	@Column(name = "NICK_NAME", nullable = false, length = 25)
	private String nickName;

	/** The acct type. */
	@Column(name = "ACCT_TYPE", nullable = false, length = 1)
	private char acctType;

	/** The acct no. */
	@Column(name = "ACCT_NO", nullable = false, length = 20)
	private String acctNo;

	/** The ifsc code. */
	@Column(name = "IFSC_CODE", length = 11)
	private String ifscCode;

	/** The status. */
	@Column(name = "STATUS", nullable = false, length = 1)
	private char status;

	@Temporal(TemporalType.TIMESTAMP)
	@Generated(GenerationTime.ALWAYS)
	@Column(name = "LST_UPDT_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lstUpdtTs;

	/** The lst updt id. */
	@Column(name = "LST_UPDT_ID", nullable = false, length = 10)
	private String lstUpdtId;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getPayeeId() {
		return this.payeeId;
	}

	/**
	 * Sets the id.
	 *
	 * @param id
	 *            the new id
	 */
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the payee name.
	 *
	 * @return the payee name
	 */
	public String getPayeeName() {
		return this.payeeName;
	}

	/**
	 * Sets the payee name.
	 *
	 * @param string
	 *            the new payee name
	 */
	public void setPayeeName(String name) {
		this.payeeName = name;
	}

	/**
	 * Gets the nick name.
	 *
	 * @return the nick name
	 */
	public String getNickName() {
		return this.nickName;
	}

	/**
	 * Sets the nick name.
	 *
	 * @param string
	 *            the new nick name
	 */
	public void setNickName(String name) {
		this.nickName = name;
	}

	/**
	 * Gets the acct type.
	 *
	 * @return the acct type
	 */
	public char getAcctType() {
		return this.acctType;
	}

	/**
	 * Sets the acct type.
	 *
	 * @param acctType
	 *            the new acct type
	 */
	public void setAcctType(char acctType) {
		this.acctType = acctType;
	}

	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return this.acctNo;
	}

	/**
	 * Sets the acct no.
	 *
	 * @param acctNo
	 *            the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	/**
	 * Gets the ifsc code.
	 *
	 * @return the ifsc code
	 */
	public String getIfscCode() {
		return this.ifscCode;
	}

	/**
	 * Sets the ifsc code.
	 *
	 * @param ifscCode
	 *            the new ifsc code
	 */
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public char getStatus() {
		return this.status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status
	 *            the new status
	 */
	public void setStatus(char status) {
		this.status = status;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return this.lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return this.lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	@Override
	public String toString() {
		return "Payee [payeeId=" + payeeId + ", custId=" + custId + ", payeeName=" + payeeName + ", nickName="
				+ nickName + ", acctType=" + acctType + ", acctNo=" + acctNo + ", ifscCode=" + ifscCode + ", status="
				+ status + ", lstUpdtTs=" + lstUpdtTs + ", lstUpdtId=" + lstUpdtId + "]";
	}
	
	

}
