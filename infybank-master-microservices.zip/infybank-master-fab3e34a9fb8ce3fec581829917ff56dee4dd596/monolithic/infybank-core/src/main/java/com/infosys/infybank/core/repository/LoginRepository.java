package com.infosys.infybank.core.repository;
 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.entity.Login;

/**
 * The Interface LoginRepository.
 */
@Repository
public interface LoginRepository extends JpaRepository<Login, Integer> {

	/**
	 * Find user having user name like.
	 *
	 * @param userId
	 *            the user id
	 * @return the list
	 */
	@Query("select l.userId from Login l where l.userId LIKE CONCAT(:userId, '%')")
	public List<String> findUserHavingUserNameLike(@Param("userId") String userId);

	/**
	 * Find by user id.
	 *
	 * @param userId
	 *            the user id
	 * @return the login
	 */
	public Login findByUserId(String userId);

}
