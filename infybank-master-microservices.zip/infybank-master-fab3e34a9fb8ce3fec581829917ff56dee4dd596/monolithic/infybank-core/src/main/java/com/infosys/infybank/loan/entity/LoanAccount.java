package com.infosys.infybank.loan.entity;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

/**
 * The Class LoanAccount.
 */
@Entity
@Table(name = "loan_account")
public class LoanAccount implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@EmbeddedId

	@AttributeOverrides({ @AttributeOverride(name = "custId", column = @Column(name = "CUST_ID", nullable = false)),
			@AttributeOverride(name = "loanAcctNo", column = @Column(name = "LOAN_ACCT_NO", nullable = false, length = 20)) })
	private LoanAccountId id;

	/** The loan amount. */
	@Column(name = "LOAN_AMOUNT", nullable = false, precision = 12, scale = 4)
	private BigDecimal loanAmount;

	/** The tenure. */
	@Column(name = "TENURE", nullable = false)
	private int tenure;

	/** The interest rate. */
	@Column(name = "INTEREST_RATE", nullable = true, precision = 12, scale = 4)
	private BigDecimal interestRate;

	/** The opening date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "OPENING_DATE", nullable = true, length = 10)
	private Date openingDate;

	/** The emi. */
	@Column(name = "EMI", nullable = true, precision = 12, scale = 4)
	private BigDecimal emi;

	/** The emi due date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "EMI_DUE_DATE", nullable = true, length = 10)
	private Date emiDueDate;

	/** The loan status. */
	@Column(name = "LOAN_STATUS", nullable = false, length = 1)
	private char loanStatus;

	/** The debit acct no. */
	@Column(name = "DEBIT_ACCT_NO", nullable = false, length = 20)
	private String debitAcctNo;

	/** The remarks. */
	@Column(name = "REMARKS", length = 100)
	private String remarks;

	/** The lst updt ts. */
	@Temporal(TemporalType.TIMESTAMP)
	@Generated(GenerationTime.ALWAYS)	
	@Column(name = "LST_UPDT_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lstUpdtTs;

	/** The lst updt id. */
	@Column(name = "LST_UPDT_ID", nullable = false, length = 10)
	private String lstUpdtId;

	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public LoanAccountId getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id
	 *            the new id
	 */
	public void setId(LoanAccountId id) {
		this.id = id;
	}

	/**
	 * Gets the loan amount.
	 *
	 * @return the loan amount
	 */
	public BigDecimal getLoanAmount() {
		return this.loanAmount;
	}

	/**
	 * Sets the loan amount.
	 *
	 * @param loanAmount
	 *            the new loan amount
	 */
	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	/**
	 * Gets the tenure.
	 *
	 * @return the tenure
	 */
	public int getTenure() {
		return this.tenure;
	}

	/**
	 * Sets the tenure.
	 *
	 * @param tenure
	 *            the new tenure
	 */
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	/**
	 * Gets the interest rate.
	 *
	 * @return the interest rate
	 */
	public BigDecimal getInterestRate() {
		return this.interestRate;
	}

	/**
	 * Sets the interest rate.
	 *
	 * @param interestRate
	 *            the new interest rate
	 */
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	/**
	 * Gets the opening date.
	 *
	 * @return the opening date
	 */
	public Date getOpeningDate() {
		return this.openingDate;
	}

	/**
	 * Sets the opening date.
	 *
	 * @param openingDate
	 *            the new opening date
	 */
	public void setOpeningDate(Date openingDate) {
		this.openingDate = openingDate;
	}

	/**
	 * Gets the emi.
	 *
	 * @return the emi
	 */
	public BigDecimal getEmi() {
		return this.emi;
	}

	/**
	 * Sets the emi.
	 *
	 * @param emi
	 *            the new emi
	 */
	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}

	/**
	 * Gets the emi due date.
	 *
	 * @return the emi due date
	 */
	public Date getEmiDueDate() {
		return this.emiDueDate;
	}

	/**
	 * Sets the emi due date.
	 *
	 * @param emiDueDate
	 *            the new emi due date
	 */
	public void setEmiDueDate(Date emiDueDate) {
		this.emiDueDate = emiDueDate;
	}

	/**
	 * Gets the loan status.
	 *
	 * @return the loan status
	 */
	public char getLoanStatus() {
		return this.loanStatus;
	}

	/**
	 * Sets the loan status.
	 *
	 * @param loanStatus
	 *            the new loan status
	 */
	public void setLoanStatus(char loanStatus) {
		this.loanStatus = loanStatus;
	}

	/**
	 * Gets the debit acct no.
	 *
	 * @return the debit acct no
	 */
	public String getDebitAcctNo() {
		return this.debitAcctNo;
	}

	/**
	 * Sets the debit acct no.
	 *
	 * @param debitAcctNo
	 *            the new debit acct no
	 */
	public void setDebitAcctNo(String debitAcctNo) {
		this.debitAcctNo = debitAcctNo;
	}

	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return this.remarks;
	}

	/**
	 * Sets the remarks.
	 *
	 * @param remarks
	 *            the new remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return this.lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return this.lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

}
