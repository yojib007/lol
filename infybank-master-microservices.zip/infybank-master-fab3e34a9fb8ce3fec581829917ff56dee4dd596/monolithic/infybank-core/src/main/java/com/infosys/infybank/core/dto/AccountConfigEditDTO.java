package com.infosys.infybank.core.dto;
 
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.infosys.infybank.core.entity.AccountConfig;


/**
 * The Class AccountConfigEditDTO.
 */
public class AccountConfigEditDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The account config view dto list. */
	@JsonProperty("accountconfig")
	@Valid private List<AccountConfigViewDTO> accountConfigViewDTOs;

	/** The lst updt id. */
	@NotBlank(message = "accountconfig.lastUpdatedId.mandatory")
	@Length(max = 10, message = "accountconfig.lastUpdatedId.size")
	@JsonProperty("userId")
	private String lstUpdtId;

	/**
	 * Gets the account config view list.
	 *
	 * @return the account config view dto list
	 * @returns the account config view list
	 */
	@JsonProperty("accountconfig")
	public List<AccountConfigViewDTO> getAccountConfigViewDTOs() {
		return accountConfigViewDTOs;
	}

	/**
	 * Sets the account config view list.
	 *
	 * @param accountConfigViewDTOs the new account config view dto list
	 */
	public void setAccountConfigViewDTOs(List<AccountConfigViewDTO> accountConfigViewDTOs) {
		this.accountConfigViewDTOs = accountConfigViewDTOs;
	}

	/**
	 * Gets the last updated user Id.
	 *
	 * @return the lst updt id
	 * @returns the last updated user Id
	 */
	@JsonProperty("userId")
	public String getLstUpdtId() {
		return lstUpdtId;
	}

	/**
	 * Sets the last updated user Id.
	 *
	 * @param lstUpdtId the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	
	

	/**
	 * Parameterized constructor.
	 *
	 * @param accountConfigEditDTO the account config edit dto
	 * @return the list
	 */

	/**
	 * Prepares Account config entity from DTO
	 * 
	 * @param accountConfigEditDTO
	 * @returns List of account config entity
	 */
	public static List<AccountConfig> preapreEntityList(AccountConfigEditDTO accountConfigEditDTO) {

		List<AccountConfigViewDTO> accountConfigViewDTOs = accountConfigEditDTO.getAccountConfigViewDTOs();
		List<AccountConfig> accountConfigs = new ArrayList<AccountConfig>();

		for (AccountConfigViewDTO accountConfigViewDTO : accountConfigViewDTOs) {
			AccountConfig accountConfig = AccountConfigViewDTO.prepareEntity(accountConfigViewDTO);
			accountConfig.setLstUpdtId(accountConfigEditDTO.getLstUpdtId());
			accountConfigs.add(accountConfig);
		}
		return accountConfigs;
	}

	/**
	 * Prepares DTO from Account config entity list.
	 *
	 * @return Account config DTO
	 */

	@Override
	public String toString() {
		return "AccountConfigEditDTO [accountConfigViewDTOs=" + accountConfigViewDTOs + ", lstUpdtId=" + lstUpdtId
				+ "]";
	}
}
