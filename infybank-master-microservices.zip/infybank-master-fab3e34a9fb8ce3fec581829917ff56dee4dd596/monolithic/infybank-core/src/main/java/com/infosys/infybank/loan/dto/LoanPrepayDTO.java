package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

/**
 * The Class LoanPrepayDTO.
 */
public class LoanPrepayDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The from account. */
	@NotBlank(message = "user.acctno.mandatory")
	@Length(min = 10, max = 10, message = "user.accountNo.size")
	private String fromAccount;

	/** The prepay amount. */
	@NotNull(message = "loan.prepayamount.mandatory")
	private BigDecimal prepayAmount;

	/** The payment option. */
	@NotBlank(message = "loanprepay.paymentoption.mandatory")
	private String paymentOption;

	/** The loan acct no. */
	@NotBlank(message = "loan.acctno.mandatory")
	@Length(min = 10, max = 10, message = "loan.accountNo.size")
	private String loanAcctNo;

	/**
	 * Gets the from account.
	 *
	 * @return the from account
	 */
	public String getFromAccount() {
		return fromAccount;
	}

	/**
	 * Sets the from account.
	 *
	 * @param fromAccount
	 *            the new from account
	 */
	public void setFromAccount(String fromAccount) {
		this.fromAccount = fromAccount;
	}

	/**
	 * Gets the prepay amount.
	 *
	 * @return the prepay amount
	 */
	public BigDecimal getPrepayAmount() {
		return prepayAmount;
	}

	/**
	 * Sets the prepay amount.
	 *
	 * @param prepayAmount
	 *            the new prepay amount
	 */
	public void setPrepayAmount(BigDecimal prepayAmount) {
		this.prepayAmount = prepayAmount;
	}

	/**
	 * Gets the payment option.
	 *
	 * @return the payment option
	 */
	public String getPaymentOption() {
		return paymentOption;
	}

	/**
	 * Sets the payment option.
	 *
	 * @param paymentOption
	 *            the new payment option
	 */
	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

	/**
	 * Gets the loan acct no.
	 *
	 * @return the loan acct no
	 */
	public String getLoanAcctNo() {
		return loanAcctNo;
	}

	/**
	 * Sets the loan acct no.
	 *
	 * @param loanAcctNo
	 *            the new loan acct no
	 */
	public void setLoanAcctNo(String loanAcctNo) {
		this.loanAcctNo = loanAcctNo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LoanPrepayDTO [fromAccount=" + fromAccount + ", prepayAmount=" + prepayAmount + ", paymentOption="
				+ paymentOption + ", loanAcctNo=" + loanAcctNo + "]";
	}

}
