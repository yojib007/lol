package com.infosys.infybank;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * WebMvcConfig.java - a simple class which defines beans for reading from
 * .properties
 * 
 * @author ETA Java
 * @version 1.0
 */
@Configuration // Specifies the class as configuration
@EnableWebMvc // enable Spring MVC
@ComponentScan(basePackages = "com.infosys.infybank") // Specifies which package
														// to scan to configure
														// spring beans
@EnableAspectJAutoProxy // enables AOP
@Import(AppConfig.class)

public class WebMvcConfig extends WebMvcConfigurerAdapter {

	/**
	 * ResourceBundleMessageSource bean to access the resource bundle for the
	 * given base names.
	 *
	 * @return MessageSource
	 */

	@Autowired
	private Environment environment;

	@Bean
	public MessageSource messageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setBasenames("application", "messages");
		return messageSource;
	}

	@Bean
	public RestTemplate restTemplate() {
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		factory.setConnectTimeout(Integer.parseInt(environment.getProperty("ext.svc.connect.timeout")));
		factory.setReadTimeout(Integer.parseInt(environment.getProperty("ext.svc.read.timeout")));
		return new RestTemplate(factory);
	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**").allowedOrigins("*").allowedMethods("GET","PUT","POST","PATCH","DELETE","OPTIONS").maxAge(3600);
			}
		};
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new InfyBankListener());
	}

}
