package com.infosys.infybank.loan.entity;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

/**
 * The Class LoanConfig.
 */
@Entity
@Table(name = "loan_config")
public class LoanConfig implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@EmbeddedId

	@AttributeOverrides({
			@AttributeOverride(name = "creditScoreStart", column = @Column(name = "CREDIT_SCORE_START", nullable = false)),
			@AttributeOverride(name = "creditScoreEnd", column = @Column(name = "CREDIT_SCORE_END", nullable = false)) })
	private LoanConfigId id;

	/** The loan approval ind. */
	@Column(name = "LOAN_APPROVAL_IND", nullable = false, length = 1)
	private char loanApprovalInd;

	/** The interest rate. */
	@Column(name = "INTEREST_RATE", nullable = false, precision = 12, scale = 4)
	private BigDecimal interestRate;

	/** The lst updt ts. */
	@Temporal(TemporalType.TIMESTAMP)
	@Generated(GenerationTime.ALWAYS)
	@Column(name = "LST_UPDT_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lstUpdtTs;

	/** The lst updt id. */
	@Column(name = "LST_UPDT_ID", nullable = false, length = 10)
	private String lstUpdtId;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public LoanConfigId getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id
	 *            the new id
	 */
	public void setId(LoanConfigId id) {
		this.id = id;
	}

	/**
	 * Gets the loan approval ind.
	 *
	 * @return the loan approval ind
	 */
	public char getLoanApprovalInd() {
		return this.loanApprovalInd;
	}

	/**
	 * Sets the loan approval ind.
	 *
	 * @param loanApprovalInd
	 *            the new loan approval ind
	 */
	public void setLoanApprovalInd(char loanApprovalInd) {
		this.loanApprovalInd = loanApprovalInd;
	}

	/**
	 * Gets the interest rate.
	 *
	 * @return the interest rate
	 */
	public BigDecimal getInterestRate() {
		return this.interestRate;
	}

	/**
	 * Sets the interest rate.
	 *
	 * @param interestRate
	 *            the new interest rate
	 */
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return this.lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return this.lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	@Override
	public String toString() {
		return "LoanConfig [id=" + id + ", loanApprovalInd=" + loanApprovalInd + ", interestRate=" + interestRate
				+ ", lstUpdtTs=" + lstUpdtTs + ", lstUpdtId=" + lstUpdtId + "]";
	}

}
