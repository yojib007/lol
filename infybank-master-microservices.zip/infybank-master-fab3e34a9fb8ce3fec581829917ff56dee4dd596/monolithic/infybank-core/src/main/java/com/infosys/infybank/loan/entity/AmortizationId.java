package com.infosys.infybank.loan.entity;
 
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 * The Class AmortizationId.
 */
@Embeddable
public class AmortizationId implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	@Column(name = "CUST_ID", nullable = false)
	private int custId;

	/** The loan acct no. */
	@Column(name = "LOAN_ACCT_NO", nullable = false, length = 20)
	private String loanAcctNo;

	/** The installment no. */
	@Column(name = "INSTALLMENT_NO", nullable = false)
	private int installmentNo;


	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return this.custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the loan acct no.
	 *
	 * @return the loan acct no
	 */
	public String getLoanAcctNo() {
		return this.loanAcctNo;
	}

	/**
	 * Sets the loan acct no.
	 *
	 * @param loanAcctNo
	 *            the new loan acct no
	 */
	public void setLoanAcctNo(String loanAcctNo) {
		this.loanAcctNo = loanAcctNo;
	}

	/**
	 * Gets the installment no.
	 *
	 * @return the installment no
	 */
	public int getInstallmentNo() {
		return this.installmentNo;
	}

	/**
	 * Sets the installment no.
	 *
	 * @param installmentNo
	 *            the new installment no
	 */
	public void setInstallmentNo(int installmentNo) {
		this.installmentNo = installmentNo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + custId;
		result = prime * result + installmentNo;
		result = prime * result + ((loanAcctNo == null) ? 0 : loanAcctNo.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AmortizationId)) {
			return false;
		}
		AmortizationId other = (AmortizationId) obj;
		if (custId != other.custId) {
			return false;
		}
		if (installmentNo != other.installmentNo) {
			return false;
		}
		if (loanAcctNo == null) {
			if (other.loanAcctNo != null) {
				return false;
			}
		} else if (!loanAcctNo.equals(other.loanAcctNo)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AmortizationId [custId=" + custId + ", loanAcctNo=" + loanAcctNo + ", installmentNo=" + installmentNo
				+ "]";
	}

}
