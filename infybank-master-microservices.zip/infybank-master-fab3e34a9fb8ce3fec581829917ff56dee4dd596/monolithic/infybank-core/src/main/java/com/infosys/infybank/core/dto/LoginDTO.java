package com.infosys.infybank.core.dto;
 
import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

/**
 * The Class LoginDTO.
 */
public class LoginDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	/** The user id. */
	@NotBlank(message = "customer.userid.mandatory")
	private String userId;

	/** The password. */
	@NotBlank(message = "customer.password.mandatory")
	private String password;

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId
	 *            the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password
	 *            the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LoginDTO [ userId=" + userId + "]";
	}

}
