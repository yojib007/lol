package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;

/**
 * The Class CreditScoreDTO.
 */
public class CreditScoreDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** Crisil Credit Score */
	private int creditScore;

	/**
	 * Gets the credit score
	 *
	 * @return the credit score
	 */
	public int getCreditScore() {
		return this.creditScore;
	}

	/**
	 * Sets the credit score
	 *
	 * @param creditScore credit score
	 */
	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}

	@Override
	public String toString() {
		return "CreditScoreDTO [creditScore=" + creditScore + "]";
	}
	
}
