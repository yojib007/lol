package com.infosys.infybank.utilities;
 
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.orm.jpa.JpaObjectRetrievalFailureException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;

/**
 * The Class ExceptionControllerAdvice.
 */
@ControllerAdvice
public class ExceptionControllerAdvice {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The message source. */
	@Autowired
	private MessageSource messageSource;

	/**
	 * Handle Server errors due to unexpected reason
	 *
	 * @param ex
	 *            the ex
	 * @return the client errors
	 */
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(Exception.class)
	@ResponseBody
	public ClientErrors exceptionHandler(Exception ex) {
		logger.error(ex.getMessage(), ex);
		String errorCode = ExceptionConstants.SERVER_ERROR.toString();
		ClientErrors errors = new ClientErrors(errorCode,
				messageSource.getMessage(errorCode, null, LocaleContextHolder.getLocale()));
		logger.debug("{}", errors);
		return errors;
	}

	/**
	 * Handle InfyBank exception
	 *
	 * @param ex
	 *            the ex
	 * @return the client errors
	 */
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(InfyBankException.class)
	@ResponseBody
	public ClientErrors exceptionHandler(InfyBankException ex) {
		return createErrors(ex);
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseBody
	public ClientErrors exceptionHandler(ResourceNotFoundException ex) {
		return createErrors(ex);
	}

	/**
	 * Handle Object retrieval failure from database.
	 *
	 * @param ex
	 *            the ex
	 * @return the client errors
	 */
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(JpaObjectRetrievalFailureException.class)
	@ResponseBody
	public ClientErrors exceptionHandler(JpaObjectRetrievalFailureException ex) {
		logger.info(ex.getMessage(), ex);
		String errorCode = ExceptionConstants.REQUESTED_OBJECT_NOT_FOUND.toString();
		ClientErrors errors = new ClientErrors(errorCode,
				messageSource.getMessage(errorCode, null, LocaleContextHolder.getLocale()));
		logger.debug("{}", errors);
		return errors;
	}

	/**
	 * Handle missing parameters in request.
	 *
	 * @param ex
	 *            the ex
	 * @return the client erros
	 */
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler({ MissingServletRequestParameterException.class })
	@ResponseBody
	public ClientErrors handleBindingErrors(MissingServletRequestParameterException ex) {

		logger.info(ex.getMessage(), ex);
		String errorCode = ExceptionConstants.INPUT_PARM_MISSING.toString();
		String message = ex.getParameterName() + " "
				+ messageSource.getMessage(errorCode, null, LocaleContextHolder.getLocale());
		ClientErrors errors = new ClientErrors(errorCode, message);
		logger.debug("{}", errors);
		return errors;

	}

	/**
	 * Handle missing parameters in request.
	 *
	 * @param ex
	 *            the ex
	 * @return the client erros
	 */
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler({ HttpMessageNotReadableException.class })
	@ResponseBody
	public ClientErrors handleException(HttpMessageNotReadableException ex) {

		logger.info(ex.getMessage(), ex);
		String message;
		Throwable specificCause = ex.getMostSpecificCause();
		String errorCode = ExceptionConstants.MESSAGE_NOT_READABLE.toString();

		if (specificCause != null) {
			message = specificCause.getMessage();
		} else {
			message = messageSource.getMessage(errorCode, null, LocaleContextHolder.getLocale());
		}
		ClientErrors errors = new ClientErrors(errorCode, message);
		logger.debug("{}", errors);
		return errors;

	}

	/**
	 * Handle binding errors.
	 *
	 * @param ex
	 *            the ex
	 * @return the client error information
	 */
	@ExceptionHandler({ MethodArgumentNotValidException.class })
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ClientErrors handleBindingErrors(MethodArgumentNotValidException ex) {

		String message;
		ClientErrors errors = new ClientErrors();
		BindingResult result = ex.getBindingResult();

		List<FieldError> fieldErrors = result.getFieldErrors();
		for (FieldError error : fieldErrors) {
			message = error.getField() + ", " + error.getDefaultMessage();
			errors.addError(error.getField(), message);
		}

		List<ObjectError> globalErrors = result.getGlobalErrors();
		for (ObjectError error : globalErrors) {
			message = error.getObjectName() + ", " + error.getDefaultMessage();
			errors.addError(error.getObjectName(), message);
		}

		return errors;
	}

	/**
	 * Handle missing parameters in request.
	 *
	 * @param ex
	 *            the ex
	 * @return the client erros
	 */
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler({ HttpMediaTypeNotSupportedException.class })
	@ResponseBody
	public ClientErrors handleBindingErrors(HttpMediaTypeNotSupportedException ex) {

		logger.info(ex.getMessage(), ex);
		String errorCode = ExceptionConstants.MEDIA_TYPE_NOT_SUPPORTED.toString();
		String message = "Unsupported content type: " + ex.getContentType() + " " + "Supported content types: "
				+ ex.getSupportedMediaTypes();
		ClientErrors errors = new ClientErrors(errorCode, message);
		logger.debug("{}", errors);
		return errors;

	}

	/**
	 * Creates errors from Exception Object
	 * 
	 * @param ex
	 * @return
	 */
	private ClientErrors createErrors(InfyBankException ex) {
		logger.info(ex.getMessage(), ex);
		ClientErrors errors;
		String errorCode = ex.getMessage();
		if (errorCode.equals(ExceptionConstants.EXTERNAL_SVC_FAILURE.toString())) {
			errors = ex.getErrors();
		} else {
			errors = new ClientErrors(errorCode,
					messageSource.getMessage(ex.getMessage(), null, LocaleContextHolder.getLocale()));
		}

		logger.debug("{}", errors);
		return errors;
	}

}
