package com.infosys.infybank.fundtransfer.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

import com.infosys.infybank.fundtransfer.entity.FundTransfer;

/**
 * The Class FundTransferDTO.
 */
public class FundTransferDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The from account no. */
	@NotBlank(message = "fundtransfer.fromAccountNo.mandatory")
	@Length(min = 10, max = 10, message = "fundtransfer.fromAccountNo.size")
	String fromAccountNo;

	/** The to account no. */
	String toAccountNo;
	
	/** The payee id. */
	int payeeId;

	/** The amount. */
	@NotNull(message = "fundtransfer.amount.mandatory")
	@DecimalMin(value = "0.01", message = "fundtransfer.amount.nonZero")
	BigDecimal amount;

	/** The remarks. */
	@NotBlank(message = "fundtransfer.remarks.mandatory")
	String remarks;

	/** The fund transfer date. */
	@NotNull(message = "fundtransfer.date.mandatory")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	Date fundTransferDate;

	/** The user id. */
	@NotBlank(message = "fundtransfer.userId.mandatory")
	String userId;

	/** The fund transfer type. */
	@NotBlank(message = "fundtransfer.transferType.mandatory")
	String fundTransferType;

	/**
	 * Gets the from account no.
	 *
	 * @return the from account no
	 */
	public String getFromAccountNo() {
		return fromAccountNo;
	}

	/**
	 * Sets the from account no.
	 *
	 * @param fromAccountNo the new from account no
	 */
	public void setFromAccountNo(String fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}

	/**
	 * Gets the to account no.
	 *
	 * @return the to account no
	 */
	public String getToAccountNo() {
		return toAccountNo;
	}

	/**
	 * Sets the to account no.
	 *
	 * @param toAccountNo the new to account no
	 */
	public void setToAccountNo(String toAccountNo) {
		this.toAccountNo = toAccountNo;
	}

	/**
	 * Gets the payee id.
	 *
	 * @return the payee id
	 */
	public int getPayeeId() {
		return payeeId;
	}

	/**
	 * Sets the payee id.
	 *
	 * @param payeeId the new payee id
	 */
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the new amount
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * Sets the remarks.
	 *
	 * @param remarks the new remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * Gets the fund transfer date.
	 *
	 * @return the fund transfer date
	 */
	public Date getFundTransferDate() {
		return fundTransferDate;
	}

	/**
	 * Sets the fund transfer date.
	 *
	 * @param ftDate the new fund transfer date
	 */
	public void setFundTransferDate(Date ftDate) {
		this.fundTransferDate = ftDate;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the fund transfer type.
	 *
	 * @return the fund transfer type
	 */
	public String getFundTransferType() {
		return fundTransferType;
	}

	/**
	 * Sets the fund transfer type.
	 *
	 * @param transferType the new fund transfer type
	 */
	public void setFundTransferType(String transferType) {
		this.fundTransferType = transferType;
	}

	/**
	 * Prepare entity.
	 *
	 * @param ftDTO the dto
	 * @return the fund transfer
	 */
	public static FundTransfer prepareEntity(FundTransferDTO ftDTO) {
		FundTransfer fundTransfer = new FundTransfer();

		fundTransfer.setFromAcct(ftDTO.getFromAccountNo());
		if (ftDTO.getPayeeId() != 0)
			fundTransfer.setPayeeId(ftDTO.getPayeeId());
		if (ftDTO.getToAccountNo() != null)
			fundTransfer.setToAcct(ftDTO.getToAccountNo());
		fundTransfer.setFtAmount(ftDTO.getAmount());
		fundTransfer.setFtDate(ftDTO.getFundTransferDate());
		fundTransfer.setFtType(ftDTO.getFundTransferType().charAt(0));
		fundTransfer.setRemarks(ftDTO.getRemarks());
		fundTransfer.setStatus('P');
		fundTransfer.setLstUpdtId(ftDTO.getUserId());

		return fundTransfer;

	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FundTransferDTO [fromAccountNo=" + fromAccountNo + ", toAccountNo=" + toAccountNo + ", payeeId="
				+ payeeId + ", amount=" + amount + ", remarks=" + remarks + ", fundTransferDate=" + fundTransferDate
				+ ", userId=" + userId + ", transferType=" + fundTransferType + "]";
	}

}
