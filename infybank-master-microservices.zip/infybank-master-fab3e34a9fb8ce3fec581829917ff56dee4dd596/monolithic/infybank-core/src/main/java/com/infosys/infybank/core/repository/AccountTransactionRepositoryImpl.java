package com.infosys.infybank.core.repository;
 
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.dto.SearchAccountStatementDTO;
import com.infosys.infybank.core.entity.AccountTransaction;


/**
 * The Class AccountTransactionRepositoryImpl.
 */
@Repository
public class AccountTransactionRepositoryImpl implements AccountTransactionCustomRepository {

	/** The emf. */
	private EntityManagerFactory emf;

	/**
	 * Sets the entity manager factory.
	 *
	 * @param emf the new entity manager factory
	 */
	@Autowired
	public void setEntityManagerFactory(EntityManagerFactory emf) {
		this.emf = emf;
	}

	/* (non-Javadoc)
	 * @see com.infosys.infybank.core.repository.AccountTransactionCustomRepository#getTransactions(com.infosys.infybank.core.dto.SearchAccountStatementDTO)
	 */
	public List<AccountTransaction> getTransactions(SearchAccountStatementDTO searchAccountStatementDTO) {

		int custId = searchAccountStatementDTO.getCustId();
		String accountNo = searchAccountStatementDTO.getAcctNo();
		Character txnType = searchAccountStatementDTO.getTxnType();
		Double fromAmount = searchAccountStatementDTO.getFromAmount();
		Double toAmount = searchAccountStatementDTO.getToAmount();
		Date startDate = searchAccountStatementDTO.getStartDate();
		Date endDate = searchAccountStatementDTO.getEndDate();

		EntityManager em = emf.createEntityManager();
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<AccountTransaction> query = builder.createQuery(AccountTransaction.class);
		Root<AccountTransaction> root = query.from(AccountTransaction.class);

		Predicate accountId = builder.equal(root.get("acctNo"), accountNo);
		Predicate customerId = builder.equal(root.get("custId"), custId);

		Predicate sDate = builder.greaterThanOrEqualTo(root.<Date>get("txnDate"), startDate);
		Predicate eDate = builder.lessThanOrEqualTo(root.<Date>get("txnDate"), endDate);
		Predicate exp = builder.and(sDate, eDate);

		if (txnType!=null && (txnType == 'C' || txnType == 'c' || txnType == 'D' || txnType == 'd')) {
			Predicate type = builder.equal(root.get("txnType"), txnType);
			exp = builder.and(exp, type);
		}
		
		if(fromAmount != null && toAmount != null){
			Predicate fAmount = builder.ge(root.<Double>get("txnAmount"), fromAmount);
			Predicate tAmount = builder.le(root.<Double>get("txnAmount"), toAmount);
			Predicate amount = builder.and(fAmount, tAmount);
			exp = builder.and(exp, amount);
		}
		else if(fromAmount != null && toAmount == null){
			Predicate fAmount = builder.ge(root.<Double>get("txnAmount"), fromAmount);
			exp = builder.and(exp, fAmount);
		}
		
		query.where(builder.and(accountId, customerId, exp));

		return em.createQuery(query.select(root)).getResultList();

	}

}
