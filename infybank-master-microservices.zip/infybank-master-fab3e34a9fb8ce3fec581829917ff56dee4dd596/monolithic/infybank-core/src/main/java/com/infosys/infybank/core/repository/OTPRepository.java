package com.infosys.infybank.core.repository;
 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.entity.Otp;


/**
 * The Interface OTPRepository.
 */
@Repository
public interface OTPRepository extends JpaRepository<Otp, Long> {

	/**
	 * Find otp for email and order based on generated timestamp.
	 *
	 * @param emailId            the email id
	 * @param otpType            the type
	 * @return the otp
	 */
	public List<Otp> findFirstByEmailIdAndOtpTypeOrderByGeneratedTsDesc(String emailId, char otpType);
	
	public List<Otp> findByCustIdAndPayeeIdOrderByGeneratedTsDesc(int custId, int payeeId);

}
