package com.infosys.infybank.fundtransfer.controller;
 
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.core.dto.OtpDTO;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.fundtransfer.dto.PayeeDTO;
import com.infosys.infybank.fundtransfer.service.PayeeService;

/**
 * The Class PayeeController.
 */
@RestController
public class PayeeController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The payee service. */
	@Autowired
	PayeeService payeeService;

	/**
	 * Adds the payee.
	 *
	 * @param payeeDTO
	 *            the payee dto
	 * @param custId
	 *            the cust id
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/payees", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.CREATED)
	public void addPayee(@Valid @RequestBody PayeeDTO payeeDTO, @PathVariable("custId") int custId)
			throws InfyBankException {

		logger.debug("New payee details for customer {} : {}", custId, payeeDTO);
		payeeDTO.setCustId(custId);
		payeeService.addPayee(payeeDTO);
	}
	
	/**
	 * Confirm payee.
	 *
	 * @param otpDTO
	 *            the otp dto
	 * @param custId
	 *            the cust id
	 * @param payeeId
	 *            the payee id
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/payees/{payeeId}/confirm", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void confirmPayee(@Valid @RequestBody OtpDTO otpDTO, @PathVariable("custId") int custId,
			@PathVariable("payeeId") int payeeId) throws InfyBankException {

		logger.debug("Confirm payee request for customer {} with details : {}", custId, otpDTO);
		payeeService.confirmPayee(custId, payeeId, otpDTO);
	}

	/**
	 * View payee.
	 *
	 * @param custId
	 *            the cust id
	 * @return the list
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/payees", params = {"status"}, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public List<PayeeDTO> viewPayees(@PathVariable("custId") int custId, @RequestParam(value = "status") char status) throws InfyBankException {

		logger.debug("View payee request for customer : {}", custId);
		List<PayeeDTO> payeeDTOs = payeeService.findPayeesByStatus(custId, status); 
		logger.debug("View payee result for customer {} : {}", custId, payeeDTOs);
		return payeeDTOs;

	}

	/**
	 * Delete payee.
	 *
	 * @param custId
	 *            the cust id
	 * @param payeeId
	 *            the payee id
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}//customers/{custId}/payees/{payeeId}", method = RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deletePayee(@PathVariable("custId") int custId, @PathVariable("payeeId") int payeeId)
			throws InfyBankException {

		logger.debug("Delete payee request for customer {} and payee {}", custId, payeeId);
		payeeService.deletePayee(custId, payeeId);

	}

}
