package com.infosys.infybank.exception;
 
import com.infosys.infybank.utilities.ClientErrors;

/**
 * The Class InfyBankServiceException.
 */
public class InfyBankException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private transient ClientErrors errors; 
	
	/**
	 * Instantiates a new infy bank service exception.
	 *
	 * @param message
	 *            the message
	 */
	public InfyBankException(String message) {
		super(message);

	}
	
	/**
	 * Instantiates a new infy bank service exception.
	 *
	 * @param message
	 *            the message
	 * @param errors
	 *            the client errors
	 */
	public InfyBankException(String message, ClientErrors errors) {
		super(message);
		this.errors = errors;

	}

	/**
	 * @return the errors
	 */
	public ClientErrors getErrors() {
		return errors;
	}
	
}
