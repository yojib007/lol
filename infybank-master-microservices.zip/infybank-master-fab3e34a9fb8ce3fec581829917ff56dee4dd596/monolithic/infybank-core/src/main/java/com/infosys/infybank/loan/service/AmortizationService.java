package com.infosys.infybank.loan.service;
 
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.loan.dto.AmortizationDTO;
import com.infosys.infybank.loan.dto.AmortizationScheduleDTO;
import com.infosys.infybank.loan.entity.Amortization;
import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.entity.LoanAccountId;
import com.infosys.infybank.loan.repository.AmortizationRepository;
import com.infosys.infybank.loan.repository.LoanRepository;
import com.infosys.infybank.utilities.DateField;
import com.infosys.infybank.utilities.DateUtil;

/**
 * The Class AmortizationService.
 */
@Service
public class AmortizationService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The customer repository. */
	@Autowired
	CustomerService custService;

	/** The amortization repository. */
	@Autowired
	AmortizationRepository amortRepo;

	/** The loan account repository. */
	@Autowired
	LoanRepository loanAcctRepo;

	/**
	 * View amortization schedule.
	 *
	 * @param custId
	 *            the cust id
	 * @param loanAcctNo
	 *            the loan acct no
	 * @return the amortization schedule dto
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public AmortizationScheduleDTO viewAmortizationSchedule(int custId, String loanAcctNo) throws InfyBankException {

		// check if custId is valid
		custService.getCustomerDetails(custId);

		LoanAccount loanAccount = loanAcctRepo.findOne(new LoanAccountId(custId, loanAcctNo));
		//
		if (loanAccount == null) {
			throw new ResourceNotFoundException(ExceptionConstants.LOAN_DETAILS_NOT_AVAILABLE.toString());
		}

		if (loanAccount.getLoanStatus() == 'S' || loanAccount.getLoanStatus() == 'R') {
			throw new InfyBankException(ExceptionConstants.LOAN_STATUS_INVALID.toString());
		}

		List<Amortization> amortList = amortRepo.getAmortizationDetails(custId, loanAcctNo);
		int totalNoOfInstallments = getNoOfEMIsPaid(amortList);
		logger.debug("Ammortization details fetched from db : {}", amortList);
		logger.debug("No. of installments already paid : {}", totalNoOfInstallments);

		List<AmortizationDTO> amortDTOs = new ArrayList<AmortizationDTO>();
		BigDecimal rateOfInterest = loanAccount.getInterestRate();
		BigDecimal emi = loanAccount.getEmi();

		if (!(amortList == null || amortList.isEmpty())) {

			for (Amortization a : amortList) {
				AmortizationDTO amortDTO = new AmortizationDTO();
				amortDTO.setInstallmentAmount(a.getInstallmentAmount().setScale(2, RoundingMode.HALF_UP));
				amortDTO.setInterestRate(rateOfInterest);
				amortDTO.setLoanAcctNo(loanAcctNo);
				amortDTO.setClosingPrincipal(a.getClosingPrincipal().setScale(2, RoundingMode.HALF_UP));
				amortDTO.setInstallmentDate(a.getInstallmentDate());
				amortDTO.setInstallmentNo(a.getId().getInstallmentNo());
				amortDTO.setInterestComponent(a.getInterestComponent().setScale(2, RoundingMode.HALF_UP));
				amortDTO.setOpeningPrincipal(a.getOpeningPrincipal().setScale(2, RoundingMode.HALF_UP));
				amortDTO.setPrincipalComponent(a.getPrincipalComponent().setScale(2, RoundingMode.HALF_UP));
				amortDTO.setStatus('P');
				amortDTOs.add(amortDTO);
			}
			logger.debug("AmmortizationDTOs : {}", amortDTOs);
		}

		Date date = loanAccount.getEmiDueDate();
		for (int i = totalNoOfInstallments + 1; i <= loanAccount.getTenure(); i++) {
			BigDecimal openingPrincipal;
			Date installmentDate = date;
			logger.debug("AmmortizationDTOs at start of iteration {} : {}", i, amortDTOs);
			if (amortDTOs.isEmpty()) {
				openingPrincipal = loanAccount.getLoanAmount();
			} else {
				AmortizationDTO lastInstallment = amortDTOs.get(amortDTOs.size() - 1);
				openingPrincipal = lastInstallment.getClosingPrincipal();
				if (openingPrincipal.compareTo(BigDecimal.valueOf(0)) == 0) {
					break;
				}
			}
			// calculate installment date for next iteration upfront
			date = DateUtil.addDuration(date, DateField.DAY, 1);

			BigDecimal interestComponent = (openingPrincipal).multiply(rateOfInterest.divide(new BigDecimal(100)));
			BigDecimal principalComponent = emi.subtract(interestComponent);
			if (openingPrincipal.compareTo(emi) < 0) {
				emi = openingPrincipal.add(interestComponent);
				principalComponent = openingPrincipal;
			}
			AmortizationDTO amortDTO = new AmortizationDTO();
			amortDTO.setInstallmentAmount(emi.setScale(2, RoundingMode.HALF_UP));
			amortDTO.setInterestRate(rateOfInterest);
			amortDTO.setLoanAcctNo(loanAcctNo);
			if (amortDTOs.size() != 0) {
				amortDTO.setInstallmentNo(amortDTOs.get(amortDTOs.size() - 1).getInstallmentNo() + 1);

			} else {
				amortDTO.setInstallmentNo(1);
			}
			if (!(installmentDate instanceof java.sql.Date)) {
				installmentDate = new java.sql.Date(installmentDate.getTime());
			}
			amortDTO.setInstallmentDate(installmentDate);
			amortDTO.setInterestComponent(interestComponent.setScale(2, RoundingMode.HALF_UP));
			amortDTO.setPrincipalComponent(principalComponent.setScale(2, RoundingMode.HALF_UP));
			amortDTO.setOpeningPrincipal(openingPrincipal.setScale(2, RoundingMode.HALF_UP));
			amortDTO.setClosingPrincipal(
					(openingPrincipal.subtract(principalComponent)).setScale(2, RoundingMode.HALF_UP));
			amortDTO.setStatus('D');
			logger.debug("AmmortizationDTO being added to list in iteration {} : {}", i, amortDTO);
			amortDTOs.add(amortDTO);
		}

		AmortizationScheduleDTO amortScheduleDTO = new AmortizationScheduleDTO();
		amortScheduleDTO.setAmmortizationList(amortDTOs);
		amortScheduleDTO.setTotalNoOfInstallments(amortDTOs.get(amortDTOs.size() - 1).getInstallmentNo());
		logger.debug("Final AmmortizationDTOs : {}", amortDTOs);

		return amortScheduleDTO;
	}

	/**
	 * Gets the amortization details.
	 *
	 * @param custId
	 *            the cust id
	 * @param loanAcctNo
	 *            the loan acct no
	 * @return the amortization details
	 */
	public List<Amortization> getAmortizationDetails(int custId, String loanAcctNo) {
		return amortRepo.getAmortizationDetails(custId, loanAcctNo);
	}

	/**
	 * Finds number of EMIs already paid
	 * 
	 * @param amortList
	 * @return
	 */
	public int getNoOfEMIsPaid(List<Amortization> amortList) {

		int noOfEMIs = 0;
		for (Amortization amort : amortList) {
			if (amort.getInterestComponent().compareTo(BigDecimal.valueOf(0.0)) > 0) {
				noOfEMIs++;
			}
		}
		return noOfEMIs;
	}

}
