package com.infosys.infybank.core.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.infosys.infybank.core.entity.AccountTransaction;

/**
 * The Class AccountStatementDTO.
 */
public class AccountStatementDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The cust id. */
	private int custId;
	
	/** The acct no. */
	private String acctNo;
	
	/** The txn type. */
	private char txnType;
	
	/** The txn date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date txnDate;
	
	/** The remarks. */
	private String remarks;
	
	/** The txn amount. */
	private BigDecimal txnAmount;
	
	/** The txn category. */
	private char txnCategory;
	
	/** The opening bal. */
	private BigDecimal openingBal;
	
	/** The closing bal. */
	private BigDecimal closingBal;

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return acctNo;
	}

	/**
	 * Sets the acct no.
	 *
	 * @param acctNo the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	/**
	 * Gets the txn type.
	 *
	 * @return the txn type
	 */
	public char getTxnType() {
		return txnType;
	}

	/**
	 * Sets the txn type.
	 *
	 * @param txnType the new txn type
	 */
	public void setTxnType(char txnType) {
		this.txnType = txnType;
	}

	/**
	 * Gets the txn date.
	 *
	 * @return the txn date
	 */
	public Date getTxnDate() {
		return txnDate;
	}

	/**
	 * Sets the txn date.
	 *
	 * @param txnDate the new txn date
	 */
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * Sets the remarks.
	 *
	 * @param remarks the new remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * Gets the txn amount.
	 *
	 * @return the txn amount
	 */
	public BigDecimal getTxnAmount() {
		return txnAmount;
	}

	/**
	 * Sets the txn amount.
	 *
	 * @param txnAmount the new txn amount
	 */
	public void setTxnAmount(BigDecimal txnAmount) {
		this.txnAmount = txnAmount;
	}

	/**
	 * Gets the txn category.
	 *
	 * @return the txn category
	 */
	public char getTxnCategory() {
		return txnCategory;
	}

	/**
	 * Sets the txn category.
	 *
	 * @param txnCategory the new txn category
	 */
	public void setTxnCategory(char txnCategory) {
		this.txnCategory = txnCategory;
	}

	/**
	 * Gets the opening bal.
	 *
	 * @return the opening bal
	 */
	public BigDecimal getOpeningBal() {
		return openingBal;
	}

	/**
	 * Sets the opening bal.
	 *
	 * @param openingBal the new opening bal
	 */
	public void setOpeningBal(BigDecimal openingBal) {
		this.openingBal = openingBal;
	}

	/**
	 * Gets the closing bal.
	 *
	 * @return the closing bal
	 */
	public BigDecimal getClosingBal() {
		return closingBal;
	}

	/**
	 * Sets the closing bal.
	 *
	 * @param closingBal the new closing bal
	 */
	public void setClosingBal(BigDecimal closingBal) {
		this.closingBal = closingBal;
	}

	/**
	 * Prepare dto.
	 *
	 * @param accTx the acc tx
	 * @return the account statement dto
	 */
	public static AccountStatementDTO valueOf(AccountTransaction accTx) {
		AccountStatementDTO accStatementDTO = new AccountStatementDTO();
		accStatementDTO.setAcctNo(accTx.getAcctNo());
		accStatementDTO.setCustId(accTx.getCustId());
		accStatementDTO.setTxnDate(accTx.getTxnDate());
		accStatementDTO.setTxnAmount(accTx.getTxnAmount());
		accStatementDTO.setRemarks(accTx.getRemarks());
		accStatementDTO.setOpeningBal(accTx.getOpeningBal());
		accStatementDTO.setClosingBal(accTx.getClosingBal());
		accStatementDTO.setTxnType(accTx.getTxnTyp());
		accStatementDTO.setTxnCategory(accTx.getTxnCategory());
		return accStatementDTO;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AccountStatementDTO [custId=" + custId + ", acctNo=" + acctNo + ", txnType=" + txnType + ", txnDate="
				+ txnDate + ", remarks=" + remarks + ", txnAmount=" + txnAmount + ", txnCategory=" + txnCategory
				+ ", openingBal=" + openingBal + ", closingBal=" + closingBal + "]";
	}

}
