package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * The Class ViewLoanDetailsDTO.
 */
public class ViewLoanDetailsDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The loan acct no. */
	private String loanAcctNo;
	
	/** The loan amount. */
	private BigDecimal loanAmount;
	
	/** The tenure. */
	private int tenure;
	
	/** The emi. */
	private BigDecimal emi;
	
	/** The interest rate. */
	private BigDecimal interestRate;
	
	/** The loan status. */
	private char loanStatus;
	
	/** The Outstanding amount. */
	private BigDecimal outstandingBalance;
	
	/** The total interest paid. */
	private BigDecimal totalInterestPaid;
	
	/** The total principal amount paid. */
	private BigDecimal totalPrincipalAmountPaid;
	
	/** The expected closure date. */
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date expectedClosureDate;
	
	private Date lastPrepaymentDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date lstUpdtTs;

	/**
	 * Gets the loan acct no.
	 *
	 * @return the loan acct no
	 */
	public String getLoanAcctNo() {
		return loanAcctNo;
	}

	/**
	 * Sets the loan acct no.
	 *
	 * @param loanAcctNo the new loan acct no
	 */
	public void setLoanAcctNo(String loanAcctNo) {
		this.loanAcctNo = loanAcctNo;
	}

	/**
	 * Gets the loan amount.
	 *
	 * @return the loan amount
	 */
	public BigDecimal getLoanAmount() {
		return loanAmount;
	}

	/**
	 * Sets the loan amount.
	 *
	 * @param loanAmount the new loan amount
	 */
	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	/**
	 * Gets the tenure.
	 *
	 * @return the tenure
	 */
	public int getTenure() {
		return tenure;
	}

	/**
	 * Sets the tenure.
	 *
	 * @param tenure the new tenure
	 */
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	/**
	 * Gets the emi.
	 *
	 * @return the emi
	 */
	public BigDecimal getEmi() {
		return emi;
	}

	/**
	 * Sets the emi.
	 *
	 * @param emi the new emi
	 */
	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}

	/**
	 * Gets the interest rate.
	 *
	 * @return the interest rate
	 */
	public BigDecimal getInterestRate() {
		return interestRate;
	}

	/**
	 * Sets the interest rate.
	 *
	 * @param interestRate the new interest rate
	 */
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	/**
	 * Gets the loan status.
	 *
	 * @return the loan status
	 */
	public char getLoanStatus() {
		return loanStatus;
	}

	/**
	 * Sets the loan status.
	 *
	 * @param loanStatus the new loan status
	 */
	public void setLoanStatus(char loanStatus) {
		this.loanStatus = loanStatus;
	}

	/**
	 * Gets the outstanding amount.
	 *
	 * @return the outstanding amount
	 */
	public BigDecimal getOutstandingBalance() {
		return outstandingBalance;
	}

	/**
	 * Sets the outstanding amount.
	 *
	 * @param outstandingBalance the new outstanding amount
	 */
	public void setOutstandingBalance(BigDecimal outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	/**
	 * Gets the total interest paid.
	 *
	 * @return the total interest paid
	 */
	public BigDecimal getTotalInterestPaid() {
		return totalInterestPaid;
	}

	/**
	 * Sets the total interest paid.
	 *
	 * @param totalInterestPaid the new total interest paid
	 */
	public void setTotalInterestPaid(BigDecimal totalInterestPaid) {
		this.totalInterestPaid = totalInterestPaid;
	}

	/**
	 * Gets the total principal amount.
	 *
	 * @return the total principal amount
	 */
	public BigDecimal getTotalPrincipalAmount() {
		return totalPrincipalAmountPaid;
	}

	/**
	 * Sets the total principal amount.
	 *
	 * @param totalPrincipalAmount the new total principal amount
	 */
	public void setTotalPrincipalAmount(BigDecimal totalPrincipalAmount) {
		this.totalPrincipalAmountPaid = totalPrincipalAmount;
	}

	/**
	 * Gets the expected closure date.
	 *
	 * @return the expected closure date
	 */
	public Date getExpectedClosureDate() {
		return this.expectedClosureDate;
	}

	/**
	 * Sets the expected closure date.
	 *
	 * @param expectedClosureDate the new expected closure date
	 */
	public void setExpectedClosureDate(Date expectedClosureDate) {
		this.expectedClosureDate = expectedClosureDate;
	}

	/**
	 * Gets the last prepayment date..
	 *
	 * @return last prepayment date.
	 */
	public Date getLastPrepaymentDate() {
		return lastPrepaymentDate;
	}


	/**
	 * Sets the last prepayment date.
	 *
	 * @param lastPrepaymentDate the new last prepayment date
	 */
	public void setLastPrepaymentDate(Date lastPrepaymentDate) {
		this.lastPrepaymentDate = lastPrepaymentDate;
	}
	
	public Date getLstUpdtTs() {
		return lstUpdtTs;
	}

	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		String expectedClDate = expectedClosureDate != null ? dateFormat.format(expectedClosureDate) : null;
		String lastPPDate = lastPrepaymentDate != null ? dateFormat.format(lastPrepaymentDate) : null;

		return "ViewLoanDetailsDTO [loanAcctNo=" + loanAcctNo + ", loanAmount=" + loanAmount + ", tenure=" + tenure
				+ ", emi=" + emi + ", loanStatus=" + loanStatus + ", outstandingAmount=" + outstandingBalance
				+ ", totalInterestPaid=" + totalInterestPaid + ", totalPrincipalAmount=" + totalPrincipalAmountPaid
				+ ", expectedClosureDate=" + expectedClDate 
				+ ", lastPrepaymentDate=" + lastPPDate + "]";
	}

}
