package com.infosys.infybank;
 
import java.math.BigDecimal;

public class ApplicationProperties {

	// Urls for external services
	private String aadharUrl;
	private String ifscUrl;
	private String creditScoreUrl;
	private String emailServiceUrl;

	// Customer profile preferences
	private String datePref;
	private String amountPref;
	private BigDecimal creditLimit;

	// Account configurations
	private int acctStartDefVal;
	private String ifscCode;
	private int ftLimit;

	// loan configurations
	private int cibilMinScore;
	private int cibilMaxScore;
	private int minLoanTenure;
	private int noOfSalaryCredits;

	public String getEmailServiceUrl() {
		return emailServiceUrl;
	}

	public void setEmailServiceUrl(String emailServiceUrl) {
		this.emailServiceUrl = emailServiceUrl;
	}

	public int getCibilMinScore() {
		return cibilMinScore;
	}

	public void setCibilMinScore(int cibilMinScore) {
		this.cibilMinScore = cibilMinScore;
	}

	public int getCibilMaxScore() {
		return cibilMaxScore;
	}

	public void setCibilMaxScore(int cibilMaxScore) {
		this.cibilMaxScore = cibilMaxScore;
	}

	public int getMinLoanTenure() {
		return minLoanTenure;
	}

	public void setMinLoanTenure(int minLoanTenure) {
		this.minLoanTenure = minLoanTenure;
	}

	public int getMaxLoanTenure() {
		return maxLoanTenure;
	}

	public void setMaxLoanTenure(int maxLoanTenure) {
		this.maxLoanTenure = maxLoanTenure;
	}

	private int maxLoanTenure;

	public int getFtLimit() {
		return ftLimit;
	}

	public void setFtLimit(int ftLimit) {
		this.ftLimit = ftLimit;
	}

	public BigDecimal getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(BigDecimal creditLimit) {
		this.creditLimit = creditLimit;
	}

	public int getAcctStartDefVal() {
		return acctStartDefVal;
	}

	public void setAcctStartDefVal(int acctStartDefVal) {
		this.acctStartDefVal = acctStartDefVal;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAadharUrl() {
		return aadharUrl;
	}

	public void setAadharUrl(String aadharUrl) {
		this.aadharUrl = aadharUrl;
	}

	public String getDatePref() {
		return datePref;
	}

	public void setDatePref(String datePref) {
		this.datePref = datePref;
	}

	public String getAmountPref() {
		return amountPref;
	}

	public void setAmountPref(String amountPref) {
		this.amountPref = amountPref;
	}

	public String getIfscUrl() {
		return ifscUrl;
	}

	public void setIfscUrl(String ifscUrl) {
		this.ifscUrl = ifscUrl;
	}

	public String getCreditScoreUrl() {
		return creditScoreUrl;
	}

	public void setCreditScoreUrl(String creditScoreUrl) {
		this.creditScoreUrl = creditScoreUrl;
	}

	public int getNoOfSalaryCredits() {
		return noOfSalaryCredits;
	}

	public void setNoOfSalaryCredits(int noOfSalaryCredits) {
		this.noOfSalaryCredits = noOfSalaryCredits;
	}

	@Override
	public String toString() {
		return "ApplicationProperties [aadharUrl=" + aadharUrl + ", ifscUrl=" + ifscUrl + ", creditScoreUrl="
				+ creditScoreUrl + ", emailServiceUrl=" + emailServiceUrl + ", datePref=" + datePref + ", amountPref="
				+ amountPref + ", creditLimit=" + creditLimit + ", acctStartDefVal=" + acctStartDefVal + ", ifscCode="
				+ ifscCode + ", ftLimit=" + ftLimit + ", cibilMinScore=" + cibilMinScore + ", cibilMaxScore="
				+ cibilMaxScore + ", minLoanTenure=" + minLoanTenure + ", noOfSalaryCredits=" + noOfSalaryCredits
				+ ", maxLoanTenure=" + maxLoanTenure + "]";
	}
	
}
