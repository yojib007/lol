package com.infosys.infybank.core.repository;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.entity.Customer;

/**
 * The Interface CustomerRepository.
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	/**
	 * Find customer by aadhar id.
	 * 
	 * @param aadharId
	 *            the aadhar id
	 * @return the integer
	 */
	Customer findByAadharId(String aadharId);

	/**
	 * Find customer by email id.
	 * 
	 * @param emailId
	 *            the email id
	 * @return the integer
	 */
	Customer findByEmailId(String emailId);

}
