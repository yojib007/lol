package com.infosys.infybank;
 
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * ApplicationInitializer.java - a class which registers
 * DispatcherServlet(Spring MVC Controller) avoiding XML-configuration of
 * web-application.
 * 
 * @author ETA Java
 * @version 1.0
 * 
 */
public class ApplicationInitializer implements WebApplicationInitializer {

	/**
	 * add DispatcherServlet to ServletContext
	 */
	public void onStartup(ServletContext container) throws ServletException {
		// Create the 'root' Spring application context
		AnnotationConfigWebApplicationContext ctx = new AnnotationConfigWebApplicationContext();
		ctx.register(WebMvcConfig.class);
		ctx.setServletContext(container);

		// Create & initialize DispatcherServlet with WebApplicationContext,
		// mapped to "/" URLs
		// and set to eagerly load on application startup
		ServletRegistration.Dynamic servlet = container.addServlet("dispatcher", new DispatcherServlet(ctx));
		servlet.setLoadOnStartup(1);
		servlet.addMapping("/");
	}

}
