package com.infosys.infybank.core.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.infosys.infybank.core.entity.Customer;

/**
 * The Class CustomerDTO.
 */
public class CustomerDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	@JsonProperty(value = "cust", access = Access.READ_ONLY)
	private int custId;

	/** The first name. */
	@JsonProperty(value = "firstName", access = Access.READ_ONLY)
	private String firstName;

	/** The last name. */
	@JsonProperty(value = "lastName", access = Access.READ_ONLY)
	private String lastName;

	/** The aadhar id. */
	@JsonProperty(value = "aadharId", access = Access.READ_ONLY)
	private String aadharId;

	/** The email id. */
	@NotBlank(message = "newcustomer.email.mandatory")
	@Email(message = "newcustomer.email.valid")
	@JsonProperty("email")
	private String emailId;

	/** The address. */
	@NotBlank(message = "newcustomer.address.mandatory")
	@JsonProperty("address")
	private String address;

	/** The city. */
	@NotBlank(message = "newcustomer.city.mandatory")
	@JsonProperty("city")
	private String city;

	/** The state. */
	@NotBlank(message = "newcustomer.state.mandatory")
	@JsonProperty("state")
	private String state;

	/** The pincode. */
	@Pattern(regexp = "[0-9]{6}", message = "newcustomer.pincode.invalid")
	@NotBlank(message = "newcustomer.pincode.mandatory")
	@JsonProperty("pinCode")
	private String pincode;

	/** The cr db notif limit. */
	@JsonProperty("creditDebitLimit")
	@NotNull(message = "updatecustomer.creditDebitLimit.mandatory")
	private BigDecimal crDbNotifLimit;

	/** The amount pref. */
	@JsonProperty("amountPref")
	@NotBlank(message = "updatecustomer.amountPref.mandatory")
	private String amountPref;

	/** The date pref. */
	@NotBlank(message = "updatecustomer.datePref.mandatory")
	@JsonProperty("datePref")
	private String datePref;

	/** The lst updt id. */
	@NotBlank(message = "updatecustomer.lastUpdatedId.mandatory")
	@JsonProperty(value = "userId", access = Access.WRITE_ONLY)
	private String lstUpdtId;

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the aadhar id.
	 *
	 * @return the aadhar id
	 */
	public String getAadharId() {
		return aadharId;
	}

	/**
	 * Sets the aadhar id.
	 *
	 * @param aadharId
	 *            the new aadhar id
	 */
	public void setAadharId(String aadharId) {
		this.aadharId = aadharId;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName
	 *            the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName
	 *            the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Sets the email id.
	 *
	 * @param emailId
	 *            the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address
	 *            the new address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city
	 *            the new city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state
	 *            the new state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets the pincode.
	 *
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/**
	 * Sets the pincode.
	 *
	 * @param pincode
	 *            the new pincode
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/**
	 * Gets the cr db notif limit.
	 *
	 * @return the cr db notif limit
	 */
	public BigDecimal getCrDbNotifLimit() {
		return crDbNotifLimit;
	}

	/**
	 * Sets the cr db notif limit.
	 *
	 * @param crDbNotifLimit
	 *            the new cr db notif limit
	 */
	public void setCrDbNotifLimit(BigDecimal crDbNotifLimit) {
		this.crDbNotifLimit = crDbNotifLimit;
	}

	/**
	 * Gets the amount pref.
	 *
	 * @return the amount pref
	 */
	public String getAmountPref() {
		return amountPref;
	}

	/**
	 * Sets the amount pref.
	 *
	 * @param amountPref
	 *            the new amount pref
	 */
	public void setAmountPref(String amountPref) {
		this.amountPref = amountPref;
	}

	/**
	 * Gets the date pref.
	 *
	 * @return the date pref
	 */
	public String getDatePref() {
		return datePref;
	}

	/**
	 * Sets the date pref.
	 *
	 * @param datePref
	 *            the new date pref
	 */
	public void setDatePref(String datePref) {
		this.datePref = datePref;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UpdateCustomerDTO [emailId=" + emailId + ", address=" + address + ", city=" + city + ", state=" + state
				+ ", pincode=" + pincode + ", crDbNotifLimit=" + crDbNotifLimit + ", amountPref=" + amountPref
				+ ", datePref=" + datePref + ", lstUpdtId=" + lstUpdtId + "]";
	}

	/**
	 * Used to update Customer entity object from customer.
	 *
	 * @param customer
	 *            the customer entity
	 * @param customerDTO
	 *            the update customer dto
	 * @return Customer entity object
	 */
	public static void updateEntity(Customer customer, CustomerDTO customerDTO) {
		
		if (customerDTO.getEmailId() != null) {
			customer.setEmailId(customerDTO.getEmailId());
		}
		if (customerDTO.getAddress() != null) {
			customer.setAddress(customerDTO.getAddress());
		}
		if (customerDTO.getState() != null) {
			customer.setState(customerDTO.getState());
		}
		if (customerDTO.getCity() != null) {
			customer.setCity(customerDTO.getCity());
		}
		if (customerDTO.getPincode() != null) {
			customer.setPincode(customerDTO.getPincode());
		}
		if (customerDTO.getCrDbNotifLimit() != null) {
			customer.setCrDbNotifLimit(customerDTO.getCrDbNotifLimit());
		}
		if (customerDTO.getDatePref() != null) {
			customer.setDatePref(customerDTO.getDatePref());
		}
		if (customerDTO.getAmountPref() != null) {
			customer.setAmountPref(customerDTO.getAmountPref());
		}
		if (customerDTO.getLstUpdtId() != null) {
			customer.setLstUpdtId(customerDTO.getLstUpdtId());
		}
	}

	/**
	 * Prepares Customer DTO from Customer entity object.
	 *
	 * @param customer
	 *            the customer entity
	 * @return Customer DTO
	 */
	public static CustomerDTO valueOf(Customer customer) {
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustId(customer.getCustId());
		customerDTO.setFirstName(customer.getFirstName());
		customerDTO.setLastName(customer.getLastName());
		customerDTO.setAadharId(customer.getAadharId());
		customerDTO.setEmailId(customer.getEmailId());
		customerDTO.setAddress(customer.getAddress());
		customerDTO.setState(customer.getState());
		customerDTO.setCity(customer.getCity());
		customerDTO.setPincode(customer.getPincode());
		customerDTO.setCrDbNotifLimit(customer.getCrDbNotifLimit());
		customerDTO.setDatePref(customer.getDatePref());
		customerDTO.setAmountPref(customer.getAmountPref());
		return customerDTO;
	}

	/**
	 * Prepare customer entity.
	 *
	 * @param registerDTO
	 *            the register DTO
	 * @return the customer entity object
	 */
	public static Customer prepareEntity(RegistrationDTO registerDTO) {

		Customer customer = new Customer();
		customer.setFirstName(registerDTO.getFirstName());
		customer.setLastName(registerDTO.getLastName());
		customer.setAadharId(registerDTO.getAadharId());
		customer.setEmailId(registerDTO.getEmailId());
		customer.setAddress(registerDTO.getAddress());
		customer.setCity(registerDTO.getCity());
		customer.setState(registerDTO.getState());
		customer.setPincode(registerDTO.getPincode());
		customer.setPanNo(registerDTO.getPanNo());
		customer.setDob(registerDTO.getDob());
		return customer;
	}

}
