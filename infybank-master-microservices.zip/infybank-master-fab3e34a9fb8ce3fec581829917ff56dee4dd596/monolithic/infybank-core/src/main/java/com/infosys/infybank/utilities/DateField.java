package com.infosys.infybank.utilities;
 
public enum DateField {
	DAY, SECOND
}
