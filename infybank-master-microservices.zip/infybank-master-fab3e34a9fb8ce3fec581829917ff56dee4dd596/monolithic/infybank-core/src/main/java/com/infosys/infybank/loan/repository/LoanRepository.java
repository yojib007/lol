package com.infosys.infybank.loan.repository;
 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.entity.LoanAccountId;

/**
 * The Interface LoanAccountRepository.
 */
@Repository
public interface LoanRepository extends JpaRepository<LoanAccount, LoanAccountId> {


	/**
	 * Gets the all loan accounts for the given status.
	 *
	 * @param custId
	 *            the cust id
	 * @param loanStatus
	 *            the loan status
	 * @return the all loan accounts for the given status
	 */
	public List<LoanAccount> findById_CustIdAndLoanStatus(int custId, char loanStatus);
	
	
	public List<LoanAccount> findById_CustId(int custId);

	/**
	 * Gets the submitted and approved loans.
	 *
	 * @param custId
	 *            the cust id
	 * @return the submitted and approved loans
	 */
	@Query(value = "select l.loanStatus from LoanAccount l where l.id.custId=:custId"
			+ " and (l.loanStatus='S' or l.loanStatus='A')")
	public Character getSubmittedAndApprovedLoans(@Param("custId") int custId);

	/**
	 * Gets the loan account for acct no.
	 *
	 * @param loanAcctNo
	 *            the loan acct no
	 * @return the loan account for acct no
	 */

	public LoanAccount findByIdLoanAcctNo(String loanAcctNo);

	/**
	 * Gets the loan aacounts for status.
	 *
	 * @return the loan aacounts for status.
	 */

	public List<LoanAccount> findByLoanStatus(char status);

}
