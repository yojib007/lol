/**
 * 
 */
package com.infosys.infybank.core.dto;
 
import java.io.Serializable;

/**
 * The Class Email.
 */
public class Email implements Serializable{
	
	private static final long serialVersionUID = 1L;

	/** The subject. */
	private String subject;
	
	/** The email message. */
	private String emailMessage;
	
	/** The to email id. */
	private String toEmail;
	
	

	/**
	 * Gets the subject.
	 *
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * Sets the subject.
	 *
	 * @param subject the new subject
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * Gets the email message.
	 *
	 * @return the email message
	 */
	public String getEmailMessage() {
		return emailMessage;
	}

	/**
	 * Sets the email message.
	 *
	 * @param emailMessage the new email message
	 */
	public void setEmailMessage(String emailMessage) {
		this.emailMessage = emailMessage;
	}

	/**
	 * Gets the to email id.
	 *
	 * @return the to email id
	 */
	public String getToEmail() {
		return toEmail;
	}

	/**
	 * Sets the to email id.
	 *
	 * @param toEmailId the new to email id
	 */
	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Email [subject=" + subject + ", emailMessage=" + emailMessage + ", toEmailId=" + toEmail + "]";
	}
}
