package com.infosys.infybank;
 
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;


/**
 * The listener interface for receiving infyBank events.
 * The class that is interested in processing a infyBank
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addInfyBankListener<code> method. When
 * the infyBank event occurs, that object's appropriate
 * method is invoked.
 *
 * @see InfyBankEvent
 */
@Component
public class InfyBankListener extends HandlerInterceptorAdapter {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(InfyBankListener.class);

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		MDC.clear();
		String uuid = UUID.randomUUID().toString();
		MDC.put("RequestId", uuid);
		logger.info("REST request received with id {}" , uuid);
		return super.preHandle(request, response, handler);
	}

}