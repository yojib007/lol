/**
 * 
 */
package com.infosys.infybank.exception;
 

/**
 * The Enum ExceptionConstants.
 */
public enum ExceptionConstants { 
	
	/** The customer already registered with aadhar. */
	CUSTOMER_ALREADY_REGISTERED_WITH_AADHAR("customer.registered.aadhar"),
	
	/** The customer already registered with email. */
	CUSTOMER_ALREADY_REGISTERED_WITH_EMAIL("customer.registered.email"),
	
	/** The customer not mapped to aadhar. */
	CUSTOMER_NOT_MAPPED_TO_AADHAR("customer.registered.kyc"),
	
	/** The customer otp generation failed. */
	CUSTOMER_OTP_GENERATION_FAILED("customer.otp.failed"),
	
	/** The customer invalid otp. */
	CUSTOMER_INVALID_OTP("customer.otp.invalid"),
	
	/** The customer amt lessthan minbal. */
	CUSTOMER_AMT_LESSTHAN_MINBAL("customer.minbalance.failed"),
	
	/** The customer secure pwd failed. */
	CUSTOMER_SECURE_PWD_FAILED("customer.secure.password.failed"), 
	
	/** The customer otp expired. */
	CUSTOMER_OTP_EXPIRED ("customer.otp.expired"),
	
	/** The customer id invalid. */
	CUSTOMER_ID_INVALID("customer.id.invalid"),
	
	CUSTOMER_INVALID_ACCTTYPE("customer.invalid.accttype"),
	
	/** The login id invalid. */
	LOGIN_ID_INVALID("customer.login.invalid"),
	
	/** The customer is already salaried. */
	CUSTOMER_IS_ALREADY_SALARIED("customer.account.salaried"),
	
	/** The userid invalid. */
	USERID_INVALID("customer.user.invalid"),
	
	CUSTOMER_SALARIED_INVALID("customer.salaried.invalid"),
	
	/** The customer transaction failed. */
	CUSTOMER_TRANSACTION_FAILED("customer.transaction.failed"),
	
	/** The accountconfig retrieval failed. */
	ACCOUNTCONFIG_RETRIEVAL_FAILED("accountconfig.retrieval.failed"),
	
	/** The accountconfig update failed. */
	ACCOUNTCONFIG_UPDATE_FAILED("accountconfig.update.failed"),
	
	/** The customer transaction details not present. */
	CUSTOMER_TRANSACTION_DETAILS_NOT_PRESENT("customer.accountstatement.notfound"),
	
	/** The account transaction type invalid. */
	ACCOUNT_TRANSACTION_TYPE_INVALID("account.transaction.type.invalid"),
	
	/** The account transaction start date invalid. */
	ACCOUNT_TRANSACTION_START_DATE_INVALID("account.transaction.start.date.mandatory"),
	
	/** The account transaction end date invalid. */
	ACCOUNT_TRANSACTION_END_DATE_INVALID("account.transaction.end.date.mandatory"),
	
	/** The account transaction fromto amount invalid. */
	ACCOUNT_TRANSACTION_FROMTO_AMOUNT_INVALID("account.transaction.fromTo.amount.invalid"),
	
	/** The account transaction from amount invalid. */
	ACCOUNT_TRANSACTION_FROM_AMOUNT_INVALID("account.transaction.from.amount.invalid"),
	
	/** The account transaction to amount invalid. */
	ACCOUNT_TRANSACTION_TO_AMOUNT_INVALID("account.transaction.to.amount.invalid"),
	
	/** The account transaction from to date invalid. */
	ACCOUNT_TRANSACTION_FROM_TO_DATE_INVALID("account.transaction.start.to.date.invalid"),
	
	/** The account transaction fromtodate invalid. */
	ACCOUNT_TRANSACTION_FROMTODATE_INVALID("account.transaction.date.invalid"),
	
	/** The account transaction date invalid. */
	ACCOUNT_TRANSACTION_DATE_INVALID("account.transaction.date.input.invalid"),
	
	/** The customer customerid invalid. */
	CUSTOMER_CUSTOMERID_INVALID("customer.customerId.invalid"),
	
	/** The customer account details not present. */
	CUSTOMER_ACCOUNT_DETAILS_NOT_PRESENT("customer.account.no"),
	
	/** The payee doesnot exist. */
	PAYEE_DOESNOT_EXIST("payee.doesnot.exist"),
	
	/** The customer payeeid invalid. */
	CUSTOMER_PAYEEID_INVALID("customer.payeeid.invalid"),
	
	/** The payee ifsc invalid. */
	PAYEE_IFSC_INVALID("invalid.ifsc"),
	
	/** The payee invalid otp. */
	PAYEE_INVALID_OTP("customer.otp.invalid"),
	
	/** The payee expired otp. */
	PAYEE_EXPIRED_OTP("customer.otp.expired"),
	
	/** The payee already added. */
	PAYEE_ALREADY_ADDED("payee.already.added"),
	
	/** The payee accountno invalid. */
	PAYEE_ACCOUNTNO_INVALID("payee.accountno.invalid"),
	
	/** The payee fundtransfer pending. */
	PAYEE_FUNDTRANSFER_PENDING("payee.fundtransfer.pending"),
	
	/** The payee account type invalid. */
	PAYEE_ACCOUNT_TYPE_INVALID("payee.account.type.invalid"),
	
	/** The payee ifsc code invalid. */
	PAYEE_IFSC_CODE_INVALID("payee.ifsc.code.invalid"),
	
	/** The insufficient fund. */
	INSUFFICIENT_FUND ("fundtransfer.account.insufficent.fund"), 
	
	/** The fund transfer type invalid. */
	FT_TYPE_INVALID ("fund.transfertype.invalid"), 
	
	/** The fund toaccount mandatory. */
	FT_TOACCOUNT_MANDATORY ("fundtransfer.toaccount.mandatory"), 
	
	/** The fund payeeid mandatory. */
	FT_PAYEEID_MANDATORY("fundtransfer.payeeId.mandatory"), 
	
	/** The fund transfer date invalid. */
	FT_DATE_INVALID("fundtransfer.date.invalid"),
	
	/** The payee transfer notallowed. */
	PAYEE_TRANSFER_NOTALLOWED("fundtransfer.forpayee.notallowed"), 
	
	/** The payee already confirmed. */
	PAYEE_ALREADY_CONFIRMED("payee.already.confirmed"),
	
	/** The general error. */
	GENERAL_ERROR("general.ifsc.service.error"), 
	
	/** The payee samecustomer account. */
	PAYEE_SAMECUSTOMER_ACCOUNT("payee.samecustomer.account"),
	
	/** The payee not confirmed. */
	PAYEE_NOT_CONFIRMED ("fundtransfer.payee.notconfirmed"),
	
	/** The loanconfig retrieval failed. */
	LOANCONFIG_RETRIEVAL_FAILED("loanconfig.retrieval.failed"),
	
	LOANCONFIG_EMPTY("loanconfig.empty"),

	LOANCONFIG_OVERLAPPING_SCORE_RANGE("loanconfig.score.range.overlapping"),

	LOANCONFIG_MISSING_SCORE_RANGE("loanconfig.score.range.missing"),

	LOANCONFIG_INVALID_START("loanconfig.invalid.score.start"),
	
	LOANCONFIG_INVALID_END("loanconfig.invalid.score.end"),
	
	/** The infybank unauthorized. */
	INFYBANK_UNAUTHORIZED("infybank.unauthorized"),
	
	/** The loan details not available. */
	LOAN_DETAILS_NOT_AVAILABLE("loan.details.not.available"),
	
	/** The loan status invalid. */
	LOAN_STATUS_INVALID("loan.status.invalid"),
	
	/** The account not salaried. */
	ACCOUNT_NOT_SALARIED("account.not.salaried"), 
	
	/** The loan exists. */
	LOAN_EXISTS("loan.exists"), 
	
	/** The invalid tenure. */
	INVALID_TENURE("invalid.tenure"),
	
	/** The invalid bank account. */
	INVALID_BANK_ACCOUNT("invalid.bank.account"),
	
	/** The status not valid. */
	STATUS_NOT_VALID("status.not.valid"),
	
	/** The loanprepay invalid fromaccount. */
	LOANPREPAY_INVALID_FROMACCOUNT("loanprepay.invalid.fromaccount"),
	
	/** The loanprepay invalid option. */
	LOANPREPAY_INVALID_OPTION("loanprepay.invalid.option"),
	
	LOANPREPAY_INVALID_AMOUNT("loanprepay.invalid.amount"),
	
	/** The balance lessthan minbal. */
	BALANCE_LESSTHAN_MINBAL("balance.lessthan.minbal"),
	
	/** The loanaccount invalid customer. */
	LOANACCOUNT_INVALID_CUSTOMER("loanaccount.customer.invalid"),
	
	/** The invalid loan amount. */
	INVALID_LOAN_AMOUNT("invalid.loan.amount"),
	 
 	/** The invalid interest rate. */
 	INVALID_INTEREST_RATE("invalid.interest.rate"),
	
 	/** The invalid interest rate. */
 	INTEREST_RATE_ZERO("interest.rate.zero"),
	
	/** The cannot perform transaction. */
	CANNOT_PERFORM_TRANSACTION("cannot.perform.transaction"),

	/** The otp not found. */
	OTP_NOT_FOUND("otp.not.found"),
	
	LOAN_CONFIG_DETAILS_NOT_AVAILABLE("loan.config.details.not.available"),
	
	AADHAR_SVC_FAILURE("aadhar.service.failure"),
	
	CREDITSCORE_SVC_FAILURE("credit.score.service.failure"),
	
	IFSC_SVC_FAILURE("ifsc.service.failure"),

	/** External service failed */
	EXTERNAL_SVC_FAILURE("external.service.failure"),
	
	INVALID_DATE_FIELD("invalid.date.field"),
	
	/** The server failed */
	SERVER_ERROR("server.error"), 
	
	/** The validation failed */
	INPUT_PARM_MISSING("input.parameter.missing"),
	
	/** The validation failed */
	MEDIA_TYPE_NOT_SUPPORTED("media.type.not.supported"),
	
	/** The validation failed */
	REQUESTED_OBJECT_NOT_FOUND("requested.object.not.found"),
	
	/** The http message not readable */
	MESSAGE_NOT_READABLE("message.not.readable");
	
	

	/** The type. */
	private final String type;
	
	/**
	 * Instantiates a new exception constants.
	 *
	 * @param type the type
	 */
	private ExceptionConstants(String type){
		this.type=type;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString(){
		return this.type;
	}
	
}
