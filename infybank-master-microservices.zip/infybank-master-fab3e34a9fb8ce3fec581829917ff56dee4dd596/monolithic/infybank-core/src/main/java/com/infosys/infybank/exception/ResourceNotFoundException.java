package com.infosys.infybank.exception;
 
import com.infosys.infybank.utilities.ClientErrors;

public class ResourceNotFoundException extends InfyBankException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new ResourceNotFoundException
	 *
	 * @param message
	 *            the message
	 * @param errors
	 *            the client errors
	 */
	public ResourceNotFoundException(String message, ClientErrors errors) {
		super(message, errors);
	}
	
	/**
	 * Instantiates a new ResourceNotFoundException
	 *
	 * @param message
	 *            the message
	 */
	public ResourceNotFoundException(String message) {
		super(message);
	}

}
