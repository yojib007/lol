package com.infosys.infybank.utilities;
 
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;

import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

public class DateUtil {

	private DateUtil() {
		throw new IllegalAccessError("Utility class cannot be instantiated");
	}

	/**
	 * Adds a duration to date
	 * 
	 * @param date
	 * @param field
	 * @param duration
	 * @return
	 * @throws InfyBankException
	 */
	public static Date addDuration(Date date, DateField field, long duration) throws InfyBankException {
		LocalDate ld = getLocalDate(date);
		LocalDate modifiedDate;

		switch (field) {
		case DAY:
			modifiedDate = ld.plusDays(duration);
			break;
		case SECOND:
			LocalDateTime ldt = getLocalDateTime(date).plusSeconds(duration);
			return Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
		default:
			throw new InfyBankException(ExceptionConstants.INVALID_DATE_FIELD.toString());
		}

		return Date.from(modifiedDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * Converts java.util.Date or java.sql.Date to java.time.LocalDate
	 * 
	 * @param date
	 *            input date
	 * @return local date
	 */
	public static LocalDate getLocalDate(Date date) {
		LocalDate localDate;
		if (date instanceof java.sql.Date) {
			java.sql.Date sqlDate = (java.sql.Date) date;
			localDate = sqlDate.toLocalDate();
		} else {
			localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		}
		return localDate;
	}

	/**
	 * Creates start of date from a given date
	 * 
	 * @param date
	 * @return
	 */
	public static Date getStartOfDay(Date date) {

		LocalDate localDate = getLocalDate(date);
		LocalDateTime startOfDay = LocalDateTime.of(localDate, LocalTime.MIN);
		return Date.from(startOfDay.atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * Creates end of date from a given date
	 * 
	 * @param date
	 * @return
	 */
	public static Date getEndOfDay(Date date) {
		LocalDate localDate = getLocalDate(date);
		LocalDateTime endOfDay = LocalDateTime.of(localDate, LocalTime.MAX);
		return Date.from(endOfDay.atZone(ZoneId.systemDefault()).toInstant());
	}
	
	public static LocalDateTime getLocalDateTime(Date date){
		 LocalDateTime ldt = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
		 return ldt;
	}

}
