package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


import com.fasterxml.jackson.annotation.JsonFormat;


/**
 * The Class AmortizationDTO.
 */
public class AmortizationDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The loan acct no. */
	private String loanAcctNo;
	
	/** The interest rate. */
	private BigDecimal interestRate;
	
	/** The installment no. */
	private int installmentNo;
	
	/** The installment amount. */
	private BigDecimal installmentAmount;
	
	/** The installment date. */
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date installmentDate;
	
	/** The principal component. */
	private BigDecimal principalComponent;
	
	/** The interest component. */
	private BigDecimal interestComponent;
	
	/** The opening principal. */
	private BigDecimal openingPrincipal;
	
	/** The closing principal. */
	private BigDecimal closingPrincipal;
	
	/** The payment status. */
	private char status;

	/**
	 * Gets the loan acct no.
	 *
	 * @return the loan acct no
	 */
	public String getLoanAcctNo() {
		return loanAcctNo;
	}
	
	/**
	 * Sets the loan acct no.
	 *
	 * @param loanAcctNo the new loan acct no
	 */
	public void setLoanAcctNo(String loanAcctNo) {
		this.loanAcctNo = loanAcctNo;
	}
	
	/**
	 * Gets the interest rate.
	 *
	 * @return the interest rate
	 */
	public BigDecimal getInterestRate() {
		return interestRate;
	}
	
	/**
	 * Sets the interest rate.
	 *
	 * @param interestRate the new interest rate
	 */
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	
	/**
	 * Gets the installment no.
	 *
	 * @return the installment no
	 */
	public int getInstallmentNo() {
		return installmentNo;
	}
	
	/**
	 * Sets the installment no.
	 *
	 * @param installmentNo the new installment no
	 */
	public void setInstallmentNo(int installmentNo) {
		this.installmentNo = installmentNo;
	}
	
	/**
	 * Gets the installment amount.
	 *
	 * @return the installment amount
	 */
	public BigDecimal getInstallmentAmount() {
		return installmentAmount;
	}
	
	/**
	 * Sets the installment amount.
	 *
	 * @param installmentAmount the new installment amount
	 */
	public void setInstallmentAmount(BigDecimal installmentAmount) {
		this.installmentAmount = installmentAmount;
	}
	
	/**
	 * Gets the installment date.
	 *
	 * @return the installment date
	 */
	public Date getInstallmentDate() {
		return installmentDate;
	}
	
	/**
	 * Sets the installment date.
	 *
	 * @param installmentDate the new installment date
	 */
	public void setInstallmentDate(Date installmentDate) {
		this.installmentDate = installmentDate;
	}
	
	/**
	 * Gets the principal component.
	 *
	 * @return the principal component
	 */
	public BigDecimal getPrincipalComponent() {
		return principalComponent;
	}
	
	/**
	 * Sets the principal component.
	 *
	 * @param principalComponent the new principal component
	 */
	public void setPrincipalComponent(BigDecimal principalComponent) {
		this.principalComponent = principalComponent;
	}
	
	/**
	 * Gets the interest component.
	 *
	 * @return the interest component
	 */
	public BigDecimal getInterestComponent() {
		return interestComponent;
	}
	
	/**
	 * Sets the interest component.
	 *
	 * @param interestComponent the new interest component
	 */
	public void setInterestComponent(BigDecimal interestComponent) {
		this.interestComponent = interestComponent;
	}
	
	/**
	 * Gets the opening principal.
	 *
	 * @return the opening principal
	 */
	public BigDecimal getOpeningPrincipal() {
		return openingPrincipal;
	}
	
	/**
	 * Sets the opening principal.
	 *
	 * @param openingPrincipal the new opening principal
	 */
	public void setOpeningPrincipal(BigDecimal openingPrincipal) {
		this.openingPrincipal = openingPrincipal;
	}
	
	/**
	 * Gets the closing principal.
	 *
	 * @return the closing principal
	 */
	public BigDecimal getClosingPrincipal() {
		return closingPrincipal;
	}
	
	/**
	 * Sets the closing principal.
	 *
	 * @param closingPrincipal the new closing principal
	 */
	public void setClosingPrincipal(BigDecimal closingPrincipal) {
		this.closingPrincipal = closingPrincipal;
	}
	
	/**
	 * Gets the payment status.
	 *
	 * @return the payment status
	 */
	public char getStatus() {
		return status;
	}

	/**
	 * Sets the payment status.
	 *
	 * @param payment status the new payment status
	 */
	public void setStatus(char status) {
		this.status = status;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AmortizationDTO [loanAcctNo=" + loanAcctNo + ", interestRate=" + interestRate
				+ ", installmentNo=" + installmentNo + ", installmentAmount=" + installmentAmount + ", installmentDate="
				+ installmentDate + ", principalComponent=" + principalComponent + ", interestComponent="
				+ interestComponent + ", openingPrincipal=" + openingPrincipal + ", closingPrincipal="
				+ closingPrincipal + "]";
	}	
	
	
}
