package com.infosys.infybank.core.repository;
 
import java.util.List;

import com.infosys.infybank.core.dto.SearchAccountStatementDTO;
import com.infosys.infybank.core.entity.AccountTransaction;

/**
 * The Interface AccountTransactionCustomRepository.
 */
public interface AccountTransactionCustomRepository {
	
	/**
	 * Gets the transactions.
	 *
	 * @param searchAccountStatementDTO the search account statement dto
	 * @return the transactions
	 */
	public List<AccountTransaction> getTransactions(SearchAccountStatementDTO searchAccountStatementDTO);
	
}
