package com.infosys.infybank.core.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.core.dto.AccountDTO;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class AccountController.
 */
@RestController
public class AccountController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	AccountService acctService;

	/**
	 * Open account.
	 *
	 * @param acctDTO
	 *            details of account to be opened
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/accounts", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.CREATED)
	public void openAccount(@Valid @RequestBody AccountDTO acctDTO, @PathVariable int custId)
			throws InfyBankException {
		logger.debug("Open Account request details for customer {} : {}", custId, acctDTO);
		acctDTO.setCustId(custId);
		
		// validate input data
		String emailId = acctService.validateOpenAccountInput(acctDTO);
		
		// open the account and deposit opening balance
		acctService.openAccount(acctDTO);
		
		// notify the customer
		acctService.notifyCustomer(emailId);
	}

	/**
	 * To get the Accountnumber for given custId
	 * 
	 * @param custId
	 *            the customer Id
	 * @return List from the Service method to get account number
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	// http://localhost:8082/infybank/v1/customers/101/accounts?onlyAcctNo=true
	@RequestMapping(value = "/${project.version}/customers/{custId}/accounts", params = "onlyAcctNo=true", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public List<String> getAllAccountNumbers(@PathVariable("custId") int custId) throws InfyBankException {
		logger.debug("Get All Accounts request for customer : {}", custId);
		List<String> accounts = acctService.getAccountNumbers(custId);
		logger.debug("Get All Accounts result for customer {} : {}", custId, accounts);
		return accounts;
	}

}