package com.infosys.infybank.core.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.infosys.infybank.core.entity.AccountTransaction;


/**
 * The Class AccountTransactionDTO.
 */
public class AccountTransactionDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The txn id. */
	private int txnId;
	
	/** The cust id. */
	private int custId;
	
	/** The acct no. */
	private String acctNo;
	
	/** The txn date. */
	private Date txnDate;
	
	/** The txn typ. */
	private char txnTyp;
	
	/** The txn amount. */
	private BigDecimal txnAmount;
	
	/** The opening bal. */
	private BigDecimal openingBal;
	
	/** The closing bal. */
	private BigDecimal closingBal;
	
	/** The txn category. */
	private char txnCategory;
	
	/** The remarks. */
	private String remarks;
	
	/** The ref id. */
	private String refId;
	
	/** The lst updt ts. */
	private Date lstUpdtTs;
	
	/** The lst updt id. */
	private String lstUpdtId;
	
	/**
	 * Gets the txn id.
	 *
	 * @return the txn id
	 */
	public int getTxnId() {
		return txnId;
	}
	
	/**
	 * Sets the txn id.
	 *
	 * @param txnId the new txn id
	 */
	public void setTxnId(int txnId) {
		this.txnId = txnId;
	}
	
	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}
	
	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}
	
	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return acctNo;
	}
	
	/**
	 * Sets the acct no.
	 *
	 * @param acctNo the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	
	/**
	 * Gets the txn date.
	 *
	 * @return the txn date
	 */
	public Date getTxnDate() {
		return txnDate;
	}
	
	/**
	 * Sets the txn date.
	 *
	 * @param txnDate the new txn date
	 */
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}
	
	/**
	 * Gets the txn typ.
	 *
	 * @return the txn typ
	 */
	public char getTxnTyp() {
		return txnTyp;
	}
	
	/**
	 * Sets the txn typ.
	 *
	 * @param txnTyp the new txn typ
	 */
	public void setTxnTyp(char txnTyp) {
		this.txnTyp = txnTyp;
	}
	
	/**
	 * Gets the txn amount.
	 *
	 * @return the txn amount
	 */
	public BigDecimal getTxnAmount() {
		return txnAmount;
	}
	
	/**
	 * Sets the txn amount.
	 *
	 * @param txnAmount the new txn amount
	 */
	public void setTxnAmount(BigDecimal txnAmount) {
		this.txnAmount = txnAmount;
	}
	
	/**
	 * Gets the opening bal.
	 *
	 * @return the opening bal
	 */
	public BigDecimal getOpeningBal() {
		return openingBal;
	}
	
	/**
	 * Sets the opening bal.
	 *
	 * @param openingBal the new opening bal
	 */
	public void setOpeningBal(BigDecimal openingBal) {
		this.openingBal = openingBal;
	}
	
	/**
	 * Gets the closing bal.
	 *
	 * @return the closing bal
	 */
	public BigDecimal getClosingBal() {
		return closingBal;
	}
	
	/**
	 * Sets the closing bal.
	 *
	 * @param closingBal the new closing bal
	 */
	public void setClosingBal(BigDecimal closingBal) {
		this.closingBal = closingBal;
	}
	
	/**
	 * Gets the txn category.
	 *
	 * @return the txn category
	 */
	public char getTxnCategory() {
		return txnCategory;
	}
	
	/**
	 * Sets the txn category.
	 *
	 * @param txnCategory the new txn category
	 */
	public void setTxnCategory(char txnCategory) {
		this.txnCategory = txnCategory;
	}
	
	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	
	/**
	 * Sets the remarks.
	 *
	 * @param remarks the new remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	/**
	 * Gets the ref id.
	 *
	 * @return the ref id
	 */
	public String getRefId() {
		return refId;
	}
	
	/**
	 * Sets the ref id.
	 *
	 * @param refId the new ref id
	 */
	public void setRefId(String refId) {
		this.refId = refId;
	}
	
	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return lstUpdtTs;
	}
	
	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}
	
	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return lstUpdtId;
	}
	
	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}
	
	/**
	 * Prepare transaction entity.
	 *
	 * @param acctTxnDTO the obj
	 * @return the account transaction
	 */
	public static AccountTransaction prepareEntity(AccountTransactionDTO acctTxnDTO){
		AccountTransaction transaction=new AccountTransaction();
		transaction.setAcctNo(acctTxnDTO.getAcctNo());
		transaction.setCustId(acctTxnDTO.getCustId());
		transaction.setTxnTyp(acctTxnDTO.getTxnCategory());
		transaction.setTxnAmount(acctTxnDTO.getTxnAmount());
		transaction.setOpeningBal( BigDecimal.valueOf(0.0));
		transaction.setClosingBal(acctTxnDTO.getTxnAmount());
		char category = AccountTransactionCategory.CASH_BALANCE.toString().charAt(0);
		transaction.setTxnCategory(category);
		transaction.setRemarks("Account Opening");
		transaction.setLstUpdtId(acctTxnDTO.getLstUpdtId());
		return transaction;
	}
	
	/**
	 * Prepare transaction entity.
	 *
	 * @param custId the cust id
	 * @param accNo the acc no
	 * @param amount the amount
	 * @param accType the acc type
	 * @param userId the user id
	 * @return the account transaction
	 */
	public static AccountTransaction prepareEntity(int custId, String accNo, BigDecimal amount, String userId){
		AccountTransaction transaction=new AccountTransaction();
		transaction.setAcctNo(accNo);
		transaction.setCustId(custId);
		transaction.setTxnTyp(AccountTransactionType.CREDIT.toString().charAt(0));
		transaction.setTxnAmount(amount);
		transaction.setOpeningBal(BigDecimal.valueOf(0.0));
		transaction.setClosingBal(amount);
		char category = AccountTransactionCategory.CASH_BALANCE.toString().charAt(0);
		transaction.setTxnCategory(category);
		transaction.setRemarks("Account Opening");
		transaction.setLstUpdtId(userId);
		return transaction;
	}
	
	public static AccountTransactionDTO prepareDTO(AccountTransaction transaction) {
		AccountTransactionDTO txnDTO = new AccountTransactionDTO();
		txnDTO.setTxnDate(transaction.getTxnDate());
		txnDTO.setRemarks(transaction.getRemarks());
		txnDTO.setTxnAmount(transaction.getTxnAmount());
		return txnDTO;
	}

	@Override
	public String toString() {
		return "AccountTransactionDTO [txnId=" + txnId + ", custId=" + custId + ", acctNo=" + acctNo + ", txnDate="
				+ txnDate + ", txnTyp=" + txnTyp + ", txnAmount=" + txnAmount + ", openingBal=" + openingBal
				+ ", closingBal=" + closingBal + ", txnCategory=" + txnCategory + ", remarks=" + remarks + ", refId="
				+ refId + ", lstUpdtTs=" + lstUpdtTs + ", lstUpdtId=" + lstUpdtId + "]";
	}
}
