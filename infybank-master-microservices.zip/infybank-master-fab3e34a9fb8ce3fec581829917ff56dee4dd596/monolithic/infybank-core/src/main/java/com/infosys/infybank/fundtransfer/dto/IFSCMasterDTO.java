package com.infosys.infybank.fundtransfer.dto;
 
import java.io.Serializable;

/**
 * The Class IFSCMasterDTO.
 */
public class IFSCMasterDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The ifsc code. */
	private String ifscCode;
	
	/** The bank name. */
	private String bankName;
	
	/** The branch name. */
	private String branchName;

	/**
	 * Gets the ifsc code.
	 *
	 * @return the ifsc code
	 */
	public String getIfscCode() {
		return this.ifscCode;
	}

	/**
	 * Sets the ifsc code.
	 *
	 * @param ifscCode the new ifsc code
	 */
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	/**
	 * Gets the bank name.
	 *
	 * @return the bank name
	 */
	public String getBankName() {
		return this.bankName;
	}

	/**
	 * Sets the bank name.
	 *
	 * @param bankName the new bank name
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * Gets the branch name.
	 *
	 * @return the branch name
	 */
	public String getBranchName() {
		return this.branchName;
	}

	/**
	 * Sets the branch name.
	 *
	 * @param branchName the new branch name
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IFSCMasterDTO [ifscCode=" + ifscCode + ", bankName=" + bankName + ", branchName=" + branchName + "]";
	}
}
