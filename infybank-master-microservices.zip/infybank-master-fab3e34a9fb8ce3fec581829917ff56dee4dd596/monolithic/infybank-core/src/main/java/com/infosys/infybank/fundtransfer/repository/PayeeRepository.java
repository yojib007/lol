/**
 * 
 */
package com.infosys.infybank.fundtransfer.repository;
 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.fundtransfer.entity.Payee;

/**
 * The Interface PayeeRepository.
 *
 * @author kumar.pallav
 */
@Repository
public interface PayeeRepository extends JpaRepository<Payee, Integer> {

	/**
	 * Find payee by acct number.
	 *
	 * @param acctNo the acct no
	 * @param custId the cust id
	 * @return the payee
	 */
	@Query(value = "select * from payee where acct_No=:acctNo and cust_Id=:custId and status in ('C','S')", nativeQuery = true)
	public Payee findPayeeByAcctNumber(@Param("acctNo") String acctNo, @Param("custId") int custId);

	/**
	 * Gets the all payee for customer.
	 *
	 * @param custId the cust id
	 * @return the all payee for customer
	 */
	@Query(value = "select * from payee where cust_id=:custId and status = :status", nativeQuery = true)
	public List<Payee> getConfirmedPayees(@Param("custId") int custId, @Param("status") char status);

	/**
	 * Gets the payee for customer.
	 *
	 * @param custId the cust id
	 * @param payeeId the payee id
	 * @return the payee for customer
	 */
	@Query(value = "select * from payee where cust_id=:custId and payee_id = :payeeId and status in ('C','S')", nativeQuery = true)
	public Payee getPayeeForCustomer(@Param("custId") int custId, @Param("payeeId") int payeeId);

	/**
	 * Update payee status.
	 *
	 * @param custId the cust id
	 * @param payeeId the payee id
	 * @param status the status
	 * @return the int
	 */
	@Modifying
	@Query(value = "update payee set status=:status where cust_Id=:custId and payee_id=:payeeId", nativeQuery = true)
	public int updatePayeeStatus(@Param("custId") int custId, @Param("payeeId") int payeeId,
			@Param("status") char status);

}
