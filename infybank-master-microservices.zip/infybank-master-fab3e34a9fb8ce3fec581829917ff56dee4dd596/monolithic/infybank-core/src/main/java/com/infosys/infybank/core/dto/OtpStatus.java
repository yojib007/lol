package com.infosys.infybank.core.dto;
 
/**
 * OtpType.java - enum to represent the type of OTP
 * 
 * 
 */
public enum OtpStatus {

	/** Valid */
	VALID, 
	
	/** Invalid */
	INVALID, 
	
	/** Expired */
	EXPIRED;

}
