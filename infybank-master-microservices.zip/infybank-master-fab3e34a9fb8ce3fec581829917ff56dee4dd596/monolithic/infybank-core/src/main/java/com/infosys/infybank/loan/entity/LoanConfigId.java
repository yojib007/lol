package com.infosys.infybank.loan.entity;
 
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 * The Class LoanConfigId.
 */
@Embeddable
public class LoanConfigId implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The credit score start. */
	@Column(name = "CREDIT_SCORE_START", nullable = false)
	private int creditScoreStart;

	/** The credit score end. */
	@Column(name = "CREDIT_SCORE_END", nullable = false)
	private int creditScoreEnd;

	/**
	 * Gets the credit score start.
	 *
	 * @return the credit score start
	 */
	public int getCreditScoreStart() {
		return this.creditScoreStart;
	}

	/**
	 * Sets the credit score start.
	 *
	 * @param creditScoreStart
	 *            the new credit score start
	 */
	public void setCreditScoreStart(int creditScoreStart) {
		this.creditScoreStart = creditScoreStart;
	}

	/**
	 * Gets the credit score end.
	 *
	 * @return the credit score end
	 */
	public int getCreditScoreEnd() {
		return this.creditScoreEnd;
	}

	/**
	 * Sets the credit score end.
	 *
	 * @param creditScoreEnd
	 *            the new credit score end
	 */
	public void setCreditScoreEnd(int creditScoreEnd) {
		this.creditScoreEnd = creditScoreEnd;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		if (other == null)
			return false;
		if (!(other instanceof LoanConfigId))
			return false;
		LoanConfigId castOther = (LoanConfigId) other;

		return (this.getCreditScoreStart() == castOther.getCreditScoreStart())
				&& (this.getCreditScoreEnd() == castOther.getCreditScoreEnd());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		int result = 17;

		result = 37 * result + this.getCreditScoreStart();
		result = 37 * result + this.getCreditScoreEnd();
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LoanConfigId [creditScoreStart=" + creditScoreStart + ", creditScoreEnd=" + creditScoreEnd + "]";
	}
}
