package com.infosys.infybank.core.dto;
 
import java.io.Serializable;

import com.infosys.infybank.core.entity.Login;

/**
 * The Class UserDTO.
 */
public class UserDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	private int custId;

	/** The user id. */
	private String userId;

	/** The role. */
	private char role;

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId
	 *            the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the role.
	 *
	 * @return the role
	 */
	public char getRole() {
		return role;
	}

	/**
	 * Sets the role.
	 *
	 * @param role
	 *            the new role
	 */
	public void setRole(char role) {
		this.role = role;
	}

	/**
	 * Prepare DTO.
	 *
	 * @param loginEntity
	 *            the login entity
	 * @return the user DTO
	 */
	public static UserDTO prepareDTO(Login loginEntity) {
		UserDTO loginDTO = new UserDTO();
		loginDTO.setCustId(loginEntity.getCustId());
		loginDTO.setRole(loginEntity.getRole());
		loginDTO.setUserId(loginEntity.getUserId());
		return loginDTO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserDTO [custId=" + custId + ", userId=" + userId + ", role=" + role + "]";
	}

}
