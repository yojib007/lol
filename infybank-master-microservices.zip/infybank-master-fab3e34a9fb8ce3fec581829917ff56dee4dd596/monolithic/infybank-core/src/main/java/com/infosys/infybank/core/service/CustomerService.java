package com.infosys.infybank.core.service;
 
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.AadharDTO;
import com.infosys.infybank.core.dto.AccountDTO;
import com.infosys.infybank.core.dto.CustomerDTO;
import com.infosys.infybank.core.dto.Email;
import com.infosys.infybank.core.dto.NewCustomerDTO;
import com.infosys.infybank.core.dto.OtpStatus;
import com.infosys.infybank.core.dto.OtpType;
import com.infosys.infybank.core.dto.RegistrationDTO;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.entity.Otp;
import com.infosys.infybank.core.repository.CustomerRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.utilities.ClientErrors;
import com.infosys.infybank.utilities.UserUtil;

/**
 * RegistrationController.java - controller class to handle Http Requests
 * 
 * @author ETA Java
 * @version 1.0
 */

@Service
public class CustomerService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The Configuration Bean */
	@Autowired
	ApplicationProperties appProps;

	/** The rest template. */
	@Autowired
	RestTemplate restTemplate;

	/** The customer repository. */
	@Autowired
	CustomerRepository custRepo;

	@Autowired
	NotificationService notificationService;

	/** The otp service. */
	@Autowired
	OTPService otpService;

	/** The account service. */
	@Autowired
	AccountService acctService;

	/** The login service. */
	@Autowired
	LoginService loginService;

	@Autowired
	RandomPasswordGeneratorService pswdService;

	/**
	 * Generate OTP.
	 *
	 * @param custDTO
	 *            the obj
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public void generateOTP(NewCustomerDTO custDTO) throws InfyBankException {

		verifyEmailAndAadhar(custDTO.getAadharId(), custDTO.getEmailId(), custDTO.getFirstName(),
				custDTO.getLastName());

		// if aadhar is valid then generate and save an otp
		Otp otp = otpService.saveOTPForCustomer(custDTO.getCustId(), custDTO.getEmailId(), OtpType.ACCOUNT_OPEN, 0);
		if (otp == null) {
			throw new InfyBankException(ExceptionConstants.CUSTOMER_OTP_GENERATION_FAILED.toString());
		}

		// send an email to customer with generated otp
		notifyCustomer(custDTO.getEmailId(), otp.getOtp(), otp.getGeneratedTs());

	}

	/**
	 * creates and populates an email instance and invokes the notifyCustomer
	 * method from NotificationService
	 * 
	 * @param emailId
	 *            the emailId of the customer
	 * @param otp
	 *            the generated otp String
	 * @param generatedTs
	 *            the timestamp when the otp String was generated
	 * @return void
	 */
	public void notifyCustomer(String emailId, String otp, Date generatedTs) {
		Email email = new Email();
		email.setToEmail(emailId);

		email.setSubject("OTP confirmation alert for your InfyBank Registration ");
		String message = java.text.MessageFormat.format(
				"Dear Customer,\n \t    Thank you for registering with InfyBank. Please use {0} as"
						+ " as One Time Password (OTP) to complete your registration process. This OTP was generated on {1} and expires in 5 minutes."
						+ "\n Looking forward to more opportunities to be of service to you. \n\n Sincerely,\n InfyBank Customer Care",
				otp, generatedTs);

		email.setEmailMessage(message);

		notificationService.notifyCustomer(email);
	}

	/**
	 * creates and populates an email instance and invokes the notifyCustomer
	 * method from NotificationService
	 * 
	 * @param emailId
	 *            the emailId of the customer
	 * @param login
	 *            the Login details of the customer
	 * @param password
	 *            the password of the customer's account
	 * @return void
	 */
	public void notifyCustomer(String emailId, String userId, String password) {
		Email email = new Email();
		email.setToEmail(emailId);

		email.setSubject("Confirmation alert for your InfyBank Registration");

		String message = java.text.MessageFormat
				.format("Dear Customer, \n \t Thank you for opening an account with InfyBank. Your internet banking user id and password has been generated. "
						+ "\n\n\t userId: {0} \n\t password: {1} \n\n Your transaction alert threshold has been set to {2}."
						+ "\n\n Sincerely,\n InfyBank Customer Care", userId, password, appProps.getCreditLimit());

		email.setEmailMessage(message);

		notificationService.notifyCustomer(email);
	}

	/**
	 * Verify OTP.
	 *
	 * @param otp
	 *            the otp
	 * @param email
	 *            the email
	 * @param otpType
	 *            the otp type
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public boolean verifyOTP(String otp, String email, OtpType otpType) throws InfyBankException {

		OtpStatus status = otpService.isOTPValid(otp, email, otpType);
		switch (status) {
		case VALID:
			return true;
		case INVALID:
			throw new InfyBankException(ExceptionConstants.CUSTOMER_INVALID_OTP.toString());
		case EXPIRED:
			throw new InfyBankException(ExceptionConstants.CUSTOMER_OTP_EXPIRED.toString());
		}
		return false;

	}

	/**
	 * Create customer and account
	 *
	 * @param dto
	 *            the obj
	 * @param password
	 *            the password
	 * @return true, if successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public Login createCustomerAndAccount(RegistrationDTO dto, String password) throws InfyBankException {

		// Account type must be valid
		acctService.verifyAcctType(dto.getAcctType());

		// Create customer entity and populate default values
		Customer customer = CustomerDTO.prepareEntity(dto);
		customer.setCrDbNotifLimit(appProps.getCreditLimit());
		customer.setDatePref(appProps.getDatePref());
		customer.setAmountPref(appProps.getAmountPref());

		// create the user id and password
		Login login = createLoginDetails(dto.getFirstName(), dto.getLastName(), password);
		customer.setLstUpdtId(login.getUserId());

		// create the customer in database
		customer = custRepo.saveAndFlush(customer);
		if (customer.getCustId() <= 0) {
			logger.error("Customer record could not be created in database");
			throw new InfyBankException(ExceptionConstants.SERVER_ERROR.toString());
		}

		// store login credentials for the customer
		login.setCustId(customer.getCustId());
		login = loginService.saveLoginDetails(login);
		if (login == null) {
			logger.error("Login detail could not be created in database");
			throw new InfyBankException(ExceptionConstants.SERVER_ERROR.toString());
		}

		// create bank account for the customer
		AccountDTO acctDTO = new AccountDTO();
		acctDTO.setCustId(customer.getCustId());
		acctDTO.setBalance(dto.getBalance());
		acctDTO.setAcctType(dto.getAcctType());
		acctDTO.setUserId(login.getUserId());
		acctDTO.setSalaried(dto.getSalaried());
		acctService.openAccount(acctDTO);

		return login;

	}

	/**
	 * Verifies Email and Aadhar Id.
	 *
	 * @param aadharId
	 *            the Aadhar Id
	 * @param emailId
	 *            the email id
	 */
	public void verifyEmailAndAadhar(String aadharId, String emailId, String firstName, String lastName)
			throws InfyBankException {
		// If another customer is already registered with the same aadhar
		// id/email id then reject the request
		if (custRepo.findByAadharId(aadharId) != null)
			throw new InfyBankException(ExceptionConstants.CUSTOMER_ALREADY_REGISTERED_WITH_AADHAR.toString());
		else if (custRepo.findByEmailId(emailId) != null)
			throw new InfyBankException(ExceptionConstants.CUSTOMER_ALREADY_REGISTERED_WITH_EMAIL.toString());

		// Authenticate that the Aadhar Id really belongs to this customer
		Boolean aadharValid = authenticateAadhar(aadharId, firstName, lastName);
		if (!aadharValid)
			throw new InfyBankException(ExceptionConstants.CUSTOMER_NOT_MAPPED_TO_AADHAR.toString());

	}

	/**
	 * Perform KYC authentication.
	 *
	 * @param obj
	 *            the obj
	 * @return true, if successful
	 */
	private Boolean authenticateAadhar(String aadharId, String firstName, String lastName) throws InfyBankException {

		// Get Url for Aadhar Service
		String url = appProps.getAadharUrl();
		logger.debug("External URL for aadhar {}", url);

		// Add query parameter
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url).queryParam("aadharId", aadharId)
				.queryParam("firstName", firstName).queryParam("lastName", lastName);
		String urlWithParam = builder.toUriString();
		logger.debug("URL with parameters {}", urlWithParam);

		ClientErrors errors;
		ResponseEntity<AadharDTO> response;
		// Invoke external service to validate Aadhar
		try {
			response = restTemplate.getForEntity(urlWithParam, AadharDTO.class);
			Boolean result = response.getBody().isAadharValid();
			logger.debug("Return value from external aadhar {}", result);
			return result;
		} catch (HttpClientErrorException ex) {
			// if there is client error then parse the error json to extract
			// specific error messages
			logger.error("Exception while invoking aadhar service", ex);

			try {
				errors = new ObjectMapper().readValue(ex.getResponseBodyAsString(), ClientErrors.class);
				logger.debug("Error from Aadhar Service {}", errors);
			} catch (Exception e) {
				logger.debug("Unable to parse error from Aadhar Service");
				logger.debug(e.getMessage(), e);
				throw new InfyBankException(ExceptionConstants.AADHAR_SVC_FAILURE.toString());
			}
			throw new InfyBankException(ExceptionConstants.EXTERNAL_SVC_FAILURE.toString(), errors);
		}
	}

	/**
	 * Creates the user profile.
	 *
	 * @param firstName
	 *            the first name
	 * @param lastName
	 *            the last name
	 * @return the login
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public Login createLoginDetails(String firstName, String lastName, String password) throws InfyBankException {

		String userIdSuggestion = UserUtil.createUserIdFromName(firstName, lastName);
		List<String> userList = loginService.getUserIdsStartingWithName(userIdSuggestion);
		if (userList != null && !userList.isEmpty())
			userIdSuggestion = UserUtil.createUserId(userList, userIdSuggestion);
		String securePassword = pswdService.encryptPassword(password);

		return new Login(0, userIdSuggestion, securePassword, 'C', userIdSuggestion);
	}

	/**
	 * View Customer profile for a given Customer Id.
	 *
	 * @param custId
	 *            - the customer id
	 * @return Customer object
	 * @throws InfyBankException
	 *             if customer does not exist
	 */
	public CustomerDTO viewCustomerProfile(int custId) throws InfyBankException {
		return CustomerDTO.valueOf(getCustomerDetails(custId));
	}

	/**
	 * Fetch details for a given customer
	 *
	 * @param custId
	 *            - the customer id
	 * @return Customer object
	 * @throws InfyBankException
	 *             if customer does not exist
	 */
	public Customer getCustomerDetails(int custId) throws InfyBankException {
		Customer customer = custRepo.findOne(custId);
		if (customer != null)
			return customer;
		else
			throw new ResourceNotFoundException(ExceptionConstants.CUSTOMER_ID_INVALID.toString());
	}

	/**
	 * Method for updating Customer Details.
	 *
	 * @param customerDTO
	 *            the customer dto
	 * @param custId
	 *            the cust id
	 * @return true- if update successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public void updateCustomerProfile(CustomerDTO customerDTO) throws InfyBankException {
		Customer customer = getCustomerDetails(customerDTO.getCustId());
		CustomerDTO.updateEntity(customer, customerDTO);
		custRepo.saveAndFlush(customer);
	}

	// for loan prepay

	/**
	 * Gets the email idfor customer.
	 *
	 * @param custId
	 *            the cust id
	 * @return the email idfor customer
	 */
	public String getEmailIdforCustomer(int custId) {
		Customer customer = custRepo.findOne(custId);
		String emailId = null;
		if (customer != null) {
			emailId = customer.getEmailId();
		}
		return emailId;
	}

}
