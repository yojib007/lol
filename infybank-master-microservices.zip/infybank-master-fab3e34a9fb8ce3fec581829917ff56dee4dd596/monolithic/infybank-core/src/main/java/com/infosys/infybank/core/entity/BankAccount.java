package com.infosys.infybank.core.entity;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;


/**
 * The Class BankAccount.
 */
@Entity
@Table(name = "BANK_ACCOUNT")
public class BankAccount implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The bank account id. */
	@EmbeddedId
	private BankAccountId bankAccountId;

	/** The acct type. */
	@Column(name = "ACCT_TYPE", nullable = false, length = 1)
	private char acctType;

	/** The balance. */
	@Column(name = "BALANCE", nullable = false, precision = 12, scale = 4)
	private BigDecimal balance;

	/** The salaried. */
	@Column(name = "SALARIED", nullable = false, length = 1)
	private char salaried;

	/** The lst updt ts. */
	@Temporal(TemporalType.TIMESTAMP)
	@Generated(GenerationTime.ALWAYS)
	@Column(name = "LST_UPDT_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lstUpdtTs;

	/** The lst updt id. */
	@Column(name = "LST_UPDT_ID", nullable = false, length = 10)
	private String lstUpdtId;

	
	/**
	 * Gets the acct type.
	 *
	 * @return the acct type
	 */
	public char getAcctType() {
		return this.acctType;
	}

	/**
	 * Sets the acct type.
	 *
	 * @param acctType
	 *            the new acct type
	 */
	public void setAcctType(char acctType) {
		this.acctType = acctType;
	}

	/**
	 * Gets the balance.
	 *
	 * @return the balance
	 */
	public BigDecimal getBalance() {
		return this.balance;
	}

	/**
	 * Sets the balance.
	 *
	 * @param balance
	 *            the new balance
	 */
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	/**
	 * Gets the salaried.
	 *
	 * @return the salaried
	 */
	public char getSalaried() {
		return this.salaried;
	}

	/**
	 * Gets the bank account id.
	 *
	 * @return the bank account id
	 */
	public BankAccountId getBankAccountId() {
		return bankAccountId;
	}

	/**
	 * Sets the bank account id.
	 *
	 * @param bankAccountId
	 *            the new bank account id
	 */
	public void setBankAccountId(BankAccountId bankAccountId) {
		this.bankAccountId = bankAccountId;
	}

	/**
	 * Sets the salaried.
	 *
	 * @param salaried
	 *            the new salaried
	 */
	public void setSalaried(char salaried) {
		this.salaried = salaried;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return this.lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return this.lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BankAccount [custId=" + bankAccountId.getCustId() + ", acctNo=" + bankAccountId.getAcctNo()
				+ ", acctType=" + acctType + ", balance=" + balance + ", salaried=" + salaried + ", lstUpdtTs="
				+ lstUpdtTs + ", lstUpdtId=" + lstUpdtId + "]";
	}

}
