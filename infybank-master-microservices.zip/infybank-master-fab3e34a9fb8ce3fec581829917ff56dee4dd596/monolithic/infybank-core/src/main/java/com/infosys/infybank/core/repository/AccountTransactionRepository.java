/**
 * 
 */
package com.infosys.infybank.core.repository;
 
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.entity.AccountTransaction;

/**
 * The Interface AccountTransactionRepository.
 */
@Repository
public interface AccountTransactionRepository
		extends JpaRepository<AccountTransaction, Integer>, AccountTransactionCustomRepository {

	/**
	 * Gets the salary credit.
	 *
	 * @param custId the cust id
	 * @param acctNo the acct no
	 * @param txnType the txn type
	 * @param txnCategory the txn category
	 * @return the salary credit
	 */
	@Query(value = "select a from AccountTransaction a where a.custId=:custId and a.acctNo=:acctNo "
			+ "and a.txnType=:txnType and a.txnCategory=:txnCategory order by a.txnDate")
	public List<AccountTransaction> getSalaryCredit(@Param("custId") int custId, @Param("acctNo") String acctNo, 
			@Param("txnType") char txnType, @Param("txnCategory") char txnCategory);
	
	/**
	 * Find txn date by custid.
	 *
	 * @param loanAcctNo the loan acct no
	 * @param custId the cust id
	 * @return the list
	 */
	@Query(value ="select a from AccountTransaction a where a.custId=:custId and a.refId=:loanAcctNo and a.txnCategory='N' order by a.txnDate desc")
	public List<AccountTransaction> findTxnDateByCustid(@Param("loanAcctNo") String loanAcctNo,@Param("custId") int custId);

	/**
	 * Gets the salary credits for the last N days.
	 *
	 * @param custId
	 *            the cust id
	 * @param acctNo
	 *            the acct no
	 * @param txnType
	 *            the txn type
	 * @param txnCategory
	 *            the txn category
	 * @param lastNthDate           
	 *            the lastNthDate
	 * @return the last N salary credits
	 */
	@Query("select a from AccountTransaction a where a.custId=:custId and a.acctNo=:acctNo "
			+ "and a.txnType=:txnType and a.txnCategory=:txnCategory and a.txnDate>=:lastNthDate order by a.txnDate desc")
	public List<AccountTransaction> getSalaryCreditForNDays(@Param("custId") int custId, @Param("acctNo") String acctNo, 
			@Param("txnType") char txnType, @Param("txnCategory") char txnCategory,
			@Param("lastNthDate") Date lastNthDate);

}
