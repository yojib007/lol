package com.infosys.infybank.core.service;
 
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.infybank.core.dto.AccountConfigEditDTO;
import com.infosys.infybank.core.dto.AccountConfigViewDTO;
import com.infosys.infybank.core.entity.AccountConfig;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.repository.AccountConfigRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class AccountConfigService.
 */
@Service
public class AccountConfigService {

	/** The Constant ADMIN_ROLE. */
	public static final char ADMIN_ROLE = 'A';

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The account config repository. */
	@Autowired
	AccountConfigRepository acctConfigRepo;

	/** The login service. */
	@Autowired
	private LoginService loginService;

	/**
	 * View account configuration.
	 *
	 * @return list of account config DTOs
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public List<AccountConfigViewDTO> viewAccountConfig() throws InfyBankException {
		List<AccountConfig> acctConfig = acctConfigRepo.findAll();
		logger.debug("AccountConfig Entity objects from db : {}", acctConfig);
		if (acctConfig == null || acctConfig.isEmpty()) {
			logger.warn("AccountConfig table not setup in database");
			throw new InfyBankException(ExceptionConstants.SERVER_ERROR.toString());
		} else {
			logger.info("AccountConfig entity objects retrieved successfully");
			List<AccountConfigViewDTO> acctConfigDTOs = new ArrayList<AccountConfigViewDTO>();
			for (AccountConfig acc : acctConfig) {
				acctConfigDTOs.add(AccountConfigViewDTO.valueOf(acc));
			}
			logger.debug("AccountConfigDTO objects : {}", acctConfigDTOs);
			return acctConfigDTOs;
		}
	}

	/**
	 * Updates AccountConfig.
	 *
	 * @param acctConfigEditDTO
	 *            the account config edit dto
	 * @return true- if updated is successful
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public void updateAccountConfig(AccountConfigEditDTO acctConfigEditDTO) throws InfyBankException {
		String userId = acctConfigEditDTO.getLstUpdtId();
		Login login = loginService.getLoginDetails(userId);
		logger.debug("Login details for user from db : {}", login);
		// perform edit if role is admin
		if (login != null && login.getRole() == ADMIN_ROLE) {
			List<AccountConfig> acctConfigs = AccountConfigEditDTO.preapreEntityList(acctConfigEditDTO);
			logger.debug("AccountConfigs for save : {}", acctConfigs);
			for (AccountConfig acctConfig : acctConfigs) {
				acctConfigRepo.save(acctConfig);
			}
			acctConfigRepo.flush();
		} else {
			throw new InfyBankException(ExceptionConstants.INFYBANK_UNAUTHORIZED.toString());
		}
	}

	/**
	 * Gets the minimum balance.
	 *
	 * @param accType
	 *            the acc type
	 * @return the minimum balance
	 */
	public BigDecimal getMinimumBalance(char accType) throws InfyBankException {
		AccountConfig acctConfig = acctConfigRepo.findByAcctType(accType);
		if (acctConfig == null) {
			logger.error("Minimum balance is not setup on Account Config table");
			throw new InfyBankException(ExceptionConstants.SERVER_ERROR.toString());
		}
		return acctConfig.getMinBalance();
	}

	// for loan prepay

	/**
	 * Gets the account config details.
	 *
	 * @param bankAccount
	 *            the bank account
	 * @return the account config details
	 */
	public AccountConfig getAccountConfigDetails(BankAccount bankAccount) {

		return acctConfigRepo.findOne(bankAccount.getAcctType());
	}

}
