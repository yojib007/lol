package com.infosys.infybank.core.service;
 
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.AccountDTO;
import com.infosys.infybank.core.dto.AccountTransactionCategory;
import com.infosys.infybank.core.dto.AccountTransactionDTO;
import com.infosys.infybank.core.dto.AccountTransactionType;
import com.infosys.infybank.core.dto.AccountType;
import com.infosys.infybank.core.dto.Email;
import com.infosys.infybank.core.entity.AccountSequence;
import com.infosys.infybank.core.entity.AccountTransaction;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.BankAccountId;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.repository.AccountRepository;
import com.infosys.infybank.core.repository.AccountSequenceRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;

/**
 * The Class AccountService.
 */
@Service
public class AccountService {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The account repository. */
	@Autowired
	AccountRepository acctRepo;

	/** The account sequence repository. */
	@Autowired
	AccountSequenceRepository acctSeqRepo;

	/** The account config repository. */
	@Autowired
	AccountConfigService acctConfigService;

	/** The transaction service. */
	@Autowired
	AccountTransactionService acctTxnService;

	/** The customer repository. */
	@Autowired
	CustomerService custService;

	/** The login service. */
	@Autowired
	LoginService loginService;

	/** The notification service. */
	@Autowired
	NotificationService notificationService;

	/** The Configuration Bean */
	@Autowired
	ApplicationProperties appProps;

	/**
	 * Checks if is account salaried.
	 *
	 * @param custId
	 *            the cust id
	 * @param acctNo
	 *            the acct no
	 * @return true, if is account salaried
	 * @throws InfyBankException
	 */
	public boolean isAccountSalaried(int custId, String acctNo) throws InfyBankException {

		BankAccount bankAccount = acctRepo.findOne(new BankAccountId(custId, acctNo));
		if (bankAccount == null) {
			throw new ResourceNotFoundException(ExceptionConstants.INVALID_BANK_ACCOUNT.toString());
		}
		return (bankAccount.getSalaried() == 'N') ? false : true;

	}

	/**
	 * check whether given custId and account number exists in bank account.
	 *
	 * @param custId
	 *            the cust id
	 * @param acctNo
	 *            the acct no
	 * @return the boolean value
	 */

	public Boolean isBankAccountValid(int custId, String acctNo) {

		BankAccountId bankAccountId = new BankAccountId(custId, acctNo);
		return acctRepo.exists(bankAccountId);
	}

	/**
	 * Gets the max account no value.
	 *
	 * @return the max account no value
	 */
	private AccountSequence getMaxAccountNoValue() {
		List<AccountSequence> acctSequences = acctSeqRepo.findAll();
		AccountSequence sequence = acctSequences.get(0);
		if (sequence == null) {
			int propValue = appProps.getAcctStartDefVal();
			logger.info("propValue {}", propValue);

			Integer startAcctNo = Integer.valueOf(propValue);
			logger.info("startAcctNo {}", startAcctNo);
			sequence = new AccountSequence(startAcctNo);
			sequence = acctSeqRepo.saveAndFlush(sequence);
			logger.info("Sequence created {}", sequence);

		}
		return sequence;
	}

	/**
	 * Validates data for Open account request
	 *
	 * @param acctDTO
	 *            the obj
	 * @return email id of the customer
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	public String validateOpenAccountInput(AccountDTO acctDTO) throws InfyBankException {

		// check if custId is valid
		Customer cust = custService.getCustomerDetails(acctDTO.getCustId());

		// check if userId is valid for customer
		Login login = loginService.getLoginDetails(acctDTO.getUserId());
		if (login == null) {
			throw new ResourceNotFoundException(ExceptionConstants.USERID_INVALID.toString());
		}

		// check if customer is already salaried if new account is salaried
		if (acctDTO.getSalaried() == 'Y'
				&& acctRepo.findByBankAccountIdCustIdAndSalaried(acctDTO.getCustId(), 'Y') != null) {
			throw new InfyBankException(ExceptionConstants.CUSTOMER_IS_ALREADY_SALARIED.toString());
		}

		if (!(acctDTO.getSalaried() == 'Y' || acctDTO.getSalaried() == 'N')) {
			throw new InfyBankException(ExceptionConstants.CUSTOMER_SALARIED_INVALID.toString());
		}

		// check for account type
		verifyAcctType(acctDTO.getAcctType());

		return cust.getEmailId();

	}

	/**
	 * creates and populates an email instance and invokes the notifyCustomer
	 * method from NotificationService
	 * 
	 * @param emailId
	 *            the emailId of the customer
	 * @return void
	 */
	public void notifyCustomer(String emailId) {
		Email email = new Email();

		email.setToEmail(emailId);
		email.setSubject("Notification for Amount Threshold");

		String message = java.text.MessageFormat.format(
				"Dear Customer, \n \t Your transaction alert threshold has been set to {0}.\n\n Sincerely,\n InfyBank Customer Care",
				appProps.getCreditLimit());

		email.setEmailMessage(message);

		notificationService.notifyCustomer(email);
	}

	/**
	 * Generate account number.
	 *
	 * @param accType
	 *            the acc type
	 * @return the long
	 */
	public String generateAccountNumber(char accType) {

		int accountNo;
		String accountType;
		String ifscCode = appProps.getIfscCode();
		if (accType == 'C')
			accountType = "01";
		else if (accType == 'S')
			accountType = "02";
		else
			accountType = "03";
		AccountSequence sequence = getMaxAccountNoValue();
		accountNo = sequence.getCurrentAcctGen() + 1;

		sequence.setCurrentAcctGen(accountNo);
		acctSeqRepo.saveAndFlush(sequence);

		return ifscCode + accountType + accountNo;
	}

	/**
	 * Open account and credit amount.
	 *
	 * @param custId
	 *            the cust id
	 * @param amount
	 *            the amount
	 * @param accType
	 *            the acc type
	 * @param userId
	 *            the user id
	 * @param salaried
	 *            the salaried
	 * @return the int
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */
	@Transactional(value = "transactionManager", rollbackFor = InfyBankException.class)
	public void openAccount(AccountDTO acctDTO) throws InfyBankException {

		// check if amount to be deposited is >= Min. Balance
		BigDecimal minBalance = acctConfigService.getMinimumBalance(acctDTO.getAcctType());

		if (acctDTO.getBalance().floatValue() < minBalance.floatValue()) {
			throw new InfyBankException(ExceptionConstants.CUSTOMER_AMT_LESSTHAN_MINBAL.toString());
		}

		// insertion into Account table
		BankAccount account = AccountDTO.prepareEntity(acctDTO);
		String accId = generateAccountNumber(acctDTO.getAcctType());
		account.getBankAccountId().setAcctNo(accId);
		account = acctRepo.saveAndFlush(account);

		if (account == null) {
			logger.error("Account could not be saved");
			throw new InfyBankException(ExceptionConstants.SERVER_ERROR.toString());
		}
		logger.debug("Account created");

		// populate accountTransaction entity & perform transaction
		AccountTransaction acctTxn = AccountTransactionDTO.prepareEntity(acctDTO.getCustId(),
				account.getBankAccountId().getAcctNo(), acctDTO.getBalance(), acctDTO.getUserId());
		Integer txnId = acctTxnService.performTransaction(acctTxn);
		if (txnId <= 0) {
			logger.error("Account Transaction could not be saved");
			throw new InfyBankException(ExceptionConstants.SERVER_ERROR.toString());
		}
		logger.debug("Account Transaction with id {} created", txnId);
	}

	/**
	 * To get the account number for given customerId.
	 *
	 * @param custId
	 *            , the customerId
	 * @return accountNumbers if data exists in Bank account table
	 * @throws InfyBankException
	 *             the infy bank service exception
	 */

	/* Retrieve all account numbers */
	public List<String> getAccountNumbers(int custId) throws InfyBankException {

		// check if custId is valid
		custService.getCustomerDetails(custId);

		List<BankAccount> bankAccounts = acctRepo.findByBankAccountIdCustId(custId);
		List<String> accountNumbers = new ArrayList<String>();
		for (BankAccount b : bankAccounts) {
			accountNumbers.add(b.getBankAccountId().getAcctNo());
		}
		return accountNumbers;
	}

	/**
	 * To get account details.
	 *
	 * @param custId
	 *            the customerId
	 * @param acctNo
	 *            ,tthe accountNo
	 * @return account if data exists in table
	 */
	public BankAccount getAccountDetails(int custId, String acctNo) {

		return acctRepo.findOne(new BankAccountId(custId, acctNo));
	}

	/**
	 * Method to perform transfer.
	 *
	 * @param ft
	 *            , the fund transfer entity
	 * @param acct
	 *            , the bankaccount
	 * @param txnType
	 *            , the transaction id
	 */
	@Transactional(value = "transactionManager")
	public void performTransaction(BigDecimal amount, String refId, BankAccount acct, AccountTransactionType txnType, AccountTransactionCategory txnCategory) {

		BigDecimal openBalance = acct.getBalance();
		BigDecimal balance = null;
		if (txnType.equals(AccountTransactionType.DEBIT))
			balance = openBalance.subtract(amount);
		if (txnType.equals(AccountTransactionType.CREDIT))
			balance = openBalance.add(amount);
		acct.setBalance(balance);
		acctRepo.saveAndFlush(acct);

		AccountTransaction txn = new AccountTransaction();
		txn.setAcctNo(acct.getBankAccountId().getAcctNo());
		txn.setCustId(acct.getBankAccountId().getCustId());
		txn.setTxnTyp(txnType.toString().charAt(0));
		txn.setTxnAmount(amount);
		txn.setOpeningBal(openBalance);
		txn.setClosingBal(balance);
		String remarks = txnCategory.equals(AccountTransactionCategory.LOAN_PAYMENT) ? "Loan Pre-payment" : "Immediate Funds Transfer";
		txn.setRemarks(remarks);
		txn.setLstUpdtId(acct.getLstUpdtId());
		txn.setRefId(refId);
		txn.setTxnDate(new Date());
		txn.setTxnCategory(txnCategory.toString().charAt(0));
		acctTxnService.performTransaction(txn);
	}

	/**
	 * Persist into bank account.
	 *
	 * @param bankAccount
	 *            the bank account
	 * @return true, if successful
	 */
	// for loan prepay
	public boolean persistIntoBankAccount(BankAccount bankAccount) {

		acctRepo.saveAndFlush(bankAccount);

		return true;
	}

	/**
	 * Gets the acct detail.
	 *
	 * @param acctNo
	 *            the acct no
	 * @return the acct detail
	 */
	public BankAccount getAcctDetail(String acctNo) {
		return acctRepo.findByBankAccountIdAcctNo(acctNo);
	}

	/**
	 * Verifies the Account Type
	 *
	 * @param acctType
	 */
	public void verifyAcctType(char acctType) throws InfyBankException {

		String acctTyp = String.valueOf(acctType);
		AccountType type = AccountType.fromString(acctTyp);

		switch (type) {
		case CURRENT_ACCOUNT:
		case SAVINGS_BANK_ACCOUNT:
			break;
		default:
			throw new InfyBankException(ExceptionConstants.CUSTOMER_INVALID_ACCTTYPE.toString());
		}
	}

}
