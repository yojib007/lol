package com.infosys.infybank.loan.entity;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

/**
 * The Class Amortization.
 */
@Entity
@Table(name = "amortization")
public class Amortization implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The id. */
	@EmbeddedId

	@AttributeOverrides({ @AttributeOverride(name = "custId", column = @Column(name = "CUST_ID", nullable = false)),
			@AttributeOverride(name = "loanAcctNo", column = @Column(name = "LOAN_ACCT_NO", nullable = false, length = 20)),
			@AttributeOverride(name = "installmentNo", column = @Column(name = "INSTALLMENT_NO", nullable = false)) })
	private AmortizationId id;

	/** The installment date. */
	@Temporal(TemporalType.DATE)
	@Column(name = "INSTALLMENT_DATE", nullable = false, length = 10)
	private Date installmentDate;

	/** The installment amount. */
	@Column(name = "INSTALLMENT_AMOUNT", nullable = false, precision = 12, scale = 4)
	private BigDecimal installmentAmount;

	/** The principal component. */
	@Column(name = "PRINCIPAL_COMPONENT", nullable = false, precision = 12, scale = 4)
	private BigDecimal principalComponent;

	/** The interest component. */
	@Column(name = "INTEREST_COMPONENT", nullable = false, precision = 12, scale = 4)
	private BigDecimal interestComponent;

	/** The opening principal. */
	@Column(name = "OPENING_PRINCIPAL", nullable = false, precision = 12, scale = 4)
	private BigDecimal openingPrincipal;

	/** The closing principal. */
	@Column(name = "CLOSING_PRINCIPAL", nullable = false, precision = 12, scale = 4)
	private BigDecimal closingPrincipal;

	/** The interest rate. */
	@Column(name = "INTEREST_RATE", nullable = false, precision = 12, scale = 4)
	private BigDecimal interestRate;

	/** The last update timestamp. */
	@Temporal(TemporalType.TIMESTAMP)
	@Generated(GenerationTime.ALWAYS)	
	@Column(name = "LST_UPDT_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lstUpdtTs;

	/** The last update id. */
	@Column(name = "LST_UPDT_ID", nullable = false, length = 10)
	private String lstUpdtId;


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public AmortizationId getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id
	 *            the new id
	 */
	public void setId(AmortizationId id) {
		this.id = id;
	}

	/**
	 * Gets the installment date.
	 *
	 * @return the installment date
	 */
	public Date getInstallmentDate() {
		return this.installmentDate;
	}

	/**
	 * Sets the installment date.
	 *
	 * @param installmentDate
	 *            the new installment date
	 */
	public void setInstallmentDate(Date installmentDate) {
		this.installmentDate = installmentDate;
	}

	/**
	 * Gets the installment amount.
	 *
	 * @return the installment amount
	 */
	public BigDecimal getInstallmentAmount() {
		return this.installmentAmount;
	}

	/**
	 * Sets the installment amount.
	 *
	 * @param installmentAmount
	 *            the new installment amount
	 */
	public void setInstallmentAmount(BigDecimal installmentAmount) {
		this.installmentAmount = installmentAmount;
	}

	/**
	 * Gets the principal component.
	 *
	 * @return the principal component
	 */
	public BigDecimal getPrincipalComponent() {
		return this.principalComponent;
	}

	/**
	 * Sets the principal component.
	 *
	 * @param principalComponent
	 *            the new principal component
	 */
	public void setPrincipalComponent(BigDecimal principalComponent) {
		this.principalComponent = principalComponent;
	}

	/**
	 * Gets the interest component.
	 *
	 * @return the interest component
	 */
	public BigDecimal getInterestComponent() {
		return this.interestComponent;
	}

	/**
	 * Sets the interest component.
	 *
	 * @param interestComponent
	 *            the new interest component
	 */
	public void setInterestComponent(BigDecimal interestComponent) {
		this.interestComponent = interestComponent;
	}

	/**
	 * Gets the opening principal.
	 *
	 * @return the opening principal
	 */
	public BigDecimal getOpeningPrincipal() {
		return this.openingPrincipal;
	}

	/**
	 * Sets the opening principal.
	 *
	 * @param openingPrincipal
	 *            the new opening principal
	 */
	public void setOpeningPrincipal(BigDecimal openingPrincipal) {
		this.openingPrincipal = openingPrincipal;
	}

	/**
	 * Gets the closing principal.
	 *
	 * @return the closing principal
	 */
	public BigDecimal getClosingPrincipal() {
		return this.closingPrincipal;
	}

	/**
	 * Sets the closing principal.
	 *
	 * @param closingPrincipal
	 *            the new closing principal
	 */
	public void setClosingPrincipal(BigDecimal closingPrincipal) {
		this.closingPrincipal = closingPrincipal;
	}

	/**
	 * Gets the interest rate.
	 *
	 * @return the interest rate
	 */
	public BigDecimal getInterestRate() {
		return this.interestRate;
	}

	/**
	 * Sets the interest rate.
	 *
	 * @param interestRate
	 *            the new interest rate
	 */
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return this.lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return this.lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	@Override
	public String toString() {
		return "Amortization [id=" + id + ", installmentDate=" + installmentDate + ", installmentAmount="
				+ installmentAmount + ", principalComponent=" + principalComponent + ", interestComponent="
				+ interestComponent + ", openingPrincipal=" + openingPrincipal + ", closingPrincipal="
				+ closingPrincipal + ", interestRate=" + interestRate + ", lstUpdtId=" + lstUpdtId + "]";
	}
	 
	

}
