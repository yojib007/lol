package com.infosys.infybank.core.controller;

import java.util.List; 

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infybank.core.dto.AccountConfigEditDTO;
import com.infosys.infybank.core.dto.AccountConfigViewDTO;
import com.infosys.infybank.core.service.AccountConfigService;
import com.infosys.infybank.exception.InfyBankException;


/**
 * The Class AccountConfigController.
 */
@RestController
public class AccountConfigController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** The account config service. */
	@Autowired
	AccountConfigService acctConfigService;

	/**
	 * this method handles the request for viewing the accountConfig which is
	 * returned in the form of a List by this function.
	 *
	 * @return AccountConfigDTOList if data exists in AccountConfig Table
	 * @throws InfyBankException the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/acctconfigs", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<AccountConfigViewDTO> viewAccountConfig() throws InfyBankException {
		
		return acctConfigService.viewAccountConfig();
	}

	/**
	 * This controller handles the request for updating the accoutConfig details.
	 *
	 * @param acctConfigEditDTO            - list of accountConfigViewDTO and userid
	 * @return true - if update successful
	 * @throws InfyBankException the infy bank service exception
	 */
	@RequestMapping(value = "/${project.version}/acctconfigs", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void editAccountConfig(@RequestBody @Valid AccountConfigEditDTO acctConfigEditDTO)
			throws InfyBankException {
		logger.debug("Data received is {}", acctConfigEditDTO);
		acctConfigService.updateAccountConfig(acctConfigEditDTO);

	}
}
