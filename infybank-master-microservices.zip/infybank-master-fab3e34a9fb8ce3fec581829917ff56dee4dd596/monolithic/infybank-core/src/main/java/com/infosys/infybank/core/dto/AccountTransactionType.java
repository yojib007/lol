package com.infosys.infybank.core.dto;
 
/**
 * AccountTransactionType.java - enum to represent the type of account transacion
 * 
 * @author ETA Java
 * @version 1.0
 */
public enum AccountTransactionType {

	/** The credit. */
	CREDIT("C"),
	
	/** The debit. */
	DEBIT("D");

	/** The type. */
	private final String type;

	/**
	 * Instantiates a new transaction type.
	 *
	 * @param type
	 *            the type
	 */
	private AccountTransactionType(String type) {
		this.type = type;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString() {
		return this.type;
	}

}
