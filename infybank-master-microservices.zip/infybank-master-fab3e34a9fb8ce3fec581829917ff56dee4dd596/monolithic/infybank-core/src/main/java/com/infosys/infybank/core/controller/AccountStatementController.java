package com.infosys.infybank.core.controller;
 
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.infosys.infybank.core.dto.AccountStatementDTO;
import com.infosys.infybank.core.dto.SearchAccountStatementDTO;
import com.infosys.infybank.core.service.AccountTransactionService;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The AccountStatementController
 *
 */
@RestController
public class AccountStatementController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	AccountTransactionService acctTxnService;

	/**
	 * This controller handles the request for the account statement for a
	 * custId
	 * 
	 * @param custId
	 *            the customer ID
	 * @param accountNo
	 *            , the account number
	 * @param accountStatementDTOs
	 * @return List AccountStatementDTO if data exists in transaction table.
	 * @throws InfyBankException
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/${project.version}/customers/{custId}/accounts/{accId}/transactions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public List<AccountStatementDTO> getAccountStatement(@PathVariable("custId") int custId,
			@PathVariable("accId") String accountNo,
			@RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") String startDate,
			@RequestParam(required = false) @JsonFormat(pattern = "yyyy-MM-dd") String endDate,
			@RequestParam(required = false) Double fromAmount, @RequestParam(required = false) Double toAmount,
			@RequestParam(required = false) Character txnType, @RequestParam(required = false) boolean lastMonth)
			throws InfyBankException, ParseException {
		
		// parse input dates into Date object
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date start = (startDate!=null) ? sdf.parse(startDate) : null;
		Date end = (endDate!=null) ? sdf.parse(endDate) : null;
		
		// Create searchDTO and populate with input parameters 
		SearchAccountStatementDTO searchDTO = new SearchAccountStatementDTO();
		searchDTO.setAcctNo(accountNo);
		searchDTO.setCustId(custId);
		searchDTO.setEndDate(end);
		searchDTO.setFromAmount(fromAmount);
		searchDTO.setLastMonth(lastMonth);
		searchDTO.setStartDate(start);
		searchDTO.setToAmount(toAmount);
		searchDTO.setTxnType(txnType);
		logger.debug("Search parameters for account statement : {}", searchDTO);
		
		// fetch transactions
		List<AccountStatementDTO> acctStmtDTOs = acctTxnService.getTransactionsForAccount(searchDTO);
		logger.debug("Search results : {}", acctStmtDTOs);
		return acctStmtDTOs;
	}
}
