package com.infosys.infybank.core.repository;
 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.BankAccountId;


/**
 * The Interface AccountRepository.
 */
@Repository
public interface AccountRepository extends JpaRepository<BankAccount, BankAccountId> {
	/**
	 * Checks if is salaried customer.
	 *
	 * @param custId
	 *            the cust id
	 * @return the char
	 */

	public BankAccount findByBankAccountIdCustIdAndSalaried(int custId, char salaried);
	
	/**
	 * Gets the all accounts for the given customer.
	 *
	 * @param custId the cust id
	 * @return the all accounts for the given customer
	 */
	public List<BankAccount> findByBankAccountIdCustId(int custId);
	
	public BankAccount findByBankAccountIdAcctNo(String acctNo);
}
