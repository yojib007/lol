package com.infosys.infybank.loan.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.infosys.infybank.core.dto.AccountTransactionDTO;

/**
 * The Class ViewLoanApplicationDTO.
 */
public class LoanApplicationDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/** The cust name. */
	private String custName;
	
	/** The loan acct no. */
	private String loanAcctNo;
	
	/** The credit score. */
	private Integer creditScore;
	
	/** The loan amount. */
	private BigDecimal loanAmount;
	
	/** The debit acct no. */
	private String debitAcctNo;
	
	/** The tenure. */
	private int tenure;
	
	/** The is salary credited for last three days. */
	private Boolean isSalaryCreditedForLastNDays;
	
	/** The last three salary credits. */
	private List<AccountTransactionDTO> lastNSalaryCredits;
	
	/** The is credit score eligible. */
	private Boolean isCreditScoreEligible;
	
	/** The interest rate. */
	private BigDecimal interestRate;
	
	/** The emi. */
	private BigDecimal emi;
	
	/** The is valid emi. */
	private Boolean isValidEmi;
	
	/** The eligible. */
	private Boolean eligible;
	
	/**
	 * Gets the checks if is salary credited for last three days.
	 *
	 * @return the checks if is salary credited for last three days
	 */
	public Boolean getIsSalaryCreditedForLastNDays() {
		return isSalaryCreditedForLastNDays;
	}
	
	/**
	 * Sets the checks if is salary credited for last three days.
	 *
	 * @param isSalaryCreditedForLastNDays the new checks if is salary credited for last three days
	 */
	public void setIsSalaryCreditedForLastNDays(Boolean isSalaryCreditedForLastNDays) {
		this.isSalaryCreditedForLastNDays = isSalaryCreditedForLastNDays;
	}
	
	/**
	 * Gets the last three salary credits.
	 *
	 * @return the last three salary credits
	 */
	public List<AccountTransactionDTO> getLastNSalaryCredits() {
		return lastNSalaryCredits;
	}
	
	/**
	 * Sets the last three salary credits.
	 *
	 * @param lastNSalaryCredits the new last three salary credits
	 */
	public void setLastNSalaryCredits(List<AccountTransactionDTO> lastNSalaryCredits) {
		this.lastNSalaryCredits = lastNSalaryCredits;
	}
	
	/**
	 * Gets the checks if is credit score eligible.
	 *
	 * @return the checks if is credit score eligible
	 */
	public Boolean getIsCreditScoreEligible() {
		return isCreditScoreEligible;
	}
	
	/**
	 * Sets the checks if is credit score eligible.
	 *
	 * @param isCreditScoreEligible the new checks if is credit score eligible
	 */
	public void setIsCreditScoreEligible(Boolean isCreditScoreEligible) {
		this.isCreditScoreEligible = isCreditScoreEligible;
	}
	
	/**
	 * Gets the interest rate.
	 *
	 * @return the interest rate
	 */
	public BigDecimal getInterestRate() {
		return interestRate;
	}
	
	/**
	 * Sets the interest rate.
	 *
	 * @param interestRate the new interest rate
	 */
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	
	/**
	 * Gets the emi.
	 *
	 * @return the emi
	 */
	public BigDecimal getEmi() {
		return emi;
	}
	
	/**
	 * Sets the emi.
	 *
	 * @param emi the new emi
	 */
	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}
	
	/**
	 * Gets the checks if is valid emi.
	 *
	 * @return the checks if is valid emi
	 */
	public Boolean getIsValidEmi() {
		return isValidEmi;
	}
	
	/**
	 * Sets the checks if is valid emi.
	 *
	 * @param isValidEmi the new checks if is valid emi
	 */
	public void setIsValidEmi(Boolean isValidEmi) {
		this.isValidEmi = isValidEmi;
	}
	
	/**
	 * Gets the loan acct no.
	 *
	 * @return the loan acct no
	 */
	public String getLoanAcctNo() {
		return loanAcctNo;
	}
	
	/**
	 * Sets the loan acct no.
	 *
	 * @param loanAcctNo the new loan acct no
	 */
	public void setLoanAcctNo(String loanAcctNo) {
		this.loanAcctNo = loanAcctNo;
	}
	
	/**
	 * Gets the credit score.
	 *
	 * @return the credit score
	 */
	public Integer getCreditScore() {
		return creditScore;
	}
	
	/**
	 * Sets the credit score.
	 *
	 * @param creditScore the new credit score
	 */
	public void setCreditScore(Integer creditScore) {
		this.creditScore = creditScore;
	}
	
	/**
	 * Gets the loan amount.
	 *
	 * @return the loan amount
	 */
	public BigDecimal getLoanAmount() {
		return loanAmount;
	}
	
	/**
	 * Sets the loan amount.
	 *
	 * @param loanAmount the new loan amount
	 */
	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}
	
	/**
	 * Gets the debit acct no.
	 *
	 * @return the debit acct no
	 */
	public String getDebitAcctNo() {
		return debitAcctNo;
	}
	
	/**
	 * Sets the debit acct no.
	 *
	 * @param debitAcctNo the new debit acct no
	 */
	public void setDebitAcctNo(String debitAcctNo) {
		this.debitAcctNo = debitAcctNo;
	}
	
	/**
	 * Gets the tenure.
	 *
	 * @return the tenure
	 */
	public int getTenure() {
		return tenure;
	}
	
	/**
	 * Sets the tenure.
	 *
	 * @param tenure the new tenure
	 */
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	/**
	 * Gets the cust name.
	 *
	 * @return the cust name
	 */
	public String getCustName() {
		return custName;
	}
	
	/**
	 * Sets the cust name.
	 *
	 * @param custName the new cust name
	 */
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	/**
	 * Gets the eligible.
	 *
	 * @return the eligible
	 */
	public Boolean getEligible() {
		return eligible;
	}
	
	/**
	 * Sets the eligible.
	 *
	 * @param eligible the new eligible
	 */
	public void setEligible(Boolean eligible) {
		this.eligible = eligible;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ViewLoanApplicationDTO [custName=" + custName + ", loanAcctNo=" + loanAcctNo + ", creditScore="
				+ creditScore + ", loanAmount=" + loanAmount + ", debitAcctNo=" + debitAcctNo + ", tenure=" + tenure
				+ ", isSalaryCreditedForLastThreeDays=" + isSalaryCreditedForLastNDays + ", lastThreeSalaryCredits="
				+ lastNSalaryCredits + ", isCreditScoreEligible=" + isCreditScoreEligible + ", interestRate="
				+ interestRate + ", emi=" + emi + ", isValidEmi=" + isValidEmi + ", eligible=" + eligible + "]";
	}
	
	
	
}
