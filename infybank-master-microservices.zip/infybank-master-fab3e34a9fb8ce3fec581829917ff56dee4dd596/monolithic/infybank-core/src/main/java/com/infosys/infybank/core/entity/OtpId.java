package com.infosys.infybank.core.entity;
 
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The Class OtpId.
 */
@Embeddable
public class OtpId implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	@Column(name = "CUST_ID", nullable = false)
	private int custId;

	/** The otp. */
	@Column(name = "OTP", nullable = false)
	private int otp;

	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return this.custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the otp.
	 *
	 * @return the otp
	 */
	public int getOtp() {
		return this.otp;
	}

	/**
	 * Sets the otp.
	 *
	 * @param otp
	 *            the new otp
	 */
	public void setOtp(int otp) {
		this.otp = otp;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		if (other == null)
			return false;
		if (!(other instanceof OtpId))
			return false;
		OtpId castOther = (OtpId) other;

		return (this.getCustId() == castOther.getCustId()) && (this.getOtp() == castOther.getOtp());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		int result = 17;

		result = 37 * result + this.getCustId();
		result = 37 * result + this.getOtp();
		return result;
	}

}
