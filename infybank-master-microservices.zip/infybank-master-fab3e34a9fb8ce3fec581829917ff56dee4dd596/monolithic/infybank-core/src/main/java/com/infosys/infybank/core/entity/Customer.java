package com.infosys.infybank.core.entity;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;


/**
 * The Class Customer.
 */
@Entity
@Table(name = "CUSTOMER")
public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The cust id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CUST_ID", unique = true, nullable = false)
	private int custId;

	/** The aadhar id. */
	@Column(name = "AADHAR_ID", nullable = false, length = 12)
	private String aadharId;

	/** The pan no. */
	@Column(name = "PAN_NO", nullable = false, length = 10)
	private String panNo;

	/** The first name. */
	@Column(name = "FIRST_NAME", nullable = false, length = 50)
	private String firstName;

	/** The last name. */
	@Column(name = "LAST_NAME", nullable = false, length = 50)
	private String lastName;

	/** The email id. */
	@Column(name = "EMAIL_ID", nullable = false, length = 100)
	private String emailId;

	/** The address. */
	@Column(name = "ADDRESS", nullable = false, length = 100)
	private String address;

	/** The city. */
	@Column(name = "CITY", nullable = false, length = 30)
	private String city;

	/** The state. */
	@Column(name = "STATE", nullable = false, length = 30)
	private String state;

	/** The pincode. */
	@Column(name = "PINCODE", nullable = false, length = 6)
	private String pincode;

	/** The dob. */
	@Temporal(TemporalType.DATE)
	@Column(name = "DOB", nullable = false, length = 10)
	private Date dob;

	/** The amount pref. */
	@Column(name = "AMOUNT_PREF", nullable = false, length = 10)
	@ColumnDefault("'l'")
	private String amountPref;

	/** The date pref. */
	@Column(name = "DATE_PREF", nullable = false, length = 15)
	@ColumnDefault("'dd/mm/yy'")
	private String datePref;

	/** The cr db notif limit. */
	@Column(name = "CR_DB_NOTIF_LIMIT", nullable = false, precision = 12, scale = 4)
	private BigDecimal crDbNotifLimit;

	/** The lst updt ts. */
	@Temporal(TemporalType.TIMESTAMP)
	@Generated(GenerationTime.ALWAYS)
	@Column(name = "LST_UPDT_TS", nullable = false, length = 19, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lstUpdtTs;

	/** The lst updt id. */
	@Column(name = "LST_UPDT_ID", nullable = false, length = 10)
	private String lstUpdtId;

	
	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public int getCustId() {
		return this.custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId
	 *            the new cust id
	 */
	public void setCustId(int custId) {
		this.custId = custId;
	}

	/**
	 * Gets the aadhar id.
	 *
	 * @return the aadhar id
	 */
	public String getAadharId() {
		return this.aadharId;
	}

	/**
	 * Sets the aadhar id.
	 *
	 * @param aadharId
	 *            the new aadhar id
	 */
	public void setAadharId(String aadharId) {
		this.aadharId = aadharId;
	}

	/**
	 * Gets the pan no.
	 *
	 * @return the pan no
	 */
	public String getPanNo() {
		return this.panNo;
	}

	/**
	 * Sets the pan no.
	 *
	 * @param panNo
	 *            the new pan no
	 */
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	/**
	 * Gets the fisrt name.
	 *
	 * @return the fisrt name
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * Sets the fisrt name.
	 *
	 * @param firstName
	 *            the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName
	 *            the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return this.emailId;
	}

	/**
	 * Sets the email id.
	 *
	 * @param emailId
	 *            the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address
	 *            the new address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return this.city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city
	 *            the new city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return this.state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state
	 *            the new state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets the pincode.
	 *
	 * @return the pincode
	 */
	public String getPincode() {
		return this.pincode;
	}

	/**
	 * Sets the pincode.
	 *
	 * @param pincode
	 *            the new pincode
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/**
	 * Gets the dob.
	 *
	 * @return the dob
	 */
	public Date getDob() {
		return this.dob;
	}

	/**
	 * Sets the dob.
	 *
	 * @param dob
	 *            the new dob
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}

	/**
	 * Gets the amount pref.
	 *
	 * @return the amount pref
	 */
	public String getAmountPref() {
		return this.amountPref;
	}

	/**
	 * Sets the amount pref.
	 *
	 * @param amountPref
	 *            the new amount pref
	 */
	public void setAmountPref(String amountPref) {
		this.amountPref = amountPref;
	}

	/**
	 * Gets the date pref.
	 *
	 * @return the date pref
	 */
	public String getDatePref() {
		return this.datePref;
	}

	/**
	 * Sets the date pref.
	 *
	 * @param datePref
	 *            the new date pref
	 */
	public void setDatePref(String datePref) {
		this.datePref = datePref;
	}

	/**
	 * Gets the cr db notif limit.
	 *
	 * @return the cr db notif limit
	 */
	public BigDecimal getCrDbNotifLimit() {
		return this.crDbNotifLimit;
	}

	/**
	 * Sets the cr db notif limit.
	 *
	 * @param crDbNotifLimit
	 *            the new cr db notif limit
	 */
	public void setCrDbNotifLimit(BigDecimal crDbNotifLimit) {
		this.crDbNotifLimit = crDbNotifLimit;
	}

	/**
	 * Gets the lst updt ts.
	 *
	 * @return the lst updt ts
	 */
	public Date getLstUpdtTs() {
		return this.lstUpdtTs;
	}

	/**
	 * Sets the lst updt ts.
	 *
	 * @param lstUpdtTs
	 *            the new lst updt ts
	 */
	public void setLstUpdtTs(Date lstUpdtTs) {
		this.lstUpdtTs = lstUpdtTs;
	}

	/**
	 * Gets the lst updt id.
	 *
	 * @return the lst updt id
	 */
	public String getLstUpdtId() {
		return this.lstUpdtId;
	}

	/**
	 * Sets the lst updt id.
	 *
	 * @param lstUpdtId
	 *            the new lst updt id
	 */
	public void setLstUpdtId(String lstUpdtId) {
		this.lstUpdtId = lstUpdtId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", aadharId=" + aadharId + ", panNo=" + panNo + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", emailId=" + emailId + ", address=" + address + ", city=" + city
				+ ", state=" + state + ", pincode=" + pincode + ", dob=" + dob + ", amountPref=" + amountPref
				+ ", datePref=" + datePref + ", crDbNotifLimit=" + crDbNotifLimit + ", lstUpdtTs=" + lstUpdtTs
				+ ", lstUpdtId=" + lstUpdtId + "]";
	}

}
