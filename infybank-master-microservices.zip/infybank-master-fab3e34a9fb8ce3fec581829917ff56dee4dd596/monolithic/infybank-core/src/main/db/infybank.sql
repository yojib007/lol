-- Drop all tables 
DROP TABLE otp;
DROP TABLE account_config;
DROP TABLE customer;
DROP TABLE login;
DROP TABLE accno_seq;
DROP TABLE bank_account;
DROP TABLE account_transaction;
DROP TABLE payee;
DROP TABLE fund_transfer;
DROP TABLE loan_config;
DROP TABLE loan_account;
DROP TABLE amortization;
DROP TABLE batch_status;

-- Create all tables
CREATE TABLE otp (
  ID                   BIGINT(20)      NOT NULL AUTO_INCREMENT,
  OTP                  VARCHAR(255)    NOT NULL,
  OTP_TYPE             CHAR(1)         NOT NULL,
  CUST_ID              INT(11)         NOT NULL,
  EMAIL_ID             VARCHAR(100)    NOT NULL,
  PAYEE_ID             INT(11)         DEFAULT NULL,
  GENERATED_TS         TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (ID)
);

CREATE TABLE account_config (
  ACCT_TYPE            CHAR(1)         NOT NULL,
  MIN_BALANCE          DECIMAL(12,4)   NOT NULL,
  INTEREST_RATE        DECIMAL(12,4)   NOT NULL,
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (ACCT_TYPE)
);

CREATE TABLE customer (
  CUST_ID              INT(11)         NOT NULL AUTO_INCREMENT,
  FIRST_NAME           VARCHAR(50)     NOT NULL,
  LAST_NAME            VARCHAR(50)     NOT NULL,
  DOB                  DATE            NOT NULL,
  EMAIL_ID             VARCHAR(100)    NOT NULL,
  ADDRESS              VARCHAR(100)    NOT NULL,
  CITY                 VARCHAR(30)     NOT NULL,
  STATE                VARCHAR(30)     NOT NULL,
  PINCODE              VARCHAR(6)      NOT NULL,
  AADHAR_ID            VARCHAR(12)     NOT NULL,
  PAN_NO               VARCHAR(10)     NOT NULL,
  AMOUNT_PREF          VARCHAR(15)     NOT NULL,
  DATE_PREF            VARCHAR(15)     NOT NULL,
  CR_DB_NOTIF_LIMIT    DECIMAL(12,4)   NOT NULL,
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (CUST_ID)
);

CREATE TABLE login (
  CUST_ID              INT(11)         NOT NULL,
  USER_ID              VARCHAR(10)     NOT NULL,
  PASSWORD             VARCHAR(255)    NOT NULL,
  ROLE                 CHAR(1)         NOT NULL,
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (CUST_ID)
);

CREATE TABLE accno_seq (
  ID                   BIGINT(20)      NOT NULL AUTO_INCREMENT,
  ACCT_CURRENT_NO      INT(11),
  PRIMARY KEY (ID)
);

CREATE TABLE bank_account (
  ACCT_NO              VARCHAR(20)     NOT NULL,
  CUST_ID              INT(11)         NOT NULL,
  ACCT_TYPE            CHAR(1)         NOT NULL,
  BALANCE              DECIMAL(12,4)   NOT NULL,
  SALARIED             CHAR(1)         NOT NULL,
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (ACCT_NO,CUST_ID)
);

CREATE TABLE account_transaction (
  TXN_ID               INT(11)         NOT NULL AUTO_INCREMENT,
  CUST_ID              INT(11)         NOT NULL,
  ACCT_NO              VARCHAR(20)     NOT NULL,
  TXN_DATE             DATE            NOT NULL,
  TXN_AMOUNT           DECIMAL(12,4)   NOT NULL,
  TXN_TYP              CHAR(1)         NOT NULL,
  OPENING_BAL          DECIMAL(12,4)   NOT NULL,
  CLOSING_BAL          DECIMAL(12,4)   NOT NULL,
  TXN_CATEGORY         CHAR(1)         NOT NULL,
  REF_ID               VARCHAR(20),
  REMARKS              VARCHAR(100),
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (TXN_ID)
);

CREATE TABLE payee (
  PAYEE_ID             INT(11)         NOT NULL AUTO_INCREMENT,
  CUST_ID              INT(11)         NOT NULL,
  ACCT_NO              VARCHAR(20)     NOT NULL,
  ACCT_TYPE            CHAR(1)         NOT NULL,
  IFSC_CODE            VARCHAR(11),
  NICK_NAME            VARCHAR(25)     NOT NULL,
  PAYEE_NAME           VARCHAR(255)    NOT NULL,
  STATUS               CHAR(1)         NOT NULL,
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (PAYEE_ID)
);


CREATE TABLE fund_transfer (
  FT_ID                BIGINT(20)      NOT NULL AUTO_INCREMENT,
  FROM_ACCT            VARCHAR(20)     NOT NULL,
  TO_ACCT              VARCHAR(20),
  PAYEE_ID             INT(11),
  FT_DATE              DATE            NOT NULL,
  FT_AMOUNT            DECIMAL(12,4)   NOT NULL,
  FT_TYPE              CHAR(1)         NOT NULL,
  STATUS               CHAR(1)         NOT NULL,
  REMARKS              VARCHAR(100),
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (FT_ID)
);

CREATE TABLE loan_config (
  CREDIT_SCORE_START   INT(11)         NOT NULL,
  CREDIT_SCORE_END     INT(11)         NOT NULL,
  LOAN_APPROVAL_IND    CHAR(1)         NOT NULL,
  INTEREST_RATE        DECIMAL(12,4)   NOT NULL,
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(CREDIT_SCORE_START, CREDIT_SCORE_END)
);

CREATE TABLE loan_account (
  LOAN_ACCT_NO         VARCHAR(20)     NOT NULL,
  CUST_ID              INT(11)         NOT NULL,
  LOAN_AMOUNT          DECIMAL(12,4)   NOT NULL,
  TENURE               INT(11)         NOT NULL,
  INTEREST_RATE        DECIMAL(12,4),
  DEBIT_ACCT_NO        VARCHAR(20)     NOT NULL,
  EMI                  DECIMAL(12,4),
  EMI_DUE_DATE         DATE,
  OPENING_DATE         DATE,
  LOAN_STATUS          CHAR(1)         NOT NULL,
  REMARKS              VARCHAR(100),
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (LOAN_ACCT_NO,CUST_ID)
);

CREATE TABLE amortization (
  LOAN_ACCT_NO         VARCHAR(20)     NOT NULL,
  CUST_ID              INT(11)         NOT NULL,
  INSTALLMENT_NO       INT(11)         NOT NULL,
  INSTALLMENT_DATE     DATE            NOT NULL,
  OPENING_PRINCIPAL    DECIMAL(12,4)   NOT NULL,
  INSTALLMENT_AMOUNT   DECIMAL(12,4)   NOT NULL,
  PRINCIPAL_COMPONENT  DECIMAL(12,4)   NOT NULL,
  INTEREST_COMPONENT   DECIMAL(12,4)   NOT NULL,
  CLOSING_PRINCIPAL    DECIMAL(12,4)   NOT NULL,
  INTEREST_RATE        DECIMAL(12,4)   NOT NULL,
  LST_UPDT_ID          VARCHAR(10)     NOT NULL,
  LST_UPDT_TS          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (LOAN_ACCT_NO,CUST_ID,INSTALLMENT_NO)
);

CREATE TABLE batch_status (
  BATCH_ID             INT(10)         NOT NULL AUTO_INCREMENT,
  CREDIT_TYPE          VARCHAR(1)      NOT NULL,
  TXN_DATE             DATE            NOT NULL,
  STATUS               VARCHAR(1)      NOT NULL,
  PRIMARY KEY (BATCH_ID)
);

-- Insert minimum configuration data for the application to work
INSERT INTO customer (
  CUST_ID, FIRST_NAME, LAST_NAME, DOB, EMAIL_ID, ADDRESS, CITY, STATE, 
  PINCODE, AADHAR_ID, PAN_NO, AMOUNT_PREF, DATE_PREF, CR_DB_NOTIF_LIMIT, LST_UPDT_ID 
) VALUES (
  1, 'Administrator', ' ', '1990-01-01', 'admin@infybank.com', 'Electronic City','Bangalore', 'Karnataka', 
  '560100', '111111111111', 'AAAAA0000A', 'international', 'dd-MM-yyyy', 5000.0, 'admin' );

INSERT INTO login ( CUST_ID, USER_ID, PASSWORD, ROLE, LST_UPDT_ID 
) VALUES ( 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'A', 'admin');

INSERT INTO account_config ( 
  ACCT_TYPE, INTEREST_RATE, MIN_BALANCE, LST_UPDT_ID 
) VALUES 
 ('C', 1.0 , 1000.0, 'admin'),
 ('S', 4.0 , 4000.0, 'admin');

INSERT INTO accno_seq (ID, ACCT_CURRENT_NO ) VALUES (1, 100);

INSERT INTO loan_config ( 
  CREDIT_SCORE_START, CREDIT_SCORE_END, INTEREST_RATE, LOAN_APPROVAL_IND, LST_UPDT_ID 
) VALUES
 (300, 500, 0.0, 'N', 'admin'), 
 (501, 600, 10.0, 'Y', 'admin'),
 (601, 700, 8.5, 'Y', 'admin'),
 (701, 900, 6.5, 'Y', 'admin');

