package com.infosys.infybank.core.utilities;
  
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.utilities.AccountStatementValidator;


/**
 * The Class AccountStatementValidatorTest.
 */
public class AccountStatementValidatorTest {

	/** The expected exception. */
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	/**
	 * Test is transaction type valid with valid txt type.
	 */
	@Test
	public void testIsTransactionTypeValidWithValidTxtType() {
		assertTrue(AccountStatementValidator.isTransactionTypeValid('C'));
		assertTrue(AccountStatementValidator.isTransactionTypeValid('D'));
	}

	/**
	 * Test is transaction type valid with in valid txt type.
	 */
	@Test
	public void testIsTransactionTypeValidWithInValidTxtType() {
		assertFalse(AccountStatementValidator.isTransactionTypeValid('A'));
	}

	/**
	 * Test is from to date valid with from date null.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsFromToDateValidWithFromDateNull() throws InfyBankException {
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.ACCOUNT_TRANSACTION_START_DATE_INVALID.toString());
		
		AccountStatementValidator.validateFromToDate(false, null, TestUtil.createDate(2017, 1, 1));
	}

	/**
	 * Test is from to date valid with to date null.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsFromToDateValidWithToDateNull() throws InfyBankException {
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.ACCOUNT_TRANSACTION_END_DATE_INVALID.toString());
		AccountStatementValidator.validateFromToDate(false, TestUtil.createDate(2017, 1, 2), null);
	}

	/**
	 * Test is from to date valid with from date greater.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsFromToDateValidWithFromDateGreater() throws InfyBankException {
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.ACCOUNT_TRANSACTION_FROM_TO_DATE_INVALID.toString());
		AccountStatementValidator.validateFromToDate(false, TestUtil.createDate(2017, 1, 2), TestUtil.createDate(2017, 1, 1));
	}

	/**
	 * Test is from to amount valid with invalid from amount.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsFromToAmountValidWithInvalidFromAmount() throws InfyBankException {
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.ACCOUNT_TRANSACTION_FROM_AMOUNT_INVALID.toString());
		AccountStatementValidator.validateFromToAmount(-1D, 1000D);
	}

	/**
	 * Test is from to amount valid with invalid to amount.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsFromToAmountValidWithInvalidToAmount() throws InfyBankException {
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.ACCOUNT_TRANSACTION_TO_AMOUNT_INVALID.toString());
		AccountStatementValidator.validateFromToAmount(1000D, 0.0);
	}

	/**
	 * Test is from to amount valid with from amount greater.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsFromToAmountValidWithFromAmountGreater() throws InfyBankException {
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.ACCOUNT_TRANSACTION_FROMTO_AMOUNT_INVALID.toString());
		AccountStatementValidator.validateFromToAmount(1000D, 500D);
	}

}