package com.infosys.infybank.core.service;
 
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.AccountDTO;
import com.infosys.infybank.core.dto.AccountTransactionCategory;
import com.infosys.infybank.core.dto.AccountTransactionType;
import com.infosys.infybank.core.entity.AccountSequence;
import com.infosys.infybank.core.entity.AccountTransaction;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.BankAccountId;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.repository.AccountRepository;
import com.infosys.infybank.core.repository.AccountSequenceRepository;
import com.infosys.infybank.core.repository.CustomerRepository;
import com.infosys.infybank.core.repository.LoginRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.fundtransfer.entity.FundTransfer;

/**
 * The Class AccountServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
public class AccountServiceTest {

	/** The account repository. */
	@Mock
	private AccountRepository accountRepository;

	/** The customer repository. */
	@Mock
	private CustomerRepository customerRepository;

	/** The login repository. */
	@Mock
	private LoginRepository loginRepository;

	/** The account sequence repository. */
	@Mock
	private AccountSequenceRepository accountSequenceRepository;

	/** The env. */
	@Mock
	private Environment env;

	/** The account config service. */
	@Mock
	private AccountConfigService accountConfigService;
	
	/** The login service. */
	@Mock
	LoginService loginService;

	/** The transaction service. */
	@Mock
	private AccountTransactionService transactionService;
	
	@Mock
	private CustomerService customerService;
	
	@Mock
	NotificationService notificationService;
	
	@Mock
	ApplicationProperties appProps;

	/** The account service. */
	@Spy
	@InjectMocks
	private AccountService accountService;

	/** The account service1. */
	@InjectMocks
	@Spy
	private AccountService accountService1;

	/** The account dto. */
	private static AccountDTO accountDTO;
	
	/** The account entity. */
	private static BankAccount accountEntity;
	
	private static List<BankAccount> accountEntityList;
	
	/** The bank account id. */
	private static BankAccountId bankAccountId;
	
	/** The account numbers. */
	private static List<String> accountNumbers;
	
	/** The entity. */
	private static FundTransfer entity;

	/** The expected exception. */
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	/**
	 * Initialize.
	 */
	@BeforeClass
	public static void initialize() {
		accountDTO = new AccountDTO();
		accountDTO.setBalance(BigDecimal.valueOf(10000));
		bankAccountId = new BankAccountId(1001, "101202303404");
		accountEntity = new BankAccount();
		accountEntityList = new ArrayList<BankAccount>();
		accountEntity.setBankAccountId(bankAccountId);
		accountEntity.setBalance(new BigDecimal(10000));
		accountEntityList.add(accountEntity);
		accountNumbers = new ArrayList<String>();
		entity = new FundTransfer();
		entity.setFtAmount(new BigDecimal(1000));
	}

	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test is bank account valid with valid details.
	 */
	@Test
	public void testIsBankAccountValidWithValidDetails() {
		Mockito.when(accountRepository.exists(Mockito.any(BankAccountId.class))).thenReturn(true);
		assertTrue(accountService.isBankAccountValid(1001, "101202303404"));
	}

	/**
	 * Test is bank account valid with invalid details.
	 */
	@Test
	public void testIsBankAccountValidWithInvalidDetails() {
		Mockito.when(accountRepository.exists(Mockito.any(BankAccountId.class))).thenReturn(false);
		assertFalse(accountService.isBankAccountValid(1001, "101202303404"));
	}

	/**
	 * Test open account with valid credentials.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testOpenAccountWithValidCredentials() throws InfyBankException {
		Customer c = new Customer();
		c.setEmailId("abc@infosys.com");
		Mockito.when(loginService.getLoginDetails(Mockito.anyString())).thenReturn(new Login());
		Mockito.when(customerService.getCustomerDetails(Mockito.anyInt())).thenReturn(c);
		accountDTO.setSalaried('N');
		accountDTO.setAcctType('C');
		assertEquals("abc@infosys.com", accountService.validateOpenAccountInput(accountDTO));
	}

	/**
	 * Test open account with invalid customer.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testOpenAccountWithInvalidCustomer() throws InfyBankException {
		Mockito.when(customerService.getCustomerDetails(Mockito.anyInt())).thenThrow(
				new ResourceNotFoundException(ExceptionConstants.CUSTOMER_ID_INVALID.toString()));
		expectedException.expect(ResourceNotFoundException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_ID_INVALID.toString());
		accountService.validateOpenAccountInput(accountDTO);
	}

	@Test
	public void testOpenAccountWithInvalidUserId() throws InfyBankException {
		Mockito.when(customerRepository.findOne(Mockito.anyInt())).thenReturn(new Customer());
		Mockito.when(loginRepository.findByUserId(Mockito.anyString())).thenReturn(null);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.USERID_INVALID.toString());
		accountService.validateOpenAccountInput(accountDTO);
	}
	
	/**
	 * Test open account with already salaried customer.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testOpenAccountWithAlreadySalariedCustomer() throws InfyBankException {
		Mockito.when(customerRepository.findOne(Mockito.anyInt())).thenReturn(new Customer());
		accountDTO.setSalaried('Y');
		Mockito.when(loginService.getLoginDetails(Mockito.anyString())).thenReturn(new Login());
		Mockito.when(accountRepository.findByBankAccountIdCustIdAndSalaried(Mockito.anyInt(), Mockito.anyChar())).thenReturn(accountEntity);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_IS_ALREADY_SALARIED.toString());
		accountService.validateOpenAccountInput(accountDTO);
	}

	/**
	 * Test generate account number.
	 */
	@Test
	public void testGenerateAccountNumberWithC() {
		List<AccountSequence> acctSequences = new ArrayList<AccountSequence>();
		AccountSequence sequence = new AccountSequence();
		sequence.setCurrentAcctGen(100);
		acctSequences.add(sequence);
		Mockito.when(appProps.getIfscCode()).thenReturn("04490");
		Mockito.when(env.getProperty("account.start.default.value")).thenReturn("100");
		Mockito.when(accountSequenceRepository.saveAndFlush(Mockito.any(AccountSequence.class)))
				.thenReturn(new AccountSequence(100));
		Mockito.when(accountSequenceRepository.findAll()).thenReturn(acctSequences);
		assertEquals("0449001101", accountService.generateAccountNumber('C'));
	}

	@Test
	public void testGenerateAccountNumberWithS(){
		Mockito.when(appProps.getIfscCode()).thenReturn("04490");
		Mockito.when(env.getProperty("account.start.default.value")).thenReturn("100");
		Mockito.when(accountSequenceRepository.saveAndFlush(Mockito.any(AccountSequence.class)))
				.thenReturn(new AccountSequence(100));
		List<AccountSequence> acctSeqList = new ArrayList<AccountSequence>();
		acctSeqList.add(new AccountSequence(100));
		Mockito.when(accountSequenceRepository.findAll()).thenReturn(acctSeqList);
		assertEquals("0449002101", accountService.generateAccountNumber('S'));
	}
	
	@Test
	public void testGenerateAccountNumberWithL(){
		List<AccountSequence> acctSequences = new ArrayList<AccountSequence>();
		AccountSequence sequence = new AccountSequence();
		sequence.setCurrentAcctGen(100);
		acctSequences.add(sequence);
		Mockito.when(appProps.getIfscCode()).thenReturn("04490");
		Mockito.when(env.getProperty("account.start.default.value")).thenReturn("100");
		Mockito.when(accountSequenceRepository.saveAndFlush(Mockito.any(AccountSequence.class)))
				.thenReturn(new AccountSequence(100));
		Mockito.when(accountSequenceRepository.findAll()).thenReturn(acctSequences);
		assertEquals("0449003101", accountService.generateAccountNumber('L'));
	}
	
	/**
	 * Test open account and credit amount.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testOpenAccountAndCreditAmount() throws InfyBankException {
		Mockito.doReturn("0449001101").when(accountService1).generateAccountNumber(Mockito.anyChar());
		Mockito.when(customerRepository.findOne(Mockito.anyInt())).thenReturn(new Customer());
		Mockito.when(accountRepository.saveAndFlush(Mockito.any(BankAccount.class))).thenReturn(accountEntity);
		Mockito.when(accountConfigService.getMinimumBalance(Mockito.anyChar())).thenReturn(new BigDecimal(1000));
		Mockito.when(transactionService.performTransaction(Mockito.any(AccountTransaction.class))).thenReturn(101);
		AccountDTO dto = new AccountDTO();
		dto.setBalance(BigDecimal.valueOf(5000));
		accountService1.openAccount(dto);
		Mockito.verify(accountConfigService).getMinimumBalance(Mockito.anyChar());
		Mockito.verify(accountService1).generateAccountNumber(Mockito.anyChar());
		Mockito.verify(accountRepository).saveAndFlush(Mockito.any(BankAccount.class));
		Mockito.verify(transactionService).performTransaction(Mockito.any(AccountTransaction.class));
	}

	/**
	 * Test open account and credit amount with acc id gen failed.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testOpenAccountAndCreditAmountWithAccIdGenFailed() throws InfyBankException {
		Mockito.doReturn("0449001101").when(accountService1).generateAccountNumber(Mockito.anyChar());
		Mockito.when(accountRepository.saveAndFlush(Mockito.any(BankAccount.class))).thenReturn(null);
		Mockito.when(accountConfigService.getMinimumBalance((Mockito.anyChar()))).thenReturn(BigDecimal.valueOf(1000));
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.SERVER_ERROR.toString());
		AccountDTO dto = new AccountDTO();
		dto.setBalance(BigDecimal.valueOf(5000));
		accountService1.openAccount(dto);
	}

	/**
	 * Test open account and credit amount with no acc config.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testOpenAccountAndCreditAmountWithNoAccConfig() throws InfyBankException {
		Mockito.doReturn("0449001101").when(accountService1).generateAccountNumber(Mockito.anyChar());
		Mockito.when(accountRepository.saveAndFlush(Mockito.any(BankAccount.class))).thenReturn(accountEntity);
		Mockito.when(accountConfigService.getMinimumBalance(Mockito.anyChar()))
		.thenThrow(new InfyBankException(ExceptionConstants.SERVER_ERROR.toString()));
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.SERVER_ERROR.toString());
		accountService1.openAccount(new AccountDTO());
	}

	/**
	 * Test open account and credit amount with insufficient amount.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testOpenAccountAndCreditAmountWithInsufficientAmount() throws InfyBankException {
		Mockito.doReturn("0449001101").when(accountService1).generateAccountNumber(Mockito.anyChar());
		Mockito.when(accountRepository.saveAndFlush(Mockito.any(BankAccount.class))).thenReturn(accountEntity);
		Mockito.when(accountConfigService.getMinimumBalance(Mockito.anyChar())).thenReturn(new BigDecimal(1000));
		Mockito.when(transactionService.performTransaction(Mockito.any(AccountTransaction.class))).thenReturn(1);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_AMT_LESSTHAN_MINBAL.toString());
		AccountDTO dto = new AccountDTO();
		dto.setBalance(BigDecimal.valueOf(900));
		accountService1.openAccount(dto);
	}

	/**
	 * Test get account numbers.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGetAccountNumbers() throws InfyBankException {
		accountNumbers.add("101202303404");
		Mockito.when(accountRepository.findByBankAccountIdCustId(Mockito.anyInt())).thenReturn(accountEntityList);
		assertEquals(accountNumbers, accountService.getAccountNumbers(1001));
	}

	/**
	 * Test get account numbers with no account.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGetAccountNumbersWithNoAccount() throws InfyBankException {
		Mockito.when(customerService.getCustomerDetails(Mockito.anyInt())).thenThrow(
				new ResourceNotFoundException(ExceptionConstants.CUSTOMER_ID_INVALID.toString()));
		expectedException.expect(ResourceNotFoundException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_ID_INVALID.toString());
		accountService.getAccountNumbers(0);
	}

	/**
	 * Test get account numbers with invalid customer id.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGetAccountNumbersWithInvalidCustomerId() throws InfyBankException {
		Mockito.when(customerService.getCustomerDetails(Mockito.anyInt())).thenThrow(
				new ResourceNotFoundException(ExceptionConstants.CUSTOMER_ID_INVALID.toString()));
		expectedException.expect(ResourceNotFoundException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_ID_INVALID.toString());
		accountService.getAccountNumbers(1001);
	}

	/**
	 * Test get account details.
	 */
	@Test
	public void testGetAccountDetails() {
		Mockito.when(accountRepository.findOne(Mockito.any(BankAccountId.class))).thenReturn(accountEntity);
		assertEquals(accountEntity, accountService.getAccountDetails(1001, "101202303404"));
	}

	/**
	 * Test get account details with invalid details.
	 */
	@Test
	public void testGetAccountDetailsWithInvalidDetails() {
		Mockito.when(accountRepository.findOne(Mockito.any(BankAccountId.class))).thenReturn(null);
		assertNull(accountService.getAccountDetails(1002, "101202303405"));
	}

	/**
	 * Test perform transfer.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testPerformTransferWithDebit() throws InfyBankException {
		BigDecimal ftAmount = BigDecimal.valueOf(1000);
		BigDecimal updatedBal = accountEntity.getBalance().subtract(ftAmount);
		accountService.performTransaction(ftAmount, null, accountEntity, 
				AccountTransactionType.DEBIT, AccountTransactionCategory.FUNDS_TRANSFER);
		Mockito.verify(accountRepository).saveAndFlush(Mockito.any(BankAccount.class));
		Mockito.verify(transactionService).performTransaction(Mockito.any(AccountTransaction.class));
		assertEquals(updatedBal, accountEntity.getBalance());
	}
	
	@Test
	public void testPerformTransferWithCredit() throws InfyBankException {
		BigDecimal ftAmount = BigDecimal.valueOf(1000);
		BigDecimal updatedBal = accountEntity.getBalance().add(ftAmount);
		accountService.performTransaction(ftAmount, null, accountEntity, 
				AccountTransactionType.CREDIT, AccountTransactionCategory.FUNDS_TRANSFER);
		Mockito.verify(accountRepository).saveAndFlush(accountEntity);
		Mockito.verify(transactionService).performTransaction(Mockito.any(AccountTransaction.class));
		assertEquals(updatedBal, accountEntity.getBalance());
	} 

	@Test
	public void testIsAccountSalariedWithFalse() throws InfyBankException{
		accountEntity.setSalaried('N');
		Mockito.when(accountRepository.findOne(Mockito.any(BankAccountId.class))).thenReturn(accountEntity);
		assertFalse(accountService.isAccountSalaried(101, "101202303404"));
	}
	
	@Test
	public void testIsAccountSalariedWithTrue() throws InfyBankException{
		accountEntity.setSalaried('Y');
		Mockito.when(accountRepository.findOne(Mockito.any(BankAccountId.class))).thenReturn(accountEntity);
		assertTrue(accountService.isAccountSalaried(101, "101202303404"));
	}
	
	@Test
	public void testPersistIntoBankAccount(){
		assertTrue(accountService.persistIntoBankAccount(accountEntity));
		Mockito.verify(accountRepository).saveAndFlush(accountEntity);
	}

	@Test
	public void testGetAcctDetail(){
		Mockito.when(accountRepository.findByBankAccountIdAcctNo(Mockito.anyString())).thenReturn(accountEntity);
		BankAccount accountEntity1 = accountService.getAcctDetail("101202303404");
		assertEquals(1001, accountEntity1.getBankAccountId().getCustId());
		assertEquals("101202303404", accountEntity1.getBankAccountId().getAcctNo());
	}
	
}
