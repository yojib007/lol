package com.infosys.infybank.core.utilities;
 
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.infosys.infybank.utilities.UserUtil;

public class UserProfileTest {
	
	List<String> userList;
	String userIdSuggestion;
	String firstName;
	String lastName;
	
	@Before
	public void init(){
		userList = new ArrayList<String>();
		userIdSuggestion = "ahamed";
	}
	
	@Test
	public void testCreateUserId() {
		assertEquals("ahamed", UserUtil.createUserId(userList, userIdSuggestion));
	}
	
	@Test
	public void testCreateUserIdWithUserIdAlreadyPresent() {
		userList.add(userIdSuggestion);
		assertEquals("ahamed1", UserUtil.createUserId(userList, userIdSuggestion));
	}

	@Test
	public void testSuggestUserIdFromName() {
		firstName = "Ahamed";
		lastName = "Shameem";
		assertEquals("ahamsham", UserUtil.createUserIdFromName(firstName, lastName));
	}
	
	@Test
	public void testSuggestUserIdFromNameWithShorterFname() {
		firstName = "A";
		lastName = "Shameem";
		assertEquals("a###sham", UserUtil.createUserIdFromName(firstName, lastName));
	}

	@Test
	public void testSuggestUserIdFromNameWithShorterLname() {
		firstName = "Ahamed";
		lastName = "S";
		assertEquals("ahams###", UserUtil.createUserIdFromName(firstName, lastName));
	}
}
