package com.infosys.infybank.core.utilities;
 
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TestUtil {

	public static Date createDate(int year, int month, int day) {
		Calendar calendar = new GregorianCalendar(year, month - 1, day);
		return calendar.getTime();
	}

	public static Date createDate(int year, int month, int day, int hour, int min, int sec) {
		Calendar calendar = new GregorianCalendar(year, month - 1, day, hour, min, sec);
		return calendar.getTime();
	}
	
	public static Date getMaxTimeStamp(Date date) { 
		LocalDateTime ldt = LocalDateTime.of(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), LocalTime.MAX);
		return Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
	}

}
