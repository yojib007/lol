package com.infosys.infybank.core.service;
 
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.core.dto.SearchAccountStatementDTO;
import com.infosys.infybank.core.entity.AccountTransaction;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.repository.AccountTransactionRepository;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.AccountTransactionService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class AccountTransactionServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
public class AccountTransactionServiceTest {

	/** The transaction repository. */
	@Mock
	private AccountTransactionRepository transactionRepository;

	/** The account service. */
	@Mock
	private AccountService accountService;
	
	/** The customer service. */
	@Mock
	CustomerService custService;

	/** The account transaction service. */
	@InjectMocks
	public static AccountTransactionService accountTransactionService;

	/** The entity. */
	public static AccountTransaction entity;

	/** The account statement dto. */
	public SearchAccountStatementDTO accountStatementDTO;

	/** The account txn. */
	public static AccountTransaction accountTxn;

	/** The search account statement dto. */
	public static List<SearchAccountStatementDTO> searchAccountStatementDTO;
	
	/** The account tx. */
	public List<AccountTransaction> accountTx;

	/** The expected exception. */
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	/**
	 * Creates the mock.
	 */
	@BeforeClass
	public static void createMock() {
		entity = new AccountTransaction();
		searchAccountStatementDTO = new ArrayList<SearchAccountStatementDTO>();
		accountTxn = new AccountTransaction();
		accountTxn.setAcctNo("123456789123");
	}

	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
		accountTx = new ArrayList<AccountTransaction>();
		accountStatementDTO = new SearchAccountStatementDTO();
	}

	/**
	 * Test perform transaction.
	 */
	@Test
	public void testPerformTransaction() {
		entity.setTxnId(1);
		Mockito.when(transactionRepository.saveAndFlush(Mockito.any(AccountTransaction.class))).thenReturn(entity);
		assertEquals(Integer.valueOf(1), accountTransactionService.performTransaction(entity));
	}
	
	@Test
	public void testGetSalaryCredit(){
		List<AccountTransaction> acctTxnList = new ArrayList<AccountTransaction>();
		AccountTransaction acctTxn = new AccountTransaction();
		acctTxn.setTxnId(1);
		acctTxnList.add(acctTxn);
		Mockito.when(transactionRepository.getSalaryCredit(Mockito.anyInt(), Mockito.anyString(), 
				Mockito.anyChar(), Mockito.anyChar())).thenReturn(acctTxnList);
		assertEquals(1, accountTransactionService.getSalaryCredits(101, "101202303404",
				'C', 'S').get(0).getTxnId());
	}

	/**
	 * Test get customer transactions with valid details.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGetCustomerTransactionsWithValidDetails() throws InfyBankException {
		accountStatementDTO.setTxnType(null);
		accountStatementDTO.setLastMonth(true);
		accountStatementDTO.setFromAmount(1000D);
		accountStatementDTO.setToAmount(20000D);
		accountTx.add(accountTxn);
		Mockito.when(transactionRepository.exists(Mockito.anyInt())).thenReturn(true);
		Mockito.when(transactionRepository.getTransactions(Mockito.any(SearchAccountStatementDTO.class)))
				.thenReturn(accountTx);
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		Mockito.when(custService.getCustomerDetails(Mockito.anyInt())).thenReturn(new Customer());
		assertEquals(accountTxn.getAcctNo(),
				accountTransactionService.getTransactionsForAccount(accountStatementDTO).get(0).getAcctNo());
	}

	/**
	 * Test get customer transactions with invalid tx type.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGetCustomerTransactionsWithInvalidTxType() throws InfyBankException {
		accountStatementDTO.setTxnType(' ');
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.ACCOUNT_TRANSACTION_TYPE_INVALID.toString());
		accountTransactionService.getTransactionsForAccount(accountStatementDTO);
	}
	
	@Test
	public void testGetCustomerTransactionsWithInvalidBankAcct() throws InfyBankException {
		accountStatementDTO.setTxnType(null);
		accountStatementDTO.setLastMonth(true);
		accountStatementDTO.setStartDate(null);
		accountStatementDTO.setEndDate(null);
		accountStatementDTO.setFromAmount(1000D);
		accountStatementDTO.setToAmount(2000D);
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(false);
		expectedException.expect(InfyBankException.class);
		
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_ACCOUNT_DETAILS_NOT_PRESENT.toString());
		accountTransactionService.getTransactionsForAccount(accountStatementDTO);
	}
	
	@Test
	public void testGetCustomerTransactionsWithLastMonthFalse() throws InfyBankException {
		accountStatementDTO.setTxnType(null);
		accountStatementDTO.setLastMonth(false);
		accountStatementDTO.setFromAmount(1000D);
		accountStatementDTO.setToAmount(20000D);
		accountStatementDTO.setStartDate(new Date(java.sql.Date.valueOf(LocalDate.of(2017, 8, 20)).getTime()));
		accountStatementDTO.setEndDate(new Date(java.sql.Date.valueOf(LocalDate.of(2017, 8, 23)).getTime()));
		accountTx.add(accountTxn);
		Mockito.when(transactionRepository.exists(Mockito.anyInt())).thenReturn(true);
		Mockito.when(transactionRepository.getTransactions(Mockito.any(SearchAccountStatementDTO.class)))
				.thenReturn(accountTx);
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		assertEquals(accountTxn.getAcctNo(),
				accountTransactionService.getTransactionsForAccount(accountStatementDTO).get(0).getAcctNo());
	}
	
	@Test
	public void testGetCustomerTransactionsWithInvalidFromAmount() throws InfyBankException {
		accountStatementDTO.setTxnType(null);
		accountStatementDTO.setLastMonth(false);
		accountStatementDTO.setFromAmount(-1D);
		accountStatementDTO.setToAmount(1000D);
		accountStatementDTO.setStartDate(new Date(java.sql.Date.valueOf(LocalDate.of(2017, 8, 20)).getTime()));
		accountStatementDTO.setEndDate(new Date(java.sql.Date.valueOf(LocalDate.of(2017, 8, 23)).getTime()));
		accountTx.add(accountTxn);
		Mockito.when(transactionRepository.exists(Mockito.anyInt())).thenReturn(true);
		Mockito.when(transactionRepository.getTransactions(Mockito.any(SearchAccountStatementDTO.class)))
				.thenReturn(accountTx);
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.ACCOUNT_TRANSACTION_FROM_AMOUNT_INVALID.toString());
		accountTransactionService.getTransactionsForAccount(accountStatementDTO).get(0).getAcctNo();
	}
	
	@Test
	public void testGetTxnDetailForLoanByCustId(){
		accountTxn.setTxnId(1);
		accountTx.add(accountTxn);
		Mockito.when(transactionRepository.findTxnDateByCustid(Mockito.anyString(), Mockito.anyInt()))
		.thenReturn(accountTx);
		assertEquals(1, accountTransactionService.getTxnDetailForLoanByCustId("102203304405", 101).get(0).getTxnId());
	}

}
