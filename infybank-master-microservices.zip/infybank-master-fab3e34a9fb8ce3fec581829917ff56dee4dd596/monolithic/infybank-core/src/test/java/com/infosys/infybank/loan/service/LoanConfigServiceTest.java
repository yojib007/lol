package com.infosys.infybank.loan.service;
 
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.service.LoginService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.loan.dto.LoanConfigDTO;
import com.infosys.infybank.loan.entity.LoanConfig;
import com.infosys.infybank.loan.entity.LoanConfigId;
import com.infosys.infybank.loan.repository.LoanConfigRepository;

/**
 * The Class LoanConfigServiceTest.
 */
/*
 * 
 */
public class LoanConfigServiceTest {

	/** The e. */
	@Rule
	public ExpectedException e= ExpectedException.none();
	
	/** The loan config repository. */
	@Mock
	LoanConfigRepository loanConfigRepository;
	
	/** The login service. */
	@Mock
	LoginService loginService;
	
	@Mock
	ApplicationProperties appProps;
	
	/** The loan config service. */
	@InjectMocks
	LoanConfigService loanConfigService;
	
	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * Test view loan rates.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewLoanRates() throws InfyBankException {
		Mockito.when(loanConfigRepository.findAll()).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOANCONFIG_RETRIEVAL_FAILED.toString());
		loanConfigService.viewLoanRates();
	}
	
	/**
	 * Test view loan rates1.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewLoanRates1() throws InfyBankException {
		List<LoanConfigDTO> dtoList = new ArrayList<LoanConfigDTO>();
		List<LoanConfig> loanConfigList =new ArrayList<LoanConfig>() ;
		LoanConfig l = new LoanConfig();
		LoanConfigId id = new LoanConfigId();
		id.setCreditScoreEnd(300);
		id.setCreditScoreStart(0);
		l.setId(id);
		loanConfigList.add(l);
		LoanConfigDTO dto = LoanConfigDTO.valueOf(l);
		dtoList.add(dto);
		Mockito.when(loanConfigRepository.findAllByOrderByIdCreditScoreStart()).thenReturn(loanConfigList);
		Assert.assertEquals(dto.getCreditScoreStart(), loanConfigService.viewLoanRates().get(0).getCreditScoreStart());
		Assert.assertEquals(dto.getCreditScoreEnd(), loanConfigService.viewLoanRates().get(0).getCreditScoreEnd());
	}

}
