package com.infosys.infybank.loan.service;
 
import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.loan.entity.Amortization;
import com.infosys.infybank.loan.entity.AmortizationId;
import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.entity.LoanAccountId;
import com.infosys.infybank.loan.repository.AmortizationRepository;
import com.infosys.infybank.loan.repository.LoanRepository;



/**
 * The Class AmmortizationServiceTest.
 */
public class AmortizationServiceTest {

	
	/** The e. */
	@Rule
	public ExpectedException e= ExpectedException.none();
	
	/** The loan account repository. */
	@Mock
	LoanRepository loanRepo ;
	
	/** The amortization repository. */
	@Mock
	AmortizationRepository amortizationRepo;
	
	/** The customer service. */
	@Mock
	CustomerService customerService;
	
	/** The amortization service. */
	@InjectMocks
	AmortizationService amortizationService;
	
	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}

	
	/**
	 * Testview amortization schedule for invalid account details.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testviewAmmortizationScheduleForInvalidAccountDetails() throws InfyBankException {
		Mockito.when(loanRepo.findOne(Mockito.any(LoanAccountId.class))).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOAN_DETAILS_NOT_AVAILABLE.toString());
		amortizationService.viewAmortizationSchedule(101, "112233445566");
		
	}
	
	
	
	/**
	 * Testview ammortization schedule for invalid loan status.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test 
	public void testviewAmmortizationScheduleForInvalidLoanStatus() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanStatus('S');
		Mockito.when(loanRepo.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOAN_STATUS_INVALID.toString());
		amortizationService.viewAmortizationSchedule(101,"123123123123");
	}
	
	@Test 
	public void testviewAmmortizationScheduleForInvalidLoanStatusAsRejected() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanStatus('R');
		Mockito.when(loanRepo.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOAN_STATUS_INVALID.toString());
		amortizationService.viewAmortizationSchedule(101,"123123123123");
	}
	
	/**
	 * Test view ammortization schedule for valid loan status.
	 */
	@Test
	public void testViewAmmortizationScheduleForValidLoanStatus(){
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanStatus('A');
		Mockito.when(loanRepo.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
	}
	
	/**
	 * Test view ammortization schedule.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewAmmortizationSchedule() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanStatus('A');
		loanAccount.setId(new LoanAccountId(1, "123456789098"));
		loanAccount.setTenure(5);
		loanAccount.setLoanAmount(BigDecimal.valueOf(200000));
		loanAccount.setInterestRate(BigDecimal.valueOf(10));
		loanAccount.setEmi(BigDecimal.valueOf(50000));
		loanAccount.setEmiDueDate(new Date());
		Mockito.when(customerService.getCustomerDetails(Mockito.anyInt()))
		.thenReturn(new Customer());
		Mockito.when(loanRepo.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
		assertEquals("123456789098", amortizationService.viewAmortizationSchedule(1, "123456789098").getAmmortizationList().get(0).getLoanAcctNo());
		assertEquals(1, amortizationService.viewAmortizationSchedule(1, "123456789098").getAmmortizationList().get(0).getInstallmentNo());
	}
	
	@Test
	public void testViewAmmortizationSchedule1() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		Mockito.when(loanRepo.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
		loanAccount.setLoanStatus('A');
		ArrayList<Amortization> ammortizationList = new ArrayList<Amortization>();
		Amortization ammortization = new Amortization();
		ammortization.setId(new AmortizationId());
		ammortization.setInstallmentDate(new Date());
		ammortization.setClosingPrincipal(BigDecimal.valueOf(0));
		ammortization.setInstallmentAmount(BigDecimal.valueOf(0));
		ammortization.setInterestComponent(BigDecimal.valueOf(0));
		ammortization.setPrincipalComponent(BigDecimal.valueOf(0));
		ammortization.setOpeningPrincipal(BigDecimal.valueOf(0));
		ammortizationList.add(ammortization);
		loanAccount.setId(new LoanAccountId(1, "123456789098"));
		loanAccount.setTenure(5);
		loanAccount.setLoanAmount(BigDecimal.valueOf(200000));
		loanAccount.setInterestRate(BigDecimal.valueOf(10));
		loanAccount.setEmi(BigDecimal.valueOf(50000));
		loanAccount.setEmiDueDate(new Date());
		Mockito.when(amortizationRepo.getAmortizationDetails(Mockito.anyInt(),Mockito.anyString())).thenReturn(ammortizationList);
		Mockito.when(loanRepo.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
		assertEquals("123456789098", amortizationService.viewAmortizationSchedule(1, "123456789098").getAmmortizationList().get(0).getLoanAcctNo());
		assertEquals(0, amortizationService.viewAmortizationSchedule(1, "123456789098").getAmmortizationList().get(0).getInstallmentNo());
	}
		
}
