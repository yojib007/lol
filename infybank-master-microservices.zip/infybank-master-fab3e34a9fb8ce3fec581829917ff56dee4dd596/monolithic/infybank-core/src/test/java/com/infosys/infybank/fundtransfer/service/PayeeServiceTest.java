package com.infosys.infybank.fundtransfer.service;
 
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.CustomerDTO;
import com.infosys.infybank.core.dto.OtpDTO;
import com.infosys.infybank.core.dto.OtpStatus;
import com.infosys.infybank.core.dto.OtpType;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.Otp;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.core.service.NotificationService;
import com.infosys.infybank.core.service.OTPService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.exception.ResourceNotFoundException;
import com.infosys.infybank.fundtransfer.dto.IFSCMasterDTO;
import com.infosys.infybank.fundtransfer.dto.PayeeDTO;
import com.infosys.infybank.fundtransfer.entity.FundTransfer;
import com.infosys.infybank.fundtransfer.entity.Payee;
import com.infosys.infybank.fundtransfer.repository.FundTransferRepository;
import com.infosys.infybank.fundtransfer.repository.PayeeRepository;

/**
 * The Class PayeeServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })

public class PayeeServiceTest {

	/** The payee. */
	static Payee payee;
	
	@Mock
	NotificationService notificationService;

	/** The environment. */
	@Mock
	Environment environment;
	
	@Mock
	FundTransferRepository fundTransferRepository;
	
	@Mock
	FundTransferService ftService;

	/** The payee repository. */
	@Mock
	PayeeRepository payeeRepository;

	/** The account service. */
	@Mock
	AccountService accountService;
	
	/** The customer service. */
	@Mock
	CustomerService customerService;
	
	/** The otp service. */
	@Mock
	OTPService otpService;
	
	@Mock
	ApplicationProperties appProps;
	
	/** The rest template. */
	@Mock
	RestTemplate restTemplate;

	/** The payee service. */
	@InjectMocks
	@Spy
	PayeeService payeeService;

	/** The payee dto. */
	static PayeeDTO payeeDTO;

	/** The otp dto. */
	static OtpDTO otpDTO;

	static Otp otp;
	
	static FundTransfer fundTransfer;
	
	List<FundTransfer> ftList;

	/** The e. */
	@Rule
	public ExpectedException e = ExpectedException.none();

	/**
	 * Initialise.
	 */
	@BeforeClass
	public static void initialise() {
		payeeDTO = new PayeeDTO();
		payee = new Payee();
		otpDTO = new OtpDTO();
		otp = new Otp();
		fundTransfer = new FundTransfer();
		fundTransfer.setPayeeId(001);
	}

	/**
	 * Inits the.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ftList = new ArrayList<FundTransfer>();
		ftList.add(fundTransfer);
	}

	/**
	 * Test add payee positive.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testAddPayeePositive() throws InfyBankException {
		payeeDTO.setIfscCode(null);
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		payeeDTO.setAcctType('c');
		payeeDTO.setAcctNo("1234567890");
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(false);
		Mockito.when(payeeRepository.findPayeeByAcctNumber(Mockito.anyString(), Mockito.anyInt())).thenReturn(null);
		Mockito.when(customerService.viewCustomerProfile(Mockito.anyInt())).thenReturn(new CustomerDTO());
		Mockito.when(environment.getProperty("external.ifsc.url")).thenReturn("");
		Mockito.when(payeeRepository.saveAndFlush(Mockito.any(Payee.class))).thenReturn(new Payee());
		Mockito.when(otpService.saveOTPForCustomer(Mockito.anyInt(), Mockito.anyString(),
				Mockito.eq(OtpType.ADD_PAYEE), Mockito.anyInt())).thenReturn(otp);
		//Mockito.when( payeeRepository.getAcctDetail(Mockito.anyString())).thenReturn(new BankAccount());
		Mockito.when(accountService.getAcctDetail(Mockito.anyString())).thenReturn(new BankAccount());
		assertTrue(payeeService.addPayee(payeeDTO));
 
	}

	/**
	 * Test add payee with invalid acct type.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testAddPayeeWithInvalidAcctType() throws InfyBankException {
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		payeeDTO.setAcctType('d');
		payeeDTO.setAcctNo("1234567890");
		Mockito.doThrow(new InfyBankException(ExceptionConstants.CUSTOMER_INVALID_ACCTTYPE.toString())).
		when(accountService).verifyAcctType(Mockito.anyChar());
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(false);
		Mockito.when(accountService.getAcctDetail(Mockito.anyString())).thenReturn(new BankAccount());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_ACCOUNT_TYPE_INVALID.toString());
		payeeService.addPayee(payeeDTO);

	}

	/**
	 * Test add payee with duplicate payee.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testAddPayeeWithDuplicatePayee() throws InfyBankException {
		payeeDTO.setIfscCode(null);
		payeeDTO.setAcctType('c');
		Payee payee = new Payee();
		Mockito.when(payeeRepository.findPayeeByAcctNumber(Mockito.anyString(), Mockito.anyInt())).thenReturn(payee);
		payee.setPayeeId(123);
		payeeDTO.setAcctNo("1234567890");
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(false);
		//Mockito.when(payeeRepository.getAcctDetail( Mockito.anyString())).thenReturn(new BankAccount());
		Mockito.when(accountService.getAcctDetail(Mockito.anyString())).thenReturn(new BankAccount());
		Mockito.when(customerService.viewCustomerProfile(Mockito.anyInt())).thenReturn(new CustomerDTO());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_ALREADY_ADDED.toString());
		payeeService.addPayee(payeeDTO);

	}

	/**
	 * Test add payee with invalid customer.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testAddPayeeWithInvalidCustomer() throws InfyBankException {
		payeeDTO.setIfscCode(null);
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		payeeDTO.setAcctType('c');
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(false);
		Mockito.when(payeeRepository.findPayeeByAcctNumber(Mockito.anyString(), Mockito.anyInt())).thenReturn(null);
		Mockito.when(customerService.viewCustomerProfile(Mockito.anyInt()))
		.thenThrow(new ResourceNotFoundException(ExceptionConstants.CUSTOMER_ID_INVALID.toString()));
		Mockito.when(environment.getProperty("external.ifsc.url")).thenReturn("");
		Mockito.when(accountService.getAcctDetail(Mockito.anyString())).thenReturn(new BankAccount());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_ID_INVALID.toString());
		payeeService.addPayee(payeeDTO);

	}


	/**
	 * Test add payee invalid ifsc.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testAddPayeeInvalidIFSC() throws InfyBankException {
		payeeDTO.setIfscCode("IC001234567");
		payeeDTO.setAcctNo("1234567890");
		Mockito.when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(IFSCMasterDTO.class))).thenReturn(null);
		Mockito.when(environment.getProperty("external.ifsc.url")).thenReturn("");
		Mockito.when(accountService.getAcctDetail(Mockito.anyString())).thenReturn(new BankAccount());
		Mockito.when(appProps.getIfscUrl()).thenReturn("");
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_IFSC_INVALID.toString());
		payeeService.addPayee(payeeDTO);

	}

	/**
	 * Test confirm payee does not exist.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testConfirmPayeeDoesNotExist() throws InfyBankException {
		Mockito.when(payeeRepository.getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_DOESNOT_EXIST.toString());
		payeeService.confirmPayee(101, 001, otpDTO);

	}

	/**
	 * Test confirm payee already confirmed.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testConfirmPayeeAlreadyConfirmed() throws InfyBankException {
		payee.setStatus('C');
		Mockito.when(payeeRepository.getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt())).thenReturn(payee);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_ALREADY_CONFIRMED.toString());
		payeeService.confirmPayee(101, 001, otpDTO);

	}

	/**
	 * Test confirm payee positive.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testConfirmPayeePositive() throws InfyBankException {
		payee.setStatus('S');
		Mockito.when(payeeRepository.getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt())).thenReturn(payee);
		Mockito.when(otpService.isValidOTPForPayee(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt()))
				.thenReturn(OtpStatus.VALID);
		Mockito.when(payeeRepository.updatePayeeStatus(Mockito.anyInt(), Mockito.anyInt(), Mockito.eq('C')))
				.thenReturn(001);
		payeeService.confirmPayee(101, 001, otpDTO);
		Mockito.verify(customerService).getCustomerDetails(Mockito.anyInt());
		Mockito.verify(payeeRepository).getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt());
		Mockito.verify(otpService).isValidOTPForPayee(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt());
		Mockito.verify(payeeService).updatePayeeStatus(Mockito.anyInt(), Mockito.anyInt());
	}

	/**
	 * Test confirm payee invalid otp.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testConfirmPayeeInvalidOtp() throws InfyBankException {
		payee.setStatus('S');
		Mockito.when(payeeRepository.getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt())).thenReturn(payee);
		Mockito.when(otpService.isValidOTPForPayee(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt()))
				.thenReturn(OtpStatus.INVALID);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_INVALID_OTP.toString());
		payeeService.confirmPayee(101, 001, otpDTO);

	}

	/**
	 * Test confirm payee expired otp.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testConfirmPayeeExpiredOtp() throws InfyBankException {
		payee.setStatus('S');
		Mockito.when(payeeRepository.getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt())).thenReturn(payee);
		Mockito.when(otpService.isValidOTPForPayee(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt()))
				.thenReturn(OtpStatus.EXPIRED);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_EXPIRED_OTP.toString());
		payeeService.confirmPayee(101, 001, otpDTO);

	}

	/**
	 * Test find active payees positive.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testFindActivePayeesPositive() throws InfyBankException {
		List<Payee> payeeList = new ArrayList<Payee>();
		List<PayeeDTO> payeeDTOList = new ArrayList<PayeeDTO>();
		payee.setPayeeId(001);
		payeeList.add(payee);
		Mockito.when(payeeRepository.getConfirmedPayees(Mockito.anyInt(), Mockito.anyChar())).thenReturn(payeeList);
		payeeDTOList.add(PayeeDTO.prepareDTO(payee));
		assertEquals(payeeDTOList.get(0).getPayeeId(), payeeService.findPayeesByStatus(101, 'C').get(0).getPayeeId());

	}

	/**
	 * Test delete payee positive.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testDeletePayeePositive() throws InfyBankException {
		payee.setStatus('C');
		Mockito.when(payeeRepository.getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt())).thenReturn(payee);
		Mockito.when(payeeRepository.updatePayeeStatus(Mockito.anyInt(), Mockito.anyInt(), Mockito.eq('D')))
				.thenReturn(1);
		Mockito.when(fundTransferRepository.findByPayeeIdAndStatus(Mockito.anyInt(), Mockito.anyChar())).thenReturn(ftList);
		//assertTrue(payeeService.deletePayee(101, 002));

	}

	/**
	 * Test delete payee invalid payee id.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testDeletePayeeInvalidPayeeId() throws InfyBankException {
		e.expect(ResourceNotFoundException.class);
		e.expectMessage(ExceptionConstants.PAYEE_DOESNOT_EXIST.toString());
		payeeService.deletePayee(101, 0);
	}

	/**
	 * Test delete payee invalid cust id.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testDeletePayeeInvalidCustId() throws InfyBankException {
		Mockito.when(customerService.getCustomerDetails(Mockito.anyInt()))
		.thenThrow(	new ResourceNotFoundException(ExceptionConstants.CUSTOMER_ID_INVALID.toString()));
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_ID_INVALID.toString());
		payeeService.deletePayee(0, 001);
	}

	/**
	 * Test delete payee does not exist.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testDeletePayeeDoesNotExist() throws InfyBankException {
		Mockito.when(payeeRepository.getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_DOESNOT_EXIST.toString());
		payeeService.deletePayee(101, 001);
	}

	/**
	 * Test delete status update fail.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testDeleteStatusUpdateFail() throws InfyBankException {
		Mockito.when(payeeRepository.getPayeeForCustomer(Mockito.anyInt(), Mockito.anyInt())).thenReturn(payee);
		Mockito.when(payeeRepository.updatePayeeStatus(Mockito.anyInt(), Mockito.anyInt(), Mockito.eq('D')))
				.thenReturn(0);
		Mockito.when(fundTransferRepository.findByPayeeIdAndStatus(Mockito.anyInt(),Mockito.anyChar())).thenReturn(ftList);
		Mockito.when(ftService.getPendingTransfersForPayee(Mockito.anyInt())).thenReturn(new ArrayList<FundTransfer>());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.SERVER_ERROR.toString());
		payeeService.deletePayee(101, 002);
	}

}
