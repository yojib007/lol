package com.infosys.infybank.core.service;
 
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.loan.repository.AmortizationRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
public class RepositoryTest {
	
	@Autowired
	AmortizationRepository ammor;
	
	@Test
	public void test(){
		System.out.println(ammor.getAmortizationDetails(101, "0449003103"));
	}
	
}
