package com.infosys.infybank.core.service;
 
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.core.dto.LoginDTO;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.repository.LoginRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class LoginServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })

public class LoginServiceTest {

	/** The login repository. */
	@Mock
	private LoginRepository loginRepository;
	
	@Mock
	RandomPasswordGeneratorService randomPasswordGeneratorService;

	/** The login service. */
	@InjectMocks
	public static LoginService loginService;

	/** The login dto. */
	public static LoginDTO loginDTO;
	
	/** The login. */
	public static Login login;
	
	/** The user name. */
	public static String userName;

	/** The expected exception. */
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	/**
	 * Creates the mock.
	 */
	@BeforeClass
	public static void createMock() {
		login = new Login();
		login.setUserId("a");
		login.setPassword("");
		loginDTO = new LoginDTO();
		loginDTO.setPassword("");
		userName = "A";
	}

	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test verify user name existence.
	 */
	@Test
	public void testVerifyUserNameExistence() {
		Mockito.when(loginRepository.findUserHavingUserNameLike(Mockito.anyString()))
				.thenReturn(new ArrayList<String>());
		Assert.assertNotNull(loginService.getUserIdsStartingWithName(userName));
	}

	/**
	 * Test save user profile.
	 */
	@Test
	public void testSaveUserProfile() {
		Mockito.when(loginRepository.saveAndFlush(login)).thenReturn(login);
		Assert.assertEquals(login, loginService.saveLoginDetails(login));
	}
	
	@Test
	public void testAuthenticate() throws InfyBankException{
		Mockito.when(randomPasswordGeneratorService.encryptPassword(Mockito.anyString())).thenReturn("*******");
		LoginDTO loginDto = new LoginDTO();
		loginDto.setPassword("Abc123$");
		Login login = new Login();
		login.setPassword("*******");
		Mockito.when(loginRepository.findByUserId(Mockito.anyString())).thenReturn(login);
		Assert.assertEquals(login.getUserId(), loginService.authenticate(loginDto).getUserId());
	}

	/**
	 * Test authenticate with invalid id.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testAuthenticateWithInvalidId() throws InfyBankException {
		Mockito.when(loginRepository.findByUserId(Mockito.anyString())).thenReturn(null);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.LOGIN_ID_INVALID.toString());
		loginService.authenticate(loginDTO);
	}

	/**
	 * Test authenticate with unequal ids.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testAuthenticateWithUnequalIds() throws InfyBankException {
		Mockito.when(loginRepository.findByUserId(Mockito.anyString())).thenReturn(login);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.LOGIN_ID_INVALID.toString());
		loginService.authenticate(loginDTO);
	}

	/**
	 * Test get login details.
	 */
	@Test
	public void testGetLoginDetails() {
		Mockito.when(loginRepository.findByUserId(Mockito.anyString())).thenReturn(login);
		Assert.assertEquals(login.getUserId(), loginService.getLoginDetails(login.getUserId()).getUserId());
	}

	/**
	 * Test get login details with invalid user id.
	 */
	@Test
	public void testGetLoginDetailsWithInvalidUserId() {
		Mockito.when(loginRepository.findByUserId(Mockito.anyString())).thenReturn(null);
		Assert.assertNull(loginService.getLoginDetails(login.getUserId()));
	}

}
