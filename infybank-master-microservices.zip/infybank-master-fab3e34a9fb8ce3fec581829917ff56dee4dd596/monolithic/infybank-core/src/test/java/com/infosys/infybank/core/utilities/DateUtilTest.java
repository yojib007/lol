package com.infosys.infybank.core.utilities;
 
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import org.junit.Test;

import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.utilities.DateField;
import com.infosys.infybank.utilities.DateUtil;

public class DateUtilTest {

	@Test
	public void testAddDurationWithDaysPositive() throws InfyBankException {
		Date date = TestUtil.createDate(2017, 1, 1);
		Date expRetDate = TestUtil.createDate(2017, 1, 2);
		assertEquals(expRetDate, DateUtil.addDuration(date, DateField.DAY, 1));
	}

	@Test
	public void testAddDurationWithDaysNegative() throws InfyBankException {
		Date date = TestUtil.createDate(2017, 1, 1);
		Date expRetDate = TestUtil.createDate(2016, 12, 31);
		assertEquals(expRetDate, DateUtil.addDuration(date, DateField.DAY, -1));
	}

	@Test
	public void testAddDurationWithSeconds() throws InfyBankException {
		Date date = TestUtil.createDate(2017, 1, 1, 1, 10, 20);
		Date expRetDate = TestUtil.createDate(2017, 1, 1, 1, 10, 40);
		assertEquals(expRetDate, DateUtil.addDuration(date, DateField.SECOND, 20));
	}

	@Test
	public void testAddDurationWithSecondsNegative() throws InfyBankException {
		Date date = TestUtil.createDate(2017, 1, 1, 1, 10, 20);
		Date expRetDate = TestUtil.createDate(2017, 1, 1, 1, 9, 50);
		assertEquals(expRetDate, DateUtil.addDuration(date, DateField.SECOND, -30));
	}

	@Test
	public void testGetLocalDateWithSqlDate() {
		java.sql.Date date = new java.sql.Date(TestUtil.createDate(2017, 1, 1).getTime());
		LocalDate localDate = LocalDate.of(2017, 1, 1);
		assertEquals(localDate, DateUtil.getLocalDate(date));
	}

	@Test
	public void testGetLocalDate() {
		Date date = TestUtil.createDate(2017, 1, 1);
		LocalDate localDate = LocalDate.of(2017, 1, 1);
		assertEquals(localDate, DateUtil.getLocalDate(date));
	}

	@Test
	public void testGetStartOfDay() {
		Date date = TestUtil.createDate(2017, 1, 1);
		Date expRetDate = TestUtil.createDate(2017, 1, 1, 0, 0, 0);
		assertEquals(expRetDate, DateUtil.getStartOfDay(date));
	}

	@Test
	public void testGetEndOfDay() {
		Date date = TestUtil.createDate(2017, 1, 1);
		Date expRetDate = TestUtil.getMaxTimeStamp(date);
		assertEquals(expRetDate, DateUtil.getEndOfDay(date));
	}

	@Test
	public void testGetLocalDateTime() {
		Date date = TestUtil.createDate(2017, 1, 1, 1, 10, 20);
		LocalDateTime localDateTime = LocalDateTime.of(2017, 1, 1, 1, 10, 20);
		assertEquals(localDateTime, DateUtil.getLocalDateTime(date));
	}

}
