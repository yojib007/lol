package com.infosys.infybank.core.service;
 
import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.core.dto.OtpStatus;
import com.infosys.infybank.core.dto.OtpType;
import com.infosys.infybank.core.entity.Otp;
import com.infosys.infybank.core.repository.OTPRepository;
import com.infosys.infybank.core.service.OTPService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class OtpServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })

public class OtpServiceTest {

	/** The env. */
	@Mock
	private Environment env;

	/** The otp repository. */
	@Mock
	private OTPRepository otpRepository;
	
	@Mock
	OTPGeneratorService otpGeneratorService;

	/** The otp service. */
	@InjectMocks
	public static OTPService otpService;

	/** The cust id. */
	public static int custId;
	
	/** The payee id. */
	public static int payeeId;
	
	/** The email id. */
	public static String emailId;
	
	/** The otp type. */
	public static String otpType;
	
	/** The otp. */
	public static String otp;
	
	/** The otp entity. */
	public static Otp otpEntity;
	
	/** The otp list. */
	public static List<Otp> otpList;
	
	/** The date. */
	public static Date date;

	/** The expected exception. */
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	/**
	 * Initialize.
	 */
	@BeforeClass
	public static void initialize() {
		custId = 1001;
		payeeId = 1;
		emailId = "abc@infosys.com";
		otpType = OtpType.ACCOUNT_OPEN.toString();
		date = new Date();
		otp = "123456789";
		otpEntity = new Otp();
		otpEntity.setOtp(otp);
		otpList = new ArrayList<Otp>();
		otpList.add(otpEntity);
	}

	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
		otpEntity.setGeneratedTs(date);
	}

	/**
	 * Test generate and save otp for customer.
	 */
	@Test
	public void testSaveOTPForCustomer() {
		Mockito.when(otpGeneratorService.createOTP()).thenReturn("123456789");
		Mockito.when(otpRepository.saveAndFlush(Mockito.any(Otp.class))).thenReturn(otpEntity);
		assertEquals("123456789", otpService.saveOTPForCustomer(custId, emailId, OtpType.ACCOUNT_OPEN, payeeId).getOtp());
	}

	@Test
	public void testSaveOTPForCustomerWithOtpGenFailed() {
		Mockito.when(otpGeneratorService.createOTP()).thenReturn("123456789");
		Mockito.when(otpRepository.saveAndFlush(Mockito.any(Otp.class))).thenReturn(null);
		assertNull(otpService.saveOTPForCustomer(custId, emailId,OtpType.ADD_PAYEE, payeeId));
	}
	/**
	 * Test is valid otp.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Ignore
	@Test
	public void testIsValidOTP() throws InfyBankException {
		Mockito.when(otpRepository.findFirstByEmailIdAndOtpTypeOrderByGeneratedTsDesc(Mockito.anyString(), Mockito.anyChar())).thenReturn(otpList);
		Mockito.when(env.getProperty("otp.expiry.limit.insec")).thenReturn(String.valueOf(300));
		assertEquals(OtpStatus.VALID, otpService.isOTPValid(otpEntity.getOtp(), emailId, OtpType.ACCOUNT_OPEN));
	}

	/**
	 * Test is valid ot pdoesnt exist.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsValidOTPdoesntExist() throws InfyBankException {
		Mockito.when(otpRepository.findFirstByEmailIdAndOtpTypeOrderByGeneratedTsDesc(Mockito.anyString(), Mockito.anyChar())).thenReturn(null);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.OTP_NOT_FOUND.toString());
		otpService.isOTPValid(otp, emailId,  OtpType.ACCOUNT_OPEN);
	}

	/**
	 * Test is valid ot pdoesnt match.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsValidOTPdoesntMatch() throws InfyBankException {
		Mockito.when(otpRepository.findFirstByEmailIdAndOtpTypeOrderByGeneratedTsDesc(Mockito.anyString(), Mockito.anyChar())).thenReturn(otpList);
		Mockito.when(env.getProperty("otp.expiry.limit.insec")).thenReturn(String.valueOf(1));
		assertEquals(OtpStatus.INVALID, otpService.isOTPValid("12345678", emailId,  OtpType.ACCOUNT_OPEN));
	}

	/**
	 * Test is valid ot pexpired.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsValidOTPexpired() throws InfyBankException {
		Mockito.when(otpRepository.findFirstByEmailIdAndOtpTypeOrderByGeneratedTsDesc(Mockito.anyString(), Mockito.anyChar())).thenReturn(otpList);
		Mockito.when(env.getProperty("otp.expiry.limit.insec")).thenReturn(String.valueOf(1));
		assertEquals(OtpStatus.EXPIRED, otpService.isOTPValid(otpEntity.getOtp(), emailId,  OtpType.ACCOUNT_OPEN));
	}

	@Ignore
	@Test
	public void testIsValidOTPForPayee() throws InfyBankException{
		Mockito.when(otpRepository.findByCustIdAndPayeeIdOrderByGeneratedTsDesc(Mockito.anyInt(), Mockito.anyInt())).thenReturn(otpList);
		Mockito.when(env.getProperty("otp.expiry.limit.insec")).thenReturn(String.valueOf(60));
		assertEquals(OtpStatus.VALID, otpService.isValidOTPForPayee(otp, custId, payeeId));
	}
	
	@Test
	public void testIsValidOTPForPayeeWithExpiredOtp() throws InfyBankException{
		otpEntity.setGeneratedTs(new Date(java.sql.Date.valueOf(LocalDate.now().minusDays(1)).getTime()));
		Mockito.when(otpRepository.findByCustIdAndPayeeIdOrderByGeneratedTsDesc(Mockito.anyInt(), Mockito.anyInt())).thenReturn(otpList);
		Mockito.when(env.getProperty("otp.expiry.limit.insec")).thenReturn(String.valueOf(1));
		assertEquals(OtpStatus.EXPIRED, otpService.isValidOTPForPayee(otp, custId, payeeId));
	}
	
	@Test
	public void testIsValidOTPForPayeeWithInvalidOtp() throws InfyBankException{
		Mockito.when(otpRepository.findByCustIdAndPayeeIdOrderByGeneratedTsDesc(Mockito.anyInt(), Mockito.anyInt())).thenReturn(otpList);
		assertEquals(OtpStatus.INVALID, otpService.isValidOTPForPayee("987654321", custId, payeeId));
	}
	
	@Test
	public void testIsValidOTPForPayeeWithOtpNotFound() throws InfyBankException{
		Mockito.when(otpRepository.findByCustIdAndPayeeIdOrderByGeneratedTsDesc(Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.OTP_NOT_FOUND.toString());
		otpService.isValidOTPForPayee("987654321", custId, payeeId);
	}
}
