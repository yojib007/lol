package com.infosys.infybank.core.controller;
 
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.infosys.infybank.WebMvcConfig;


/**
 * The Class TestProfileController.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebMvcConfig.class })

@WebAppConfiguration

public class TestProfileController {

	/** The ctx. */
	@Autowired
	private WebApplicationContext ctx;

	/** The mock mvc. */
	private MockMvc mockMvc;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();

	}

	/**
	 * Test get customer profile valid.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testGetCustomerProfileValid() throws Exception {
		int id = 2;
		mockMvc.perform(get("/v1/customers/{id}", id).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$.custId", is(2))).andExpect(jsonPath("$.aadharId", is("200123465555")))
				.andExpect(jsonPath("$.panNo", is("AHWPM3456Z"))).andExpect(jsonPath("$.firstName", is("Raj")))
				.andExpect(jsonPath("$.lastName", is("Singh")));
		// .andDo(print());
	}

	/**
	 * Test get customer profile in valid.
	 *
	 * @throws Exception the exception
	 */
	@Ignore
	@Test
	public void testGetCustomerProfileInValid() throws Exception {
		int id = 1;
		mockMvc.perform(get("/v1/customers/{id}", id).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is5xxServerError()).andExpect(jsonPath("$.errorCode", is(500)))
				.andExpect(jsonPath("$.errorMsg", is("Customer ID is not registered")));
		// .andDo(print());
	}
}
