package com.infosys.infybank.core.service;
 
import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.core.dto.AccountConfigEditDTO;
import com.infosys.infybank.core.dto.AccountConfigViewDTO;
import com.infosys.infybank.core.entity.AccountConfig;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.Login;
import com.infosys.infybank.core.repository.AccountConfigRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class AccountConfigServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
public class AccountConfigServiceTest {

	/** The account config repository. */
	@Mock
	private AccountConfigRepository accountConfigRepository;

	/** The login service. */
	@Mock
	private LoginService loginService;

	/** The account config service. */
	@InjectMocks
	private AccountConfigService accountConfigService;

	/** The account config list. */
	private static List<AccountConfig> accountConfigList;
	
	/** The account config entity. */
	private static AccountConfig accountConfigEntity;
	
	/** The account config dto list. */
	private static List<AccountConfigViewDTO> accountConfigDTOList;
	
	/** The account config edit dto. */
	private static AccountConfigEditDTO accountConfigEditDTO;
	
	/** The login. */
	private static Login login;
	
	/** The account config view dto list. */
	private static List<AccountConfigViewDTO> accountConfigViewDTOList;
	
	/** The account config view dto. */
	private static AccountConfigViewDTO accountConfigViewDTO;
	
	private static BankAccount bankAccount;

	/** The expected exception. */
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	/**
	 * Initialize.
	 */
	@BeforeClass
	public static void initialize() {
		accountConfigEntity = new AccountConfig();
		accountConfigEntity.setAcctType('S');
		accountConfigEntity.setMinBalance(BigDecimal.valueOf(5000));
		accountConfigList = new ArrayList<AccountConfig>();
		accountConfigList.add(accountConfigEntity);
		accountConfigDTOList = new ArrayList<AccountConfigViewDTO>();
		accountConfigDTOList.add(AccountConfigViewDTO.valueOf(accountConfigEntity));
		accountConfigEditDTO = new AccountConfigEditDTO();
		accountConfigViewDTOList = new ArrayList<AccountConfigViewDTO>();
		accountConfigViewDTO = new AccountConfigViewDTO();
		accountConfigViewDTOList.add(accountConfigViewDTO);
		accountConfigEditDTO.setAccountConfigViewDTOs(accountConfigViewDTOList);
		login = new Login();
		login.setRole(AccountConfigService.ADMIN_ROLE);
		bankAccount = new BankAccount();
		bankAccount.setAcctType('S');
	}

	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test view account config.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewAccountConfig() throws InfyBankException {
		Mockito.when(accountConfigRepository.findAll()).thenReturn(accountConfigList);
		assertEquals(accountConfigDTOList.get(0).getAcctType(),
				accountConfigService.viewAccountConfig().get(0).getAcctType());
	}

	/**
	 * Test view account config with retrieval failed.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewAccountConfigWithRetrievalFailed() throws InfyBankException {
		Mockito.when(accountConfigRepository.findAll()).thenReturn(null);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.SERVER_ERROR.toString());
		assertEquals(accountConfigDTOList, accountConfigService.viewAccountConfig());
	}

	/**
	 * Test edit account config.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testEditAccountConfig() throws InfyBankException {
		Mockito.when(loginService.getLoginDetails(Mockito.anyString())).thenReturn(login);
		accountConfigService.updateAccountConfig(accountConfigEditDTO);
		Mockito.verify(loginService).getLoginDetails(Mockito.anyString());
		Mockito.verify(accountConfigRepository).save(Mockito.any(AccountConfig.class));
	}

	/**
	 * Test edit account config with invalid credentials.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testEditAccountConfigWithInvalidCredentials() throws InfyBankException {
		Mockito.when(loginService.getLoginDetails(Mockito.anyString())).thenReturn(null);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.INFYBANK_UNAUTHORIZED.toString());
		accountConfigService.updateAccountConfig(accountConfigEditDTO);
	}

	/**
	 * Test get minimum balance.
	 */
	@Test
	public void testGetMinimumBalance() throws InfyBankException {
		Mockito.when(accountConfigRepository.findByAcctType(Mockito.anyChar())).thenReturn(accountConfigEntity);
		assertEquals(new BigDecimal(5000), accountConfigService.getMinimumBalance('S'));
	}

	@Test
	public void testGetAccountConfigDetails(){
		Mockito.when(accountConfigRepository.findOne(Mockito.anyChar())).thenReturn(accountConfigEntity);
		assertEquals(accountConfigEntity, accountConfigService.getAccountConfigDetails(bankAccount));
	}
}
