package com.infosys.infybank.loan.service;
 
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.infosys.infybank.core.dto.AccountTransactionCategory;
import com.infosys.infybank.core.dto.AccountTransactionType;
import com.infosys.infybank.core.dto.Email;
import com.infosys.infybank.core.entity.AccountConfig;
import com.infosys.infybank.core.entity.AccountTransaction;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.BankAccountId;
import com.infosys.infybank.core.service.AccountConfigService;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.AccountTransactionService;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.core.service.NotificationService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.loan.dto.LoanPrepayDTO;
import com.infosys.infybank.loan.entity.Amortization;
import com.infosys.infybank.loan.entity.AmortizationId;
import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.entity.LoanAccountId;
import com.infosys.infybank.loan.repository.AmortizationRepository;
import com.infosys.infybank.loan.repository.LoanRepository;
import com.infosys.infybank.loan.service.LoanService;
import com.infosys.infybank.loan.service.LoanPrepayService;



/**
 * The Class LoanPrepayServiceTest.
 */
public class LoanPrepayServiceTest {
	
	/** The e. */
	@Rule
	public ExpectedException e= ExpectedException.none();
	
	@Mock
	NotificationService notificationService ;
	
	/** The account config service. */
	@Mock
	AccountConfigService accountConfigService;
	
	/** The acct trans service. */
	@Mock
	AccountTransactionService acctTransService;
	
	/** The account service. */
	@Mock
	AccountService accountService;
	
	/** The customer service. */
	@Mock
	CustomerService  customerService;
	
	/** The loan account repository. */
	@Mock
	LoanRepository loanAccountRepository;
	
	/** The ammortization repository. */
	@Mock
	AmortizationRepository amortizationRepository;
	
	@Mock
	LoanService loanAccountService;
	
	/** The loan prepay service. */
	@InjectMocks
	LoanPrepayService loanPrepayService;
	
	/** The loan prepay service spy. */
	@Spy
	@InjectMocks
	LoanPrepayService loanPrepayServiceSpy;
	
	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test is valid payment option.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsValidPaymentOption() throws InfyBankException {
		LoanPrepayDTO loanPrepayDTO = new LoanPrepayDTO();
		loanPrepayDTO.setPaymentOption("SE");
		loanPrepayDTO.setPaymentOption("ST");
		assertTrue(loanPrepayService.isValidPaymentOption(loanPrepayDTO));
		
		
	}

	/**
	 * Test is in valid payment option.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testIsInValidPaymentOption() throws InfyBankException {
		LoanPrepayDTO loanPrepayDTO = new LoanPrepayDTO();
		loanPrepayDTO.setPaymentOption("SP");
		loanPrepayDTO.setPaymentOption("SQ");
		assertFalse(loanPrepayService.isValidPaymentOption(loanPrepayDTO));
	
	}
	
	/**
	 * Testis valid txn date.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testisValidTxnDate() throws InfyBankException, ParseException{
		Mockito.when(acctTransService.getTxnDetailForLoanByCustId(Mockito.anyString(),Mockito.anyInt()))
		.thenReturn(new ArrayList<AccountTransaction>());
		assertTrue(loanPrepayService.isValidTxnDate("123123123123",101));
			
			
	}

/**
 * Test is valid loan amount.
 *
 * @throws InfyBankException the infy bank service exception
 */
//	}
	@Test
	public void TestIsValidLoanAmount() throws InfyBankException{
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
				.thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOANACCOUNT_INVALID_CUSTOMER.toString());
		loanPrepayService.isValidLoanAmount("123456789876", 1);
	}
	
	/**
	 * Test is valid loan amount with no principal.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestIsValidLoanAmountWithNoPrincipal() throws InfyBankException{
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(new LoanAccount());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOANACCOUNT_INVALID_CUSTOMER.toString());
		loanPrepayService.isValidLoanAmount("123456789876", 1);
	}
	
	/**
	 * Test is valid loan amount with no loan amount.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestIsValidLoanAmountWithNoLoanAmount() throws InfyBankException{
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(new LoanAccount());
		List<Amortization> list = new ArrayList<Amortization>();
		Amortization a= new Amortization();
		a.setClosingPrincipal(BigDecimal.valueOf(2000));
		list.add(a);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(list);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOANACCOUNT_INVALID_CUSTOMER.toString());
		loanPrepayService.isValidLoanAmount("123456789876", 1);
	}
	
	/**
	 * Test is valid loan amount true.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestIsValidLoanAmountTrue() throws InfyBankException{
		LoanAccount l = new LoanAccount();
		l.setLoanAmount(BigDecimal.valueOf(15000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(l);
		List<Amortization> list = new ArrayList<Amortization>();
		Amortization a= new Amortization();
		a.setClosingPrincipal(BigDecimal.valueOf(2000));
		list.add(a);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(list);
		assertTrue(loanPrepayService.isValidLoanAmount("123456789876", 1));
	}
	
	@Test
	public void isValidTxnDate() throws InfyBankException, ParseException{
		Mockito.when(acctTransService.getTxnDetailForLoanByCustId(Mockito.anyString(),Mockito.anyInt())).thenReturn(null);
		assertTrue(loanPrepayService.isValidTxnDate("123123123123", 101));
	}
	
	/**
	 * Test is valid loan amount false.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestIsValidLoanAmountFalse() throws InfyBankException{
		LoanAccount l = new LoanAccount();
		l.setLoanAmount(BigDecimal.valueOf(25000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(l);
		List<Amortization> list = new ArrayList<Amortization>();
		Amortization a= new Amortization();
		a.setClosingPrincipal(BigDecimal.valueOf(2000));
		list.add(a);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(list);
		assertFalse(loanPrepayService.isValidLoanAmount("123456789876", 1));
	}
	
	/**
	 * Min balance check true.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void minBalanceCheckTrue() throws InfyBankException{
		LoanPrepayDTO l = new LoanPrepayDTO();
		l.setPrepayAmount(BigDecimal.valueOf(2000));
		AccountConfig accountConfig = new AccountConfig();
		accountConfig.setMinBalance(BigDecimal.valueOf(5000));
		BankAccount b = new BankAccount();
		b.setBalance(BigDecimal.valueOf(10000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(new LoanAccount());
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(b);
		Mockito.when(accountConfigService.getAccountConfigDetails(Mockito.any(BankAccount.class)))
		.thenReturn(accountConfig);
		assertTrue(loanPrepayService.minBalanceCheck(1, l));
	}
	
	/**
	 * Min balance check false.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void minBalanceCheckFalse() throws InfyBankException{
		LoanPrepayDTO l = new LoanPrepayDTO();
		l.setPrepayAmount(BigDecimal.valueOf(2000));
		AccountConfig accountConfig = new AccountConfig();
		accountConfig.setMinBalance(BigDecimal.valueOf(5000));
		BankAccount b = new BankAccount();
		b.setBalance(BigDecimal.valueOf(6000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(new LoanAccount());
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(b);
		Mockito.when(accountConfigService.getAccountConfigDetails(Mockito.any(BankAccount.class)))
		.thenReturn(accountConfig);
		assertFalse(loanPrepayService.minBalanceCheck(1, l));
	}
	
	/**
	 * Test loan prepay for customer with invalid payment option.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testLoanPrepayForCustomerWithInvalidPaymentOption() throws InfyBankException, ParseException{
		LoanPrepayDTO l = new LoanPrepayDTO();
		l.setPaymentOption("S");
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOANPREPAY_INVALID_OPTION.toString());
		loanPrepayService.loanPrepayForCustomer(1, l);
	}
	
	/**
	 * Test loan prepay for customer with invalid from acct no.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testLoanPrepayForCustomerWithInvalidFromAcctNo() throws InfyBankException, ParseException{
		LoanPrepayDTO l = new LoanPrepayDTO();
		l.setPaymentOption(LoanPrepayService.SAME_EMI);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOANPREPAY_INVALID_FROMACCOUNT.toString());
		loanPrepayService.loanPrepayForCustomer(1, l);
	}
	
	/**
	 * Test loan prepay for customer with invalid loan amounut.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testLoanPrepayForCustomerWithInvalidLoanAmounut() throws InfyBankException, ParseException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanAmount(BigDecimal.valueOf(25000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(loanAccount);
		List<Amortization> list = new ArrayList<Amortization>();
		Amortization a= new Amortization();
		a.setClosingPrincipal(BigDecimal.valueOf(2000));
		list.add(a);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(list);
		LoanPrepayDTO l = new LoanPrepayDTO();
		l.setPaymentOption(LoanPrepayService.SAME_EMI);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(new BankAccount());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.INVALID_LOAN_AMOUNT.toString());
		loanPrepayService.loanPrepayForCustomer(1, l);
	}
	
	/**
	 * Test loan prepay for customer with insufficient balance.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testLoanPrepayForCustomerWithInsufficientBalance() throws InfyBankException, ParseException{
		Mockito.doReturn(true).when(loanPrepayServiceSpy).isValidPaymentOption(Mockito.any(LoanPrepayDTO.class));
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(new BankAccount());
		Mockito.doReturn(true).when(loanPrepayServiceSpy)
		.isValidLoanAmount(Mockito.anyString(), Mockito.anyInt());
		Mockito.doReturn(true).when(loanPrepayServiceSpy)
		.isValidTxnDate(Mockito.anyString(), Mockito.anyInt());
		Mockito.doReturn(false).when(loanPrepayServiceSpy)
		.minBalanceCheck(Mockito.anyInt(), Mockito.any(LoanPrepayDTO.class));
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.BALANCE_LESSTHAN_MINBAL.toString());
		loanPrepayServiceSpy.loanPrepayForCustomer(1, new LoanPrepayDTO());
	}
	
	/**
	 * Test loan prepay for customer with invalid txn date.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testLoanPrepayForCustomerWithInvalidTxnDate() throws InfyBankException, ParseException{
		Mockito.doReturn(true).when(loanPrepayServiceSpy).isValidPaymentOption(Mockito.any(LoanPrepayDTO.class));
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(new BankAccount());
		Mockito.doReturn(true).when(loanPrepayServiceSpy)
		.isValidLoanAmount(Mockito.anyString(), Mockito.anyInt());
		Mockito.doReturn(false).when(loanPrepayServiceSpy)
		.isValidTxnDate(Mockito.anyString(), Mockito.anyInt());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.CANNOT_PERFORM_TRANSACTION.toString());
		loanPrepayServiceSpy.loanPrepayForCustomer(1, new LoanPrepayDTO());
	}
	
	/**
	 * Test loan prepay for customer.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testLoanPrepayForCustomer() throws InfyBankException, ParseException{
		Mockito.doReturn(true).when(loanPrepayServiceSpy).isValidPaymentOption(Mockito.any(LoanPrepayDTO.class));
		BankAccount b = new BankAccount();
		b.setBalance(BigDecimal.valueOf(5000));
		Mockito.doReturn(b).when(accountService).getAccountDetails(Mockito.anyInt(), Mockito.anyString());
		Mockito.doReturn(true).when(loanPrepayServiceSpy)
		.isValidLoanAmount(Mockito.anyString(), Mockito.anyInt());
		Mockito.doReturn(true).when(loanPrepayServiceSpy)
		.isValidTxnDate(Mockito.anyString(), Mockito.anyInt());
		Mockito.doReturn(true).when(loanPrepayServiceSpy)
		.minBalanceCheck(Mockito.anyInt(), Mockito.any(LoanPrepayDTO.class));
		LoanAccount l = new LoanAccount();
		l.setLoanAmount(BigDecimal.valueOf(10000));
		l.setInterestRate(BigDecimal.valueOf(10));
		Mockito.doReturn(l).when(loanAccountRepository).findOne(Mockito.any(LoanAccountId.class));
		LoanPrepayDTO lDto = new LoanPrepayDTO();
		lDto.setPaymentOption(LoanPrepayService.SAME_TENURE);
		lDto.setPrepayAmount(BigDecimal.valueOf(2000));
		loanPrepayServiceSpy.loanPrepayForCustomer(1, lDto);
		Mockito.verify(loanPrepayServiceSpy).isValidPaymentOption(Mockito.any(LoanPrepayDTO.class));
		Mockito.verify(customerService).getCustomerDetails(Mockito.anyInt());
		Mockito.verify(customerService).getCustomerDetails(Mockito.anyInt());
		Mockito.verify(accountService).getAccountDetails(Mockito.anyInt(), Mockito.anyString());
		Mockito.verify(loanPrepayServiceSpy).isValidLoanAmount(Mockito.anyString(), Mockito.anyInt());
		Mockito.verify(loanPrepayServiceSpy).isValidTxnDate(Mockito.anyString(), Mockito.anyInt());
		Mockito.verify(loanPrepayServiceSpy).minBalanceCheck(Mockito.anyInt(), Mockito.any(LoanPrepayDTO.class));
		Mockito.verify(loanPrepayServiceSpy).loanPrepay(Mockito.anyInt(), Mockito.any(LoanPrepayDTO.class), 
				Mockito.any(BankAccount.class));
	}
	
//	/**
//	 * Test loan prepay.
//	 *
//	 * @throws InfyBankException the infy bank service exception
//	 * @throws ParseException the parse exception
//	 */
//	@Test
//	public void testLoanPrepay() throws InfyBankException, ParseException{
//		LoanAccount loanAccount = new LoanAccount();
//		loanAccount.setLoanAmount(BigDecimal.valueOf(25000));
//		loanAccount.setInterestRate(BigDecimal.valueOf(10));
//		loanAccount.setEmi(BigDecimal.valueOf(2000));
//		BankAccount b = new BankAccount();
//		b.setBalance(BigDecimal.valueOf(10000));
//		b.setBankAccountId(new BankAccountId(1, "123456789876"));
//		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
//		.thenReturn(loanAccount);
//		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
//		.thenReturn(b);
//		Mockito.when(customerService.getEmailIdforCustomer(Mockito.anyInt()))
//		.thenReturn("abc@infosys.com");
//		LoanPrepayDTO l = new LoanPrepayDTO();
//		l.setLoanAcctNo("1357986432");
//		l.setPrepayAmount(BigDecimal.valueOf(1000));
//		l.setPaymentOption(LoanPrepayService.SAME_EMI);
//		Mockito.doReturn(true).when(loanPrepayServiceSpy).loanPrepay(Mockito.anyInt(), Mockito.any(LoanPrepayDTO.class), Mockito.any(BankAccount.class));
//		loanPrepayServiceSpy.loanPrepay(1, l, b);
//		Mockito.verify(loanAccountRepository).findOne(Mockito.any(LoanAccountId.class));
//		Mockito.verify(amortizationRepository).getAmortizationDetails(Mockito.anyInt(),  Mockito.anyString());
//		Mockito.verify(amortizationRepository).saveAndFlush(Mockito.any(Amortization.class));
//		
//	}
	
	/**
	 * Test loan prepay.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testLoanPrepay() throws InfyBankException, ParseException{
		BankAccount bankAccount = new  BankAccount();
		bankAccount.setBalance(BigDecimal.valueOf(10000));
		bankAccount.setBankAccountId(new BankAccountId(101, "123456789876"));
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanAmount(BigDecimal.valueOf(20000));
		loanAccount.setInterestRate(BigDecimal.valueOf(8));
		LoanPrepayDTO lDto = new LoanPrepayDTO();
		lDto.setPaymentOption(LoanPrepayService.SAME_TENURE);
		lDto.setPrepayAmount(BigDecimal.valueOf(2000));
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(),Mockito.anyString())).thenReturn(bankAccount);
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(null);
		Mockito.when(acctTransService.getTxnDetailForLoanByCustId(Mockito.anyString(),Mockito.anyInt())).thenReturn(null);
		loanPrepayService.loanPrepay(101, lDto, bankAccount);
		Mockito.verify(loanAccountRepository).findOne(Mockito.any(LoanAccountId.class));
		Mockito.verify(amortizationRepository).getAmortizationDetails(Mockito.anyInt(), Mockito.anyString());
		Mockito.verify(accountService).performTransaction(Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.any(BankAccount.class), 
				Mockito.any(AccountTransactionType.class), Mockito.any(AccountTransactionCategory.class));
		Mockito.verify(amortizationRepository).saveAndFlush(Mockito.any(Amortization.class));
		Mockito.verify(customerService).getEmailIdforCustomer(Mockito.anyInt());
		Mockito.verify(loanAccountRepository).saveAndFlush(Mockito.any(LoanAccount.class));
		Mockito.verify(notificationService).notifyCustomer(Mockito.any(Email.class));
	}
	
	/**
	 * Test loan prepay1.
	 *
	 * @throws InfyBankException the infy bank service exception
	 * @throws ParseException the parse exception
	 */
	@Test
	public void testLoanPrepay1() throws InfyBankException, ParseException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanAmount(BigDecimal.valueOf(10000));
		loanAccount.setInterestRate(BigDecimal.valueOf(10));
		BankAccount b = new BankAccount();
		b.setBalance(BigDecimal.valueOf(5000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(loanAccount);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(b);
		Mockito.when(customerService.getEmailIdforCustomer(Mockito.anyInt()))
		.thenReturn("abc@infosys.com");
		LoanPrepayDTO dto = new LoanPrepayDTO();
		dto.setPrepayAmount(BigDecimal.valueOf(1000));
		dto.setPaymentOption(LoanPrepayService.SAME_TENURE);
		loanPrepayServiceSpy.loanPrepay(1, dto, b);
		Mockito.verify(loanAccountRepository).findOne(Mockito.any(LoanAccountId.class));
		Mockito.verify(amortizationRepository).getAmortizationDetails(Mockito.anyInt(), Mockito.anyString());
		Mockito.verify(accountService).performTransaction(Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.any(BankAccount.class), 
				Mockito.any(AccountTransactionType.class), Mockito.any(AccountTransactionCategory.class));
		Mockito.verify(amortizationRepository).saveAndFlush(Mockito.any(Amortization.class));
		Mockito.verify(customerService).getEmailIdforCustomer(Mockito.anyInt());
		Mockito.verify(loanAccountRepository).saveAndFlush(Mockito.any(LoanAccount.class));
		Mockito.verify(notificationService).notifyCustomer(Mockito.any(Email.class));
	}
	
	/**
	 * Test loan prepay list not null.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testLoanPrepayListNotNull() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanAmount(BigDecimal.valueOf(10000));
		loanAccount.setInterestRate(BigDecimal.valueOf(10));
		BankAccount b = new BankAccount();
		b.setBalance(BigDecimal.valueOf(5000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(loanAccount);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(b);
		List<Amortization> list = new ArrayList<Amortization>();
		Amortization a = new  Amortization();
		a.setClosingPrincipal(BigDecimal.valueOf(20000));
		a.setPrincipalComponent(BigDecimal.valueOf(1500));
		AmortizationId id = new AmortizationId();
		id.setInstallmentNo(1);
		a.setId(id);
		list.add(a);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(list);
		Mockito.when(customerService.getEmailIdforCustomer(Mockito.anyInt()))
		.thenReturn("abc@infosys.com");
		LoanPrepayDTO dto = new LoanPrepayDTO();
		dto.setPrepayAmount(BigDecimal.valueOf(1000));
		dto.setPaymentOption(LoanPrepayService.SAME_TENURE);
		loanPrepayServiceSpy.loanPrepay(1, dto, b);
		Mockito.verify(loanAccountRepository).findOne(Mockito.any(LoanAccountId.class));
		Mockito.verify(amortizationRepository).getAmortizationDetails(Mockito.anyInt(), Mockito.anyString());
		Mockito.verify(accountService).performTransaction(Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.any(BankAccount.class), 
				Mockito.any(AccountTransactionType.class), Mockito.any(AccountTransactionCategory.class));
		Mockito.verify(amortizationRepository).saveAndFlush(Mockito.any(Amortization.class));
		Mockito.verify(customerService).getEmailIdforCustomer(Mockito.anyInt());
		Mockito.verify(loanAccountRepository).saveAndFlush(Mockito.any(LoanAccount.class));
		Mockito.verify(notificationService).notifyCustomer(Mockito.any(Email.class));
	}
	
	/**
	 * Test loan prepay txn list not null.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testLoanPrepayTxnListNotNull() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanAmount(BigDecimal.valueOf(10000));
		loanAccount.setInterestRate(BigDecimal.valueOf(10));
		loanAccount.setTenure(5);
		BankAccount b = new BankAccount();
		b.setBalance(BigDecimal.valueOf(5000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(loanAccount);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(b);
		List<Amortization> list = new ArrayList<Amortization>();
		Amortization a = new  Amortization();
		a.setClosingPrincipal(BigDecimal.valueOf(20000));
		a.setPrincipalComponent(BigDecimal.valueOf(1500));
		AmortizationId id = new AmortizationId();
		id.setInstallmentNo(1);
		a.setId(id);
		list.add(a);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(list);
		List<AccountTransaction> acctTxnList = new ArrayList<AccountTransaction>();
		AccountTransaction at = new AccountTransaction();
		at.setClosingBal(BigDecimal.valueOf(2000));
		acctTxnList.add(at);
		Mockito.when(acctTransService.getTxnDetailForLoanByCustId( Mockito.anyString(),Mockito.anyInt())).thenReturn(acctTxnList);
		Mockito.when(customerService.getEmailIdforCustomer(Mockito.anyInt()))
		.thenReturn("abc@infosys.com");
		LoanPrepayDTO dto = new LoanPrepayDTO();
		dto.setPrepayAmount(BigDecimal.valueOf(1000));
		dto.setPaymentOption(LoanPrepayService.SAME_TENURE);
		loanPrepayServiceSpy.loanPrepay(1, dto, b);
		Mockito.verify(loanAccountRepository).findOne(Mockito.any(LoanAccountId.class));
		Mockito.verify(amortizationRepository).getAmortizationDetails(Mockito.anyInt(), Mockito.anyString());
		Mockito.verify(accountService).performTransaction(Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.any(BankAccount.class), 
				Mockito.any(AccountTransactionType.class), Mockito.any(AccountTransactionCategory.class));
		Mockito.verify(amortizationRepository).saveAndFlush(Mockito.any(Amortization.class));
		Mockito.verify(customerService).getEmailIdforCustomer(Mockito.anyInt());
		Mockito.verify(loanAccountRepository).saveAndFlush(Mockito.any(LoanAccount.class));
		Mockito.verify(notificationService).notifyCustomer(Mockito.any(Email.class));
		
	}
	
	/**
	 * Test loan prepay with same tenure.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testLoanPrepayWithSameTenure() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanAmount(BigDecimal.valueOf(10000));
		loanAccount.setInterestRate(BigDecimal.valueOf(10));
		loanAccount.setTenure(5);
		BankAccount b = new BankAccount();
		b.setBalance(BigDecimal.valueOf(5000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(loanAccount);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(b);
		List<Amortization> list = new ArrayList<Amortization>();
		Amortization a = new  Amortization();
		a.setClosingPrincipal(BigDecimal.valueOf(20000));
		a.setPrincipalComponent(BigDecimal.valueOf(1500));
		AmortizationId id = new AmortizationId();
		id.setInstallmentNo(1);
		a.setId(id);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(list);
		List<AccountTransaction> acctTxnList = new ArrayList<AccountTransaction>();
		AccountTransaction at = new AccountTransaction();
		at.setClosingBal(BigDecimal.valueOf(2000));
		acctTxnList.add(at);
		Mockito.when(acctTransService.getTxnDetailForLoanByCustId( Mockito.anyString(),Mockito.anyInt())).thenReturn(acctTxnList);
		Mockito.when(customerService.getEmailIdforCustomer(Mockito.anyInt()))
		.thenReturn("abc@infosys.com");
		LoanPrepayDTO dto = new LoanPrepayDTO();
		dto.setPrepayAmount(BigDecimal.valueOf(1000));
		dto.setPaymentOption(LoanPrepayService.SAME_TENURE);
		loanPrepayServiceSpy.loanPrepay(1, dto, b);
		Mockito.verify(loanAccountRepository).findOne(Mockito.any(LoanAccountId.class));
		Mockito.verify(amortizationRepository).getAmortizationDetails(Mockito.anyInt(), Mockito.anyString());
		Mockito.verify(accountService).performTransaction(Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.any(BankAccount.class), 
				Mockito.any(AccountTransactionType.class), Mockito.any(AccountTransactionCategory.class));
		Mockito.verify(amortizationRepository).saveAndFlush(Mockito.any(Amortization.class));
		Mockito.verify(customerService).getEmailIdforCustomer(Mockito.anyInt());
		Mockito.verify(loanAccountRepository).saveAndFlush(Mockito.any(LoanAccount.class));
		Mockito.verify(notificationService).notifyCustomer(Mockito.any(Email.class));
	}
	
	/**
	 * Test loan prepay with same emi.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testLoanPrepayWithSameEmi() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanAmount(BigDecimal.valueOf(10000));
		loanAccount.setInterestRate(BigDecimal.valueOf(10));
		loanAccount.setTenure(5);
		loanAccount.setEmi(BigDecimal.valueOf(1500));
		BankAccount b = new BankAccount();
		b.setBalance(BigDecimal.valueOf(5000));
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class)))
		.thenReturn(loanAccount);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString()))
		.thenReturn(b);
		List<Amortization> list = new ArrayList<Amortization>();
		Amortization a = new  Amortization();
		a.setClosingPrincipal(BigDecimal.valueOf(20000));
		a.setPrincipalComponent(BigDecimal.valueOf(1500));
		AmortizationId id = new AmortizationId();
		id.setInstallmentNo(1);
		a.setId(id);
		Mockito.when(amortizationRepository.getAmortizationDetails(
				Mockito.anyInt(), Mockito.anyString())).thenReturn(list);
		List<AccountTransaction> acctTxnList = new ArrayList<AccountTransaction>();
		AccountTransaction at = new AccountTransaction();
		at.setClosingBal(BigDecimal.valueOf(2000));
		acctTxnList.add(at);
		Mockito.when(acctTransService.getTxnDetailForLoanByCustId( Mockito.anyString(),Mockito.anyInt())).thenReturn(acctTxnList);
		Mockito.when(customerService.getEmailIdforCustomer(Mockito.anyInt()))
		.thenReturn("abc@infosys.com");
		LoanPrepayDTO dto = new LoanPrepayDTO();
		dto.setPrepayAmount(BigDecimal.valueOf(1000));
		dto.setPaymentOption(LoanPrepayService.SAME_EMI);
		loanPrepayServiceSpy.loanPrepay(1, dto, b);
		Mockito.verify(loanAccountRepository).findOne(Mockito.any(LoanAccountId.class));
		Mockito.verify(amortizationRepository).getAmortizationDetails(Mockito.anyInt(), Mockito.anyString());
		Mockito.verify(accountService).performTransaction(Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.any(BankAccount.class), 
				Mockito.any(AccountTransactionType.class), Mockito.any(AccountTransactionCategory.class));
		Mockito.verify(amortizationRepository).saveAndFlush(Mockito.any(Amortization.class));
		Mockito.verify(customerService).getEmailIdforCustomer(Mockito.anyInt());
		Mockito.verify(loanAccountRepository).saveAndFlush(Mockito.any(LoanAccount.class));
		Mockito.verify(notificationService).notifyCustomer(Mockito.any(Email.class));
	}
	
}
