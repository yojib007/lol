package com.infosys.infybank.core.service;
 
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.core.dto.AccountDTO;
import com.infosys.infybank.core.dto.AccountSummaryDTO;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.BankAccountId;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.repository.AccountRepository;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.loan.dto.LoanAccountDTO;
import com.infosys.infybank.loan.entity.Amortization;
import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.entity.LoanAccountId;
import com.infosys.infybank.loan.service.AmortizationService;
import com.infosys.infybank.loan.service.LoanService;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
public class AccountSummaryServiceTest {
	
	@Mock
	AmortizationService ammortizationService;
	
	@Mock
	AccountRepository accountRepository;
	
	@Mock
	LoanService loanAccountService;

	/** The customer service. */
	@Mock
	CustomerService custService;
	
	@InjectMocks
	AccountSummaryService accountSummaryService;
	
	@Rule
	public ExpectedException expectedException = ExpectedException.none();
	
	@BeforeClass
	public static void initialize() {
	
	}
	
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetAccountSummary() throws InfyBankException {
		List<BankAccount> bankAccounts = new ArrayList<BankAccount>();
		List<LoanAccount> loanAccounts = new ArrayList<LoanAccount>();
		List<AccountDTO> bankAccountDtoList = new ArrayList<AccountDTO>();
		List<LoanAccountDTO> loanAccountDtoList = new ArrayList<LoanAccountDTO>();
		BankAccount bankAccount = new BankAccount();
		LoanAccount loanAccount = new LoanAccount();
		bankAccount.setBankAccountId(new BankAccountId(101, "101202303404"));
		bankAccount.setBalance(BigDecimal.valueOf(5000));
		loanAccount.setId(new LoanAccountId(101, "102203304405"));
		loanAccount.setLoanAmount(BigDecimal.valueOf(20000));
		bankAccounts.add(bankAccount);
		loanAccounts.add(loanAccount);
		Mockito.when(accountRepository.findByBankAccountIdCustId(Mockito.anyInt()))
		.thenReturn(bankAccounts);
		Mockito.when(loanAccountService.getAllLoanAccounts(Mockito.anyInt()))
		.thenReturn(loanAccounts);
		Mockito.when(ammortizationService.getAmortizationDetails(Mockito.anyInt(), Mockito.anyString())).thenReturn(new ArrayList<Amortization>());
		AccountSummaryDTO accountSummaryDtoList = accountSummaryService.getAccountSummary(101);
		bankAccountDtoList = accountSummaryDtoList.getAccounts();
		loanAccountDtoList = accountSummaryDtoList.getLoanAccounts();
		
		assertEquals(bankAccountDtoList.get(0).getCustId(), 101);
		assertEquals(bankAccountDtoList.get(0).getAcctNo(), "101202303404");
		assertEquals(loanAccountDtoList.get(0).getCustId(), 101);
		assertEquals(loanAccountDtoList.get(0).getLoanAcctNo(), "102203304405");
		assertEquals(accountSummaryDtoList.getTotalAssets(), BigDecimal.valueOf(5000));
		assertEquals(accountSummaryDtoList.getTotalLiability(), BigDecimal.valueOf(20000));
	}
	
	@Test
	public void testGetAccountSummaryWithNoLoanAcct() throws InfyBankException {
		List<BankAccount> bankAccounts = new ArrayList<BankAccount>();
		List<AccountDTO> bankAccountDtoList = new ArrayList<AccountDTO>();
		List<LoanAccountDTO> loanAccountDtoList = new ArrayList<LoanAccountDTO>();
		BankAccount bankAccount = new BankAccount();
		bankAccount.setBankAccountId(new BankAccountId(101, "101202303404"));
		bankAccount.setBalance(BigDecimal.valueOf(5000));
		bankAccounts.add(bankAccount);
		Mockito.when(accountRepository.findByBankAccountIdCustId(Mockito.anyInt()))
		.thenReturn(bankAccounts);
		Mockito.when(custService.getCustomerDetails(Mockito.anyInt())).thenReturn(new Customer());
		Mockito.when(loanAccountService.getAllLoanAccounts(Mockito.anyInt()))
		.thenReturn(null);
		AccountSummaryDTO accountSummaryDtoList = accountSummaryService.getAccountSummary(101);
		bankAccountDtoList = accountSummaryDtoList.getAccounts();
		loanAccountDtoList = accountSummaryDtoList.getLoanAccounts();
		
		assertEquals(bankAccountDtoList.get(0).getCustId(), 101);
		assertEquals(bankAccountDtoList.get(0).getAcctNo(), "101202303404");
		assertTrue(loanAccountDtoList.isEmpty());
		assertEquals(accountSummaryDtoList.getTotalAssets(), BigDecimal.valueOf(5000));
		assertEquals(accountSummaryDtoList.getTotalLiability().intValue(), 0);
	}
	

}
