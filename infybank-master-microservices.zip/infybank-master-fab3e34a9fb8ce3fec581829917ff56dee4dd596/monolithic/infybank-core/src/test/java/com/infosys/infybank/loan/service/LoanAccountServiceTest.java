package com.infosys.infybank.loan.service;
 
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.CustomerDTO;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.repository.CustomerRepository;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.AccountTransactionService;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.loan.dto.ApplyLoanDTO;
import com.infosys.infybank.loan.dto.ApproveLoanDTO;
import com.infosys.infybank.loan.dto.CreditScoreDTO;
import com.infosys.infybank.loan.dto.LoanAccountDTO;
import com.infosys.infybank.loan.dto.LoanApplicationDTO;
import com.infosys.infybank.loan.dto.ViewLoanDetailsDTO;
import com.infosys.infybank.loan.entity.LoanAccount;
import com.infosys.infybank.loan.entity.LoanAccountId;
import com.infosys.infybank.loan.entity.LoanConfig;
import com.infosys.infybank.loan.entity.LoanConfigId;
import com.infosys.infybank.loan.repository.LoanRepository;



/**
 * The Class LoanAccountServiceTest.
 */
public class LoanAccountServiceTest {
	
	/** The e. */
	@Rule
	public ExpectedException e= ExpectedException.none();
	
	@Mock
	CustomerRepository customerRepository;
	
	/** The loan account repository. */
	@Mock
	LoanRepository loanAccountRepository;
	
	/** The ammortization service. */
	@Mock
	AmortizationService ammortizationService;
	
	/** The customer service. */
	@Mock
	CustomerService customerService;
	
	/** The account service. */
	@Mock
	AccountService accountService;
	
	/** The loan config service. */
	@Mock
	LoanConfigService loanConfigService;
	
	/** The rest template. */
	@Mock
	RestTemplate restTemplate;
	
	/** The account transaction service. */
	@Mock
	AccountTransactionService accountTransactionService;
	
	@Mock
	ApplicationProperties appProps;
	
	/** The loan account service. */
	@InjectMocks
	LoanService loanAccountService;
	
	/** The loan account servicespy. */
	@Spy
	@InjectMocks
	LoanService loanAccountServicespy;

	
	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * Testview loan details.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testviewLoanDetailsWithNoLoanAccount() throws InfyBankException {
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class))).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOAN_DETAILS_NOT_AVAILABLE.toString());
		loanAccountService.viewLoanDetails(101, "123412341234");
		
	}
	
	/**
	 * Testview loan details with invalid loan status.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testviewLoanDetailsWithInvalidLoanStatus() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanStatus('S');
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOAN_STATUS_INVALID.toString());
		loanAccountService.viewLoanDetails(101,"123123123123");
		
	}
	
	/**
	 * Testview loan details.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testviewLoanDetails() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		Mockito.when(loanAccountRepository.findOne(Mockito.any(LoanAccountId.class))).thenReturn(loanAccount);
		loanAccount.setLoanStatus('C');
		loanAccount.setLoanStatus('A');
		ViewLoanDetailsDTO viewLoanDetailsDTO = new ViewLoanDetailsDTO();
		loanAccount.setId(new LoanAccountId(101,"123123123123"));
		viewLoanDetailsDTO.setLoanAcctNo("123123123123");
		loanAccount.setOpeningDate(new Date());
		loanAccount.setLoanAmount(BigDecimal.valueOf(123000));
		ViewLoanDetailsDTO v =  loanAccountService.viewLoanDetails(101,"123123123123");
		Assert.assertEquals("123123123123", v.getLoanAcctNo());
		Assert.assertEquals(BigDecimal.valueOf(123000), v.getOutstandingBalance());
		Assert.assertEquals(BigDecimal.valueOf(0), v.getTotalPrincipalAmount());
		Assert.assertEquals(BigDecimal.valueOf(0), v.getTotalInterestPaid());
	}
	
	/**
	 * Test apply personal loan with invalid debit acct.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestApplyPersonalLoanWithInvalidDebitAcct() throws InfyBankException{
		Mockito.when(customerService.viewCustomerProfile(101)).thenReturn(new CustomerDTO());
		Mockito.when(accountService.isAccountSalaried(Mockito.anyInt(), Mockito.anyString())).
		thenThrow(new InfyBankException(ExceptionConstants.INVALID_BANK_ACCOUNT.toString()));
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.INVALID_BANK_ACCOUNT.toString());
		loanAccountService.applyPersonalLoan(new ApplyLoanDTO());
	}
	
	/**
	 * Test apply personal loan with acct not salaried.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestApplyPersonalLoanWithAcctNotSalaried() throws InfyBankException{
		Mockito.when(customerService.viewCustomerProfile(101)).thenReturn(new CustomerDTO());
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		Mockito.when(accountService.isAccountSalaried(Mockito.anyInt(), Mockito.anyString())).thenReturn(false);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.ACCOUNT_NOT_SALARIED.toString());
		loanAccountService.applyPersonalLoan(new ApplyLoanDTO());
	}
	
	/**
	 * Test apply personal loan with submitted loan exists.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestApplyPersonalLoanWithSubmittedLoanExists() throws InfyBankException{
		Mockito.when(customerService.viewCustomerProfile(101)).thenReturn(new CustomerDTO());
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		Mockito.when(accountService.isAccountSalaried(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		Mockito.when(loanAccountRepository.getSubmittedAndApprovedLoans(Mockito.anyInt())).thenReturn('S');
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOAN_EXISTS.toString());
		loanAccountService.applyPersonalLoan(new ApplyLoanDTO());
	}
	
	/**
	 * Test apply personal loan with invalid tenure.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestApplyPersonalLoanWithInvalidTenure() throws InfyBankException{
		ApplyLoanDTO a = new ApplyLoanDTO();
		a.setTenure(8);
		Mockito.when(customerService.viewCustomerProfile(101)).thenReturn(new CustomerDTO());
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		Mockito.when(accountService.isAccountSalaried(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		Mockito.when(loanAccountRepository.getSubmittedAndApprovedLoans(Mockito.anyInt())).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.INVALID_TENURE.toString());
		loanAccountService.applyPersonalLoan(a);
	}
	
	/**
	 * Test apply personal loan.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void TestApplyPersonalLoan() throws InfyBankException{
		ApplyLoanDTO a = new ApplyLoanDTO();
		a.setTenure(5);
		a.setCustId(101);
		a.setDebitAcctNo("111222333444");
		LoanConfig l = new LoanConfig();
		LoanConfigId id = new LoanConfigId();
		id.setCreditScoreStart(0);
		id.setCreditScoreEnd(300);
		l.setId(id);
		l.setInterestRate(BigDecimal.valueOf(0));
		Mockito.when(customerService.viewCustomerProfile(Mockito.anyInt())).thenReturn(new CustomerDTO());
		Mockito.when(accountService.isBankAccountValid(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		Mockito.when(accountService.isAccountSalaried(Mockito.anyInt(), Mockito.anyString())).thenReturn(true);
		Mockito.when(accountService.generateAccountNumber(Mockito.anyChar())).thenReturn("123456789098");
		Mockito.when(loanAccountRepository.getSubmittedAndApprovedLoans(Mockito.anyInt())).thenReturn(null);
		Mockito.doReturn(100).when(loanAccountServicespy).getCreditScore(Mockito.anyInt(), Mockito.anyString());
		Mockito.doReturn(l).when(loanConfigService).getLoanConfigForCreditScore(Mockito.anyInt());
		Mockito.when(appProps.getMinLoanTenure()).thenReturn(3);
		Mockito.when(appProps.getMaxLoanTenure()).thenReturn(7);
		LoanAccountDTO loanAccountDto = new LoanAccountDTO();
		loanAccountDto.setLoanAcctNo("123456789098");
		loanAccountDto.setCustId(101);
		loanAccountServicespy.applyPersonalLoan(a); 
		Mockito.verify(customerService).getCustomerDetails(Mockito.anyInt());
		Mockito.verify(accountService).isAccountSalaried(Mockito.anyInt(), Mockito.anyString());
		Mockito.verify(loanAccountRepository).getSubmittedAndApprovedLoans(Mockito.anyInt());
	}
	
	/**
	 * Test view submitted loans with no submitted loans.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewSubmittedLoansWithNOSubmittedLoans() throws InfyBankException{
		Mockito.when(loanAccountRepository.findByLoanStatus('S')).thenReturn(null);
		Assert.assertEquals(0, loanAccountService.viewSubmittedLoans('S').size());
	}
	
	/**
	 * Test view submitted loans.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewSubmittedLoans() throws InfyBankException{
		List<LoanAccount> loanApplications = new ArrayList<LoanAccount>();
		LoanAccount l = new LoanAccount();
		l.setId(new LoanAccountId(101, "123456789098"));
		l.setLoanAmount(BigDecimal.valueOf(20000));
		l.setTenure(5);
		loanApplications.add(l);
		Customer c = new Customer();
		c.setFirstName("a");
		c.setLastName("b");
		c.setCustId(101);
		LoanConfig lc = new LoanConfig();
		lc.setInterestRate(BigDecimal.valueOf(0));
		lc.setLoanApprovalInd('N');
		LoanConfigId id = new LoanConfigId();
		id.setCreditScoreStart(0);
		id.setCreditScoreEnd(300);
		lc.setId(id);
		lc.setInterestRate(BigDecimal.valueOf(0));
		Mockito.when(loanAccountRepository.findByLoanStatus('S')).thenReturn(loanApplications);
		Mockito.when(customerRepository.findOne(Mockito.anyInt())).thenReturn(c);
		Mockito.when(loanConfigService.getLoanConfigForCreditScore(Mockito.anyInt())).thenReturn(lc);
		Mockito.doReturn(100).when(loanAccountServicespy).getCreditScore(Mockito.anyInt(), Mockito.anyString());
		Assert.assertEquals("123456789098", loanAccountServicespy.viewSubmittedLoans('S').get(0).getLoanAcctNo());
		Assert.assertEquals(5, loanAccountServicespy.viewSubmittedLoans('S').get(0).getTenure());
		Assert.assertEquals(BigDecimal.valueOf(20000), loanAccountServicespy.viewSubmittedLoans('S').get(0).getLoanAmount());
	}
	
	/**
	 * Test view loan application with invalid loan acct no.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewLoanApplicationWithInvalidLoanAcctNo() throws InfyBankException{
		Mockito.when(loanAccountRepository.findByIdLoanAcctNo(Mockito.anyString())).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOAN_DETAILS_NOT_AVAILABLE.toString());
		loanAccountService.viewLoanApplication("123456789098");
	}
	
	/**
	 * Test view loan application with invalid status.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewLoanApplicationWithInvalidStatus() throws InfyBankException{
		LoanAccount l = new LoanAccount();
		l.setLoanStatus('C');
		Mockito.when(loanAccountRepository.findByIdLoanAcctNo(Mockito.anyString())).thenReturn(l);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.STATUS_NOT_VALID.toString());
		loanAccountService.viewLoanApplication("123456789098");
	}
	
	/**
	 * Test view loan application.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewLoanApplication() throws InfyBankException{
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanStatus('S');
		loanAccount.setId(new LoanAccountId(101, "123456789098"));
		LoanConfig l = new LoanConfig();
		l.setInterestRate(BigDecimal.valueOf(0));
		l.setLoanApprovalInd('N');
		LoanConfigId id = new LoanConfigId();
		id.setCreditScoreStart(0);
		id.setCreditScoreEnd(300);
		l.setId(id);
		l.setInterestRate(BigDecimal.valueOf(0));
		Customer c = new Customer();
		c.setFirstName("a");
		c.setLastName("b");
		c.setPanNo("ABCDE1234F");
		Mockito.when(appProps.getNoOfSalaryCredits()).thenReturn(3);
		Mockito.when(loanAccountRepository.findByIdLoanAcctNo(Mockito.anyString())).thenReturn(loanAccount);
		Mockito.doReturn(100).when(loanAccountServicespy).getCreditScore(Mockito.anyInt(), Mockito.anyString());
		Mockito.doReturn(l).when(loanConfigService).getLoanConfigForCreditScore(Mockito.anyInt());
		Mockito.when(customerService.getCustomerDetails(Mockito.anyInt())).thenReturn(c);
		Assert.assertFalse(loanAccountServicespy.viewLoanApplication("123456789098").getIsSalaryCreditedForLastNDays());
		Assert.assertFalse(loanAccountServicespy.viewLoanApplication("123456789098").getIsCreditScoreEligible());
		Assert.assertFalse(loanAccountServicespy.viewLoanApplication("123456789098").getIsValidEmi());
		Assert.assertFalse(loanAccountServicespy.viewLoanApplication("123456789098").getEligible());
		Assert.assertEquals("a b", String.valueOf(loanAccountServicespy.viewLoanApplication("123456789098").getCustName()));
	}
	
	/**
	 * Test approve loan with invalid loan acct no.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testApproveLoanWithInvalidLoanAcctNo() throws InfyBankException{
		Mockito.when(loanAccountRepository.findByIdLoanAcctNo(Mockito.anyString())).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.LOAN_DETAILS_NOT_AVAILABLE.toString());
		loanAccountService.approveLoan("123456789098", new ApproveLoanDTO());
	}
	
	/**
	 * Test approve loan with invalid status.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testApproveLoanWithInvalidStatus() throws InfyBankException{
		LoanAccount l = new LoanAccount();
		l.setLoanStatus('C');
		Mockito.when(loanAccountRepository.findByIdLoanAcctNo(Mockito.anyString())).thenReturn(l);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.STATUS_NOT_VALID.toString());
		loanAccountService.approveLoan("123456789098", new ApproveLoanDTO());
	}
	
	/**
	 * Test approve loan with invalid interest rate.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testApproveLoanWithInvalidInterestRate() throws InfyBankException{
		LoanAccount l = new LoanAccount();
		l.setLoanStatus('S');
		Mockito.when(loanAccountRepository.findByIdLoanAcctNo(Mockito.anyString())).thenReturn(l);
		ApproveLoanDTO a = new ApproveLoanDTO();
		a.setInterestRate(BigDecimal.valueOf(13));
		LoanApplicationDTO v = new LoanApplicationDTO();
		v.setInterestRate(BigDecimal.valueOf(10));
		v.setIsCreditScoreEligible(true);
		Mockito.doReturn(v).when(loanAccountServicespy).viewLoanApplication(Mockito.anyString());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.INVALID_INTEREST_RATE.toString());
		loanAccountServicespy.approveLoan("123456789098", a);
	}
	
	/**
	 * Test approve loan rejected.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testApproveLoanRejected() throws InfyBankException{
		LoanAccount l = new LoanAccount();
		l.setLoanStatus('S');
		l.setId(new LoanAccountId(101, "123456789098"));
		Mockito.when(loanAccountRepository.findByIdLoanAcctNo(Mockito.anyString())).thenReturn(l);
		ApproveLoanDTO a = new ApproveLoanDTO();
		a.setApprove(false);
		a.setInterestRate(BigDecimal.valueOf(10));
		LoanApplicationDTO v = new LoanApplicationDTO();
		v.setInterestRate(BigDecimal.valueOf(10));
		v.setIsCreditScoreEligible(true);
		Mockito.doReturn(v).when(loanAccountServicespy).viewLoanApplication(Mockito.anyString());
		Assert.assertEquals('R', loanAccountServicespy.approveLoan("123456789098", a).getLoanStatus());
	}
	
	/**
	 * Test approve loan approved.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testApproveLoanApproved() throws InfyBankException{
		LoanAccount l = new LoanAccount();
		l.setLoanStatus('S');
		l.setId(new LoanAccountId(101, "123456789098"));
		Mockito.when(loanAccountRepository.findByIdLoanAcctNo(Mockito.anyString())).thenReturn(l);
		ApproveLoanDTO a = new ApproveLoanDTO();
		a.setApprove(true);
		a.setInterestRate(BigDecimal.valueOf(10));
		LoanApplicationDTO v = new LoanApplicationDTO();
		v.setInterestRate(BigDecimal.valueOf(10));
		v.setIsCreditScoreEligible(true);
		Mockito.doReturn(100).when(loanAccountServicespy).getCreditScore(Mockito.anyInt(), Mockito.anyString());
		Mockito.doReturn(new ArrayList<LoanConfig>()).when(loanAccountRepository).findAll();
		CustomerDTO c = new CustomerDTO();
		c.setFirstName("a");
		c.setLastName("b");
		Mockito.when(customerService.viewCustomerProfile(Mockito.anyInt())).thenReturn(c);
		Mockito.doReturn(v).when(loanAccountServicespy).viewLoanApplication(Mockito.anyString());
		Assert.assertEquals('A', loanAccountServicespy.approveLoan("123456789098", a).getLoanStatus());
	}
	
	/**
	 * Test get credit score.
	 */
	@Test
	public void testGetCreditScore() throws InfyBankException {
		Customer c = new Customer();
		c.setPanNo("ABCDE1234F");
		CreditScoreDTO dto = new CreditScoreDTO();
		dto.setCreditScore(175);
		ResponseEntity<CreditScoreDTO> creditScoreDto = new ResponseEntity<CreditScoreDTO>(dto, HttpStatus.OK);
		Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.eq(CreditScoreDTO.class))).thenReturn(creditScoreDto);
		Mockito.when(appProps.getCreditScoreUrl()).thenReturn("");
		Mockito.when(customerService.getCustomerDetails(Mockito.anyInt())).thenReturn(c);
		Assert.assertEquals(Integer.valueOf(175), loanAccountService.getCreditScore(101, null));
	}
	
}
