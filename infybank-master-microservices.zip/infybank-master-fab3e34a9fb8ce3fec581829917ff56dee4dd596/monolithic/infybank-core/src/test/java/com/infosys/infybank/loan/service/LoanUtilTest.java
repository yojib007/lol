package com.infosys.infybank.loan.service;
 
import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class LoanUtilTest {
	
	/** The instance of ExpectedException Rule */
	@Rule
	public ExpectedException e= ExpectedException.none();
	
	/**
	 * Test calculate emi.
	 */
	@Test
	public void testCalculateEmi(){
		assertEquals(BigDecimal.valueOf(5275.949616), LoanUtil.calculateEmi(BigDecimal.valueOf(20000), BigDecimal.valueOf(10), 5));
	}
	
	/**
	 * Test calculate emi with null.
	 */
	@Test
	public void testCalculateEmiWithNull(){
		e.expect(NullPointerException.class);
		LoanUtil.calculateEmi(null, BigDecimal.valueOf(10), 5);
	}
	
	/**
	 * Test calculate tenure.
	 */
	@Test
	public void testCalculateTenure(){
		assertEquals(BigDecimal.valueOf(5), LoanUtil.calculateTenure(BigDecimal.valueOf(20000), BigDecimal.valueOf(10), BigDecimal.valueOf(5275.949616)));
	}
	
	/**
	 * Test calculate tenure with null.
	 */
	@Test
	public void testCalculateTenureWithNull(){
		e.expect(NullPointerException.class);
		LoanUtil.calculateTenure(null, BigDecimal.valueOf(10), BigDecimal.valueOf(5275.949616));
	}

}
