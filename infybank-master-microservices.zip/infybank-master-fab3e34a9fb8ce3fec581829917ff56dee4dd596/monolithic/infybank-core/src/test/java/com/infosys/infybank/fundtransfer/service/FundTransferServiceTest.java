package com.infosys.infybank.fundtransfer.service;
 
import java.math.BigDecimal;
import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.entity.BankAccount;
import com.infosys.infybank.core.entity.BankAccountId;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.service.AccountConfigService;
import com.infosys.infybank.core.service.AccountService;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.core.utilities.TestUtil;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;
import com.infosys.infybank.fundtransfer.dto.FundTransferDTO;
import com.infosys.infybank.fundtransfer.dto.FundTransferType;
import com.infosys.infybank.fundtransfer.entity.FundTransfer;
import com.infosys.infybank.fundtransfer.entity.Payee;
import com.infosys.infybank.fundtransfer.repository.FundTransferRepository;
import com.infosys.infybank.fundtransfer.repository.PayeeRepository;
import com.infosys.infybank.utilities.DateField;
import com.infosys.infybank.utilities.DateUtil;


/**
 * The Class FundTransferServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })

public class FundTransferServiceTest {

	/** The fund transfer. */
	static FundTransfer fundTransfer;

	/** The payee repository. */
	@Mock
	PayeeRepository payeeRepository;

	/** The fund transfer repository. */
	@Mock
	FundTransferRepository fundTransferRepository;

	/** The account config service. */
	@Mock
	AccountConfigService accountConfigService;

	/** The account service. */
	@Mock
	AccountService accountService;
	
	/** The customer service. */
	@Mock
	CustomerService custService;
	
	@Mock
	ApplicationProperties appProps;
	

	/** The fund transfer service. */
	@InjectMocks
	FundTransferService fundTransferService;

	/** The fund transfer dto. */
	static FundTransferDTO fundTransferDTO;
	
	/** The payee. */
	static Payee payee;

	/** The bank account. */
	static BankAccount bankAccount;
	
	/** The date. */
	Date date;
	
	/** The e. */
	@Rule
	public ExpectedException e = ExpectedException.none();

	/**
	 * Initialise.
	 */
	@BeforeClass
	public static void initialise() {
		payee = new Payee();
		fundTransferDTO = new FundTransferDTO();
		bankAccount = new BankAccount();
		fundTransfer = new FundTransfer();
		payee = new Payee();
	}

	/**
	 * Inits the.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		date = new Date();
	}

	/**
	 * Test transfer fund positive.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundPositive() throws InfyBankException {
		fundTransferDTO.setFundTransferType(FundTransferType.OWN_ACCT_TRANSFER.toString());
		fundTransferDTO.setToAccountNo("1234567890");
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString())).thenReturn(bankAccount);
		Mockito.when(fundTransferRepository.saveAndFlush(Mockito.any(FundTransfer.class))).thenReturn(fundTransfer);
		java.sql.Date fundTransferDate = java.sql.Date.valueOf((new java.sql.Date(date.getTime()).toLocalDate().plusDays(1))); 
		fundTransferDTO.setFundTransferDate(new Date(fundTransferDate.getTime()));
		fundTransferDTO.setAmount(new BigDecimal(1000));
		fundTransfer.setFtDate(new Date(fundTransferDate.getTime()));
		bankAccount.setBalance(new BigDecimal(5000));
		BankAccount fromAcct = new BankAccount();
		fromAcct.setBankAccountId(new BankAccountId(1, fundTransferDTO.getFromAccountNo()));
		fromAcct.setBalance(BigDecimal.valueOf(10000));
		BankAccount toAcct = new BankAccount();
		toAcct.setBankAccountId(new BankAccountId(1, fundTransferDTO.getToAccountNo()));
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.eq(fundTransferDTO.getFromAccountNo())))
		.thenReturn(fromAcct);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.eq(fundTransferDTO.getToAccountNo())))
		.thenReturn(toAcct);
		Mockito.when(accountConfigService.getMinimumBalance(Mockito.anyChar())).thenReturn(new BigDecimal(1000));
		Assert.assertEquals(fromAcct, fundTransferService.transferFunds(101, fundTransferDTO).get(0));
		Assert.assertEquals(toAcct, fundTransferService.transferFunds(101, fundTransferDTO).get(1));
	}

	/**
	 * Test transfer fund insufficient fund.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundInsufficientFund() throws InfyBankException {
		fundTransferDTO.setFundTransferType(FundTransferType.OWN_ACCT_TRANSFER.toString());
		fundTransferDTO.setToAccountNo("1234567890");
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString())).thenReturn(bankAccount);
		Mockito.when(fundTransferRepository.saveAndFlush(Mockito.any(FundTransfer.class))).thenReturn(fundTransfer);
		java.sql.Date fundTransferDate = java.sql.Date.valueOf((new java.sql.Date(date.getTime()).toLocalDate().plusDays(1))); 
		fundTransferDTO.setFundTransferDate(new Date(fundTransferDate.getTime()));
		fundTransferDTO.setAmount(new BigDecimal(1000));
		fundTransfer.setFtDate(new Date(fundTransferDate.getTime()));
		fundTransferDTO.setAmount(new BigDecimal(1000));
		bankAccount.setBalance(new BigDecimal(1500));
		Mockito.when(accountConfigService.getMinimumBalance(Mockito.anyChar())).thenReturn(new BigDecimal(1000));
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.INSUFFICIENT_FUND.toString());
		fundTransferService.transferFunds(101, fundTransferDTO);

	}

	/**
	 * Test transfer fund invalid fund transfer type.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundInvalidFundTransferType() throws InfyBankException {
		fundTransferDTO.setFundTransferType("OO");
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.FT_TYPE_INVALID.toString());
		fundTransferService.transferFunds(101, fundTransferDTO);
	}

	/**
	 * Test transfer fund with invalid to account no.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundWithInvalidToAccountNo() throws InfyBankException {
		fundTransferDTO.setFundTransferType(FundTransferType.OWN_ACCT_TRANSFER.toString());
		fundTransferDTO.setToAccountNo(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.FT_TOACCOUNT_MANDATORY.toString());
		fundTransferService.transferFunds(101, fundTransferDTO);
	}

	/**
	 * Test transfer fund with no payee id.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundWithNoPayeeId() throws InfyBankException {
		fundTransferDTO.setFundTransferType(FundTransferType.SAME_BANK_TRANSFER.toString());
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.FT_PAYEEID_MANDATORY.toString());
		fundTransferService.transferFunds(101, fundTransferDTO);
	}

	/**
	 * Test transfer fund with invalid transfer date.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundWithInvalidTransferDate() throws InfyBankException {
		fundTransferDTO.setFundTransferType(FundTransferType.OWN_ACCT_TRANSFER.toString());
		fundTransferDTO.setToAccountNo("1234567890");
		fundTransferDTO.setAmount(new BigDecimal(1000000000));
		date = TestUtil.createDate(117, 10, 16);
		fundTransferDTO.setFundTransferDate(date);
		fundTransferDTO.setFundTransferType(FundTransferType.SAME_BANK_TRANSFER.toString());
		fundTransferDTO.setPayeeId(1);
		BankAccount b = new BankAccount();
		b.setBalance(new BigDecimal(10021456));
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString())).thenReturn(b);
		Mockito.when(accountConfigService.getMinimumBalance(Mockito.anyChar())).thenReturn(new BigDecimal(1000));
		payee.setLstUpdtTs(new Date());
		payee.setStatus(FundTransferService.PAYEE_CONFIRMED);
		Mockito.when(payeeRepository.findOne(Mockito.anyInt())).thenReturn(payee);
		FundTransfer fundTransferEntity =  FundTransferDTO.prepareEntity(fundTransferDTO);
		Mockito.when(fundTransferRepository.saveAndFlush(Mockito.any(FundTransfer.class))).thenReturn(fundTransferEntity);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.FT_DATE_INVALID.toString());
		fundTransferService.transferFunds(101, fundTransferDTO);
	}

	/**
	 * Test transfer fund with invalid acc no or cust id.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundWithInvalidAccNoOrCustId() throws InfyBankException {
		fundTransferDTO.setFundTransferType(FundTransferType.OWN_ACCT_TRANSFER.toString());
		fundTransferDTO.setToAccountNo("1234567890");
		java.sql.Date fundTransferDate = java.sql.Date.valueOf((new java.sql.Date(date.getTime()).toLocalDate().plusDays(1))); 
		fundTransferDTO.setFundTransferDate(new Date(fundTransferDate.getTime()));
		fundTransferDTO.setAmount(new BigDecimal(1000));
		fundTransfer.setFtDate(new Date(fundTransferDate.getTime()));
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString())).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.CUSTOMER_ACCOUNT_DETAILS_NOT_PRESENT.toString());
		fundTransferService.transferFunds(101, fundTransferDTO);
	}

	/**
	 * Test transfer fund with payee doesnt exist in account.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundWithPayeeDoesntExistInAccount() throws InfyBankException {
		fundTransferDTO.setFundTransferType(FundTransferType.SAME_BANK_TRANSFER.toString());
		fundTransferDTO.setToAccountNo("1234567890");
		date = TestUtil.createDate(117, 11, 29);
		fundTransferDTO.setFundTransferDate(date);
		fundTransferDTO.setPayeeId(101);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString())).thenReturn(bankAccount);
		Mockito.when(payeeRepository.findOne(Mockito.anyInt())).thenReturn(null);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_DOESNOT_EXIST.toString());
		fundTransferService.transferFunds(101, fundTransferDTO);
	}

	/**
	 * Test transfer fund with invalid payee id.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testTransferFundWithPayeeNotConfirmed() throws InfyBankException {
		fundTransferDTO.setFundTransferType(FundTransferType.SAME_BANK_TRANSFER.toString());
		fundTransferDTO.setToAccountNo("1234567890");
		fundTransferDTO.setFundTransferDate(DateUtil.addDuration(date, DateField.DAY, 1));
		fundTransferDTO.setAmount(new BigDecimal(1000));
		fundTransfer.setFtDate(fundTransferDTO.getFundTransferDate());
		fundTransferDTO.setPayeeId(101);
		Mockito.when(accountService.getAccountDetails(Mockito.anyInt(), Mockito.anyString())).thenReturn(bankAccount);
		Date date1  = TestUtil.createDate(117, 11, 5);
		payee.setLstUpdtTs(date1);
		Mockito.when(custService.getCustomerDetails(Mockito.anyInt())).thenReturn(new Customer());
		Mockito.when(payeeRepository.findOne(Mockito.anyInt())).thenReturn(payee);
		Mockito.when(appProps.getFtLimit()).thenReturn(3000);
		e.expect(InfyBankException.class);
		e.expectMessage(ExceptionConstants.PAYEE_NOT_CONFIRMED.toString());
		fundTransferService.transferFunds(101, fundTransferDTO);
	}

}
