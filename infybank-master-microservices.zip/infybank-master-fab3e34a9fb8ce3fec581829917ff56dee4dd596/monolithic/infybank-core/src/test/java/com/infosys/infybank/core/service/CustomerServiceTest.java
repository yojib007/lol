package com.infosys.infybank.core.service;
 
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyString;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.infosys.infybank.AppConfig;
import com.infosys.infybank.ApplicationProperties;
import com.infosys.infybank.core.dto.AadharDTO;
import com.infosys.infybank.core.dto.CustomerDTO;
import com.infosys.infybank.core.dto.NewCustomerDTO;
import com.infosys.infybank.core.dto.OtpStatus;
import com.infosys.infybank.core.dto.OtpType;
import com.infosys.infybank.core.dto.RegistrationDTO;
import com.infosys.infybank.core.entity.Customer;
import com.infosys.infybank.core.entity.Otp;
import com.infosys.infybank.core.repository.CustomerRepository;
import com.infosys.infybank.core.repository.LoginRepository;
import com.infosys.infybank.exception.ExceptionConstants;
import com.infosys.infybank.exception.InfyBankException;

/**
 * The Class CustomerServiceTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })

public class CustomerServiceTest {

	/** The customer repository. */
	@Mock
	private CustomerRepository customerRepository;

	/** The login repository. */
	@Mock
	private LoginRepository loginRepository;

	/** The account service. */
	@Mock
	private AccountService accountService;

	/** The rest template. */
	@Mock
	private RestTemplate restTemplate;

	/** The otp service. */
	@Mock
	private OTPService otpService;

	/** The login service. */
	@Mock
	private LoginService loginService;

	@Mock
	private NotificationService notificationService;
	
	@Mock
	RandomPasswordGeneratorService randomPasswordGeneratorService; 
	
	@Mock
	ResponseEntity<AadharDTO> response;
	

	@Mock
	AadharDTO aadharDto;
	
	@Mock
	ApplicationProperties appProps;
	
	/** The customer service. */
	@InjectMocks
	public static CustomerService customerService;
	

	/** The customer dto. */
	public static NewCustomerDTO customerDTO;

	/** The obj. */
	public static RegistrationDTO obj;

	/** The cust entity. */
	public static Customer custEntity;

	/** The cust entity1. */
	public static Customer custEntity1;

	/** The otp. */
	public static String otp;
	
	/** The email. */
	public static String email;
	
	/** The otp type. */
	public static String otpType;

	/** The expected exception. */
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	/**
	 * Initialize.
	 */
	@BeforeClass
	public static void initialize() {

		otp = "123456789";
		email = "abc@infosys.com";
		otpType = OtpType.ACCOUNT_OPEN.toString();
		customerDTO = new NewCustomerDTO();
		customerDTO.setAadharId("123123123123");
		customerDTO.setEmailId(email);
		custEntity = new Customer();
		custEntity.setCustId(1);
		custEntity1 = new Customer();
		custEntity1.setCustId(0);
		obj = new RegistrationDTO();
		obj.setFirstName("A");
		obj.setLastName("B");
		obj.setAcctType('S');
	}

	/**
	 * Inits the mock.
	 */
	@Before
	public void initMock() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test generate otp with registered aadhar id.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGenerateOTPWithRegisteredAadharId() throws InfyBankException {
		Mockito.when(customerRepository.findByAadharId(anyString())).thenReturn(new Customer());
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_ALREADY_REGISTERED_WITH_AADHAR.toString());
		customerService.generateOTP(customerDTO);
	}

	/**
	 * Test generate otp with registered email.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGenerateOTPWithRegisteredEmail() throws InfyBankException {
		Mockito.when(customerRepository.findByAadharId(anyString())).thenReturn(null);
		Mockito.when(customerRepository.findByEmailId(anyString())).thenReturn(new Customer());
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_ALREADY_REGISTERED_WITH_EMAIL.toString());
		customerService.generateOTP(customerDTO);
	}

	/**
	 * Test generate otp customer not mapped with aadhar.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGenerateOTPCustomerNotMappedWithAadhar() throws InfyBankException {
		Mockito.when(customerRepository.findByAadharId(Mockito.anyString())).thenReturn(null);
		Mockito.when(customerRepository.findByEmailId(Mockito.anyString())).thenReturn(null);
		Mockito.when(response.getBody()).thenReturn(aadharDto);
		Mockito.when(aadharDto.isAadharValid()).thenReturn(false);
		Mockito.when(appProps.getAadharUrl()).thenReturn("");
		Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.eq(AadharDTO.class))).thenReturn(response);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_NOT_MAPPED_TO_AADHAR.toString());
		customerService.generateOTP(customerDTO);
	}

	/**
	 * Test generate ot pvalid.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGenerateOTPvalid() throws InfyBankException {
		Mockito.when(appProps.getAadharUrl()).thenReturn("");
		Mockito.when(customerRepository.findByAadharId(anyString())).thenReturn(null);
		Mockito.when(customerRepository.findByEmailId(anyString())).thenReturn(null);
		Mockito.when(response.getBody()).thenReturn(aadharDto);
		Mockito.when(aadharDto.isAadharValid()).thenReturn(true);
		Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.eq(AadharDTO.class))).thenReturn(response);		Mockito.when(
				otpService.saveOTPForCustomer(Mockito.anyInt(), anyString(),  Mockito.eq(OtpType.ACCOUNT_OPEN), Mockito.anyInt()))
				.thenReturn(new Otp());
		customerService.generateOTP(customerDTO);
		Mockito.verify(otpService).saveOTPForCustomer(Mockito.anyInt(), Mockito.anyString(), 
				Mockito.any(OtpType.class), Mockito.anyInt());
	}

	/**
	 * Test generate ot pgeneration failed.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testGenerateOTPgenerationFailed() throws InfyBankException {
		Mockito.when(customerRepository.findByAadharId(Mockito.anyString())).thenReturn(null);
		Mockito.when(customerRepository.findByEmailId(Mockito.anyString())).thenReturn(null);
		Mockito.when(response.getBody()).thenReturn(aadharDto);
		Mockito.when(aadharDto.isAadharValid()).thenReturn(true);
		Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.eq(AadharDTO.class))).thenReturn(response);
		Mockito.when(
				otpService.saveOTPForCustomer(Mockito.anyInt(), anyString(), Mockito.eq(OtpType.ACCOUNT_OPEN), Mockito.anyInt()))
				.thenReturn(null);
		Mockito.when(appProps.getAadharUrl()).thenReturn("");
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_OTP_GENERATION_FAILED.toString());
		customerService.generateOTP(customerDTO);
	}

	/**
	 * Test verify otp with valid otp.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testVerifyOTPWithValidOTP() throws InfyBankException {
		Mockito.when(otpService.isOTPValid(Mockito.anyString(), anyString(),  Mockito.eq(OtpType.ACCOUNT_OPEN))).thenReturn(OtpStatus.VALID);
		assertTrue(customerService.verifyOTP(otp, email,  OtpType.ACCOUNT_OPEN));
	}

	/**
	 * Test verify otp with invalid otp.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testVerifyOTPWithInvalidOTP() throws InfyBankException {
		Mockito.when(otpService.isOTPValid(anyString(), Mockito.anyString(),  Mockito.eq(OtpType.ACCOUNT_OPEN)))
				.thenReturn(OtpStatus.INVALID);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_INVALID_OTP.toString());
		customerService.verifyOTP(otp, email,  OtpType.ACCOUNT_OPEN);
	}

	/**
	 * Test verify otp with otp expired.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testVerifyOTPWithOTPExpired() throws InfyBankException {
		Mockito.when(otpService.isOTPValid(anyString(), Mockito.anyString(),  Mockito.eq(OtpType.ACCOUNT_OPEN)))
				.thenReturn(OtpStatus.EXPIRED);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_OTP_EXPIRED.toString());
		customerService.verifyOTP(otp, email,  OtpType.ACCOUNT_OPEN);
	}

	/**
	 * Test view customer profile with valid customer.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewCustomerProfileWithValidCustomer() throws InfyBankException {
		Mockito.when(customerRepository.findOne(Mockito.anyInt())).thenReturn(custEntity);
		Assert.assertEquals(CustomerDTO.class, (customerService.viewCustomerProfile(1)).getClass());
	}

	/**
	 * Test view customer profile with invalid customer.
	 *
	 * @throws InfyBankException the infy bank service exception
	 */
	@Test
	public void testViewCustomerProfileWithInvalidCustomer() throws InfyBankException {
		Mockito.when(customerRepository.findOne(Mockito.anyInt())).thenReturn(null);
		expectedException.expect(InfyBankException.class);
		expectedException.expectMessage(ExceptionConstants.CUSTOMER_ID_INVALID.toString());
		customerService.viewCustomerProfile(2);
	}
}
