/**
 * 
 */
package onlinebank;
 
import org.junit.Test;

import org.junit.Assert;

/**
 * @author Vidya_Lakshman01
 *
 */
public class AadharServiceTest {
	@Test
	public void simple() {
		Assert.assertTrue(true);
	}
}
