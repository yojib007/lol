/**
 * 
 */
package onlinebank;
 
import org.junit.Assert;
import org.junit.Test;

/**
 * @author Vidya_Lakshman01
 *
 */
public class RegistrationControllerTest {
	@Test
	public void simple() {
		Assert.assertTrue(true);
	}
}
